<?php
/**
 * The public / internal language firewall.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Support;

use EstatOS\Data\PostTypes;

defined( 'ABSPATH' ) || exit;

/**
 * One door between the office's notes and the customer's screen.
 *
 * A project record is written by three hands: the office typing into a form,
 * a spreadsheet importer filling 24 columns at once, and whoever researched
 * the project before either of those. Only the first of the three is writing
 * for a customer. The other two write things like "unit not confirmed in the
 * source sheet" — true, useful, and nobody's business.
 *
 * Every string the public templates print goes through here. The rule is
 * deliberately blunt and safe in both directions:
 *
 *   - a fragment that is *about* the record rather than about the property
 *     is office-only, and its whole line is dropped;
 *   - a fragment that is about the property but carries an office-only aside
 *     keeps the property part and loses the aside.
 *
 * Nothing here invents a replacement. When a line is office-only it simply
 * does not appear, which is what "no data" means on the public site.
 */
final class PublicText {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		/*
		 * The content filter is the one place a project description can be
		 * drawn without going through the plugin's own template — an Elementor
		 * single-project layout using a dynamic tag, for example. Guarding it
		 * to the project post type keeps it off posts, pages and listings, and
		 * the cleaner is idempotent, so running it twice changes nothing.
		 */
		add_filter( 'the_content', array( __CLASS__, 'filter_project_content' ), 20 );
	}

	/**
	 * Clean a project description before WordPress prints it.
	 *
	 * @param string $content Post content.
	 * @return string
	 */
	public static function filter_project_content( string $content ): string {
		if ( is_admin() || ! is_singular( PostTypes::PROJECT ) ) {
			return $content;
		}
		if ( ! in_the_loop() ) {
			return $content;
		}
		return self::prose( $content );
	}

	/**
	 * A single short public string — a highlight, a label, a line.
	 *
	 * Office-only lines come back empty. Everything else keeps its meaning
	 * and loses only the aside that was never meant for a customer.
	 *
	 * @param string $text    Raw text.
	 * @param string $context Optional context, passed to the filter.
	 * @return string
	 */
	public static function clean( string $text, string $context = '' ): string {
		$text = trim( wp_strip_all_tags( $text ) );
		if ( '' === $text ) {
			return '';
		}

		if ( self::is_internal( $text ) ) {
			return '';
		}

		return self::strip_asides( $text, $context );
	}

	/**
	 * A block of prose — the project description.
	 *
	 * Paragraphs are treated separately: an office-only paragraph disappears,
	 * a real paragraph keeps its sentences and only loses an aside.
	 *
	 * @param string $html Raw content, may contain markup.
	 * @return string
	 */
	public static function prose( string $html ): string {
		if ( '' === trim( $html ) ) {
			return '';
		}

		/*
		 * Work on the block level so tags survive. Anything that is not a
		 * block tag is treated as one paragraph, which is the common case —
		 * an imported description is a single run of text.
		 *
		 * The split keeps each closing tag with the block that ends there.
		 * A lookbehind would say so in one pattern, but a lookbehind with
		 * alternatives of different lengths is not fixed length, and older
		 * PCRE (WordPress hosts still run it) refuses to compile it at all —
		 * the live log filled with preg_split warnings and the split silently
		 * degraded to one whole-content block. Capture the separators and
		 * glue them back instead; that works on every PCRE2 and does the
		 * same job.
		 */
		$blocks = array();
		$parts  = preg_split( '/(<\/(?:p|div|h[1-6]|li|blockquote)>)/i', $html, -1, PREG_SPLIT_DELIM_CAPTURE );
		if ( is_array( $parts ) ) {
			for ( $i = 0, $n = count( $parts ); $i < $n; $i += 2 ) {
				$chunk = $parts[ $i ] . ( isset( $parts[ $i + 1 ] ) ? $parts[ $i + 1 ] : '' );
				if ( '' !== trim( $chunk ) ) {
					$blocks[] = $chunk;
				}
			}
		}
		if ( ! $blocks ) {
			$blocks = array( $html );
		}

		/*
		 * A description typed straight into the editor box carries no block
		 * tags at all — it is paragraphs separated by a blank line. Split on
		 * nothing but tags would make the whole description a single block,
		 * and then one office sentence anywhere inside it would take every
		 * public sentence with it. So a plain-text description is split on
		 * its blank lines first, and the firewall then works paragraph by
		 * paragraph, which is the unit it was always meant to work on.
		 */
		$join = '';
		if ( 1 === count( $blocks ) && preg_match( '/\R[ \t]*\R/u', $blocks[0] ) ) {
			$split = preg_split( '/\R[ \t]*\R/u', $blocks[0], -1, PREG_SPLIT_NO_EMPTY );
			if ( is_array( $split ) && $split ) {
				$blocks = $split;
				$join   = "\n\n";
			}
		}

		$out = '';
		foreach ( $blocks as $block ) {
			$plain = wp_strip_all_tags( $block );
			if ( '' === trim( $plain ) ) {
				$out .= $block;
				continue;
			}
			/*
			 * Asides first, judgement second. A paragraph that says something
			 * about the project and then adds "(to be verified)" is a public
			 * paragraph with an office aside in it; only a paragraph that is
			 * *still* office-only once the aside is gone is dropped.
			 */
			$block = self::strip_asides( $block, 'prose' );
			if ( '' === trim( wp_strip_all_tags( $block ) ) ) {
				continue;
			}
			if ( self::is_internal( wp_strip_all_tags( $block ) ) ) {
				continue;
			}
			$out .= $block . $join;
		}

		return $out;
	}

	/**
	 * A stored highlights blob (one point per line) as clean public lines.
	 *
	 * @param string $text Raw textarea value.
	 * @return array<int,string>
	 */
	public static function lines( string $text ): array {
		if ( '' === trim( $text ) ) {
			return array();
		}

		$out = array();
		foreach ( preg_split( '/\R/u', $text ) ?: array() as $line ) {
			$line = self::clean( (string) $line, 'highlights' );
			if ( '' === $line ) {
				continue;
			}
			// A bullet the office typed by hand is decoration, not content.
			$line = ltrim( $line, "-*•\t " );
			if ( '' === $line ) {
				continue;
			}
			$out[] = $line;
		}

		return array_values( array_unique( $out ) );
	}

	/**
	 * A comma-separated value list ("2 BHK, 3 BHK") as clean public items.
	 *
	 * @param string $text Raw value.
	 * @return array<int,string>
	 */
	public static function list_items( string $text ): array {
		if ( '' === trim( $text ) ) {
			return array();
		}

		$out = array();
		foreach ( preg_split( '/[,;\n]/u', $text ) ?: array() as $item ) {
			$item = self::clean( (string) $item, 'list' );
			if ( '' === $item ) {
				continue;
			}
			$out[] = $item;
		}

		return array_values( array_unique( $out ) );
	}

	/**
	 * Would printing this on the website be a mistake?
	 *
	 * @param string $text Plain text.
	 * @return bool
	 */
	public static function is_internal( string $text ): bool {
		$text = wp_strip_all_tags( $text );
		if ( '' === trim( $text ) ) {
			return false;
		}

		foreach ( self::internal_markers() as $marker ) {
			if ( preg_match( $marker, $text ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Remove an office-only aside from an otherwise public sentence.
	 *
	 * @param string $text    Text, possibly with markup.
	 * @param string $context Optional context, passed to the filter.
	 * @return string
	 */
	private static function strip_asides( string $text, string $context = '' ): string {
		foreach ( self::aside_patterns( $context ) as $pattern => $replacement ) {
			$text = (string) preg_replace( (string) $pattern, (string) $replacement, $text );
		}

		/*
		 * An aside was the only thing between two spaces. Tidy the gap so the
		 * sentence reads as one sentence, without touching the markup.
		 */
		$text = (string) preg_replace( '/[ \t]{2,}/', ' ', $text );
		$text = (string) preg_replace( '/ ([,.;:])/', '$1', $text );

		return trim( $text );
	}

	/**
	 * Patterns that mean "this whole line belongs to the office".
	 *
	 * @return array<int,string>
	 */
	private static function internal_markers(): array {
		$markers = array(
			// The sheet itself.
			'/\b(?:source|office|master|import|research|reference)\s+sheet\b/iu',
			'/\bsource\s+data\b/iu',
			'/\b(?:internal|office|verification|research|import)\s+(?:note|comment|remark|only|use)\b/iu',
			'/\bfor\s+internal\s+use\b/iu',
			'/\bdo\s+not\s+(?:publish|show|display)\b/iu',
			/*
			 * Uncertainty the office records but a buyer must never read.
			 * Deliberately narrow: "parking not available" is a fact about a
			 * property and stays on the page, "not confirmed" is a fact about
			 * the record and does not.
			 */
			'/\bnot\s+(?:confirmed|verified|found|known)\b/iu',
			'/\bunconfirmed\b/iu',
			'/\bunverified\b/iu',
			'/\bto\s+be\s+(?:confirmed|verified|checked)\b/iu',
			'/\bneeds?\s+(?:verification|checking|confirmation)\b/iu',
			'/\bpending\s+verification\b/iu',
			'/\bconflict(?:ing|s)?\s+(?:source|data|information)\b/iu',
			'/^[^a-z0-9]*tbc\b/iu',
			'/^[^a-z0-9]*tbd\b/iu',
		);

		/**
		 * Filter the patterns that mark a line as office-only.
		 *
		 * Add a pattern here when the office starts writing a new kind of
		 * internal note. Remove one and that note reaches the website.
		 *
		 * @param array<int,string> $markers Regex patterns.
		 */
		return (array) apply_filters( 'estat_public_internal_markers', $markers );
	}

	/**
	 * Patterns for an office-only aside inside a public sentence.
	 *
	 * @param string $context Optional context, passed to the filter.
	 * @return array<string,string>
	 */
	private static function aside_patterns( string $context = '' ): array {
		$patterns = array(
			// "(unit not confirmed in the source sheet)" — the whole bracket.
			'/\(\s*[^()]*\b(?:source\s+sheet|office\s+sheet|not\s+confirmed|unconfirmed|unverified|to\s+be\s+(?:verified|confirmed)|needs?\s+verification|pending\s+verification|verification|internal|import|research)\b[^()]*\)\s*/iu' => '',
			// "[office note: …]" and "[verify]".
			'/\[\s*(?:office|internal|verify|verification|source)[^\]]*\]\s*/iu'          => '',
			// A trailing "— internal note" / ", needs verification".
			'/[,;\s—-]+\s*(?:internal|office)\s+(?:note|only)\b.*$/iu'                    => '',
			'/[,;\s—-]+\s*(?:needs?\s+verification|to\s+be\s+verified|unconfirmed)\b.*$/iu' => '',
		);

		/**
		 * Filter the aside patterns.
		 *
		 * @param array<string,string> $patterns Regex => replacement.
		 * @param string               $context  Where the text is being printed.
		 */
		return (array) apply_filters( 'estat_public_aside_patterns', $patterns, $context );
	}
}
