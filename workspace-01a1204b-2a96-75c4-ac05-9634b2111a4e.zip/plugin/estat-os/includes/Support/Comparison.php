<?php
/**
 * The ten questions, in one place.
 *
 * A property is compared the same way whether the person asking is sitting
 * in the office, standing at the gate with a phone, or reading the website
 * at midnight. That only stays true if the questions are written down once
 * — three copies of a list is three lists, and they drift.
 *
 * The rule this file exists to keep: **a question with no answer is shown
 * as "not said", never left out.** A missing row reads as a missing fact
 * only when the gap is visible; silently dropping it makes two unlike
 * properties look alike.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Support;

use EstatOS\Data\PostTypes;

defined( 'ABSPATH' ) || exit;

final class Comparison {

	/**
	 * The questions, in the order they are always asked.
	 *
	 * Keys are the answers Comparison::facts() returns; values are what the
	 * reader sees. Order matters: the eye learns it after the first pair.
	 *
	 * @return array<string,string>
	 */
	public static function questions(): array {
		return array(
			'price'        => __( 'Price', 'estat-os' ),
			'area'         => __( 'Size', 'estat-os' ),
			'bedrooms'     => __( 'Bedrooms', 'estat-os' ),
			'bathrooms'    => __( 'Bathrooms', 'estat-os' ),
			'floor'        => __( 'Floor', 'estat-os' ),
			'furnishing'   => __( 'Furnishing', 'estat-os' ),
			'parking'      => __( 'Parking', 'estat-os' ),
			'locality'     => __( 'Where', 'estat-os' ),
			'availability' => __( 'Availability', 'estat-os' ),
			'society'      => __( 'Society', 'estat-os' ),
		);
	}

	/**
	 * The ten answers for one record.
	 *
	 * A society answers the same ten questions as a flat — where it is, what
	 * it costs, when it is ready — and simply has nothing to say to the ones
	 * that belong to a single home. That is not an error; it arrives as an
	 * empty string and the screen prints "not said".
	 *
	 * @param int $id Listing or project ID.
	 * @return array<string,string> Keyed by question.
	 */
	public static function facts( int $id ): array {
		$post = get_post( $id );
		if ( ! $post ) {
			return array();
		}

		if ( PostTypes::PROJECT === $post->post_type ) {
			return self::project_facts( $id );
		}

		return self::listing_facts( $id );
	}

	/**
	 * A single home.
	 *
	 * @param int $id Listing ID.
	 * @return array<string,string>
	 */
	private static function listing_facts( int $id ): array {
		$data = \EstatOS\Data\Listings::to_array( $id );

		$price = (string) ( $data['price_display'] ?? '' );
		if ( '' === $price && ! empty( $data['rent'] ) ) {
			$price = Format::money( (float) $data['rent'] );
		}
		if ( '' === $price && ! empty( $data['price'] ) ) {
			$price = Format::money( (float) $data['price'] );
		}

		$availability = (string) ( $data['availability'] ?? '' );

		return array(
			'price'        => $price,
			'area'         => ! empty( $data['area'] ) ? Format::area( (float) $data['area'], (string) ( $data['area_unit'] ?? 'sqft' ) ) : '',
			'bedrooms'     => ! empty( $data['bedrooms'] ) ? (string) (int) $data['bedrooms'] : '',
			'bathrooms'    => ! empty( $data['bathrooms'] ) ? (string) (int) $data['bathrooms'] : '',
			'floor'        => ! empty( $data['floor'] ) ? (string) (int) $data['floor'] : '',
			'furnishing'   => (string) ( $data['furnishing'] ?? '' ),
			'parking'      => ! empty( $data['parking'] ) ? (string) (int) $data['parking'] : '',
			'locality'     => implode( ', ', array_filter( (array) ( $data['locality'] ?? array() ) ) ),
			'availability' => '' !== $availability ? Status::label( Status::AVAILABILITY, $availability ) : '',
			'society'      => (string) ( $data['project_name'] ?? '' ),
		);
	}

	/**
	 * A society or project.
	 *
	 * @param int $id Project ID.
	 * @return array<string,string>
	 */
	private static function project_facts( int $id ): array {
		$low  = (string) get_post_meta( $id, '_estat_price_min', true );
		$high = (string) get_post_meta( $id, '_estat_price_max', true );

		$price = '';
		if ( '' !== $low ) {
			$price = Format::price_range( (float) $low, (float) ( '' !== $high ? $high : $low ), 'sale' );
		}

		$terms = wp_get_object_terms( $id, 'estat_locality', array( 'fields' => 'names' ) );

		return array(
			'price'        => $price,
			'area'         => '',
			'bedrooms'     => (string) get_post_meta( $id, '_estat_unit_types', true ),
			'bathrooms'    => '',
			'floor'        => '',
			'furnishing'   => (string) get_post_meta( $id, '_estat_project_type', true ),
			'parking'      => '',
			'locality'     => is_wp_error( $terms ) || ! $terms ? '' : (string) $terms[0],
			'availability' => (string) get_post_meta( $id, '_estat_possession_date', true ),
			'society'      => (string) get_post_meta( $id, '_estat_developer', true ),
		);
	}
}
