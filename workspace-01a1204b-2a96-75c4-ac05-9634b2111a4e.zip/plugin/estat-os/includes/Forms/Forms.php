<?php
/**
 * Form storage: definitions, settings, duplication and safe deletion — F8 multi-step + project attach.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Forms;

use EstatOS\Audit\AuditLog;
use EstatOS\Install\Schema;
use EstatOS\Support\Sanitize;
use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * A form definition is a small JSON document: steps -> rows -> columns -> fields OR rows -> columns -> fields (BC).
 * Visual design and business behaviour are stored separately so changing the layout can never break lead creation.
 * F8: multi-step wizard, custom fields, project attach.
 */
final class Forms {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {}

	/**
	 * Default business settings for a form — F8 adds multi_step, project attach enhancements.
	 *
	 * @return array<string,mixed>
	 */
	public static function default_settings(): array {
		return array(
			'create_lead'      => true,
			'lead_source'      => 'website',
			'notify'           => true,
			'notify_email'     => '',
			'success_message'  => __( 'Thank you. We have received your enquiry and will contact you soon.', 'estat-os' ),
			'error_message'    => __( 'Sorry, we could not send your enquiry. Please check the form and try again.', 'estat-os' ),
			'submit_label'     => __( 'Send enquiry', 'estat-os' ),
			'next_label'       => __( 'Next', 'estat-os' ),
			'prev_label'       => __( 'Back', 'estat-os' ),
			'redirect_url'     => '',
			'store_submission' => true,
			'require_consent'  => false,
			'listing_field'    => '',
			'project_field'    => '',
			'agent_field'      => '',
			'rate_limit'       => 5,
			'style'            => Style::defaults(),
			'multi_step'       => false,
			'show_progress'    => true,
			'project_attach'   => 'auto', // auto|required|hidden|dropdown
		);
	}

	/**
	 * A sensible starter form definition (two columns, then a message) — F8 multi-step example.
	 *
	 * @param bool $multi_step Whether to create multi-step starter.
	 * @return array<string,mixed>
	 */
	public static function starter_definition( bool $multi_step = false ): array {
		$step1 = array(
			'id'    => 'step_1',
			'label' => __( 'Your details', 'estat-os' ),
			'rows'  => array(
				array(
					'columns' => array(
						array( 'width' => 50, 'fields' => array( self::field( 'name', 'name', __( 'Your name', 'estat-os' ), true, __( 'For example: Priya Sharma', 'estat-os' ) ) ) ),
						array( 'width' => 50, 'fields' => array( self::field( 'phone', 'phone', __( 'Phone number', 'estat-os' ), true, __( 'For example: +91 98765 43210', 'estat-os' ) ) ) ),
					),
				),
				array(
					'columns' => array(
						array( 'width' => 100, 'fields' => array( self::field( 'email', 'email', __( 'Email address', 'estat-os' ), false, 'name@example.com' ) ) ),
					),
				),
			),
		);
		$step2 = array(
			'id'    => 'step_2',
			'label' => __( 'Property', 'estat-os' ),
			'rows'  => array(
				array(
					'columns' => array(
						array( 'width' => 50, 'fields' => array( self::field( 'property_type', 'property_type', __( 'Property type', 'estat-os' ), false ) ) ),
						array( 'width' => 50, 'fields' => array( self::field( 'budget', 'budget', __( 'Budget', 'estat-os' ), false ) ) ),
					),
				),
				array(
					'columns' => array(
						array( 'width' => 50, 'fields' => array( self::field( 'project', 'project', __( 'Society / Project', 'estat-os' ), false ) ) ),
						array( 'width' => 50, 'fields' => array( self::field( 'locality', 'locality', __( 'Preferred locality', 'estat-os' ), false ) ) ),
					),
				),
				array(
					'columns' => array(
						array( 'width' => 100, 'fields' => array( self::field( 'message', 'message', __( 'What would you like to know?', 'estat-os' ), false, __( 'I would like to visit this property this weekend.', 'estat-os' ) ) ) ),
					),
				),
			),
		);

		if ( $multi_step ) {
			return array( 'steps' => array( $step1, $step2 ) );
		}

		// Single-step BC: merge rows.
		return array( 'rows' => array_merge( $step1['rows'], $step2['rows'] ) );
	}

	/**
	 * Build one field definition.
	 *
	 * @param string $type        Field type.
	 * @param string $key         Stable field key.
	 * @param string $label       Label.
	 * @param bool   $required    Required.
	 * @param string $placeholder Placeholder/example.
	 * @return array<string,mixed>
	 */
	public static function field( string $type, string $key, string $label, bool $required = false, string $placeholder = '' ): array {
		return array(
			'id'          => $key,
			'type'        => $type,
			'label'       => $label,
			'placeholder' => $placeholder,
			'help'        => '',
			'required'    => $required,
			'default'     => '',
			'options'     => array(),
			'width'       => 100,
			'width_tablet'=> 100,
			'width_mobile'=> 100,
			'rows'        => 4,
			'size'        => 'md',
			'visible'     => array( 'desktop' => true, 'tablet' => true, 'mobile' => true ),
			'condition'   => array( 'field' => '', 'operator' => 'is', 'value' => '' ),
		);
	}

	/**
	 * Sanitize a whole definition document — F8 supports steps.
	 *
	 * @param mixed $definition Raw definition (array or JSON string).
	 * @return array<string,mixed>
	 */
	public static function sanitize_definition( $definition ): array {
		if ( is_string( $definition ) ) {
			$decoded    = json_decode( $definition, true );
			$definition = is_array( $decoded ) ? $decoded : array();
		}
		if ( ! is_array( $definition ) ) {
			$definition = array();
		}

		// F8: if steps present, sanitize steps.
		if ( isset( $definition['steps'] ) && is_array( $definition['steps'] ) ) {
			$steps = array();
			$used  = array();
			foreach ( array_slice( $definition['steps'], 0, 10 ) as $step ) {
				if ( ! is_array( $step ) ) { continue; }
				$rows_in = isset( $step['rows'] ) && is_array( $step['rows'] ) ? $step['rows'] : array();
				$rows = self::sanitize_rows( $rows_in, $used );
				$steps[] = array(
					'id'    => sanitize_key( $step['id'] ?? 'step_' . ( count( $steps ) + 1 ) ),
					'label' => Sanitize::text( $step['label'] ?? sprintf( __( 'Step %d', 'estat-os' ), count( $steps ) + 1 ) ),
					'rows'  => $rows,
				);
			}
			return array( 'steps' => $steps );
		}

		// BC: rows only.
		$rows_in = isset( $definition['rows'] ) && is_array( $definition['rows'] ) ? $definition['rows'] : array();
		$used = array();
		$rows = self::sanitize_rows( $rows_in, $used );
		return array( 'rows' => $rows );
	}

	/**
	 * Sanitize rows array.
	 *
	 * @param array<int,mixed> $rows_in Raw rows.
	 * @param string[]         $used    Used IDs reference.
	 * @return array<int,array<string,mixed>>
	 */
	private static function sanitize_rows( array $rows_in, array &$used ): array {
		$rows = array();
		foreach ( array_slice( $rows_in, 0, 50 ) as $row ) {
			if ( ! is_array( $row ) ) { continue; }
			$columns_in = isset( $row['columns'] ) && is_array( $row['columns'] ) ? $row['columns'] : array();
			$columns    = array();
			foreach ( array_slice( $columns_in, 0, 4 ) as $column ) {
				if ( ! is_array( $column ) ) { continue; }
				$fields_in = isset( $column['fields'] ) && is_array( $column['fields'] ) ? $column['fields'] : array();
				$fields    = array();
				foreach ( array_slice( $fields_in, 0, 30 ) as $field ) {
					$clean = self::sanitize_field( is_array( $field ) ? $field : array(), $used );
					if ( $clean ) {
						$used[]   = $clean['id'];
						$fields[] = $clean;
					}
				}
				$columns[] = array(
					'width'        => Sanitize::int( $column['width'] ?? 100, 10, 100 ),
					'width_tablet' => Sanitize::int( $column['width_tablet'] ?? 100, 10, 100 ),
					'width_mobile' => Sanitize::int( $column['width_mobile'] ?? 100, 10, 100 ),
					'fields'       => $fields,
				);
			}
			$rows[] = array(
				'heading'    => Sanitize::text( $row['heading'] ?? '' ),
				'gap'        => Sanitize::int( $row['gap'] ?? 16, 0, 80 ),
				'gap_mobile' => Sanitize::int( $row['gap_mobile'] ?? 12, 0, 80 ),
				'align'      => Sanitize::choice( $row['align'] ?? 'stretch', array( 'stretch', 'start', 'center', 'end' ), 'stretch' ),
				'columns'    => $columns,
			);
		}
		return $rows;
	}

	/**
	 * Sanitize one field, guaranteeing a unique stable id.
	 *
	 * @param array<string,mixed> $field Raw field.
	 * @param string[]            $used  Already used ids.
	 * @return array<string,mixed>|null
	 */
	private static function sanitize_field( array $field, array $used ): ?array {
		$type = strtolower( Sanitize::text( $field['type'] ?? 'text' ) );

		/*
		 * The everyday names for the same box.
		 *
		 * A form writer — an import, an integration, whoever comes next —
		 * says "tel" or "dropdown" or "longtext", and until now that field
		 * was thrown away without a word. A thrown-away field is not a
		 * cosmetic matter: the requirement stayed in the form, so the website
		 * refused every visitor with "please check the form", about a box
		 * that was never drawn. The known names are understood, and anything
		 * else is kept as an ordinary text box rather than dropped.
		 */
		$aliases = array(
			'tel'        => 'phone',
			'mobile'     => 'phone',
			'telephone'  => 'phone',
			'longtext'   => 'textarea',
			'long_text'  => 'textarea',
			'message'    => 'textarea',
			'dropdown'   => 'select',
			'choice'     => 'radio',
			'checkboxes' => 'checkbox',
			'boolean'    => 'checkbox',
		);
		if ( isset( $aliases[ $type ] ) ) {
			$type = $aliases[ $type ];
		}
		if ( ! FieldTypes::exists( $type ) ) {
			$type = 'text';
		}
		$id = sanitize_key( (string) ( $field['id'] ?? '' ) );
		if ( '' === $id ) {
			$id = $type . '_' . substr( md5( (string) wp_rand() . microtime() ), 0, 6 );
		}
		while ( in_array( $id, $used, true ) ) {
			$id .= '_' . wp_rand( 1, 99 );
		}

		$options_in = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$options    = array();
		foreach ( array_slice( $options_in, 0, 100 ) as $option ) {
			if ( is_array( $option ) ) {
				$value = Sanitize::text( $option['value'] ?? '' );
				$label = Sanitize::text( $option['label'] ?? $value );
			} else {
				$value = Sanitize::text( $option );
				$label = $value;
			}
			if ( '' !== $value ) {
				$options[] = array( 'value' => $value, 'label' => $label );
			}
		}

		$visible = isset( $field['visible'] ) && is_array( $field['visible'] ) ? $field['visible'] : array();
		$cond    = isset( $field['condition'] ) && is_array( $field['condition'] ) ? $field['condition'] : array();

		return array(
			'id'           => $id,
			'type'         => $type,
			'label'        => Sanitize::text( $field['label'] ?? '' ),
			'placeholder'  => Sanitize::text( $field['placeholder'] ?? '' ),
			'help'         => Sanitize::text( $field['help'] ?? '' ),
			'required'     => Sanitize::bool( $field['required'] ?? false ),
			'default'      => Sanitize::text( $field['default'] ?? '' ),
			'options'      => $options,
			'width'        => Sanitize::int( $field['width'] ?? 100, 10, 100 ),
			'width_tablet' => Sanitize::int( $field['width_tablet'] ?? 100, 10, 100 ),
			'width_mobile' => Sanitize::int( $field['width_mobile'] ?? 100, 10, 100 ),
			'rows'         => Sanitize::int( $field['rows'] ?? 4, 2, 20 ),
			'size'         => Sanitize::choice( $field['size'] ?? 'md', array( 'sm', 'md', 'lg' ), 'md' ),
			'content'      => Sanitize::textarea( $field['content'] ?? '' ),
			'visible'      => array(
				'desktop' => Sanitize::bool( $visible['desktop'] ?? true ),
				'tablet'  => Sanitize::bool( $visible['tablet'] ?? true ),
				'mobile'  => Sanitize::bool( $visible['mobile'] ?? true ),
			),
			'condition'    => array(
				'field'    => sanitize_key( (string) ( $cond['field'] ?? '' ) ),
				'operator' => Sanitize::choice( $cond['operator'] ?? 'is', array( 'is', 'is_not', 'contains', 'filled', 'empty' ), 'is' ),
				'value'    => Sanitize::text( $cond['value'] ?? '' ),
			),
		);
	}

	/**
	 * Sanitize form business settings — F8 adds multi_step, project_attach.
	 *
	 * @param mixed $settings Raw settings.
	 * @return array<string,mixed>
	 */
	public static function sanitize_settings( $settings ): array {
		if ( is_string( $settings ) ) {
			$decoded  = json_decode( $settings, true );
			$settings = is_array( $decoded ) ? $decoded : array();
		}
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}
		$d = self::default_settings();
		return array(
			'create_lead'      => Sanitize::bool( $settings['create_lead'] ?? $d['create_lead'] ),
			'lead_source'      => Sanitize::choice( $settings['lead_source'] ?? $d['lead_source'], array( 'website', 'form', 'phone', 'walkin', 'api', 'other' ), 'website' ),
			'notify'           => Sanitize::bool( $settings['notify'] ?? $d['notify'] ),
			'notify_email'     => Sanitize::email( $settings['notify_email'] ?? '' ),
			'success_message'  => Sanitize::textarea( $settings['success_message'] ?? $d['success_message'] ),
			'error_message'    => Sanitize::textarea( $settings['error_message'] ?? $d['error_message'] ),
			'submit_label'     => Sanitize::text( $settings['submit_label'] ?? $d['submit_label'] ),
			'next_label'       => Sanitize::text( $settings['next_label'] ?? $d['next_label'] ),
			'prev_label'       => Sanitize::text( $settings['prev_label'] ?? $d['prev_label'] ),
			'redirect_url'     => Sanitize::url( $settings['redirect_url'] ?? '' ),
			'store_submission' => Sanitize::bool( $settings['store_submission'] ?? $d['store_submission'] ),
			'require_consent'  => Sanitize::bool( $settings['require_consent'] ?? $d['require_consent'] ),
			'listing_field'    => sanitize_key( (string) ( $settings['listing_field'] ?? '' ) ),
			'project_field'    => sanitize_key( (string) ( $settings['project_field'] ?? '' ) ),
			'agent_field'      => sanitize_key( (string) ( $settings['agent_field'] ?? '' ) ),
			'rate_limit'       => Sanitize::int( $settings['rate_limit'] ?? $d['rate_limit'], 1, 60 ),
			'style'            => Style::sanitize( $settings['style'] ?? array() ),
			'multi_step'       => Sanitize::bool( $settings['multi_step'] ?? $d['multi_step'] ),
			'show_progress'    => Sanitize::bool( $settings['show_progress'] ?? $d['show_progress'] ),
			'project_attach'   => Sanitize::choice( $settings['project_attach'] ?? $d['project_attach'], array( 'auto', 'required', 'hidden', 'dropdown' ), 'auto' ),
		);
	}

	/**
	 * Create or update a form.
	 *
	 * @param array<string,mixed> $input   Raw input.
	 * @param int                 $form_id Existing form ID or 0.
	 * @return int|WP_Error
	 */
	public static function save( array $input, int $form_id = 0 ) {
		global $wpdb;
		if ( ! Schema::healthy() ) {
			return new WP_Error( 'estat_no_storage', __( 'The office database is not ready yet.', 'estat-os' ) );
		}
		$name = Sanitize::text( $input['name'] ?? '' );

		/*
		 * The builder on the Forms screen draws fields, not a name box, so its
		 * save arrives without one. Demanding a name there meant every save
		 * was refused and answered "Saved" (see the Ajax handler) — the
		 * office's changes to a website form were never stored. When the
		 * caller sends no name, the form keeps the name it already has; a new
		 * form with no name is still refused.
		 */
		$named = array_key_exists( 'name', $input ) && '' !== Sanitize::text( $input['name'] );

		if ( '' === $name && $form_id > 0 ) {
			$existing_name = $wpdb->get_var( $wpdb->prepare( 'SELECT name FROM ' . Schema::table( 'estat_forms' ) . ' WHERE id = %d', $form_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
			$name          = Sanitize::text( (string) $existing_name );
		}

		if ( '' === $name && ! $named && 0 === $form_id ) {
			// A form made from a list of boxes, with nobody to ask for a name:
			// it is named after what it does, and numbered if the office
			// already has one by that name. Refusing here would mean the
			// builder had no way to make a form at all.
			$name = self::first_free_name( __( 'Property enquiry', 'estat-os' ) );
		}

		if ( '' === $name ) {
			return new WP_Error( 'estat_invalid_name', __( 'Please give this form a name, for example "Property enquiry".', 'estat-os' ) );
		}

		/*
		 * A caller who hands over a plain list of fields — name, phone,
		 * email — is describing a form in the only way the words allow, and
		 * everything about the save looked like it had worked: a form was
		 * stored with no rows in it, the page drew nothing, and the website
		 * quietly stopped asking anybody for anything. That shape is now
		 * understood and wrapped into one row and one column, which is what
		 * the builder would have drawn for it.
		 */
		$definition = $input['definition'] ?? array();

		/*
		 * The office's own builder posts the layout on its own — the decoded
		 * JSON *is* the input (see Ajax::save), while the admin-post route
		 * and the templates wrap it in 'definition'. Reading only the wrapped
		 * shape meant every Save from the builder stored an empty layout: the
		 * screen said "Form saved", the form's boxes disappeared, and the
		 * page on the website stopped asking for anything at all.
		 */
		if ( ! is_array( $definition ) || ( empty( $definition['rows'] ) && empty( $definition['steps'] ) ) ) {
			if ( isset( $input['rows'] ) || isset( $input['steps'] ) ) {
				$definition = $input;
			}
		}

		// A caller who hands over a plain list of fields — name, phone,
		// email — is describing a form in the only way the words allow. That
		// shape is understood and wrapped into one row and one column, which
		// is what the builder would have drawn for it.
		if ( ( ! is_array( $definition ) || ( empty( $definition['rows'] ) && empty( $definition['steps'] ) ) )
			&& ! empty( $input['fields'] ) && is_array( $input['fields'] ) ) {
			$definition = array( 'rows' => array( array( 'columns' => array( array( 'fields' => $input['fields'] ) ) ) ) );
		}

		/*
		 * Settings the caller did not mention stay as they are.
		 *
		 * The builder saves boxes, not behaviour, and it sends no settings at
		 * all. sanitize_settings() fills every missing key from the defaults,
		 * so those saves quietly put the office's own words back to the
		 * factory ones — the "thank you" line, who gets the email, whether
		 * consent is asked for. Absent means "leave it", not "reset it".
		 */
		$settings_in = $input['settings'] ?? null;
		$sent_settings = null !== $settings_in && ( is_array( $settings_in ) || '' !== (string) $settings_in );
		if ( ! $sent_settings && $form_id > 0 ) {
			$settings_in = $wpdb->get_var( $wpdb->prepare( 'SELECT settings FROM ' . Schema::table( 'estat_forms' ) . ' WHERE id = %d', $form_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
		}

		$table = Schema::table( 'estat_forms' );
		$now   = current_time( 'mysql', true );
		$row   = array(
			'name'       => $name,
			'updated_at' => $now,
			'status'     => Sanitize::choice( $input['status'] ?? 'active', array( 'active', 'inactive' ), 'active' ),
			'definition' => (string) wp_json_encode( self::sanitize_definition( $definition ) ),
			'settings'   => (string) wp_json_encode( self::sanitize_settings( null === $settings_in ? array() : $settings_in ) ),
		);

		if ( $form_id > 0 ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->update( $table, $row, array( 'id' => $form_id ) );
		} else {
			$row['created_at'] = $now;
			$row['slug']       = self::unique_slug( $name );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->insert( $table, $row );
			$form_id = (int) $wpdb->insert_id;
		}

		AuditLog::record( 'form.saved', 'form', $form_id, array() );
		wp_cache_delete( 'estat_form_' . $form_id, 'estat' );
		return $form_id;
	}

	/**
	 * The first name of this shape that is not taken yet.
	 *
	 * @param string $wanted Suggested name.
	 * @return string
	 */
	private static function first_free_name( string $wanted ): string {
		global $wpdb;
		$table = Schema::table( 'estat_forms' );
		$taken = $wpdb->get_col( $table ? "SELECT name FROM {$table}" : '' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
		$taken = array_map( 'strval', is_array( $taken ) ? $taken : array() );
		if ( ! in_array( $wanted, $taken, true ) ) {
			return $wanted;
		}
		for ( $n = 2; $n < 100; $n++ ) {
			$candidate = $wanted . ' ' . $n;
			if ( ! in_array( $candidate, $taken, true ) ) {
				return $candidate;
			}
		}
		return $wanted;
	}

	/**
	 * Build a unique website address for a form.
	 *
	 * @param string $name Form name.
	 * @return string
	 */
	private static function unique_slug( string $name ): string {
		global $wpdb;
		$base  = sanitize_title( $name );
		$base  = '' !== $base ? $base : 'form';
		$slug  = $base;
		$table = Schema::table( 'estat_forms' );
		$i     = 2;
		while ( true ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$exists = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE slug = %s", $slug ) );
			if ( ! $exists ) {
				return $slug;
			}
			$slug = $base . '-' . $i;
			++$i;
			if ( $i > 200 ) {
				return $base . '-' . wp_rand( 1000, 9999 );
			}
		}
	}

	/**
	 * Get a form.
	 *
	 * @param int $form_id Form ID.
	 * @return array<string,mixed>|null Decoded form.
	 */
	public static function get( int $form_id ): ?array {
		global $wpdb;
		if ( ! Schema::healthy() || $form_id <= 0 ) {
			return null;
		}
		$cached = wp_cache_get( 'estat_form_' . $form_id, 'estat' );
		if ( is_array( $cached ) ) {
			return $cached;
		}
		$table = Schema::table( 'estat_forms' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $form_id ), ARRAY_A );
		if ( ! is_array( $row ) ) {
			return null;
		}
		$row['definition'] = self::sanitize_definition( $row['definition'] );
		$row['settings']   = self::sanitize_settings( $row['settings'] );
		wp_cache_set( 'estat_form_' . $form_id, $row, 'estat', HOUR_IN_SECONDS );
		return $row;
	}

	/**
	 * List forms.
	 *
	 * @param int $limit Maximum rows.
	 * @return array<int,array<string,mixed>>
	 */
	public static function all( int $limit = 100 ): array {
		global $wpdb;
		if ( ! Schema::healthy() ) {
			return array();
		}
		$table = Schema::table( 'estat_forms' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, name, slug, status, created_at, updated_at FROM {$table} ORDER BY id DESC LIMIT %d", max( 1, min( 500, $limit ) ) ), ARRAY_A );
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Duplicate a form including its layout and behaviour.
	 *
	 * @param int $form_id Form ID.
	 * @return int|WP_Error New form ID.
	 */
	public static function duplicate( int $form_id ) {
		$form = self::get( $form_id );
		if ( ! $form ) {
			return new WP_Error( 'estat_not_found', __( 'That form could not be found.', 'estat-os' ) );
		}
		return self::save(
			array(
				/* translators: %s: form name */
				'name'       => sprintf( __( '%s (copy)', 'estat-os' ), $form['name'] ),
				'status'     => $form['status'],
				'definition' => $form['definition'],
				'settings'   => $form['settings'],
			)
		);
	}

	/**
	 * Delete a form. Submissions are kept and simply detached.
	 *
	 * @param int $form_id Form ID.
	 * @return bool
	 */
	public static function delete( int $form_id ): bool {
		global $wpdb;
		if ( ! Schema::healthy() ) {
			return false;
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->delete( Schema::table( 'estat_forms' ), array( 'id' => $form_id ), array( '%d' ) );
		wp_cache_delete( 'estat_form_' . $form_id, 'estat' );
		AuditLog::record( 'form.deleted', 'form', $form_id, array() );
		return true;
	}

	/**
	 * Flatten a definition into an ordered list of fields — F8 supports steps.
	 *
	 * @param array<string,mixed> $definition Definition.
	 * @return array<int,array<string,mixed>>
	 */
	public static function flatten( array $definition ): array {
		$fields = array();
		// Steps first.
		if ( isset( $definition['steps'] ) && is_array( $definition['steps'] ) ) {
			foreach ( $definition['steps'] as $step ) {
				foreach ( (array) ( $step['rows'] ?? array() ) as $row ) {
					foreach ( (array) ( $row['columns'] ?? array() ) as $column ) {
						foreach ( (array) ( $column['fields'] ?? array() ) as $field ) {
							$fields[] = $field;
						}
					}
				}
			}
			return $fields;
		}
		foreach ( (array) ( $definition['rows'] ?? array() ) as $row ) {
			foreach ( (array) ( $row['columns'] ?? array() ) as $column ) {
				foreach ( (array) ( $column['fields'] ?? array() ) as $field ) {
					$fields[] = $field;
				}
			}
		}
		return $fields;
	}

	/**
	 * Get steps from definition, or wrap rows into single step for BC.
	 *
	 * @param array<string,mixed> $definition Definition.
	 * @return array<int,array<string,mixed>> Steps.
	 */
	public static function get_steps( array $definition ): array {
		if ( isset( $definition['steps'] ) && is_array( $definition['steps'] ) && $definition['steps'] ) {
			return $definition['steps'];
		}
		// BC: single step containing rows.
		return array(
			array(
				'id'    => 'step_1',
				'label' => __( 'Details', 'estat-os' ),
				'rows'  => $definition['rows'] ?? array(),
			),
		);
	}

	/**
	 * Create the default enquiry form on activation, once.
	 *
	 * @return void
	 */
	public static function seed(): void {
		if ( ! Schema::healthy() ) {
			return;
		}
		if ( self::all( 1 ) ) {
			return;
		}
		self::save(
			array(
				'name'       => __( 'Property enquiry', 'estat-os' ),
				'definition' => self::starter_definition( true ),
				'settings'   => array_merge( self::default_settings(), array( 'multi_step' => true, 'project_attach' => 'auto' ) ),
			)
		);
	}
}
