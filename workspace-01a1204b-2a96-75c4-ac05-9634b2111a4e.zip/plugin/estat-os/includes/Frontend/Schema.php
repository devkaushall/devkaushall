<?php
/**
 * SEO structured data.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Frontend;

use EstatOS\Data\Agents;
use EstatOS\Data\Listings;
use EstatOS\Data\PostTypes;
use EstatOS\Data\Projects;
use EstatOS\Support\PublicText;
use EstatOS\Settings\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Conservative schema: only what the plugin actually knows, only when enabled,
 * and never a price when the office has chosen "price on request".
 */
final class Schema {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'wp_head', array( __CLASS__, 'output' ), 20 );
	}

	/**
	 * Print the JSON-LD block.
	 *
	 * @return void
	 */
	public static function output(): void {
		if ( ! Settings::get( 'enable_schema' ) ) {
			return;
		}
		$data = null;

		if ( is_singular( PostTypes::LISTING ) ) {
			$data = self::listing( (int) get_the_ID() );
		} elseif ( is_singular( PostTypes::PROJECT ) ) {
			$data = self::project( (int) get_the_ID() );
		} elseif ( is_singular( PostTypes::AGENT ) ) {
			$data = self::agent( (int) get_the_ID() );
		} elseif ( is_front_page() ) {
			$data = self::organization();
		}

		/*
		 * Breadcrumbs are their own graph item, so they are attached to
		 * whichever page is being described rather than replacing it. A page
		 * with nothing else to say still gets its trail.
		 */
		$crumbs = self::breadcrumbs();
		if ( $crumbs ) {
			$data = array(
				'@context' => 'https://schema.org',
				'@graph'   => array_values( array_filter( array( $data, $crumbs ) ) ),
			);
		}

		if ( ! $data ) {
			return;
		}

		/**
		 * Filter the structured data before it is printed. Return an empty
		 * array from another SEO plugin to suppress it entirely.
		 *
		 * @param array<string,mixed> $data Structured data.
		 */
		$data = (array) apply_filters( 'estat_schema_data', $data );
		if ( ! $data ) {
			return;
		}

				/*
		 * JSON_HEX_TAG and JSON_HEX_AMP are not decoration. A property named
		 * "2 < 3 BHK Flats" — or a title imported with an HTML tag left in it —
		 * used to be printed straight into this <script> block, where a `<` is
		 * not text: it ends the element. The page then either lost its
		 * structured data or ran whatever came after it. Encoded as \\u003C the
		 * same characters are data again, and every parser reads them back.
		 */
		$flags = JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP;

		echo '<script type="application/ld+json">' . wp_json_encode( $data, $flags ) . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Listing schema.
	 *
	 * @param int $listing_id Listing ID.
	 * @return array<string,mixed>|null
	 */
	private static function listing( int $listing_id ): ?array {
		$listing = Listings::to_array( $listing_id, false );
		if ( ! $listing ) {
			return null;
		}
		$schema = array(
			'@context' => 'https://schema.org',
			'@type'    => 'RealEstateListing',
			'name'     => $listing['title'],
			'url'      => $listing['url'],
		);
		$locality = (array) ( $listing['locality'] ?? array() );
		if ( '' !== (string) $listing['cover'] ) {
			$schema['image'] = $listing['cover'];
		}
		/*
		 * The description published to search engines is cleaned the same
		 * way the visible one is. It used to be the raw excerpt, which put
		 * an office note straight onto the page — invisible on screen, but
		 * printed in the structured data for every crawler to read.
		 */
		$excerpt = get_post_field( 'post_content', $listing_id );
		if ( ! is_string( $excerpt ) || '' === trim( $excerpt ) ) {
			$excerpt = (string) get_the_excerpt( $listing_id );
		}
		$excerpt = trim( wp_strip_all_tags( PublicText::prose( (string) $excerpt ) ) );
		if ( '' !== $excerpt ) {
			$schema['description'] = wp_trim_words( $excerpt, 60, '' );
		}
		if ( null !== $listing['price'] && (float) $listing['price'] > 0 ) {
			$offer = array(
				'@type'         => 'Offer',
				'price'         => (float) $listing['price'],
				'priceCurrency' => (string) Settings::get( 'currency', 'INR' ),
			);
			// Availability is only said when the office has said it. A blank
			// answer used to be published as SoldOut, which is a claim nobody
			// made — the property was simply never asked about.
			$availability = (string) ( $listing['availability'] ?? '' );
			if ( 'available' === $availability ) {
				$offer['availability'] = 'https://schema.org/InStock';
			} elseif ( 'on_hold' === $availability ) {
				// Under offer: still for sale, but promised to somebody.
				$offer['availability'] = 'https://schema.org/LimitedAvailability';
			} elseif ( 'sold' === $availability || 'rented' === $availability ) {
				$offer['availability'] = 'https://schema.org/SoldOut';
			}
			$schema['offers'] = $offer;
		}
		if ( (float) $listing['area_sqft'] > 0 ) {
			$schema['floorSize'] = array(
				'@type'    => 'QuantitativeValue',
				'value'    => (float) $listing['area_sqft'],
				'unitCode' => 'FTK',
			);
		}
		if ( (int) $listing['bedrooms'] > 0 ) {
			$schema['numberOfRooms'] = (int) $listing['bedrooms'];
		}
		if ( $locality ) {
			$address = array(
				'@type'           => 'PostalAddress',
				'addressLocality' => (string) $locality[0],
			);
			$city = (string) Settings::get( 'city', '' );
			if ( '' !== $city && 0 !== strcasecmp( $city, (string) $locality[0] ) ) {
				$address['addressRegion'] = $city;
			}
			$country = (string) Settings::get( 'country', '' );
			if ( '' !== $country ) {
				$address['addressCountry'] = $country;
			}
			$schema['address'] = $address;
		}
		return $schema;
	}

	/**
	 * Agent schema.
	 *
	 * @param int $agent_id Agent ID.
	 * @return array<string,mixed>|null
	 */
	private static function agent( int $agent_id ): ?array {
		$agent = Agents::to_array( $agent_id );
		if ( ! $agent ) {
			return null;
		}
		$schema = array(
			'@context' => 'https://schema.org',
			'@type'    => 'RealEstateAgent',
			'name'     => $agent['name'],
			'url'      => $agent['url'],
		);
		if ( '' !== (string) $agent['phone'] ) {
			$schema['telephone'] = $agent['phone'];
		}
		if ( '' !== (string) $agent['photo'] ) {
			$schema['image'] = $agent['photo'];
		}
		return $schema;
	}

	/**
	 * Project schema.
	 *
	 * A project page had no structured data at all, which meant the richest
	 * pages the office publishes — a whole development, with a builder, a
	 * stage, a price range and a location — were the ones a search engine
	 * could read the least from.
	 *
	 * Only what the record holds is written. A project with no price gets no
	 * price, and a project with no photograph gets no image: inventing either
	 * to make the graph look fuller is worse than a shorter graph.
	 *
	 * @param int $project_id Project ID.
	 * @return array<string,mixed>|null
	 */
	private static function project( int $project_id ): ?array {
		$project = Projects::to_array( $project_id );
		if ( ! $project ) {
			return null;
		}

		$name = (string) ( $project['title'] ?? '' );
		if ( '' === $name ) {
			return null;
		}

		$schema = array(
			'@context' => 'https://schema.org',
			'@type'    => 'Residence',
			'name'     => $name,
			'url'      => (string) ( $project['url'] ?? '' ),
		);

		$description = PublicText::clean(
			(string) wp_strip_all_tags( PublicText::prose( (string) ( $project['description'] ?? '' ) ) )
		);
		if ( '' === $description ) {
			$description = \EstatOS\Frontend\Seo::describe_project( $project_id );
		}
		if ( '' !== $description ) {
			$schema['description'] = wp_trim_words( $description, 60, '' );
		}

		if ( '' !== (string) ( $project['cover'] ?? '' ) ) {
			$schema['image'] = (string) $project['cover'];
		}

		/*
		 * The builder of a Residence is an Organization, not a string — that
		 * is the piece that connects a project to the name people search for.
		 */
		if ( '' !== (string) ( $project['developer'] ?? '' ) ) {
			$schema['brand'] = array(
				'@type' => 'Organization',
				'name'  => (string) $project['developer'],
			);
		}

		if ( (int) ( $project['total_units'] ?? 0 ) > 0 ) {
			$schema['numberOfAccommodationUnits'] = (int) $project['total_units'];
		}

		/*
		 * Where it is. A locality term gives a real place name; the address
		 * line the office typed is added only when it says something public.
		 */
		$areas = array_values( array_filter( array_map( 'strval', (array) ( $project['locality'] ?? array() ) ) ) );
		if ( $areas ) {
			$schema['address'] = array(
				'@type'           => 'PostalAddress',
				'addressLocality' => $areas[0],
				'addressRegion'   => implode( ', ', array_slice( $areas, 1 ) ) ?: null,
				'addressCountry'  => 'IN',
			);
			$schema['address'] = array_filter( $schema['address'] );
		}

		$lat = (float) ( $project['latitude'] ?? 0 );
		$lng = (float) ( $project['longitude'] ?? 0 );
		if ( 0.0 !== $lat && 0.0 !== $lng ) {
			$schema['geo'] = array(
				'@type'     => 'GeoCoordinates',
				'latitude'  => $lat,
				'longitude' => $lng,
			);
		}

		/*
		 * A price range only when the office actually set one, and never as a
		 * guess — a wrong price in structured data is a wrong price in a
		 * search result.
		 */
		$min = (float) ( $project['price_min'] ?? 0 );
		$max = (float) ( $project['price_max'] ?? 0 );
		if ( $min > 0 || $max > 0 ) {
			$schema['offers'] = array(
				'@type'         => 'AggregateOffer',
				'priceCurrency' => (string) Settings::get( 'currency', 'INR' ),
				'lowPrice'      => $min > 0 ? $min : $max,
				'highPrice'     => $max > 0 ? $max : $min,
			);
			$schema['offers'] = array_filter( $schema['offers'] );
		}

		/** Filter the project structured data. */
		return (array) apply_filters( 'estat_schema_project', $schema, $project_id );
	}

	/**
	 * Breadcrumb schema for the page being drawn.
	 *
	 * @return array<string,mixed>|null
	 */
	private static function breadcrumbs(): ?array {
		if ( is_front_page() ) {
			return null;
		}

		$trail = array();
		$trail[] = array(
			'label' => __( 'Home', 'estat-os' ),
			'url'   => home_url( '/' ),
		);

		if ( is_singular( PostTypes::PROJECT ) ) {
			$trail[] = array(
				'label' => __( 'Projects', 'estat-os' ),
				'url'   => (string) get_post_type_archive_link( PostTypes::PROJECT ),
			);
		} elseif ( is_singular( PostTypes::LISTING ) || is_post_type_archive( PostTypes::LISTING ) ) {
			$trail[] = array(
				'label' => __( 'Properties', 'estat-os' ),
				'url'   => (string) get_post_type_archive_link( PostTypes::LISTING ),
			);
		} elseif ( is_singular( PostTypes::AGENT ) || is_post_type_archive( PostTypes::AGENT ) ) {
			$trail[] = array(
				'label' => __( 'Our team', 'estat-os' ),
				'url'   => (string) get_post_type_archive_link( PostTypes::AGENT ),
			);
		} elseif ( is_tax() ) {
			$term = get_queried_object();
			if ( ! $term instanceof \WP_Term ) {
				return null;
			}
		}

		if ( is_singular( array( PostTypes::PROJECT, PostTypes::LISTING, PostTypes::AGENT ) ) ) {
			$trail[] = array(
				'label' => (string) get_the_title(),
				'url'   => (string) get_permalink(),
			);
		} elseif ( is_tax() ) {
			$term = get_queried_object();
			if ( $term instanceof \WP_Term ) {
				$trail[] = array(
					'label' => $term->name,
					'url'   => (string) get_term_link( $term ),
				);
			}
		} elseif ( is_post_type_archive() ) {
			$trail[] = array(
				'label' => (string) post_type_archive_title( '', false ),
				'url'   => '',
			);
		} else {
			return null;
		}

		$items = array();
		$step  = 1;
		foreach ( $trail as $crumb ) {
			if ( '' === (string) $crumb['label'] ) {
				continue;
			}
			$items[] = array(
				'@type'    => 'ListItem',
				'position' => $step++,
				'name'     => (string) $crumb['label'],
				'item'     => (string) $crumb['url'],
			);
		}

		if ( count( $items ) < 2 ) {
			return null;
		}

		/** Filter the breadcrumb structured data. */
		return (array) apply_filters(
			'estat_schema_breadcrumbs',
			array(
				'@type'           => 'BreadcrumbList',
				'itemListElement' => $items,
			)
		);
	}

	/**
	 * Organization schema for the home page.
	 *
	 * @return array<string,mixed>|null
	 */
	private static function organization(): ?array {
		$name = (string) Settings::get( 'office_name', '' );
		if ( '' === $name ) {
			return null;
		}
		$schema = array(
			'@context' => 'https://schema.org',
			'@type'    => 'RealEstateAgent',
			'name'     => $name,
			'url'      => home_url( '/' ),
		);
		$phone = (string) Settings::get( 'phone', '' );
		if ( '' !== $phone ) {
			$schema['telephone'] = $phone;
		}
		$address = (string) Settings::get( 'address', '' );
		if ( '' !== $address ) {
			$schema['address'] = array( '@type' => 'PostalAddress', 'streetAddress' => $address );
		}
		return $schema;
	}
}
