<?php
/**
 * The public project page — an explorer, drawn from the office's block order.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Frontend;

use EstatOS\Data\PostTypes;
use EstatOS\Data\Projects;
use EstatOS\Data\Templates;
use EstatOS\Data\Taxonomies;
use EstatOS\Settings\Settings;
use EstatOS\Support\Format;
use EstatOS\Support\Icon;
use EstatOS\Support\PublicText;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

/**
 * One society, drawn as somewhere to look rather than something to read.
 *
 * The order of the page still comes from `Templates::get_blocks( 'project' )`
 * — the office's own Page blocks setting is the only source of truth about
 * what appears and in what order, and a block the office has switched off is
 * never drawn. What changed is what each block *does*: the facts can be
 * opened, the writing can be unfolded, the amenities can be filtered, the
 * photographs can be inspected, the properties can be narrowed, and the
 * enquiry answers in place.
 *
 * Every one of those is built by a component in `Components`, and every
 * behaviour is handed to `assets/js/ui.js` through data attributes — so the
 * page is complete before any script runs and stays usable without one.
 *
 * Two rules hold everywhere in this file:
 *
 *   1. A block with nothing to show is not drawn — not drawn empty, not drawn
 *      with a placeholder. Absent data produces an absent section.
 *   2. Nothing is invented. Every value comes from the project record, and
 *      every string the office typed passes through PublicText on the way out.
 */
final class ProjectPage {

	/**
	 * The project record being drawn.
	 *
	 * @var array<string,mixed>
	 */
	private static $project = array();

	/**
	 * Sections offered to the jump list, in the order they will appear.
	 *
	 * @var array<int,array{id:string,label:string}>
	 */
	private static $sections = array();

	/**
	 * A block's own refinement of the words the jump list uses for it.
	 *
	 * "Properties (4)" says more than "Properties", and a block is the
	 * only place that knows the number. A block with nothing to add sets
	 * nothing, and the plain heading from `titles()` stands instead.
	 *
	 * @var array<string,string>
	 */
	private static $nav_labels = array();

	/**
	 * Draw the whole page.
	 *
	 * @param int $project_id Project ID.
	 * @return string
	 */
	public static function render( int $project_id ): string {
		$project = Projects::to_array( $project_id );
		if ( ! $project ) {
			return '';
		}

		self::$project    = $project;
		self::$sections   = array();
		self::$nav_labels = array();

		wp_enqueue_style( 'estat-public' );

		$blocks = Templates::get_blocks( 'project' );

		/*
		 * Two passes. The first asks every block what it would draw, so the
		 * jump list can be built from sections that genuinely exist — a link
		 * to a section that was not drawn is a lie, and the only way to know
		 * is to have the HTML in hand first. The second pass prints it, with
		 * the navigation and the progress line in their places.
		 */
		$rendered = array();
		foreach ( $blocks as $block ) {
			$id = (string) ( $block['id'] ?? '' );
			if ( '' === $id || empty( $block['enabled'] ) ) {
				continue;
			}

			$method = array( __CLASS__, 'block_' . $id );
			if ( ! is_callable( $method ) ) {
				continue;
			}

			$html = (string) call_user_func( $method, $project_id );

			/*
			 * The heading, if this block is one that carries one. The
			 * block's own `label` is the admin screen's description of the
			 * block ("Facts — builder, status, units"), which is not the
			 * sentence a visitor should read, so the words come from here.
			 */
			$title = isset( self::titles()[ $id ] ) ? self::titles()[ $id ] : '';
			if ( isset( self::$nav_labels[ $id ] ) ) {
				$title = (string) self::$nav_labels[ $id ];
			}
			if ( '' !== trim( $html ) && '' !== $title ) {
				self::offer( $id, $title );
			}

			/**
			 * Filter one rendered project block.
			 *
			 * @param string              $html       Block HTML.
			 * @param string              $id         Block id.
			 * @param int                 $project_id Project ID.
			 * @param array<string,mixed> $project    Project data.
			 */
			$html = (string) apply_filters( 'estat_project_block_html', $html, $id, $project_id, $project );
			$html = (string) apply_filters( 'estat_project_block_html_' . $id, $html, $project_id, $project );

			if ( '' !== trim( $html ) ) {
				$rendered[ $id ] = array(
					'title' => $title,
					'html'  => $html,
				);
			}
		}

		if ( ! $rendered ) {
			self::$project    = array();
			self::$sections   = array();
			self::$nav_labels = array();
			return '';
		}

		$out = '';

		// The header is the one block that is not a "section" you jump to.
		if ( isset( $rendered['header'] ) ) {
			$out .= '<header class="estat-project-header">' . $rendered['header']['html'] . '</header>';
			unset( $rendered['header'] );
		}

		/*
		 * The jump list. It is drawn here, after the header and before the
		 * first section, and it is drawn from the sections that were actually
		 * produced — never from a hard-coded list of what a project page
		 * usually has.
		 */
		$nav = Components::section_nav( self::$sections, __( 'Explore this project', 'estat-os' ) );
		if ( '' !== $nav ) {
			$out .= '<div class="estat-project-navwrap">'
				. $nav
				. Components::progress( 'estat-project-body' )
				. '</div>';
		}

		$out .= '<div class="estat-project-body" id="estat-project-body">';

		foreach ( $rendered as $id => $part ) {
			$section_id = 'estat-section-' . $id;
			$label      = (string) $part['title'];

			/*
			 * The anchor target sits on the section itself with a tabindex so
			 * that jumping to it moves focus as well as the viewport — a
			 * keyboard user landing on "Gallery" is then *at* the gallery.
			 */
			$out .= '<section class="estat-section estat-project-block estat-project-block-' . esc_attr( $id ) . '"'
				. ' id="' . esc_attr( $section_id ) . '"'
				. ' data-estat-section tabindex="-1"'
				. ( '' !== $label ? ' aria-labelledby="' . esc_attr( $section_id ) . '-heading"' : '' )
				. '>';

			if ( '' !== $label ) {
				$out .= '<h2 class="estat-section-title" id="' . esc_attr( $section_id ) . '-heading">'
					. esc_html( $label ) . '</h2>';
			}

			$out .= $part['html'];
			$out .= '</section>';
		}

		$out .= '</div>';

		$out .= self::mobile_bar( $project_id );

		self::$project    = array();
		self::$sections   = array();
			self::$nav_labels = array();
			return $out;
	}

	/**
	 * Offer a section to the jump list.
	 *
	 * Called by a block that produced real content, so the list can never
	 * point at a section that was not drawn.
	 *
	 * @param string $id    Block id.
	 * @param string $label Words for the link.
	 * @return void
	 */
	/**
	 * The heading a block is drawn under, in words a visitor would use.
	 *
	 * The block's own `label` in the Page blocks setting describes the block
	 * for the office ("Facts — builder, status, units"), which is not a
	 * sentence to print on a public page. A block with no entry here is drawn
	 * without a heading and without a link in the jump list — which is what
	 * the header, the cover and the share row want.
	 *
	 * @return array<string,string> Block id to heading.
	 */
	private static function titles(): array {
		return array(
			'facts'        => __( 'At a glance', 'estat-os' ),
			'description'  => __( 'Overview', 'estat-os' ),
			'gallery'      => __( 'Photographs', 'estat-os' ),
			'floor_plans'  => __( 'Plans, film and documents', 'estat-os' ),
			'amenities'    => __( 'Amenities', 'estat-os' ),
			'location'     => __( 'Location', 'estat-os' ),
			'units'        => __( 'Properties in this project', 'estat-os' ),
			'share'        => __( 'Share', 'estat-os' ),
			'enquiry'      => __( 'Enquire about this project', 'estat-os' ),
		);
	}

	/**
	 * Offer a section to the jump list.
	 *
	 * Called by a block that produced real content, so the list can never
	 * point at a section that was not drawn.
	 *
	 * @param string $id    Block id.
	 * @param string $label Words for the link.
	 * @return void
	 */
	private static function offer( string $id, string $label ): void {
		if ( '' === $label ) {
			return;
		}
		self::$sections[] = array(
			'id'    => 'estat-section-' . $id,
			'label' => $label,
		);
	}

	/* ---------------------------------------------------------------- Blocks */

	/**
	 * Header — breadcrumb, name, locality, badges, price, and the two things
	 * a visitor came to do.
	 *
	 * @param int $project_id Project ID.
	 * @return string
	 */
	private static function block_header( int $project_id ): string {
		$p = self::$project;

		$trail = array(
			array( 'label' => __( 'Home', 'estat-os' ), 'url' => home_url( '/' ) ),
			array( 'label' => __( 'Projects', 'estat-os' ), 'url' => (string) get_post_type_archive_link( PostTypes::PROJECT ) ),
		);

		$terms = (array) ( $p['locality_terms'] ?? array() );
		$term  = $terms ? $terms[0] : null;
		if ( $term instanceof \WP_Term ) {
			$trail[] = array( 'label' => $term->name, 'url' => (string) get_term_link( $term ) );
		}
		$trail[] = array( 'label' => (string) $p['title'], 'url' => '' );

		/*
		 * The hero media: the cover, plus the gallery behind it. This is what
		 * makes the page somewhere to start looking rather than something to
		 * start reading.
		 */
		$photos = array();
		$cover  = (int) get_post_thumbnail_id( $project_id );
		if ( $cover > 0 ) {
			$photos[] = array( 'id' => $cover, 'url' => '' );
		}
		foreach ( array_values( array_filter( array_map( 'absint', (array) ( $p['gallery'] ?? array() ) ) ) ) as $gid ) {
			if ( $gid !== $cover ) {
				$photos[] = array( 'id' => $gid, 'url' => '' );
			}
		}

		ob_start();
		?>
		<?php echo Components::breadcrumbs( $trail ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

		<div class="estat-project-head">
			<div class="estat-project-head-main">
				<?php
				$badges = array_filter(
					array(
						(string) ( $p['stage_label'] ?? '' ),
						(string) ( $p['category_label'] ?? '' ),
					)
				);
				?>
				<?php if ( $badges ) : ?>
					<p class="estat-project-badges">
						<?php foreach ( $badges as $badge ) : ?>
							<span class="estat-pill is-bare"><?php echo esc_html( $badge ); ?></span>
						<?php endforeach; ?>
					</p>
				<?php endif; ?>

				<h1><?php echo esc_html( (string) $p['title'] ); ?></h1>

				<?php
				$where = array_filter(
					array(
						implode( ', ', array_map( 'strval', array_filter( (array) ( $p['locality'] ?? array() ) ) ) ),
						PublicText::clean( (string) ( $p['address'] ?? '' ) ),
					)
				);
				?>
				<?php if ( $where ) : ?>
					<p class="estat-page-subtitle">
						<?php echo Icon::render( 'map-pin', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span><?php echo esc_html( implode( ' · ', $where ) ); ?></span>
					</p>
				<?php endif; ?>

				<?php if ( '' !== (string) ( $p['developer'] ?? '' ) ) : ?>
					<p class="estat-project-developer">
						<?php
						printf(
							/* translators: %s: the builder's name. */
							esc_html__( 'By %s', 'estat-os' ),
							esc_html( (string) $p['developer'] )
						);
						?>
					</p>
				<?php endif; ?>

				<?php if ( '' !== (string) ( $p['price_display'] ?? '' ) ) : ?>
					<div class="estat-detail-price estat-project-price">
						<strong><?php echo esc_html( (string) $p['price_display'] ); ?></strong>
						<?php if ( (int) ( $p['total_units'] ?? 0 ) > 0 ) : ?>
							<span>
							<?php
							printf(
								/* translators: %d: how many units the project holds in total. */
								esc_html( _n( '%d unit in total', '%d units in total', (int) $p['total_units'], 'estat-os' ) ),
								(int) $p['total_units']
							);
							?>
							</span>
						<?php endif; ?>
					</div>
				<?php endif; ?>

				<div class="estat-project-cta">
					<?php
					$wa = WhatsApp::button( $project_id );
					if ( '' !== $wa ) {
						echo $wa; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built and escaped in WhatsApp::button()
					}
					?>
					<a class="estat-btn is-ghost" href="#estat-section-enquiry"><?php esc_html_e( 'Send an enquiry', 'estat-os' ); ?></a>
				</div>
			</div>

			<?php
			echo Components::hero_media( $project_id, $photos, (string) $p['title'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			?>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Cover — when the office keeps the cover block on, the photograph is
	 * already in the hero; this draws it full width for pages that want it.
	 *
	 * @param int $project_id Project ID.
	 * @return string
	 */
	private static function block_cover( int $project_id ): string {
		// The hero already carries the cover. Drawing it twice is a duplicate.
		return '';
	}

	/**
	 * Facts — the snapshot, where a number that needs explaining can be
	 * opened rather than left mysterious.
	 *
	 * @param int $project_id Project ID.
	 * @return string
	 */
	private static function block_facts( int $project_id ): string {
		$p = self::$project;

		$facts = array();

		if ( '' !== (string) ( $p['category_label'] ?? '' ) ) {
			$facts[] = array(
				'label' => __( 'Project type', 'estat-os' ),
				'value' => (string) $p['category_label'],
				'note'  => __( 'Whether the development is homes, offices, shops or a mix.', 'estat-os' ),
			);
		}
		if ( '' !== (string) ( $p['stage_label'] ?? '' ) ) {
			$facts[] = array(
				'label' => __( 'Stage', 'estat-os' ),
				'value' => (string) $p['stage_label'],
				'note'  => __( 'How far along the development is today.', 'estat-os' ),
			);
		}
		if ( '' !== (string) ( $p['project_type'] ?? '' ) ) {
			$facts[] = array(
				'label' => __( 'Homes or units', 'estat-os' ),
				'value' => PublicText::clean( (string) $p['project_type'] ),
			);
		}

		$units = array_values( array_filter( array_map( array( PublicText::class, 'clean' ), (array) ( $p['unit_type_list'] ?? array() ) ) ) );
		if ( $units ) {
			$facts[] = array(
				'label' => __( 'Unit types', 'estat-os' ),
				'value' => implode( ', ', $units ),
			);
		}

		if ( '' !== (string) ( $p['price_display'] ?? '' ) ) {
			$facts[] = array(
				'label' => __( 'Price', 'estat-os' ),
				'value' => (string) $p['price_display'],
				'note'  => __( 'The range the office holds today. Ask us for the current figure for a specific unit.', 'estat-os' ),
			);
		}
		if ( '' !== (string) ( $p['possession_date'] ?? '' ) ) {
			$facts[] = array(
				'label' => __( 'Possession', 'estat-os' ),
				'value' => Format::month_year( (string) $p['possession_date'] ),
				'note'  => __( 'When the builder expects to hand the units over.', 'estat-os' ),
			);
		}

		$areas = array_filter( array_map( 'strval', (array) ( $p['locality'] ?? array() ) ) );
		if ( $areas ) {
			$facts[] = array(
				'label' => __( 'Locality', 'estat-os' ),
				'value' => implode( ', ', $areas ),
			);
		}
		if ( '' !== PublicText::clean( (string) ( $p['address'] ?? '' ) ) ) {
			$facts[] = array(
				'label' => __( 'Address', 'estat-os' ),
				'value' => PublicText::clean( (string) $p['address'] ),
			);
		}
		if ( (int) ( $p['total_units'] ?? 0 ) > 0 ) {
			$facts[] = array(
				'label' => __( 'Total units', 'estat-os' ),
				'value' => number_format_i18n( (int) $p['total_units'] ),
			);
		}
		if ( (int) ( $p['available_units'] ?? 0 ) > 0 ) {
			$facts[] = array(
				'label' => __( 'Units available', 'estat-os' ),
				'value' => number_format_i18n( (int) $p['available_units'] ),
				'note'  => __( 'How many the office can show you today.', 'estat-os' ),
			);
		}
		if ( ! empty( $p['regulatory_id'] ) ) {
			$facts[] = array(
				'label' => __( 'Registration number', 'estat-os' ),
				'value' => (string) $p['regulatory_id'],
				'note'  => __( 'The number the project is registered under with the regulator.', 'estat-os' ),
			);
		}

		$grid = Components::fact_grid( $facts );
		if ( '' === $grid ) {
			return '';
		}

		return $grid;
	}

	/**
	 * Description — the office's own words, shortened on screen but never in
	 * the document.
	 *
	 * @param int $project_id Project ID.
	 * @return string
	 */
	private static function block_description( int $project_id ): string {
		$raw = (string) ( self::$project['description'] ?? '' );
		if ( '' === trim( wp_strip_all_tags( $raw ) ) ) {
			return '';
		}

		$clean = PublicText::prose( $raw );
		if ( '' === trim( wp_strip_all_tags( $clean ) ) ) {
			return '';
		}

		$html = Components::read_more(
			'<div class="estat-prose">' . wp_kses_post( wpautop( $clean ) ) . '</div>',
			'estat-project-description-panel',
			260
		);

		if ( '' === $html ) {
			return '';
		}

		return $html;
	}

	/**
	 * Gallery — every photograph the record holds, inspectable.
	 *
	 * @param int $project_id Project ID.
	 * @return string
	 */
	private static function block_gallery( int $project_id ): string {
		$ids = array_values( array_filter( array_map( 'absint', (array) ( self::$project['gallery'] ?? array() ) ) ) );
		if ( ! $ids ) {
			return '';
		}

		$photos = array();
		foreach ( $ids as $photo_id ) {
			$src = wp_get_attachment_image_src( $photo_id, 'large' );
			if ( is_array( $src ) && ! empty( $src[0] ) ) {
				$photos[] = array( 'id' => $photo_id, 'url' => (string) $src[0] );
			}
		}
		if ( ! $photos ) {
			return '';
		}

		$out = Components::gallery( $photos, (string) ( self::$project['title'] ?? '' ), false );
		if ( '' === $out ) {
			return '';
		}

		self::$nav_labels['gallery'] = sprintf(
			/* translators: %d: how many photographs. */
			_n( '%d photograph', '%d photographs', count( $photos ), 'estat-os' ),
			count( $photos )
		);

		return $out;
	}

	/**
	 * Floor plans, brochures, film and walkthrough — as cards.
	 *
	 * @param int $project_id Project ID.
	 * @return string
	 */
	private static function block_floor_plans( int $project_id ): string {
		$p = self::$project;

		$plans = array();
		foreach ( array_values( array_filter( array_map( 'absint', (array) ( $p['floor_plans'] ?? array() ) ) ) ) as $plan_id ) {
			$src = wp_get_attachment_image_src( $plan_id, 'large' );
			if ( is_array( $src ) && ! empty( $src[0] ) ) {
				$plans[] = array( 'id' => $plan_id, 'url' => (string) $src[0], 'title' => get_the_title( $plan_id ) );
			}
		}

		$files = array();
		foreach ( array_values( array_filter( array_map( 'absint', (array) ( $p['brochures'] ?? array() ) ) ) ) as $doc_id ) {
			$url = (string) wp_get_attachment_url( $doc_id );
			if ( '' !== $url ) {
				$files[] = array( 'id' => $doc_id, 'title' => get_the_title( $doc_id ), 'url' => $url );
			}
		}

		$cards = array();

		// The film and the walkthrough, when the record has them.
		if ( '' !== (string) ( $p['video_url'] ?? '' ) ) {
			$cards[] = array(
				'kind'  => 'video',
				'label' => __( 'Watch the project film', 'estat-os' ),
				'note'  => __( 'Opens here', 'estat-os' ),
				'url'   => (string) $p['video_url'],
				'icon'  => 'play',
			);
		}
		if ( '' !== (string) ( $p['tour_url'] ?? '' ) ) {
			$cards[] = array(
				'kind'  => 'tour',
				'label' => __( 'Take the 360° tour', 'estat-os' ),
				'note'  => __( 'Opens here', 'estat-os' ),
				'url'   => (string) $p['tour_url'],
				'icon'  => 'compass',
			);
		}
		if ( $files ) {
			$first  = $files[0];
			$count  = count( $files );
			$cards[] = array(
				'kind'  => 'brochure',
				'label' => __( 'View the brochure', 'estat-os' ),
				'note'  => 1 === $count ? __( 'PDF', 'estat-os' ) : sprintf(
					/* translators: %d: how many documents. */
					_n( '%d document', '%d documents', $count, 'estat-os' ),
					$count
				),
				'url'   => (string) $first['url'],
				'icon'  => 'document',
			);
		}
		if ( $plans ) {
			$first   = $plans[0];
			$count   = count( $plans );
			$cards[] = array(
				'kind'  => 'plans',
				'label' => __( 'View the floor plans', 'estat-os' ),
				'note'  => sprintf(
					/* translators: %d: how many plans. */
					_n( '%d plan', '%d plans', $count, 'estat-os' ),
					$count
				),
				'url'   => (string) $first['url'],
				'icon'  => 'floor',
			);
		}

		$bar = Components::media_cards( $cards );
		$out = '';

		if ( '' !== $bar ) {
			$out .= $bar;
		}

		// The plans themselves, as pictures, when there are any.
		if ( $plans ) {
			$out .= '<div class="estat-plan-grid">';
			foreach ( $plans as $plan ) {
				$out .= '<figure class="estat-plan">'
					. '<a href="' . esc_url( $plan['url'] ) . '" target="_blank" rel="noopener">'
					. wp_get_attachment_image(
						(int) $plan['id'],
						'medium_large',
						false,
						array(
							'alt'      => (string) $plan['title'],
							'loading'  => 'lazy',
							'decoding' => 'async',
						)
					)
					. '</a>';
				if ( '' !== (string) $plan['title'] ) {
					$out .= '<figcaption>' . esc_html( (string) $plan['title'] ) . '</figcaption>';
				}
				$out .= '</figure>';
			}
			$out .= '</div>';
		}

		if ( $files && count( $files ) > 1 ) {
			$out .= Components::section_head( __( 'Downloads', 'estat-os' ), '', 'h3' );
			$out .= Components::documents( $files );
		}

		return $out;
	}

	/**
	 * Amenities — the project's amenity terms, grouped and filterable.
	 *
	 * @param int $project_id Project ID.
	 * @return string
	 */
	private static function block_amenities( int $project_id ): string {
		$data   = Components::amenity_groups( $project_id );
		$groups = (array) ( $data['groups'] ?? array() );
		$labels = (array) ( $data['labels'] ?? array() );

		$lines = array_values( array_filter( (array) ( self::$project['highlight_lines'] ?? array() ) ) );

		if ( ! $groups && ! $lines ) {
			return '';
		}

		$out = '';

		/*
		 * The amenity terms, when the project carries any. Groups with
		 * nothing in them are never offered, so the filter is always a
		 * promise the data can keep.
		 */
		if ( $groups ) {
			$total  = 0;
			$counts = array();
			foreach ( $groups as $key => $names ) {
				$counts[ $key ] = count( $names );
				$total         += count( $names );
			}

			$buttons = array(
				array(
					'value' => 'all',
					'label' => (string) ( $labels['all'] ?? __( 'All', 'estat-os' ) ),
					'count' => $total,
				),
			);
			foreach ( $counts as $key => $count ) {
				$buttons[] = array(
					'value' => (string) $key,
					'label' => (string) ( $labels[ $key ] ?? ucfirst( (string) $key ) ),
					'count' => (int) $count,
				);
			}

			$scope = 'estat-amenity-scope-' . (int) $project_id;

			/*
			 * A filter needs at least two real categories to be worth its
			 * place. With one, the button row says "All 3 / Security 3",
			 * which is not a choice — so the amenities are simply listed.
			 */
			if ( count( $groups ) > 1 ) {
				$out .= Components::filter_bar( $buttons, $scope, __( 'Filter the amenities', 'estat-os' ) );
			}
			$out .= '<ul class="estat-checkgrid" id="' . esc_attr( $scope ) . '">';
			foreach ( $groups as $key => $names ) {
				foreach ( $names as $name ) {
					$out .= '<li class="estat-checkgrid-item" data-estat-filter-item="' . esc_attr( (string) $key ) . '">'
						. '<span class="estat-checkgrid-icon" aria-hidden="true">' . Icon::render( Components::icon_for( $name ), 15 ) . '</span>' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						. '<span>' . esc_html( $name ) . '</span></li>';
				}
			}
			$out .= '</ul>';
		}

		if ( $lines ) {
			if ( $groups ) {
				$out .= Components::section_head( __( 'What stands out', 'estat-os' ), sprintf( '%d', count( $lines ) ), 'h3' );
			}
			$out .= Components::highlight_grid( $lines );
		}

		if ( '' === $out ) {
			return '';
		}

		if ( ! $groups ) {
			self::$nav_labels['amenities'] = __( 'What stands out', 'estat-os' );
		}

		return $out;
	}

	/**
	 * Location — the project's own pin, never the office's as a stand-in.
	 *
	 * @param int $project_id Project ID.
	 * @return string
	 */
	private static function block_location( int $project_id ): string {
		$p   = self::$project;
		$lat = (float) ( $p['latitude'] ?? 0 );
		$lng = (float) ( $p['longitude'] ?? 0 );

		$terms = array_values( array_filter( (array) ( $p['locality_terms'] ?? array() ) ) );

		/*
		 * Components::map() falls back to the office's own coordinates when a
		 * record has none. That is right for a property, where "roughly where
		 * we work" is still useful, and wrong for a project: it would pin an
		 * office marker on a development that is somewhere else entirely. So
		 * the map is drawn only when the project carries its own point.
		 */
		$map = ( 0.0 !== $lat && 0.0 !== $lng )
			? Components::map( $lat, $lng, (string) $p['title'] )
			: '';

		$address = PublicText::clean( (string) ( $p['address'] ?? '' ) );
		$areas   = array_values( array_filter( array_map( 'strval', (array) ( $p['locality'] ?? array() ) ) ) );

		if ( '' === $map && ! $terms && '' === $address && ! $areas ) {
			return '';
		}

		$out = '';

		if ( '' !== $map ) {
			$out .= '<div class="estat-location-map">' . $map;
			if ( 0.0 !== $lat && 0.0 !== $lng ) {
				$out .= '<a class="estat-btn is-ghost estat-map-open" href="' . esc_url( 'https://www.openstreetmap.org/?mlat=' . rawurlencode( (string) $lat ) . '&mlon=' . rawurlencode( (string) $lng ) . '#map=16/' . rawurlencode( (string) $lat ) . '/' . rawurlencode( (string) $lng ) ) . '" target="_blank" rel="noopener">'
					. Icon::render( 'external', 15 ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					. esc_html__( 'Open a larger map', 'estat-os' )
					. '</a>';
			}
			$out .= '</div>';
		}

		$out .= '<dl class="estat-location-facts">';
		if ( $areas ) {
			$out .= '<div><dt>' . esc_html__( 'Locality', 'estat-os' ) . '</dt><dd>' . esc_html( implode( ', ', $areas ) ) . '</dd></div>';
		}
		if ( '' !== $address ) {
			$out .= '<div><dt>' . esc_html__( 'Address', 'estat-os' ) . '</dt><dd>' . esc_html( $address ) . '</dd></div>';
		}
		$count = Projects::listing_count( $project_id );
		if ( $count > 0 ) {
			$out .= '<div><dt>' . esc_html__( 'Properties here', 'estat-os' ) . '</dt><dd>' . esc_html(
				sprintf(
					/* translators: %d: number of properties. */
					_n( '%d property listed by our office', '%d properties listed by our office', $count, 'estat-os' ),
					$count
				)
			) . '</dd></div>';
		}
		$out .= '</dl>';

		if ( $terms ) {
			$out .= '<ul class="estat-locality-links">';
			foreach ( $terms as $term ) {
				if ( ! $term instanceof \WP_Term ) {
					continue;
				}
				$link = get_term_link( $term );
				if ( is_wp_error( $link ) ) {
					continue;
				}
				$out .= '<li><a href="' . esc_url( (string) $link ) . '">'
					. Icon::render( 'map-pin', 15 ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					. '<span>' . esc_html(
						sprintf(
							/* translators: %s: the locality name. */
							__( 'Explore %s', 'estat-os' ),
							$term->name
						)
					) . '</span>'
					. '<span class="estat-muted">' . esc_html(
						sprintf(
							/* translators: %d: number of properties in the locality. */
							_n( '%d property', '%d properties', (int) $term->count, 'estat-os' ),
							(int) $term->count
						)
					) . '</span>'
					. Icon::render( 'arrow-right', 15 ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					. '</a></li>';
			}
			$out .= '</ul>';
		}

		return $out;
	}

	/**
	 * Units — the properties inside this project, narrowed without a reload.
	 *
	 * @param int $project_id Project ID.
	 * @return string
	 */
	private static function block_units( int $project_id ): string {
		$ids = get_posts(
			array(
				'post_type'      => PostTypes::LISTING,
				'post_status'    => 'publish',
				'posts_per_page' => 24,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_key'       => '_estat_project_id',
				'meta_value'     => $project_id,
			)
		);

		if ( ! $ids ) {
			return '';
		}

		/*
		 * Group the properties by what the record actually says about each
		 * one. A group with nothing in it is never offered, so this is never
		 * a filter that returns an empty grid.
		 */
		$buckets = array();
		$cards   = array();
		foreach ( $ids as $listing_id ) {
			$card = Components::card( (int) $listing_id );
			if ( '' === $card ) {
				continue;
			}

			$availability = (string) get_post_meta( (int) $listing_id, '_estat_availability', true );
			$type         = (string) get_post_meta( (int) $listing_id, '_estat_property_type', true );

			$key = '' !== $availability ? $availability : 'other';

			$buckets[ $key ][] = (int) $listing_id;
			if ( '' !== $type ) {
				$buckets[ 'type:' . $type ][] = (int) $listing_id;
			}

			$groups        = array( 'all', $key );
			if ( '' !== $type ) {
				$groups[] = 'type:' . $type;
			}

			$cards[ (int) $listing_id ] = array(
				'html'   => $card,
				'groups' => implode( ' ', $groups ),
			);
		}

		if ( ! $cards ) {
			return '';
		}

		$total = count( $cards );
		$scope = 'estat-units-scope-' . (int) $project_id;

		$buttons = array(
			array(
				'value' => 'all',
				'label' => __( 'All', 'estat-os' ),
				'count' => $total,
			),
		);

		$availability_labels = method_exists( Vocabulary::class, 'availability' ) ? Vocabulary::availability() : array();
		foreach ( $buckets as $key => $members ) {
			if ( 'all' === $key || 0 === strpos( (string) $key, 'type:' ) ) {
				continue;
			}

			/*
			 * Only an availability the office actually recorded is offered
			 * as a filter. A property with nothing in that field is still
			 * listed under "All" — it is simply not given a state on the
			 * strength of a guess.
			 */
			if ( ! isset( $availability_labels[ $key ] ) ) {
				continue;
			}

			$buttons[] = array(
				'value' => (string) $key,
				'label' => (string) $availability_labels[ $key ],
				'count' => count( array_intersect( $members, array_keys( $cards ) ) ),
			);
		}

		// Property types only when there is more than one kind here.
		$types = array();
		foreach ( $buckets as $key => $members ) {
			if ( 0 === strpos( (string) $key, 'type:' ) ) {
				$types[ substr( (string) $key, 5 ) ] = count( array_intersect( $members, array_keys( $cards ) ) );
			}
		}
		if ( count( $types ) > 1 ) {
			$type_labels = method_exists( Vocabulary::class, 'property_types' ) ? Vocabulary::property_types() : array();
			foreach ( $types as $type => $count ) {
				$buttons[] = array(
					'value' => 'type:' . $type,
					'label' => (string) ( $type_labels[ $type ] ?? ucfirst( str_replace( '_', ' ', (string) $type ) ) ),
					'count' => (int) $count,
				);
			}
		}

		$out = Components::filter_bar( $buttons, $scope, __( 'Filter the properties in this project', 'estat-os' ) );
		$out .= '<div class="estat-grid" id="' . esc_attr( $scope ) . '">';
		foreach ( $cards as $listing_id => $card ) {
			$out .= '<div class="estat-grid-cell" data-estat-filter-item="' . esc_attr( $card['groups'] ) . '">' . $card['html'] . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		self::$nav_labels['units'] = sprintf(
			/* translators: %d: number of properties. */
			_n( '%d property', '%d properties', $total, 'estat-os' ),
			$total
		);

		$listed = Projects::listing_count( $project_id );
		if ( $listed > count( $cards ) ) {
			$out .= '<p class="estat-section-more">'
				. '<a class="estat-btn is-ghost" href="' . esc_url( add_query_arg( 'project_id', $project_id, Pages::get_url( 'properties' ) ) ) . '">'
				. esc_html(
					sprintf(
						/* translators: %d: number of properties. */
						_n( 'See the %d property', 'See all %d properties', $listed, 'estat-os' ),
						$listed
					)
				)
				. '</a></p>';
		}

		return $out;
	}

	/**
	 * Share — three actions, not a wall of buttons.
	 *
	 * @param int $project_id Project ID.
	 * @return string
	 */
	private static function block_share( int $project_id ): string {
		$out = Components::share_actions( (string) get_permalink( $project_id ), (string) ( self::$project['title'] ?? '' ) );
		if ( '' === $out ) {
			return '';
		}
		return $out;
	}

	/**
	 * Enquiry — the project in one line, then the office's own form.
	 *
	 * @param int $project_id Project ID.
	 * @return string
	 */
	private static function block_enquiry( int $project_id ): string {
		$form = Components::enquiry_form( 0 );
		if ( '' === trim( $form ) ) {
			return '';
		}

		$p = self::$project;

		$bits = array_filter(
			array(
				(string) ( $p['stage_label'] ?? '' ),
				(string) ( $p['price_display'] ?? '' ),
				'' !== (string) ( $p['possession_date'] ?? '' ) ? Format::month_year( (string) $p['possession_date'] ) : '',
			)
		);

		$out = '<div class="estat-enquiry" id="estat-enquiry" data-estat-enquiry>';
		$out .= '<div class="estat-enquiry-context">';
		$out .= '<p class="estat-enquiry-title">'
			. esc_html(
				sprintf(
					/* translators: %s: the project name. */
					__( 'Interested in %s?', 'estat-os' ),
					(string) $p['title']
				)
			) . '</p>';
		if ( $bits ) {
			$out .= '<p class="estat-enquiry-sub">' . esc_html( implode( ' · ', $bits ) ) . '</p>';
		}
		$out .= '</div>';

		$out .= '<div class="estat-enquiry-form">' . $form . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		$out .= '<div class="estat-enquiry-sent" hidden>'
			. '<span class="estat-enquiry-tick" aria-hidden="true">' . Icon::render( 'check-circle', 26 ) . '</span>' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			. '<p class="estat-enquiry-sent-title">' . esc_html__( 'Thanks — your enquiry has been received.', 'estat-os' ) . '</p>'
			. '<p class="estat-enquiry-sent-note">' . esc_html__( 'Our team will get back to you shortly.', 'estat-os' ) . '</p>'
			. '<button type="button" class="estat-btn is-ghost" data-estat-enquiry-again>' . esc_html__( 'Send another enquiry', 'estat-os' ) . '</button>'
			. '</div>';

		$out .= '</div>';

		return $out;
	}

	/**
	 * The bar that follows a phone screen.
	 *
	 * Desktop never sees it. It stops above the home gesture and it is never
	 * drawn when there is nothing to put in it.
	 *
	 * @param int $project_id Project ID.
	 * @return string
	 */
	private static function mobile_bar( int $project_id ): string {
		$actions = array();

		$wa = WhatsApp::button( $project_id, __( 'WhatsApp', 'estat-os' ) );
		if ( '' !== $wa && WhatsApp::enabled() ) {
			$actions[] = array(
				'kind'  => 'wa',
				'label' => __( 'WhatsApp', 'estat-os' ),
				'url'   => 'https://wa.me/' . WhatsApp::number() . '?text=' . rawurlencode( WhatsApp::message( $project_id ) ),
			);
		}

		if ( self::has_block( 'enquiry' ) ) {
			$actions[] = array(
				'kind'  => 'enquire',
				'label' => __( 'Enquire', 'estat-os' ),
				'url'   => '#estat-section-enquiry',
			);
		}

		if ( ! $actions ) {
			return '';
		}

		return Components::mobile_actions( $actions );
	}

	/**
	 * Is a block switched on in the office's Page blocks setting?
	 *
	 * @param string $id Block id.
	 * @return bool
	 */
	private static function has_block( string $id ): bool {
		foreach ( Templates::get_blocks( 'project' ) as $block ) {
			if ( (string) ( $block['id'] ?? '' ) === $id ) {
				return ! empty( $block['enabled'] );
			}
		}
		return false;
	}
}
