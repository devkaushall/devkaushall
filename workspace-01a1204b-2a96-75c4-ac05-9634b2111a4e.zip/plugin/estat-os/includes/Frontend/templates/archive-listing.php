<?php
/**
 * Properties archive — /properties/ — the office's directory.
 *
 * Wrapper: <main class="estat-public estat-properties"><div class="estat-container">
 *
 * The card markup used to be written out again here, a fifth copy of the same
 * forty lines. It is drawn by Components::card() now — the same component the
 * search page, the shortcode, the Elementor widget and the project page use —
 * so a property looks identical wherever a customer meets it.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

use EstatOS\Frontend\Components;

defined( 'ABSPATH' ) || exit;

wp_enqueue_style( 'estat-public' );
wp_enqueue_script( 'estat-public' );

get_header();

/*
 * The count used to come from running the whole property search a second
 * time, on top of the query WordPress had already run to build this page.
 * The main query already knows the answer.
 */
$total = isset( $GLOBALS['wp_query'] ) ? (int) $GLOBALS['wp_query']->found_posts : 0;
?>
<main class="estat-public estat-properties" id="main">
<div class="estat-container">
	<header class="estat-page-head">
		<?php
		echo Components::breadcrumbs( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			array(
				array( 'label' => __( 'Home', 'estat-os' ), 'url' => home_url( '/' ) ),
				array( 'label' => __( 'Properties', 'estat-os' ), 'url' => '' ),
			)
		);
		?>
		<h1><?php esc_html_e( 'Properties', 'estat-os' ); ?></h1>
		<?php if ( $total > 0 ) : ?>
			<p class="estat-page-sub">
				<?php echo esc_html( sprintf( _n( '%d property', '%d properties', $total, 'estat-os' ), $total ) ); ?>
			</p>
		<?php endif; ?>
	</header>

	<?php echo Components::search_form(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

	<?php if ( have_posts() ) : ?>
		<div class="estat-grid">
			<?php
			while ( have_posts() ) :
				the_post();
				echo Components::card( (int) get_the_ID() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			endwhile;
			?>
		</div>
		<?php the_posts_pagination(); ?>
	<?php else : ?>
		<?php
		echo Components::empty_state( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			__( 'No properties found', 'estat-os' ),
			__( 'Nothing is live at the moment. Try widening your search, or call the office and we will find it for you.', 'estat-os' ),
			'home',
			'<a class="estat-btn is-ghost" href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Back to the home page', 'estat-os' ) . '</a>'
		);
		?>
	<?php endif; ?>
</div>
</main>
<?php
get_footer();
