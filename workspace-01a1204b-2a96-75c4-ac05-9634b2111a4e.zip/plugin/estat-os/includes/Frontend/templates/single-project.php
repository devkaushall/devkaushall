<?php
/**
 * Single project — /project/{slug}/ — one society, drawn as a page.
 *
 * This file is deliberately thin. It decides nothing about the layout: it
 * loads the record, hands it to ProjectPage, and ProjectPage asks the office's
 * own block order (Page blocks → project) what to draw and in what order.
 *
 * Everything the page prints comes from the project record. Everything the
 * office typed goes through the public/internal firewall on the way out, so a
 * note about the source sheet stays in the office and never reaches a customer.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

use EstatOS\Frontend\Components;
use EstatOS\Frontend\ProjectPage;

defined( 'ABSPATH' ) || exit;

wp_enqueue_style( 'estat-public' );
wp_enqueue_script( 'estat-public' );

get_header();

while ( have_posts() ) :
	the_post();
	$id   = (int) get_the_ID();
	$body = ProjectPage::render( $id );
	?>
<main class="estat-public estat-project estat-project-page" id="main">
<div class="estat-container">
	<?php
	if ( '' !== trim( $body ) ) {
		echo $body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- every block is escaped where it is built.
	} else {
		echo Components::empty_state( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			__( 'This project has no details yet', 'estat-os' ),
			__( 'Call the office and we will tell you everything about it.', 'estat-os' ),
			'buildings'
		);
	}
	?>
</div>
</main>
	<?php
endwhile;

get_footer();
