<?php
/**
 * Projects archive — /projects/ — the curated directory.
 *
 * A directory, not a list: the page says what it is, offers the filters the
 * project records can actually answer, and shows the projects as cards built
 * by the same component the shortcode and the Elementor page use, so the three
 * cannot drift apart.
 *
 * Filter state lives in the query string, so a filtered page is linkable,
 * shareable and indexable exactly as it was before — no JavaScript, no new
 * rewrite rules and no change to any existing URL. Results are drawn by
 * Components::projects_directory() whether or not a filter is set, so
 * pagination behaves the same way on page 1 and page 9.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

use EstatOS\Frontend\Components;

defined( 'ABSPATH' ) || exit;

wp_enqueue_style( 'estat-public' );
wp_enqueue_script( 'estat-public' );

get_header();

$filters = Components::project_filters_from_request();
?>
<main class="estat-public estat-projects estat-projects-archive" id="main">
<div class="estat-container">

	<header class="estat-page-head estat-projects-head">
		<?php
		echo Components::breadcrumbs( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			array(
				array( 'label' => __( 'Home', 'estat-os' ), 'url' => home_url( '/' ) ),
				array( 'label' => __( 'Projects', 'estat-os' ), 'url' => '' ),
			)
		);
		?>
		<h1><?php esc_html_e( 'Societies and projects', 'estat-os' ); ?></h1>
		<p class="estat-page-sub">
			<?php esc_html_e( 'Selected societies and developments listed by our office. Open a project for its stage, the unit types it offers, its price range, and the homes we currently have inside it.', 'estat-os' ); ?>
		</p>
	</header>

	<?php
	echo Components::projects_directory( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		array_merge( array( 'filters' => true ), $filters )
	);
	?>

</div>
</main>
<?php
get_footer();
