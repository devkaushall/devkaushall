<?php
/**
 * Locality archive — /locality/{slug}/
 *
 * Wrapper: <main class="estat-public estat-locality"><div class="estat-container">
 *
 * A locality page is one of the most useful pages the site has: it answers
 * "what is in this area?" for a buyer and it is the page a search engine
 * treats as an area page. It now shows the properties and the projects with
 * the same cards used everywhere else, so the answer looks like the rest of
 * the site instead of a bare list of links.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

use EstatOS\Data\PostTypes;
use EstatOS\Data\Taxonomies;
use EstatOS\Frontend\Components;
use EstatOS\Support\Icon;

defined( 'ABSPATH' ) || exit;

$term     = get_queried_object();
$term     = ( $term instanceof \WP_Term ) ? $term : null;
$term_id  = $term ? (int) $term->term_id : 0;
$term_name = $term ? $term->name : __( 'Locality', 'estat-os' );

wp_enqueue_style( 'estat-public' );
wp_enqueue_script( 'estat-public' );

get_header();

$project_ids = $term_id
	? get_posts(
		array(
			'post_type'      => PostTypes::PROJECT,
			'post_status'    => 'publish',
			'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery
				array(
					'taxonomy' => Taxonomies::LOCALITY,
					'field'    => 'term_id',
					'terms'    => $term_id,
				),
			),
			'posts_per_page' => 24,
			'fields'         => 'ids',
			'no_found_rows'  => true,
		)
	)
	: array();
?>
<main class="estat-public estat-locality" id="main">
<div class="estat-container">
	<header class="estat-page-head">
		<?php
		echo Components::breadcrumbs( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			array(
				array( 'label' => __( 'Home', 'estat-os' ), 'url' => home_url( '/' ) ),
				array( 'label' => __( 'Localities', 'estat-os' ), 'url' => (string) get_post_type_archive_link( PostTypes::LISTING ) ),
				array( 'label' => $term_name, 'url' => '' ),
			)
		);
		?>
		<h1><?php echo esc_html( $term_name ); ?></h1>
		<?php if ( $term ) : ?>
			<p class="estat-page-sub">
				<?php
				echo esc_html(
					sprintf(
						/* translators: %d: number of properties in this locality. */
						_n( '%d property', '%d properties', (int) $term->count, 'estat-os' ),
						(int) $term->count
					)
				);
				?>
			</p>
		<?php endif; ?>
	</header>

	<?php if ( $term && ! empty( $term->description ) ) : ?>
		<div class="estat-prose estat-section">
			<?php echo wp_kses_post( wpautop( $term->description ) ); ?>
		</div>
	<?php endif; ?>

	<?php if ( have_posts() ) : ?>
		<?php echo Components::section_head( __( 'Properties in this locality', 'estat-os' ) ); ?>
		<div class="estat-grid">
			<?php
			while ( have_posts() ) :
				the_post();
				echo Components::card( (int) get_the_ID() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			endwhile;
			?>
		</div>
		<?php the_posts_pagination(); ?>
	<?php endif; ?>

	<?php if ( $project_ids ) : ?>
		<section class="estat-section">
			<?php
			echo Components::section_head( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				__( 'Projects in this locality', 'estat-os' ),
				sprintf(
					/* translators: %d: number of projects. */
					_n( '%d project', '%d projects', count( $project_ids ), 'estat-os' ),
					count( $project_ids )
				)
			);
			echo Components::project_grid( array_map( 'intval', (array) $project_ids ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			?>
		</section>
	<?php endif; ?>

	<?php if ( ! have_posts() && ! $project_ids ) : ?>
		<?php
		echo Components::empty_state( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			__( 'Nothing in this locality yet', 'estat-os' ),
			__( 'We have no properties or projects listed here at the moment. Call the office and we will tell you what is coming up.', 'estat-os' ),
			'map-pin',
			'<a class="estat-btn is-ghost" href="' . esc_url( (string) get_post_type_archive_link( PostTypes::PROJECT ) ) . '">' . esc_html__( 'See all projects', 'estat-os' ) . '</a>'
		);
		?>
	<?php endif; ?>
</div>
</main>
<?php
get_footer();
