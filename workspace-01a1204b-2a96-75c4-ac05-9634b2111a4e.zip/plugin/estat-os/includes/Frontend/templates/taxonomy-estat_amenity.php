<?php
/**
 * Amenity archive.
 *
 * The card markup here was the same forty lines written out a fourth and
 * fifth time. It is Components::card() now, so an amenity page, a feature
 * page, the properties archive and the search results all show one property
 * the same way.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

use EstatOS\Data\PostTypes;
use EstatOS\Frontend\Components;

defined( 'ABSPATH' ) || exit;

$term      = get_queried_object();
$term      = ( $term instanceof \WP_Term ) ? $term : null;
$term_name = $term ? $term->name : __( 'Amenity', 'estat-os' );

wp_enqueue_style( 'estat-public' );
wp_enqueue_script( 'estat-public' );

get_header();
?>
<main class="estat-public estat-amenity" id="main">
<div class="estat-container">
	<header class="estat-page-head">
		<?php
		echo Components::breadcrumbs( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			array(
				array( 'label' => __( 'Home', 'estat-os' ), 'url' => home_url( '/' ) ),
				array( 'label' => __( 'Properties', 'estat-os' ), 'url' => (string) get_post_type_archive_link( PostTypes::LISTING ) ),
				array( 'label' => $term_name, 'url' => '' ),
			)
		);
		?>
		<h1><?php echo esc_html( $term_name ); ?></h1>
		<?php if ( $term ) : ?>
			<p class="estat-page-sub">
				<?php
				echo esc_html(
					sprintf(
						/* translators: %d: number of properties. */
						_n( '%d property', '%d properties', (int) $term->count, 'estat-os' ),
						(int) $term->count
					)
				);
				?>
			</p>
		<?php endif; ?>
	</header>

	<?php if ( $term && ! empty( $term->description ) ) : ?>
		<div class="estat-prose estat-section">
			<?php echo wp_kses_post( wpautop( $term->description ) ); ?>
		</div>
	<?php endif; ?>

	<?php if ( have_posts() ) : ?>
		<?php echo Components::section_head( __( 'Properties', 'estat-os' ) ); ?>
		<div class="estat-grid">
			<?php
			while ( have_posts() ) :
				the_post();
				echo Components::card( (int) get_the_ID() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			endwhile;
			?>
		</div>
		<?php the_posts_pagination(); ?>
	<?php else : ?>
		<?php
		echo Components::empty_state( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			__( 'No properties found', 'estat-os' ),
			__( 'Nothing carries this right now. Try widening your search, or call the office.', 'estat-os' ),
			'home',
			'<a class="estat-btn is-ghost" href="' . esc_url( (string) get_post_type_archive_link( PostTypes::LISTING ) ) . '">' . esc_html__( 'See all properties', 'estat-os' ) . '</a>'
		);
		?>
	<?php endif; ?>
</div>
</main>
<?php
get_footer();
