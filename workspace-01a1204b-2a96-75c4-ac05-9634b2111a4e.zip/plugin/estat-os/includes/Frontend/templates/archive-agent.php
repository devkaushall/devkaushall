<?php
/**
 * Team directory — /agents/
 *
 * This page used to print an H1 and a grid with no container, so it ran
 * edge to edge while every sibling page sat inside the same measure. It is
 * wrapped now, and it carries the same breadcrumb, header and heading
 * rhythm as the properties and projects pages.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

use EstatOS\Frontend\Components;

defined( 'ABSPATH' ) || exit;

wp_enqueue_style( 'estat-public' );
wp_enqueue_script( 'estat-public' );

get_header();
?>
<main class="estat-public estat-agents" id="main">
<div class="estat-container">
	<header class="estat-page-head">
		<?php
		echo Components::breadcrumbs( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			array(
				array( 'label' => __( 'Home', 'estat-os' ), 'url' => home_url( '/' ) ),
				array( 'label' => __( 'Our team', 'estat-os' ), 'url' => '' ),
			)
		);
		?>
		<h1><?php esc_html_e( 'Our team', 'estat-os' ); ?></h1>
		<p class="estat-page-sub"><?php esc_html_e( 'The people who will take your call, show you the property and see the paperwork through.', 'estat-os' ); ?></p>
	</header>

	<?php echo Components::agents( 60 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
</div>
</main>
<?php
get_footer();
