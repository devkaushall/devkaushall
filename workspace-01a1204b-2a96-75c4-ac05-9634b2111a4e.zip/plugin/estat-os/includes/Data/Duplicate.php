<?php
/**
 * Duplicate and near-duplicate detection.
 *
 * One question answered once, for the whole plugin: "is this the same
 * thing as something the office already has?"
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Data;

use EstatOS\Audit\AuditLog;
use EstatOS\Support\Sanitize;

defined( 'ABSPATH' ) || exit;

/**
 * Decides whether two records are the same property, unit, society or project.
 *
 * The answer is reached in one place only. The add-property screen, the
 * societies screen, the phone and the CSV import all ask the same question
 * here, so a record can never be a duplicate on one door and not on another.
 *
 * Nothing here blocks anybody. The engine says how alike two records look and
 * why; what the office then does with that — keep both, or move one to the
 * bin — is a decision a person makes, and it is written down.
 *
 * The comparison does not lean on the name alone. A name is how offices
 * avoid saying the same thing twice ("3 BHK Sector 49" and "Three bedroom,
 * Sector-49, Gurgaon" are one flat), and it is also the field most often
 * typed differently. So the name, the area, the size, the rooms, the money
 * and what the description actually says are each weighed, and a verdict is
 * only reached when they agree with one another.
 */
final class Duplicate {

	/** Stored verdict: how alike, 0-100. */
	public const META_SCORE = '_estat_duplicate_score';

	/** Stored verdict: the record it looks like. */
	public const META_OF = '_estat_duplicate_of';

	/** Stored verdict: same / near / maybe. */
	public const META_BAND = '_estat_duplicate_band';

	/** Stored verdict: why, as reason keys. */
	public const META_WHY = '_estat_duplicate_reasons';

	/** What the office decided: '' (open), 'kept' or 'binned'. */
	public const META_DECIDED = '_estat_duplicate_decided';

	/** When the verdict was last worked out. */
	public const META_SEEN = '_estat_duplicate_seen';

	/** Looks like the same record. */
	public const BAND_SAME = 'same';

	/** Very similar — almost certainly the same, worth stopping for. */
	public const BAND_NEAR = 'near';

	/** Worth a look, but said quietly and never in the way. */
	public const BAND_MAYBE = 'maybe';

	/**
	 * Scores at or above these are called the band.
	 *
	 * Deliberately spaced so that an office is stopped only when the evidence
	 * agrees on more than one thing: a name on its own never reaches 'near',
	 * and neither does a price.
	 */
	private const SAME_AT  = 85;
	private const NEAR_AT  = 65;
	private const MAYBE_AT = 45;

	/**
	 * Records at or below this many are simply all compared with one another.
	 *
	 * Blocking exists for offices with tens of thousands of properties; below
	 * this size the honest answer is cheaper than a clever one.
	 */
	private const ALL_AT_ONCE = 500;

	/**
	 * Fingerprints already worked out during this page.
	 *
	 * A spreadsheet asks the same question once per row, and most of the
	 * records it asks about are the same ones every time. Remembering what a
	 * record looks like saves the reading, not the deciding.
	 *
	 * @var array<string,array<string,mixed>>
	 */
	private static $known = array();

	/**
	 * Candidate lists already gathered during this page.
	 *
	 * Held only while nothing has been added, because a record created a
	 * moment ago is exactly the one a later row may be a duplicate of —
	 * which is why an import clears this the moment it writes something.
	 *
	 * @var array<string,int[]>
	 */
	private static $looked_up = array();

	/**
	 * Words that mean the same thing on two different sheets.
	 *
	 * @var array<string,string>
	 */
	private const SYNONYMS = array(
		'flats'       => 'apartment',
		'flat'        => 'apartment',
		'appartment'  => 'apartment',
		'apartments'  => 'apartment',
		'sec'         => 'sector',
		'sect'        => 'sector',
		'secr'        => 'sector',
		'gurugram'    => 'gurgaon',
		'bengaluru'   => 'bangalore',
		'bombay'      => 'mumbai',
		'noidagrater' => 'noida',
		'builder'     => 'builderfloor',
		'independent' => 'independent',
		'sft'         => 'sqft',
		'sqft'        => 'sqft',
		'sqyard'      => 'sqyard',
		'sqyards'     => 'sqyard',
	);

	/**
	 * Words every listing uses and none of them mean.
	 *
	 * @var string[]
	 */
	private const NOISE = array(
		'a', 'an', 'the', 'in', 'on', 'at', 'for', 'of', 'and', 'or', 'to',
		'with', 'near', 'is', 'are', 'was', 'this', 'that', 'it', 'very',
		'new', 'ready', 'available', 'immediate', 'please', 'call', 'contact',
		'property', 'properties', 'home', 'homes', 'unit', 'units', 'sale',
		'buy', 'buying', 'best', 'good', 'nice', 'great', 'excellent', 'only',
		'urgent', 'direct', 'owner', 'deal', 'option', 'options',
	);

	/* ----------------------------------------------------------------- *
	 * Words the office reads
	 * ----------------------------------------------------------------- */

	/**
	 * The three bands, in the words the office sees.
	 *
	 * @return array<string,array<string,string>>
	 */
	public static function bands(): array {
		return array(
			self::BAND_SAME  => array(
				'label' => __( 'Looks like the same one', 'estat-os' ),
				'hint'  => __( 'The name, the area and the details all agree. Two of these on the website is one too many.', 'estat-os' ),
			),
			self::BAND_NEAR  => array(
				'label' => __( 'Very similar', 'estat-os' ),
				'hint'  => __( 'Enough is the same that it is worth opening the other one before this goes any further.', 'estat-os' ),
			),
			self::BAND_MAYBE => array(
				'label' => __( 'Worth a look', 'estat-os' ),
				'hint'  => __( 'Something matches, something does not. Said here and nowhere else — nothing is held up by it.', 'estat-os' ),
			),
		);
	}

	/**
	 * The reasons, in the words the office sees.
	 *
	 * @return array<string,string>
	 */
	public static function reason_words(): array {
		return array(
			'name'    => __( 'The names are almost the same', 'estat-os' ),
			'area'    => __( 'The same area', 'estat-os' ),
			'map'     => __( 'The map pins are within a few steps of each other', 'estat-os' ),
			'size'    => __( 'The same size', 'estat-os' ),
			'rooms'   => __( 'The same rooms', 'estat-os' ),
			'money'   => __( 'The same money', 'estat-os' ),
			'kind'    => __( 'The same kind of property', 'estat-os' ),
			'details' => __( 'The same details', 'estat-os' ),
			'meaning' => __( 'The description says the same thing', 'estat-os' ),
			'builder' => __( 'The same builder', 'estat-os' ),
			'units'   => __( 'The same number of units', 'estat-os' ),
			'handed'  => __( 'Handed over at the same time', 'estat-os' ),
		);
	}

	/**
	 * Which band a score falls in.
	 *
	 * @param int $score 0-100.
	 * @return string 'same', 'near', 'maybe' or ''.
	 */
	public static function band( int $score ): string {
		if ( $score >= self::SAME_AT ) {
			return self::BAND_SAME;
		}
		if ( $score >= self::NEAR_AT ) {
			return self::BAND_NEAR;
		}
		if ( $score >= self::MAYBE_AT ) {
			return self::BAND_MAYBE;
		}
		return '';
	}

	/**
	 * Does this band stop anybody? 'Worth a look' never does.
	 *
	 * @param string $band Band key.
	 * @return bool
	 */
	public static function stops( string $band ): bool {
		return self::BAND_SAME === $band || self::BAND_NEAR === $band;
	}

	/* ----------------------------------------------------------------- *
	 * Reading a record into something comparable
	 * ----------------------------------------------------------------- */

	/**
	 * Fold a piece of text down to the words that carry meaning.
	 *
	 * @param string $text Any text.
	 * @return string Lower-case words, synonyms folded, noise gone.
	 */
	public static function normalise( string $text ): string {
		$text = html_entity_decode( strip_tags( $text ), ENT_QUOTES, 'UTF-8' );
		$text = mb_strtolower( $text );
		$text = (string) preg_replace( '/[^a-z0-9]+/u', ' ', $text );
		// "3bhk" and "3 BHK" are the same three letters.
		$text = (string) preg_replace( '/([0-9]+)\s*(bhk|sqft|sqyard|sqm)/u', '$1 $2', $text );

		return trim( (string) preg_replace( '/\s+/u', ' ', $text ) );
	}

	/**
	 * The meaningful words of a piece of text.
	 *
	 * @param string $text Any text.
	 * @return string[]
	 */
	public static function tokens( string $text ): array {
		$words = explode( ' ', self::normalise( $text ) );
		$out   = array();

		foreach ( $words as $word ) {
			if ( '' === $word ) {
				continue;
			}
			if ( isset( self::SYNONYMS[ $word ] ) ) {
				$word = self::SYNONYMS[ $word ];
			}
			if ( in_array( $word, self::NOISE, true ) ) {
				continue;
			}
			$out[] = $word;
		}

		return $out;
	}

	/**
	 * A number written in a name: "Sector 49", "S-49", "Sec 49".
	 *
	 * @param string $text Any text.
	 * @return string '' when no sector is named.
	 */
	public static function sector_of( string $text ): string {
		$t = self::normalise( $text );
		if ( preg_match( '/sector[^0-9]{0,3}([0-9]{1,3})/u', $t, $m ) ) {
			return (string) (int) $m[1];
		}
		if ( preg_match( '/\bs\s?([0-9]{1,3})\b/u', $t, $m ) ) {
			return (string) (int) $m[1];
		}
		return '';
	}

	/**
	 * The comparable shape of a record.
	 *
	 * Both a row that has not been saved yet (from a form or a CSV line) and
	 * a record already in the office are folded into this same shape, so the
	 * comparison below has nothing to know about where its two sides came
	 * from.
	 *
	 * @param array<string,mixed> $record Record parts under their short names.
	 * @return array<string,mixed>
	 */
	public static function fingerprint( array $record ): array {
		$title = (string) ( $record['title'] ?? '' );
		$text  = trim( (string) ( $record['description'] ?? '' ) . ' ' . (string) ( $record['highlights'] ?? '' ) );
		$where = trim( (string) ( $record['locality_text'] ?? '' ) . ' ' . (string) ( $record['address'] ?? '' ) );

		/*
		 * Money is read under whichever name the record actually keeps it:
		 * a property has a price, or a monthly rent if it is to let; a
		 * society is advertised as a range, and the bottom of that range is
		 * the figure two societies are compared on.
		 */
		$price = (float) ( $record['price'] ?? 0 );
		if ( $price <= 0 ) {
			$price = (float) ( $record['rent'] ?? 0 );
		}
		if ( $price <= 0 ) {
			$price = (float) ( $record['price_min'] ?? 0 );
		}

		$area = (float) ( $record['area_sqft'] ?? 0 );
		if ( $area <= 0 ) {
			$area = (float) ( $record['area'] ?? 0 );
		}

		$fp = array(
			'id'         => (int) ( $record['id'] ?? 0 ),
			'kind'       => (string) ( $record['kind'] ?? 'listing' ),
			'title'      => $title,
			'title_norm' => self::normalise( $title ),
			'title_tok'  => self::tokens( $title ),
			'text'       => $text,
			'text_norm'  => self::normalise( $text ),
			'text_tok'   => self::tokens( $text ),
			'where_text' => $where,
			'where_tok'  => self::tokens( $where ),
			'locality'   => (string) ( $record['locality'] ?? '' ),
			'sector'     => self::sector_of( $title . ' ' . $where ),
			'lat'        => (float) ( $record['latitude'] ?? 0 ),
			'lng'        => (float) ( $record['longitude'] ?? 0 ),
			'type'       => (string) ( $record['type'] ?? '' ),
			'offer'      => (string) ( $record['offer'] ?? '' ),
			'bedrooms'   => (int) ( $record['bedrooms'] ?? 0 ),
			'bathrooms'  => (int) ( $record['bathrooms'] ?? 0 ),
			'parking'    => (int) ( $record['parking'] ?? 0 ),
			'floor'      => (int) ( $record['floor'] ?? 0 ),
			'facing'     => (string) ( $record['facing'] ?? '' ),
			'furnishing' => (string) ( $record['furnishing'] ?? '' ),
			'area'       => $area,
			'price'      => $price,
			'builder'    => (string) ( $record['developer'] ?? '' ),
			'units'      => (int) ( $record['total_units'] ?? 0 ),
			'handed'     => (string) ( $record['possession_date'] ?? '' ),
			'status'     => (string) ( $record['status'] ?? '' ),
			'url'        => (string) ( $record['url'] ?? '' ),
			'edit'       => (string) ( $record['edit'] ?? '' ),
		);

		$fp['title_digits'] = self::digits_of( $fp['title_norm'] );

		return $fp;
	}

	/**
	 * Fold a record that is already in the office.
	 *
	 * @param string $kind 'listing' or 'project'.
	 * @param int    $post_id Post id.
	 * @return array<string,mixed>
	 */
	public static function from_post( string $kind, int $post_id ): array {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return array();
		}

		$cache_key = $kind . '|' . $post_id;
		if ( isset( self::$known[ $cache_key ] ) ) {
			return self::$known[ $cache_key ];
		}

		$meta = static function ( string $key ) use ( $post_id ) {
			return (string) get_post_meta( $post_id, $key, true );
		};

		if ( 'project' === $kind ) {
			$type       = $meta( '_estat_project_type' );
			$price      = (float) $meta( '_estat_price_min' );
			$locality   = self::locality_slug( $post_id );
			$locality_tx= $meta( '_estat_address' );
			return self::$known[ $cache_key ] = self::fingerprint(
				array(
					'id'             => $post_id,
					'kind'           => 'project',
					'title'          => $post->post_title,
					'description'    => $post->post_content,
					'highlights'     => $meta( '_estat_highlights' ),
					'locality_text'  => $locality_tx,
					'address'        => $locality_tx,
					'locality'       => $locality,
					'latitude'       => (float) $meta( '_estat_latitude' ),
					'longitude'      => (float) $meta( '_estat_longitude' ),
					'type'           => $type,
					'price'          => $price,
					'developer'      => $meta( '_estat_developer' ),
					'total_units'    => (int) $meta( '_estat_total_units' ),
					'possession_date'=> $meta( '_estat_possession_date' ),
					'status'         => $post->post_status,
					'url'            => (string) get_permalink( $post_id ),
					'edit'           => admin_url( 'admin.php?page=estat-projects&edit=' . $post_id ),
				)
			);
		}

		$price = (float) $meta( '_estat_price' );
		$rent  = (float) $meta( '_estat_rent' );
		$where = $meta( '_estat_address' );

		return self::$known[ $cache_key ] = self::fingerprint(
			array(
				'id'             => $post_id,
				'kind'           => 'listing',
				'title'          => $post->post_title,
				'description'    => $post->post_content,
				'locality_text'  => self::locality_names( $post_id ),
				'address'        => $where,
				'locality'       => self::locality_slug( $post_id ),
				'latitude'       => (float) $meta( '_estat_latitude' ),
				'longitude'      => (float) $meta( '_estat_longitude' ),
				'type'           => $meta( '_estat_property_type' ),
				'offer'          => $meta( '_estat_offer' ),
				'bedrooms'       => (int) $meta( '_estat_bedrooms' ),
				'bathrooms'      => (int) $meta( '_estat_bathrooms' ),
				'parking'        => (int) $meta( '_estat_parking' ),
				'floor'          => (int) $meta( '_estat_floor' ),
				'facing'         => $meta( '_estat_facing' ),
				'furnishing'     => $meta( '_estat_furnishing' ),
				'area_sqft'      => (float) $meta( '_estat_area_sqft' ),
				'area'           => (float) $meta( '_estat_area' ),
				'price'          => $price,
				'rent'           => $rent,
				'status'         => $post->post_status,
				'url'            => (string) get_permalink( $post_id ),
				'edit'           => admin_url( 'admin.php?page=estat-listings&edit=' . $post_id ),
			)
		);
	}

	/**
	 * Fold what somebody is about to save — a form, a CSV row, a phone.
	 *
	 * Both the short names a screen posts ("price") and the stored names a
	 * CSV row carries ("_estat_price") are read, because an import and a
	 * person filling in the same box must reach the same answer.
	 *
	 * @param string              $kind 'listing' or 'project'.
	 * @param array<string,mixed> $input Raw input.
	 * @return array<string,mixed>
	 */
	public static function from_input( string $kind, array $input ): array {
		$pick = static function ( string $key, string $default = '' ) use ( $input ) {
			foreach ( array( $key, '_estat_' . $key ) as $name ) {
				if ( isset( $input[ $name ] ) && ! is_array( $input[ $name ] ) ) {
					$value = (string) $input[ $name ];
					if ( '' !== trim( $value ) ) {
						return $value;
					}
				}
			}
			return $default;
		};

		$record = array(
			'kind'            => 'project' === $kind ? 'project' : 'listing',
			'id'              => (int) ( $input['id'] ?? 0 ),
			'title'           => Sanitize::title( $pick( 'title' ) ),
			'description'     => wp_strip_all_tags( (string) ( $input['description'] ?? $input['post_content'] ?? '' ) ),
			'highlights'      => (string) ( $input['highlights'] ?? '' ),
			'locality_text'   => $pick( 'locality' ) . ' ' . $pick( 'address' ),
			'address'         => $pick( 'address' ),
			'locality'        => sanitize_title( $pick( 'locality' ) ),
			'latitude'        => (float) $pick( 'latitude', '0' ),
			'longitude'       => (float) $pick( 'longitude', '0' ),
			'bedrooms'        => (int) $pick( 'bedrooms', '0' ),
			'bathrooms'       => (int) $pick( 'bathrooms', '0' ),
			'parking'         => (int) $pick( 'parking', '0' ),
			'floor'           => (int) $pick( 'floor', '0' ),
			'facing'          => $pick( 'facing' ),
			'furnishing'      => $pick( 'furnishing' ),
			'area_sqft'       => (float) $pick( 'area_sqft', '0' ),
			'area'            => (float) $pick( 'area', '0' ),
			'price'           => (float) $pick( 'price', '0' ),
			'rent'            => (float) $pick( 'rent', '0' ),
			'developer'       => $pick( 'developer' ),
			'total_units'     => (int) $pick( 'total_units', '0' ),
			'possession_date' => $pick( 'possession_date' ),
		);

		$record['type']  = 'project' === $kind ? $pick( 'project_type' ) : $pick( 'property_type' );
		$record['offer'] = $pick( 'offer' );

		if ( 'project' === $kind && $record['price'] <= 0 ) {
			$record['price'] = (float) $pick( 'price_min', '0' );
		}

		return self::fingerprint( $record );
	}

	/* ----------------------------------------------------------------- *
	 * Similarity — the parts, each answerable on its own
	 * ----------------------------------------------------------------- */

	/**
	 * How much of the one set of words is in the other.
	 *
	 * @param string[] $a Words.
	 * @param string[] $b Words.
	 * @return float 0-1.
	 */
	private static function overlap( array $a, array $b ): float {
		$a = array_values( array_unique( $a ) );
		$b = array_values( array_unique( $b ) );
		if ( ! $a || ! $b ) {
			return 0.0;
		}
		$shared = count( array_intersect( $a, $b ) );

		return $shared / ( count( $a ) + count( $b ) - $shared );
	}

	/**
	 * How much of the smaller set is inside the bigger one.
	 *
	 * For a two-line description against a paragraph: the short one can be
	 * entirely contained in the long one and still be the same property.
	 *
	 * @param string[] $a Words.
	 * @param string[] $b Words.
	 * @return float 0-1.
	 */
	private static function containment( array $a, array $b ): float {
		$a = array_values( array_unique( $a ) );
		$b = array_values( array_unique( $b ) );
		if ( ! $a || ! $b ) {
			return 0.0;
		}

		return count( array_intersect( $a, $b ) ) / min( count( $a ), count( $b ) );
	}

	/**
	 * Three-letter pieces of a string, for catching typos and re-ordering.
	 *
	 * @param string $text Normalised text.
	 * @return string[]
	 */
	private static function trigrams( string $text ): array {
		$padded = '  ' . $text . '  ';
		$out    = array();
		$len    = mb_strlen( $padded );
		for ( $i = 0; $i < $len - 2; $i++ ) {
			$out[] = mb_substr( $padded, $i, 3 );
		}
		return $out;
	}

	/**
	 * Dice coefficient of two sets of three-letter pieces.
	 *
	 * @param string[] $a Pieces.
	 * @param string[] $b Pieces.
	 * @return float 0-1.
	 */
	private static function dice( array $a, array $b ): float {
		if ( ! $a || ! $b ) {
			return 0.0;
		}
		$have = array_count_values( $b );
		$hits = 0;
		foreach ( $a as $piece ) {
			if ( ! empty( $have[ $piece ] ) ) {
				--$have[ $piece ];
				++$hits;
			}
		}
		return ( 2.0 * $hits ) / ( count( $a ) + count( $b ) );
	}

	/**
	 * How alike two names are.
	 *
	 * Words first — "3 bhk sector 49" against "sector 49 3 bhk" — and then
	 * the letters themselves, so a spelling slip or an extra word does not
	 * hide a duplicate.
	 *
	 * @param string $a Name.
	 * @param string $b Name.
	 * @return float 0-1.
	 */
	public static function name_score( string $a, string $b ): float {
		$na = self::normalise( $a );
		$nb = self::normalise( $b );
		if ( '' === $na || '' === $nb ) {
			return 0.0;
		}
		if ( $na === $nb ) {
			return 1.0;
		}

		$by_word = self::overlap( self::tokens( $a ), self::tokens( $b ) );
		$by_letters = self::dice( self::trigrams( $na ), self::trigrams( $nb ) );

		// The letters are the noisier of the two; a quarter-letter discount
		// keeps "Sector 49" and "Sector 94" apart without any cleverness.
		return max( $by_word, $by_letters * 0.75 );
	}

	/**
	 * How alike two descriptions are, in meaning rather than in spelling.
	 *
	 * @param string $a Text.
	 * @param string $b Text.
	 * @return float 0-1.
	 */
	public static function meaning_score( string $a, string $b ): float {
		$ta = self::tokens( $a );
		$tb = self::tokens( $b );
		if ( ! $ta || ! $tb ) {
			return 0.0;
		}
		$shared = self::overlap( $ta, $tb );
		$held   = self::containment( $ta, $tb );

		return min( 1.0, ( $shared * 0.6 ) + ( $held * 0.4 ) );
	}

	/**
	 * How close two numbers are.
	 *
	 * @param float $a First number, 0 when unknown.
	 * @param float $b Second number, 0 when unknown.
	 * @return float 0-1, or -1 when either side is unknown.
	 */
	private static function closeness( float $a, float $b ): float {
		if ( $a <= 0 || $b <= 0 ) {
			return -1.0;
		}
		$ratio = $a > $b ? $b / $a : $a / $b; // 0-1.
		if ( $ratio >= 0.95 ) {
			return 1.0;
		}
		if ( $ratio >= 0.88 ) {
			return 0.85;
		}
		if ( $ratio >= 0.75 ) {
			return 0.6;
		}
		if ( $ratio >= 0.6 ) {
			return 0.3;
		}
		return 0.0;
	}

	/**
	 * Distance between two map pins, in metres.
	 *
	 * @param float $lat1 First latitude.
	 * @param float $lng1 First longitude.
	 * @param float $lat2 Second latitude.
	 * @param float $lng2 Second longitude.
	 * @return float Metres, or -1 when a pin is missing.
	 */
	public static function metres( float $lat1, float $lng1, float $lat2, float $lng2 ): float {
		if ( 0.0 === $lat1 || 0.0 === $lng1 || 0.0 === $lat2 || 0.0 === $lng2 ) {
			return -1.0;
		}
		$earth = 6371000.0;
		$d_lat = deg2rad( $lat2 - $lat1 );
		$d_lng = deg2rad( $lng2 - $lng1 );
		$a     = sin( $d_lat / 2 ) ** 2 + cos( deg2rad( $lat1 ) ) * cos( deg2rad( $lat2 ) ) * sin( $d_lng / 2 ) ** 2;

		return 2 * $earth * asin( min( 1.0, sqrt( $a ) ) );
	}

	/**
	 * The numbers that appear in a name — "3", "49" — in order.
	 *
	 * Two properties with the same numbers in their names, in the same order,
	 * are far more likely to be the same property than two that merely share
	 * a word.
	 *
	 * @param string $text Normalised text.
	 * @return string[]
	 */
	private static function digits_of( string $text ): array {
		preg_match_all( '/[0-9]+/u', $text, $m );
		return array_map( 'strval', (array) $m[0] );
	}

	/* ----------------------------------------------------------------- *
	 * The verdict
	 * ----------------------------------------------------------------- */

	/**
	 * How alike two records are, and why.
	 *
	 * Weights, out of 100:
	 *
	 *   name 32 · area 24 · the property itself 26 · money 10 · meaning 8
	 *
	 * Each part only speaks when both records actually say something about
	 * it: two properties with no price between them are not called different
	 * for it, they are simply not asked. That is what keeps a half-filled
	 * record from being called a duplicate of everything.
	 *
	 * Three facts can pull the answer back down no matter what the rest say:
	 * a different kind of property, a different area, or a name and a
	 * description that share almost nothing. They are not penalties so much
	 * as refusals — without agreement on where or what, two records are not
	 * the same thing however alike their prices are.
	 *
	 * @param array<string,mixed> $a Fingerprint.
	 * @param array<string,mixed> $b Fingerprint.
	 * @return array{score:int,band:string,reasons:string[],parts:array<string,float>}
	 */
	public static function score( array $a, array $b ): array {
		if ( ! $a || ! $b ) {
			return array( 'score' => 0, 'band' => '', 'reasons' => array(), 'parts' => array() );
		}

		$is_project = 'project' === ( $a['kind'] ?? 'listing' );

		/* ------------------------------------------------------ the name */
		$name = self::name_score( (string) $a['title'], (string) $b['title'] );

		$digits_a = (array) ( $a['title_digits'] ?? array() );
		$digits_b = (array) ( $b['title_digits'] ?? array() );
		if ( $digits_a && $digits_b && $digits_a === $digits_b ) {
			$name = min( 1.0, $name + 0.15 ); // Same numbers, same order.
		}

		/* ------------------------------------------------------ the area */
		$area_score = -1.0;
		$reasons    = array();

		if ( '' !== $a['locality'] && '' !== $b['locality'] ) {
			$area_score = $a['locality'] === $b['locality'] ? 1.0 : 0.1;
		}
		$text_area = self::meaning_score( (string) $a['where_text'], (string) $b['where_text'] );
		if ( $area_score < 0 && '' !== trim( (string) $a['where_text'] ) && '' !== trim( (string) $b['where_text'] ) ) {
			$area_score = $text_area;
		} elseif ( $area_score < 0 ) {
			$area_score = -1.0;
		} else {
			$area_score = max( $area_score, $text_area * 0.9 );
		}

		// The same sector named inside two different addresses.
		if ( '' !== $a['sector'] && $a['sector'] === $b['sector'] ) {
			$area_score = min( 1.0, max( (float) $area_score, 0.85 ) );
			$reasons[]  = 'area';
		}

		$metres = self::metres( (float) $a['lat'], (float) $a['lng'], (float) $b['lat'], (float) $b['lng'] );
		if ( $metres >= 0 ) {
			$by_map = $metres <= 150 ? 1.0 : ( $metres <= 600 ? 0.8 : ( $metres <= 2000 ? 0.4 : 0.0 ) );
			$area_score = $area_score < 0 ? $by_map : max( (float) $area_score, $by_map );
			if ( $by_map >= 0.8 ) {
				$reasons[] = 'map';
			}
		}

		/* ------------------------------------------- the property itself */
		$checks = array();

		$type_a = (string) $a['type'];
		$type_b = (string) $b['type'];
		if ( '' !== $type_a && '' !== $type_b ) {
			$checks['kind'] = array( $type_a === $type_b ? 1.0 : 0.0, 8.0 );
		}

		$offer_a = (string) $a['offer'];
		$offer_b = (string) $b['offer'];
		if ( '' !== $offer_a && '' !== $offer_b ) {
			$checks['offer'] = array( $offer_a === $offer_b ? 1.0 : 0.25, 4.0 );
		}

		if ( ! $is_project ) {
			if ( $a['bedrooms'] > 0 && $b['bedrooms'] > 0 ) {
				$gap            = abs( $a['bedrooms'] - $b['bedrooms'] );
				$checks['rooms'] = array( 0 === $gap ? 1.0 : ( 1 === $gap ? 0.45 : 0.0 ), 6.0 );
			}
			if ( $a['bathrooms'] > 0 && $b['bathrooms'] > 0 ) {
				$gap = abs( $a['bathrooms'] - $b['bathrooms'] );
				$checks['bathrooms'] = array( 0 === $gap ? 1.0 : ( 1 === $gap ? 0.6 : 0.0 ), 2.0 );
			}
			if ( $a['parking'] > 0 && $b['parking'] > 0 ) {
				$gap = abs( $a['parking'] - $b['parking'] );
				$checks['parking'] = array( 0 === $gap ? 1.0 : ( 1 === $gap ? 0.6 : 0.0 ), 1.0 );
			}
			if ( $a['floor'] > 0 && $b['floor'] > 0 ) {
				$checks['floor'] = array( $a['floor'] === $b['floor'] ? 1.0 : 0.3, 2.0 );
			}
			if ( '' !== $a['facing'] && '' !== $b['facing'] ) {
				$checks['facing'] = array( $a['facing'] === $b['facing'] ? 1.0 : 0.4, 1.0 );
			}
			if ( '' !== $a['furnishing'] && '' !== $b['furnishing'] ) {
				$checks['furnishing'] = array( $a['furnishing'] === $b['furnishing'] ? 1.0 : 0.4, 2.0 );
			}
		} else {
			if ( '' !== $a['builder'] && '' !== $b['builder'] ) {
				$same = self::name_score( (string) $a['builder'], (string) $b['builder'] );
				$checks['builder'] = array( $same, 8.0 );
			}
			if ( $a['units'] > 0 && $b['units'] > 0 ) {
				$checks['units'] = array( max( 0.0, (float) self::closeness( (float) $a['units'], (float) $b['units'] ) ), 5.0 );
			}
			if ( '' !== $a['handed'] && '' !== $b['handed'] ) {
				$checks['handed'] = array( $a['handed'] === $b['handed'] ? 1.0 : 0.0, 4.0 );
			}
		}

		$size = self::closeness( (float) $a['area'], (float) $b['area'] );
		if ( $size >= 0 ) {
			$checks['size'] = array( $size, 6.0 );
		}

		$spec_score  = 0.0;
		$spec_weight = 0.0;
		foreach ( $checks as $key => $check ) {
			$spec_score  += $check[0] * $check[1];
			$spec_weight += $check[1];
		}
		$spec = $spec_weight > 0 ? $spec_score / $spec_weight : -1.0;

		/* ------------------------------------------------------ the money */
		$money = self::closeness( (float) $a['price'], (float) $b['price'] );

		/* --------------------------------------------- what it says about it */
		$meaning = self::meaning_score( (string) $a['text'], (string) $b['text'] );
		$meaning_known = '' !== trim( (string) $a['text'] ) && '' !== trim( (string) $b['text'] );

		/* --------------------------------------------------------- adding up */
		$score  = $name * 32.0;
		$known  = 1;

		if ( $area_score >= 0 ) {
			$score += $area_score * 24.0;
			++$known;
		}
		if ( $spec >= 0 ) {
			$score += $spec * 26.0;
			++$known;
		}
		if ( $money >= 0 ) {
			$score += $money * 10.0;
			++$known;
		}
		if ( $meaning_known ) {
			$score += $meaning * 8.0;
			++$known;
		}

		/*
		 * A record that says very little must not be able to score highly on
		 * the one thing it happens to have. The score is held to the share of
		 * the evidence that was actually there, so a property with nothing
		 * but a name tops out in the "worth a look" band.
		 */
		if ( $known <= 2 ) {
			$score = min( $score, (float) ( self::MAYBE_AT + 20 ) );
		} elseif ( 3 === $known ) {
			$score = min( $score, (float) ( self::SAME_AT - 1 ) );
		}

		/*
		 * Refusals. Not penalties — a record is not docked marks for being
		 * different, it is simply not called a duplicate on the strength of
		 * everything else when one of these disagrees. Each needs a second
		 * fact to agree with it, because one field alone is typed wrongly
		 * often enough to be a poor reason to stop suspecting.
		 */
		if ( '' !== $type_a && '' !== $type_b && $type_a !== $type_b ) {
			$score = min( $score, 55.0 ); // A shop is not a flat, whatever the price.
		}
		if ( '' !== $a['locality'] && '' !== $b['locality'] && $a['locality'] !== $b['locality'] ) {
			$score = min( $score, 58.0 );
		}
		if ( $name < 0.35 && ( ! $meaning_known || $meaning < 0.4 ) ) {
			$score = min( $score, 48.0 ); // Nothing in the words agrees.
		}

		/*
		 * Two flats in one tower are two flats. The rooms disagree and the
		 * size disagrees by more than a rounding — that is a different unit
		 * however much the name, the area and the broker's words match.
		 * One of the two on its own is not enough: a bedroom count typed
		 * wrong, or a size measured on a different day, are both common
		 * enough that neither alone should end the suspicion.
		 */
		if ( ! $is_project && $size >= 0 && $size < 0.85 && isset( $checks['rooms'] ) && $checks['rooms'][0] < 0.9 ) {
			$score = min( $score, 60.0 );
		}
		if ( $size >= 0 && $size < 0.6 ) {
			$score = min( $score, 60.0 ); // Half the size is not the same home.
		}

		$score = (int) round( max( 0.0, min( 100.0, $score ) ) );

		/* ------------------------------------------------------------ why */
		if ( $name >= 0.72 ) {
			$reasons[] = 'name';
		}
		if ( $area_score >= 0.8 ) {
			$reasons[] = 'area';
		}
		if ( isset( $checks['size'] ) && $checks['size'][0] >= 0.85 ) {
			$reasons[] = 'size';
		}
		if ( isset( $checks['rooms'] ) && $checks['rooms'][0] >= 0.9 ) {
			$reasons[] = 'rooms';
		}
		if ( isset( $checks['kind'] ) && $checks['kind'][0] >= 1.0 ) {
			$reasons[] = 'kind';
		}
		if ( isset( $checks['builder'] ) && $checks['builder'][0] >= 0.8 ) {
			$reasons[] = 'builder';
		}
		if ( isset( $checks['units'] ) && $checks['units'][0] >= 0.85 ) {
			$reasons[] = 'units';
		}
		if ( isset( $checks['handed'] ) && $checks['handed'][0] >= 1.0 ) {
			$reasons[] = 'handed';
		}
		if ( $money >= 0.85 ) {
			$reasons[] = 'money';
		}
		if ( $meaning_known && $meaning >= 0.6 ) {
			$reasons[] = 'meaning';
		}
		if ( ! $reasons && $score >= self::MAYBE_AT ) {
			$reasons[] = 'details';
		}

		return array(
			'score'   => $score,
			'band'    => self::band( $score ),
			'reasons' => array_values( array_unique( $reasons ) ),
			'parts'   => array(
				'name'   => round( $name, 3 ),
				'area'   => round( max( 0.0, (float) $area_score ), 3 ),
				'spec'   => round( max( 0.0, (float) $spec ), 3 ),
				'money'  => round( max( 0.0, (float) $money ), 3 ),
				'meaning'=> $meaning_known ? round( $meaning, 3 ) : -1.0,
			),
		);
	}

	/* ----------------------------------------------------------------- *
	 * Finding what to compare against
	 * ----------------------------------------------------------------- */

	/**
	 * The records worth comparing a new one with.
	 *
	 * A small office's whole inventory is simply read; above that, the search
	 * is narrowed to the records that share the area, the kind of property
	 * and the number of rooms, because a three-bedroom in Sector 49 is never
	 * a duplicate of a shop in Noida.
	 *
	 * @param string              $kind 'listing' or 'project'.
	 * @param array<string,mixed> $fp Fingerprint of the record being checked.
	 * @param int                 $exclude_id Record not to compare with itself.
	 * @param int                 $limit Most records to bring back.
	 * @return int[] Post ids.
	 */
	public static function candidates( string $kind, array $fp, int $exclude_id = 0, int $limit = 80, bool $narrow = false ): array {
		$post_type = 'project' === $kind ? PostTypes::PROJECT : PostTypes::LISTING;
		$statuses  = array( 'publish', 'draft', 'pending', 'private' );

		/*
		 * What is worth comparing against depends very little on the row in
		 * hand and very much on the office, so it is remembered for the
		 * page. A spreadsheet asks this once per row; without this, a file of
		 * two hundred rows would read the whole inventory two hundred times.
		 */
		$look_key = $kind . '|' . (string) $fp['type'] . '|' . (int) $fp['bedrooms'] . '|' . (string) $fp['locality']
			. '|' . ( $fp['price'] > 0 ? (string) (int) log10( (float) $fp['price'] ) : '0' ) . '|' . (string) $fp['sector'];
		if ( isset( self::$looked_up[ $look_key ] ) ) {
			return self::clean_ids( self::$looked_up[ $look_key ], $exclude_id );
		}

		$total = self::inventory_size( $post_type );
		if ( ! $narrow && $total > 0 && $total <= self::ALL_AT_ONCE ) {
			$query = new \WP_Query(
				array(
					'post_type'              => $post_type,
					'post_status'            => $statuses,
					'posts_per_page'         => min( $total, self::ALL_AT_ONCE ),
					'fields'                 => 'ids',
					'no_found_rows'          => true,
					'update_post_meta_cache' => true,
					'update_post_term_cache' => true,
					'orderby'                => 'ID',
					'order'                  => 'DESC',
				)
			);
			return self::clean_ids( (array) $query->posts, $exclude_id );
		}

		$ids = array();

		// Same area.
		if ( '' !== (string) $fp['locality'] ) {
			$query = new \WP_Query(
				array(
					'post_type'              => $post_type,
					'post_status'            => $statuses,
					'posts_per_page'         => $limit,
					'fields'                 => 'ids',
					'no_found_rows'          => true,
					'update_post_meta_cache' => true,
					'update_post_term_cache' => true,
					'tax_query'              => array(
						array(
							'taxonomy' => Taxonomies::LOCALITY,
							'field'    => 'slug',
							'terms'    => (string) $fp['locality'],
						),
					),
				)
			);
			$ids = array_merge( $ids, self::clean_ids( (array) $query->posts, $exclude_id ) );
		}

		// Same kind of property, same number of rooms.
		$meta  = array();
		$asked = 0;
		if ( '' !== (string) $fp['type'] ) {
			$meta[] = array(
				'key'     => 'project' === $kind ? '_estat_project_type' : '_estat_property_type',
				'value'   => (string) $fp['type'],
				'compare' => '=',
			);
			++$asked;
		}
		if ( 'listing' === $kind && (int) $fp['bedrooms'] > 0 ) {
			$meta[] = array(
				'key'     => '_estat_bedrooms',
				'value'   => (int) $fp['bedrooms'],
				'compare' => '=',
				'type'    => 'NUMERIC',
			);
			++$asked;
		}
		if ( $asked > 0 ) {
			$meta['relation'] = 'AND';
			$query            = new \WP_Query(
				array(
					'post_type'              => $post_type,
					'post_status'            => $statuses,
					'posts_per_page'         => $limit,
					'fields'                 => 'ids',
					'no_found_rows'          => true,
					'update_post_meta_cache' => true,
					'update_post_term_cache' => true,
					'meta_query'             => $meta, // phpcs:ignore WordPress.DB.SlowDBQuery
				)
			);
			$ids = array_merge( $ids, self::clean_ids( (array) $query->posts, $exclude_id ) );
		}

		// Money in the same bracket.
		if ( (float) $fp['price'] > 0 ) {
			$low  = (float) $fp['price'] * 0.65;
			$high = (float) $fp['price'] * 1.55;
			$query = new \WP_Query(
				array(
					'post_type'              => $post_type,
					'post_status'            => $statuses,
					'posts_per_page'         => $limit,
					'fields'                 => 'ids',
					'no_found_rows'          => true,
					'update_post_meta_cache' => true,
					'update_post_term_cache' => true,
					'meta_query'             => array( // phpcs:ignore WordPress.DB.SlowDBQuery
						array(
							'key'     => 'project' === $kind ? '_estat_price_min' : '_estat_price',
							'value'   => array( $low, $high ),
							'compare' => 'BETWEEN',
							'type'    => 'NUMERIC',
						),
					),
				)
			);
			$ids = array_merge( $ids, self::clean_ids( (array) $query->posts, $exclude_id ) );
		}

		// Names that share the numbers — "Sector 49", "3 BHK".
		if ( count( (array) $fp['title_digits'] ) > 0 ) {
			$query = new \WP_Query(
				array(
					'post_type'              => $post_type,
					'post_status'            => $statuses,
					'posts_per_page'         => $limit,
					'fields'                 => 'ids',
					'no_found_rows'          => true,
					'update_post_meta_cache' => true,
					'update_post_term_cache' => true,
					's'                      => implode( ' ', (array) $fp['title_digits'] ),
				)
			);
			$ids = array_merge( $ids, self::clean_ids( (array) $query->posts, $exclude_id ) );
		}

		$ids = array_slice( array_values( array_unique( $ids ) ), 0, $limit );
		self::$looked_up[ $look_key ] = $ids;

		return self::clean_ids( $ids, $exclude_id );
	}

	/**
	 * Forget what was gathered during this page.
	 *
	 * Called the moment an import adds a record: from then on the new record
	 * is itself a candidate, so the next row in the same file can be caught
	 * as a duplicate of it. Without this, two identical rows one after the
	 * other would both sail through.
	 *
	 * @return void
	 */
	public static function forget_cache(): void {
		self::$looked_up = array();
	}

	/**
	 * How many records of a kind the office has, not counting the bin.
	 *
	 * @param string $post_type Post type.
	 * @return int
	 */
	private static function inventory_size( string $post_type ): int {
		$counts = wp_count_posts( $post_type );
		$total  = 0;
		foreach ( (array) $counts as $status => $number ) {
			if ( 'trash' === (string) $status || 'auto-draft' === (string) $status ) {
				continue;
			}
			$total += (int) $number;
		}
		return $total;
	}

	/**
	 * Ids, with the record itself and the bin taken out.
	 *
	 * @param array  $ids Ids from a query.
	 * @param int    $exclude_id Record not to compare with itself.
	 * @return int[]
	 */
	private static function clean_ids( array $ids, int $exclude_id ): array {
		$out = array();
		foreach ( $ids as $id ) {
			$id = (int) $id;
			if ( $id <= 0 || $id === $exclude_id ) {
				continue;
			}
			$out[] = $id;
		}
		return $out;
	}

	/**
	 * Ask the question: what does this look like, out of what we already have?
	 *
	 * @param string              $kind 'listing' or 'project'.
	 * @param array<string,mixed> $input Raw input (a form, a CSV row).
	 * @param int                 $exclude_id The record being edited, if any.
	 * @param int                 $limit How many matches to bring back.
	 * @return array<array{id:int,title:string,score:int,band:string,reasons:string[],url:string,edit:string,status:string}>
	 */
	public static function check( string $kind, array $input, int $exclude_id = 0, int $limit = 5, bool $narrow = false ): array {
		$fp = self::from_input( $kind, $input );
		if ( '' === (string) $fp['title'] ) {
			return array();
		}

		$ids     = self::candidates( $kind, $fp, $exclude_id, 80, $narrow );
		$matches = array();

		foreach ( $ids as $id ) {
			$other = self::from_post( $kind, (int) $id );
			if ( ! $other ) {
				continue;
			}
			$verdict = self::score( $fp, $other );
			if ( $verdict['score'] < self::MAYBE_AT ) {
				continue;
			}
			$matches[] = array(
				'id'      => (int) $id,
				'title'   => (string) $other['title'],
				'status'  => (string) $other['status'],
				'url'     => (string) $other['url'],
				'edit'    => (string) $other['edit'],
				'score'   => (int) $verdict['score'],
				'band'    => (string) $verdict['band'],
				'reasons' => (array) $verdict['reasons'],
				'parts'   => (array) $verdict['parts'],
			);
		}

		usort(
			$matches,
			static function ( $a, $b ) {
				return $b['score'] <=> $a['score'];
			}
		);

		return array_slice( $matches, 0, $limit );
	}

	/**
	 * Look at a record that is already saved and say what it looks like.
	 *
	 * @param string $kind 'listing' or 'project'.
	 * @param int    $post_id Record to check.
	 * @param int    $limit How many matches to bring back.
	 * @return array<array<string,mixed>>
	 */
	public static function check_saved( string $kind, int $post_id, int $limit = 3 ): array {
		$fp = self::from_post( $kind, $post_id );
		if ( ! $fp ) {
			return array();
		}

		$ids     = self::candidates( $kind, $fp, $post_id );
		$matches = array();

		foreach ( $ids as $id ) {
			$other   = self::from_post( $kind, (int) $id );
			if ( ! $other ) {
				continue;
			}
			$verdict = self::score( $fp, $other );
			if ( $verdict['score'] < self::MAYBE_AT ) {
				continue;
			}
			$matches[] = array(
				'id'      => (int) $id,
				'title'   => (string) $other['title'],
				'status'  => (string) $other['status'],
				'url'     => (string) $other['url'],
				'edit'    => (string) $other['edit'],
				'score'   => (int) $verdict['score'],
				'band'    => (string) $verdict['band'],
				'reasons' => (array) $verdict['reasons'],
				'parts'   => (array) $verdict['parts'],
			);
		}

		usort(
			$matches,
			static function ( $a, $b ) {
				return $b['score'] <=> $a['score'];
			}
		);

		return array_slice( $matches, 0, $limit );
	}

	/* ----------------------------------------------------------------- *
	 * The whole inventory, looked over once
	 * ----------------------------------------------------------------- */

	/**
	 * Go through everything and write down every pair that looks alike.
	 *
	 * Records are put in blocks — the same kind of property, the same number
	 * of rooms, the same area, a neighbouring price — and only compared
	 * within a block, so a whole inventory can be looked over in one visit
	 * instead of every record being held against every other one.
	 *
	 * @param string $kind 'listing' or 'project'.
	 * @param int    $max_records Safety stop on how much to read.
	 * @param float  $seconds Time the page is allowed to spend.
	 * @return array{pairs:array<array<string,mixed>>,looked:int,stopped:bool}
	 */
	public static function scan( string $kind, int $max_records = 500, float $seconds = 18.0 ): array {
		$post_type = 'project' === $kind ? PostTypes::PROJECT : PostTypes::LISTING;
		$until     = microtime( true ) + $seconds;
		$records   = array();
		$looked    = 0;
		$stopped   = false;

		for ( $offset = 0; $offset < $max_records; $offset += 100 ) {
			$query = new \WP_Query(
				array(
					'post_type'              => $post_type,
					'post_status'            => array( 'publish', 'draft', 'pending', 'private' ),
					'posts_per_page'         => 100,
					'offset'                 => $offset,
					'fields'                 => 'ids',
					'no_found_rows'          => false,
					'update_post_meta_cache' => true,
					'update_post_term_cache' => true,
					'orderby'                => 'ID',
					'order'                  => 'ASC',
				)
			);

			$ids = array_map( 'intval', (array) $query->posts );
			if ( ! $ids ) {
				break;
			}
			foreach ( $ids as $id ) {
				$fp = self::from_post( $kind, (int) $id );
				if ( $fp ) {
					$records[ (int) $id ] = $fp;
					++$looked;
				}
			}
			if ( count( $ids ) < 100 ) {
				break;
			}
			if ( microtime( true ) > $until ) {
				$stopped = true;
				break;
			}
		}

		// Blocks: kind of property | rooms | area | price bracket.
		$blocks = array();
		foreach ( $records as $id => $fp ) {
			$blocks[ self::block_key( $fp ) ][] = (int) $id;
		}

		$pairs = array();
		foreach ( $blocks as $block => $ids ) {
			if ( count( $ids ) < 2 ) {
				continue;
			}
			$count = count( $ids );
			for ( $i = 0; $i < $count; $i++ ) {
				for ( $j = $i + 1; $j < $count; $j++ ) {
					$a       = $records[ $ids[ $i ] ];
					$b       = $records[ $ids[ $j ] ];
					$verdict = self::score( $a, $b );
					if ( $verdict['score'] < self::MAYBE_AT ) {
						continue;
					}
					$pairs[] = array(
						'one'     => array( 'id' => $ids[ $i ], 'title' => (string) $a['title'], 'edit' => (string) $a['edit'], 'url' => (string) $a['url'], 'status' => (string) $a['status'] ),
						'two'     => array( 'id' => $ids[ $j ], 'title' => (string) $b['title'], 'edit' => (string) $b['edit'], 'url' => (string) $b['url'], 'status' => (string) $b['status'] ),
						'score'   => (int) $verdict['score'],
						'band'    => (string) $verdict['band'],
						'reasons' => (array) $verdict['reasons'],
					);
				}
			}
			if ( microtime( true ) > $until ) {
				$stopped = true;
				break;
			}
		}

		usort(
			$pairs,
			static function ( $a, $b ) {
				return $b['score'] <=> $a['score'];
			}
		);

		/*
		 * Write the verdicts down against the records themselves.
		 *
		 * The Duplicates screen lists whatever carries a verdict (META_SCORE),
		 * and this sweep returned its pairs without ever writing one — so a
		 * scan found duplicates and the screen still showed an empty page.
		 * remember() is the same writer a save uses, so a pair found here
		 * behaves exactly like a pair found while somebody was typing.
		 */
		$touched = array();
		foreach ( $pairs as $pair ) {
			foreach ( array( 'one', 'two' ) as $side ) {
				$record_id = (int) ( $pair[ $side ]['id'] ?? 0 );
				if ( $record_id > 0 && ! isset( $touched[ $record_id ] ) ) {
					$touched[ $record_id ] = true;
					self::remember( $kind, $record_id );
				}
			}
			if ( microtime( true ) > $until ) {
				$stopped = true;
				break;
			}
		}

		return array(
			'kind'    => 'project' === $kind ? 'project' : 'listing',
			'pairs'   => $pairs,
			'looked'  => $looked,
			'stopped' => $stopped,
		);
	}

	/**
	 * The block a record belongs to.
	 *
	 * The price bracket is deliberately wide and the block is only a way of
	 * not comparing everything with everything: the score itself is still the
	 * whole answer, so a pair sitting on the edge of two brackets is simply
	 * compared twice rather than missed.
	 *
	 * @param array<string,mixed> $fp Fingerprint.
	 * @return string
	 */
	private static function block_key( array $fp ): string {
		$price = (float) $fp['price'];
		$band  = $price > 0 ? (string) (int) log10( $price ) : '0';

		return implode(
			'|',
			array(
				(string) $fp['type'],
				(string) (int) $fp['bedrooms'],
				(string) $fp['locality'],
				$band,
			)
		);
	}

	/* ----------------------------------------------------------------- *
	 * What is remembered, and what the office decided
	 * ----------------------------------------------------------------- */

	/**
	 * Work out the verdict for a saved record and keep it.
	 *
	 * @param string $kind 'listing' or 'project'.
	 * @param int    $post_id Record that was just saved.
	 * @return array<string,mixed> The strongest match, or an empty array.
	 */
	public static function remember( string $kind, int $post_id ): array {
		$matches = self::check_saved( $kind, $post_id, 1 );
		$top     = $matches ? $matches[0] : array();

		if ( ! $top ) {
			delete_post_meta( $post_id, self::META_SCORE );
			delete_post_meta( $post_id, self::META_OF );
			delete_post_meta( $post_id, self::META_BAND );
			delete_post_meta( $post_id, self::META_WHY );
			delete_post_meta( $post_id, self::META_DECIDED );
			delete_post_meta( $post_id, self::META_SEEN );
			return array();
		}

		$was = (string) get_post_meta( $post_id, self::META_DECIDED, true );

		// A decision stands: if the office has already said these two are
		// different records, it is not asked again about the same pair.
		if ( 'kept' === $was && (int) get_post_meta( $post_id, self::META_OF, true ) === (int) $top['id'] ) {
			return array();
		}

		update_post_meta( $post_id, self::META_SCORE, (int) $top['score'] );
		update_post_meta( $post_id, self::META_OF, (int) $top['id'] );
		update_post_meta( $post_id, self::META_BAND, (string) $top['band'] );
		update_post_meta( $post_id, self::META_WHY, (array) $top['reasons'] );
		update_post_meta( $post_id, self::META_SEEN, time() );

		return $top;
	}

	/**
	 * The verdict kept against a record.
	 *
	 * @param int $post_id Record.
	 * @return array<string,mixed>
	 */
	public static function stored( int $post_id ): array {
		$score = (int) get_post_meta( $post_id, self::META_SCORE, true );
		$of    = (int) get_post_meta( $post_id, self::META_OF, true );
		if ( $score <= 0 || $of <= 0 ) {
			return array();
		}

		return array(
			'score'   => $score,
			'of'      => $of,
			'band'    => (string) get_post_meta( $post_id, self::META_BAND, true ),
			'reasons' => (array) get_post_meta( $post_id, self::META_WHY, true ),
			'decided' => (string) get_post_meta( $post_id, self::META_DECIDED, true ),
			'seen'    => (int) get_post_meta( $post_id, self::META_SEEN, true ),
		);
	}

	/**
	 * "These two are different records" — said once, written down, not asked again.
	 *
	 * @param int    $post_id The record that was flagged.
	 * @param int    $other_id The record it was said to look like.
	 * @param string $kind 'listing' or 'project'.
	 * @return void
	 */
	public static function keep_both( int $post_id, int $other_id, string $kind = 'listing' ): void {
		update_post_meta( $post_id, self::META_DECIDED, 'kept' );
		update_post_meta( $post_id, self::META_OF, $other_id );

		update_post_meta( $other_id, self::META_DECIDED, 'kept' );
		update_post_meta( $other_id, self::META_OF, $post_id );

		AuditLog::record(
			'duplicate.kept_both',
			'project' === $kind ? 'project' : 'listing',
			$post_id,
			array(
				'other_id' => $other_id,
				'by'       => get_current_user_id(),
				'said'     => __( 'The office said these two are different records.', 'estat-os' ),
			)
		);
	}

	/**
	 * Forget the verdict on a record, and the decision that went with it.
	 *
	 * @param int $post_id Record.
	 * @return void
	 */
	public static function forget( int $post_id ): void {
		delete_post_meta( $post_id, self::META_DECIDED );
		delete_post_meta( $post_id, self::META_SCORE );
		delete_post_meta( $post_id, self::META_OF );
		delete_post_meta( $post_id, self::META_BAND );
		delete_post_meta( $post_id, self::META_WHY );
		delete_post_meta( $post_id, self::META_SEEN );
	}

	/* ----------------------------------------------------------------- *
	 * Small helpers
	 * ----------------------------------------------------------------- */

	/**
	 * The area terms on a record, as one slug.
	 *
	 * @param int $post_id Record.
	 * @return string
	 */
	private static function locality_slug( int $post_id ): string {
		$terms = get_the_terms( $post_id, Taxonomies::LOCALITY );
		if ( ! $terms || is_wp_error( $terms ) ) {
			return '';
		}
		$slugs = array();
		foreach ( $terms as $term ) {
			$slugs[] = (string) $term->slug;
		}
		sort( $slugs );

		return implode( ',', $slugs );
	}

	/**
	 * The area terms on a record, in words.
	 *
	 * @param int $post_id Record.
	 * @return string
	 */
	private static function locality_names( int $post_id ): string {
		$terms = get_the_terms( $post_id, Taxonomies::LOCALITY );
		if ( ! $terms || is_wp_error( $terms ) ) {
			return '';
		}
		$names = array();
		foreach ( $terms as $term ) {
			$names[] = (string) $term->name;
		}

		return implode( ' ', $names );
	}
}
