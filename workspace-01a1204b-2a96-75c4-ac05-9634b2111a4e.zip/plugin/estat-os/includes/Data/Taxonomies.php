<?php
/**
 * Classification lists (localities, features, amenities, categories).
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Data;

defined( 'ABSPATH' ) || exit;

/**
 * These are presented to office users as simple lists, never as "taxonomies".
 */
final class Taxonomies {

	/**
	 * Locality taxonomy key.
	 */
	public const LOCALITY = 'estat_locality';

	/**
	 * Feature taxonomy key.
	 */
	public const FEATURE = 'estat_feature';

	/**
	 * Amenity taxonomy key.
	 */
	public const AMENITY = 'estat_amenity';

	
	
	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		// 0 = earliest possible on init, before Elementor dynamic tags (which use wp_get_object_terms
		// and then wp_kses_post without checking WP_Error, causing TypeError fatal in kses.php:2025).
		// Also hook elementor/init as extra safety.
		add_action( 'init', array( __CLASS__, 'register_taxonomies' ), 0 );
		add_action( 'elementor/init', array( __CLASS__, 'register_taxonomies' ), 0 );
		// Safety net: if any code asks for our terms before we registered, return [] not WP_Error,
		// so Elementor Pro post-terms.php:111 wp_kses_post(WP_Error) never fatals.
		add_filter( 'get_the_terms', array( __CLASS__, 'guard_get_the_terms' ), 10, 3 );
	}

	/**
	 * Guard against WP_Error reaching wp_kses_post in Elementor Pro.
	 *
	 * @param mixed  $terms    Terms or WP_Error.
	 * @param int    $post_id  Post ID.
	 * @param string $taxonomy Taxonomy.
	 * @return mixed
	 */
	public static function guard_get_the_terms( $terms, int $post_id, string $taxonomy ) {
		if ( is_wp_error( $terms ) ) {
			$owned = array( self::LOCALITY, self::FEATURE, self::AMENITY );
			if ( in_array( $taxonomy, $owned, true ) ) {
				return array();
			}
		}
		return $terms;
	}

	/**
	 * Register taxonomies.
	 *
	 * @return void
	 */
	public static function register_taxonomies(): void {
		register_taxonomy(
			self::LOCALITY,
			array( PostTypes::LISTING, PostTypes::PROJECT ),
			array(
				'labels'            => self::labels( __( 'Locality', 'estat-os' ), __( 'Localities', 'estat-os' ) ),
				'hierarchical'      => true,
				'public'            => true,
				'show_ui'           => true,
				'show_in_menu'      => false,
				'show_admin_column' => true,
				'rewrite'           => array( 'slug' => 'locality', 'with_front' => false ),
				'capabilities'      => self::caps( 'estat_manage_listings' ),
			)
		);

		register_taxonomy(
			self::FEATURE,
			array( PostTypes::LISTING ),
			array(
				'labels'       => self::labels( __( 'Feature', 'estat-os' ), __( 'Features', 'estat-os' ) ),
				'hierarchical' => false,
				'public'       => true,
				'show_ui'      => true,
				'show_in_menu' => false,
				'rewrite'      => array( 'slug' => 'feature', 'with_front' => false ),
				'capabilities' => self::caps( 'estat_manage_listings' ),
			)
		);

		register_taxonomy(
			self::AMENITY,
			array( PostTypes::LISTING, PostTypes::PROJECT ),
			array(
				'labels'       => self::labels( __( 'Amenity', 'estat-os' ), __( 'Amenities', 'estat-os' ) ),
				'hierarchical' => false,
				'public'       => true,
				'show_ui'      => true,
				'show_in_menu' => false,
				'rewrite'      => array( 'slug' => 'amenity', 'with_front' => false ),
				'capabilities' => self::caps( 'estat_manage_listings' ),
			)
		);

	}


	/**
	 * Build taxonomy labels.
	 *
	 * @param string $singular Singular.
	 * @param string $plural   Plural.
	 * @return array<string,string>
	 */
	private static function labels( string $singular, string $plural ): array {
		return array(
			'name'          => $plural,
			'singular_name' => $singular,
			'add_new_item'  => sprintf( /* translators: %s: item */ __( 'Add %s', 'estat-os' ), $singular ),
			'edit_item'     => sprintf( /* translators: %s: item */ __( 'Edit %s', 'estat-os' ), $singular ),
			'search_items'  => $plural,
			'all_items'     => $plural,
			'menu_name'     => $plural,
			'not_found'     => __( 'Nothing added yet.', 'estat-os' ),
		);
	}

	/**
	 * Capability map for a taxonomy.
	 *
	 * @param string $cap Capability.
	 * @return array<string,string>
	 */
	private static function caps( string $cap ): array {
		return array(
			'manage_terms' => $cap,
			'edit_terms'   => $cap,
			'delete_terms' => $cap,
			'assign_terms' => $cap,
		);
	}

	/**
	 * Seed a small set of neutral, non company specific starter amenities.
	 * Idempotent: existing terms are never duplicated.
	 *
	 * @return void
	 */
	public static function seed(): void {
		$amenities = array(
			__( 'Lift', 'estat-os' ),
			__( 'Power backup', 'estat-os' ),
			__( 'Security', 'estat-os' ),
			__( 'Parking', 'estat-os' ),
			__( 'Park', 'estat-os' ),
			__( 'Gym', 'estat-os' ),
			__( 'Swimming pool', 'estat-os' ),
			__( 'Clubhouse', 'estat-os' ),
			__( 'Water supply', 'estat-os' ),
			__( 'Gated community', 'estat-os' ),
		);
		foreach ( $amenities as $name ) {
			if ( ! term_exists( $name, self::AMENITY ) ) {
				wp_insert_term( $name, self::AMENITY );
			}
		}
	}

	/**
	 * All taxonomies owned by the plugin.
	 *
	 * @return string[]
	 */
	public static function all(): array {
		return array( self::LOCALITY, self::FEATURE, self::AMENITY );
	}
}
