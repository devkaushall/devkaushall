<?php
/**
 * Estat.OS interface: shared drawing helpers.
 *
 * One place for the small pieces every screen uses — icons, badges, meters,
 * panels, empty states — so the fifteen screens stay about their own content
 * and a change to how a badge looks is a change in one file.
 *
 * The icon sprite is inlined rather than read from disk: an office screen
 * draws dozens of icons and that would be dozens of file reads per page.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Os;

defined( 'ABSPATH' ) || exit;

final class Ui {

	/**
	 * The icon set, drawn once per page.
	 *
	 * Every icon is decorative — the label next to it carries the meaning —
	 * so the whole sprite is hidden from assistive technology.
	 */
	public static function sprite(): void {
		echo self::SPRITE; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static markup below.
	}

	private const SPRITE = <<<'SPRITE_HTML'
<svg width="0" height="0" aria-hidden="true" style="position:absolute;width:0;height:0;overflow:hidden"><defs>
<symbol id="eos-i-roof" viewBox="0 0 24 24"><path d="M3 10.6 12 3.4l9 7.2"/><path d="M5.6 9.4V20.6h12.8V9.4"/><path d="M9.9 20.6v-5.9h4.2v5.9"/></symbol>
<symbol id="eos-i-today" viewBox="0 0 24 24"><rect x="3.2" y="3.2" width="7.4" height="7.4" rx="2"/><rect x="13.4" y="3.2" width="7.4" height="7.4" rx="2"/><rect x="3.2" y="13.4" width="7.4" height="7.4" rx="2"/><rect x="13.4" y="13.4" width="7.4" height="7.4" rx="2"/></symbol>
<symbol id="eos-i-home" viewBox="0 0 24 24"><path d="M3 10.6 12 3.4l9 7.2"/><path d="M5.6 9.5V20.6h12.8V9.5"/><path d="M9.7 20.6v-6.1h4.6v6.1"/></symbol>
<symbol id="eos-i-layers" viewBox="0 0 24 24"><path d="M12 3.2 21 8.2l-9 5-9-5 9-5Z"/><path d="m3.4 12.4 8.6 4.8 8.6-4.8"/><path d="m3.4 16.9 8.6 4.8 8.6-4.8"/></symbol>
<symbol id="eos-i-inbox" viewBox="0 0 24 24"><path d="M3.6 13.2 6.2 4.6h11.6l2.6 8.6v6a2 2 0 0 1-2 2H5.6a2 2 0 0 1-2-2v-6Z"/><path d="M3.6 13.2h5.5l1.2 2.3h3.4l1.2-2.3h5.5"/></symbol>
<symbol id="eos-i-kanban" viewBox="0 0 24 24"><rect x="3.4" y="4" width="4.9" height="16" rx="1.6"/><rect x="9.55" y="4" width="4.9" height="10.6" rx="1.6"/><rect x="15.7" y="4" width="4.9" height="13.4" rx="1.6"/></symbol>
<symbol id="eos-i-calendar" viewBox="0 0 24 24"><rect x="3.4" y="5" width="17.2" height="15.6" rx="2.6"/><path d="M3.4 9.9h17.2M8.2 3v4M15.8 3v4"/><path d="M7.4 13.4h2.4M11.6 13.4h2.4M7.4 17h2.4"/></symbol>
<symbol id="eos-i-users" viewBox="0 0 24 24"><circle cx="9.2" cy="8" r="3.6"/><path d="M2.9 20.3a6.3 6.3 0 0 1 12.6 0"/><path d="M16.4 5a3.6 3.6 0 0 1 0 6.9M18.4 14.6a6.3 6.3 0 0 1 3.1 5.5"/></symbol>
<symbol id="eos-i-columns" viewBox="0 0 24 24"><rect x="3.4" y="4.4" width="5.6" height="15.2" rx="1.8"/><rect x="9.9" y="4.4" width="5.6" height="15.2" rx="1.8"/><path d="M18.8 4.4h1.1a1.8 1.8 0 0 1 1.8 1.8v11.6a1.8 1.8 0 0 1-1.8 1.8h-1.1"/></symbol>
<symbol id="eos-i-shuffle" viewBox="0 0 24 24"><path d="M3.8 7.2h3.9l8.6 9.6h3.9"/><path d="M3.8 16.8h3.9l2.7-3M13.6 10.2l2.7-3h3.9"/><path d="m17.4 4 2.9 3.2-2.9 3.2M17.4 13.6l2.9 3.2-2.9 3.2"/></symbol>
<symbol id="eos-i-image" viewBox="0 0 24 24"><rect x="3.4" y="4.6" width="17.2" height="14.8" rx="2.6"/><circle cx="8.8" cy="9.8" r="1.8"/><path d="m4.2 17.6 4.6-4.2a1.9 1.9 0 0 1 2.6 0l2.4 2.2M13.9 14.3l1.5-1.4a1.9 1.9 0 0 1 2.6 0l1.8 1.7"/></symbol>
<symbol id="eos-i-form" viewBox="0 0 24 24"><rect x="4.4" y="3.4" width="15.2" height="17.2" rx="2.6"/><path d="M8.2 9h7.6M8.2 13h7.6M8.2 17h4.4"/></symbol>
<symbol id="eos-i-upload" viewBox="0 0 24 24"><path d="M20.6 15.4v3.4a2.4 2.4 0 0 1-2.4 2.4H5.8a2.4 2.4 0 0 1-2.4-2.4v-3.4"/><path d="m7.9 8.8 4.1-4.2 4.1 4.2M12 4.6v10.8"/></symbol>
<symbol id="eos-i-copy" viewBox="0 0 24 24"><rect x="8.6" y="8.6" width="11.4" height="11.4" rx="2.6"/><path d="M15.6 5.6V5.2a1.6 1.6 0 0 0-1.6-1.6H5.8A2.4 2.4 0 0 0 3.4 6v8.2a1.6 1.6 0 0 0 1.6 1.6h.4"/></symbol>
<symbol id="eos-i-chart" viewBox="0 0 24 24"><path d="M4 4v16.4h16.6"/><rect x="7.4" y="11.4" width="3.3" height="5.6" rx="1"/><rect x="13.3" y="7" width="3.3" height="10" rx="1"/></symbol>
<symbol id="eos-i-settings" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.3"/><path d="M12 3v2.4M12 18.6V21M3 12h2.4M18.6 12H21M5.7 5.7l1.7 1.7M16.6 16.6l1.7 1.7M18.3 5.7l-1.7 1.7M7.4 16.6l-1.7 1.7"/></symbol>
<symbol id="eos-i-bin" viewBox="0 0 24 24"><path d="M4.4 6.6h15.2"/><path d="M9.6 6.6V4.9a1.5 1.5 0 0 1 1.5-1.5h1.8a1.5 1.5 0 0 1 1.5 1.5v1.7"/><path d="m6.6 6.6.9 12.3a2 2 0 0 0 2 1.9h5a2 2 0 0 0 2-1.9l.9-12.3"/><path d="M10.3 10.6v6M13.7 10.6v6"/></symbol>
<symbol id="eos-i-undo" viewBox="0 0 24 24"><path d="M4 9.2h9.8a5.6 5.6 0 0 1 0 11.2H8.4"/><path d="m7.6 5.2-3.6 4 3.6 4"/></symbol>
<symbol id="eos-i-dot" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/></symbol>
<symbol id="eos-i-sliders" viewBox="0 0 24 24"><path d="M5 7.4h14M5 16.6h14"/><circle cx="9.6" cy="7.4" r="2.2"/><circle cx="15" cy="16.6" r="2.2"/></symbol>
<symbol id="eos-i-exit" viewBox="0 0 24 24"><path d="M14.6 4.6H18a2 2 0 0 1 2 2v10.8a2 2 0 0 1-2 2h-3.4"/><path d="M10.4 8.2 6.6 12l3.8 3.8M6.6 12h8"/></symbol>
<symbol id="eos-i-trash" viewBox="0 0 24 24"><path d="M4.4 6.6h15.2"/><path d="M9.6 6.6V4.9a1.5 1.5 0 0 1 1.5-1.5h1.8a1.5 1.5 0 0 1 1.5 1.5v1.7"/><path d="m6.6 6.6.9 12.3a2 2 0 0 0 2 1.9h5a2 2 0 0 0 2-1.9l.9-12.3"/><path d="M10.3 10.6v6M13.7 10.6v6"/></symbol>
<symbol id="eos-i-search" viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.6"/><path d="m15.9 15.9 4.4 4.4"/></symbol>
<symbol id="eos-i-bell" viewBox="0 0 24 24"><path d="M18 8.9a6 6 0 1 0-12 0c0 5.4-2.2 6.9-2.2 6.9h16.4S18 14.3 18 8.9Z"/><path d="M13.8 19.3a2 2 0 0 1-3.6 0"/></symbol>
<symbol id="eos-i-plus" viewBox="0 0 24 24"><path d="M12 5.4v13.2M5.4 12h13.2"/></symbol>
<symbol id="eos-i-chev-r" viewBox="0 0 24 24"><path d="m9.4 5.4 6.6 6.6-6.6 6.6"/></symbol>
<symbol id="eos-i-chev-l" viewBox="0 0 24 24"><path d="m14.6 5.4-6.6 6.6 6.6 6.6"/></symbol>
<symbol id="eos-i-chev-d" viewBox="0 0 24 24"><path d="m5.4 9.4 6.6 6.6 6.6-6.6"/></symbol>
<symbol id="eos-i-x" viewBox="0 0 24 24"><path d="m6.4 6.4 11.2 11.2M17.6 6.4 6.4 17.6"/></symbol>
<symbol id="eos-i-check" viewBox="0 0 24 24"><path d="m5 12.6 4.9 4.8L19 7.2"/></symbol>
<symbol id="eos-i-edit" viewBox="0 0 24 24"><path d="M16.5 4.3a2.3 2.3 0 0 1 3.2 3.2L8.8 18.4l-4.4 1.2 1.2-4.4L16.5 4.3Z"/></symbol>
<symbol id="eos-i-phone" viewBox="0 0 24 24"><path d="M20.9 16.6v2.5a1.8 1.8 0 0 1-2 1.8 17.4 17.4 0 0 1-7.6-2.7 17.1 17.1 0 0 1-5.3-5.3A17.4 17.4 0 0 1 3.3 5.3 1.8 1.8 0 0 1 5.1 3.3h2.5a1.8 1.8 0 0 1 1.8 1.6c.1.9.3 1.8.6 2.6a1.8 1.8 0 0 1-.4 1.9l-1.2 1.2a13.9 13.9 0 0 0 5.3 5.3l1.2-1.2a1.8 1.8 0 0 1 1.9-.4c.8.3 1.7.5 2.6.6a1.8 1.8 0 0 1 1.6 1.7Z"/></symbol>
<symbol id="eos-i-mail" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2.6"/><path d="m3.9 6.6 8.1 5.9 8.1-5.9"/></symbol>
<symbol id="eos-i-clock" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.6"/><path d="M12 6.9V12l3.3 2.1"/></symbol>
<symbol id="eos-i-pin" viewBox="0 0 24 24"><path d="M19 10.4c0 5.4-7 11.2-7 11.2s-7-5.8-7-11.2a7 7 0 1 1 14 0Z"/><circle cx="12" cy="10.3" r="2.6"/></symbol>
<symbol id="eos-i-filter" viewBox="0 0 24 24"><path d="M3.6 5.4h16.8l-6.7 7.9v6.2l-3.4-2v-4.2L3.6 5.4Z"/></symbol>
<symbol id="eos-i-more" viewBox="0 0 24 24"><circle cx="5.4" cy="12" r="1.7"/><circle cx="12" cy="12" r="1.7"/><circle cx="18.6" cy="12" r="1.7"/></symbol>
<symbol id="eos-i-user" viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.9"/><path d="M4.7 20.3a7.3 7.3 0 0 1 14.6 0"/></symbol>
<symbol id="eos-i-grip" viewBox="0 0 24 24"><circle cx="9.2" cy="6" r="1.5"/><circle cx="14.8" cy="6" r="1.5"/><circle cx="9.2" cy="12" r="1.5"/><circle cx="14.8" cy="12" r="1.5"/><circle cx="9.2" cy="18" r="1.5"/><circle cx="14.8" cy="18" r="1.5"/></symbol>
<symbol id="eos-i-eye" viewBox="0 0 24 24"><path d="M2.4 12S6 5.7 12 5.7 21.6 12 21.6 12 18 18.3 12 18.3 2.4 12 2.4 12Z"/><circle cx="12" cy="12" r="2.9"/></symbol>
<symbol id="eos-i-download" viewBox="0 0 24 24"><path d="M20.6 15.4v3.4a2.4 2.4 0 0 1-2.4 2.4H5.8a2.4 2.4 0 0 1-2.4-2.4v-3.4"/><path d="m7.9 11 4.1 4.2 4.1-4.2M12 4.2v11"/></symbol>
<symbol id="eos-i-restore" viewBox="0 0 24 24"><path d="M3.6 12a8.4 8.4 0 1 0 2.7-6.1"/><path d="M3.4 4.2v4.5h4.5"/></symbol>
<symbol id="eos-i-alert" viewBox="0 0 24 24"><path d="M12 3.6 21.3 19.7H2.7L12 3.6Z"/><path d="M12 9.6v4.3M12 17.1v.1"/></symbol>
<symbol id="eos-i-palette" viewBox="0 0 24 24"><path d="M12 3.4a8.6 8.6 0 0 0 0 17.2c1.3 0 2-.9 2-1.9 0-1.5-.7-2-.7-3 0-.9.7-1.5 1.6-1.5h1.7a4.3 4.3 0 0 0 4.3-4.3C20.9 6 17 3.4 12 3.4Z"/><circle cx="8" cy="10.4" r="1.2"/><circle cx="12" cy="7.4" r="1.2"/><circle cx="15.9" cy="9.9" r="1.2"/></symbol>
<symbol id="eos-i-type" viewBox="0 0 24 24"><path d="M4.6 6.6V4.8h14.8v1.8M12 4.8v14.4M9.2 19.2h5.6"/></symbol>
<symbol id="eos-i-layout" viewBox="0 0 24 24"><rect x="3.4" y="4.4" width="17.2" height="15.2" rx="2.6"/><path d="M3.4 9.6h17.2M10 9.6v10"/></symbol>
<symbol id="eos-i-up" viewBox="0 0 24 24"><path d="M12 19V5.4"/><path d="m6.2 11.2 5.8-5.8 5.8 5.8"/></symbol>
<symbol id="eos-i-down" viewBox="0 0 24 24"><path d="M12 5v13.6"/><path d="M17.8 12.8 12 18.6l-5.8-5.8"/></symbol>
<symbol id="eos-i-minus" viewBox="0 0 24 24"><path d="M5.4 12h13.2"/></symbol>
<symbol id="eos-i-logout" viewBox="0 0 24 24"><path d="M14.6 8.2V5.9a2.1 2.1 0 0 0-2.1-2.1H6.3a2.1 2.1 0 0 0-2.1 2.1v12.2a2.1 2.1 0 0 0 2.1 2.1h6.2a2.1 2.1 0 0 0 2.1-2.1v-2.3"/><path d="M9.8 12H21M17.9 9l3 3-3 3"/></symbol>
<symbol id="eos-i-collapse" viewBox="0 0 24 24"><path d="m14.6 5.9-6.6 6.1 6.6 6.1"/></symbol>
<symbol id="eos-i-star" viewBox="0 0 24 24"><path d="m12 3.5 2.8 5.7 6.3.9-4.5 4.4 1 6.3-5.6-3-5.6 3 1-6.3L2.9 10l6.3-.9L12 3.5Z"/></symbol>
<symbol id="eos-i-send" viewBox="0 0 24 24"><path d="M21.4 3.2 3 10.3l7.4 3.3 3.3 7.4L21.4 3.2Z"/><path d="M21.4 3.2 10.4 13.6"/></symbol>
<symbol id="eos-i-file" viewBox="0 0 24 24"><path d="M13.6 3.4H7a2.4 2.4 0 0 0-2.4 2.4v12.4a2.4 2.4 0 0 0 2.4 2.4h10a2.4 2.4 0 0 0 2.4-2.4V9L13.6 3.4Z"/><path d="M13.6 3.4V9h5.8"/></symbol>
<symbol id="eos-i-tag" viewBox="0 0 24 24"><path d="M3.5 11.4V5.4a1.9 1.9 0 0 1 1.9-1.9h5.9a1.6 1.6 0 0 1 1.1.5l7.3 7.3a1.6 1.6 0 0 1 0 2.2l-6.2 6.2a1.6 1.6 0 0 1-2.2 0L3.9 12.5a1.6 1.6 0 0 1-.4-1.1Z"/><circle cx="7.9" cy="7.9" r="1.3"/></symbol>
<symbol id="eos-i-dollar" viewBox="0 0 24 24"><path d="M12 3.4v17.2"/><path d="M16.4 7.7c0-1.8-1.9-3-4.4-3s-4.4 1.2-4.4 3 1.9 2.8 4.4 3.3 4.7 1.3 4.7 3.4-2 3.2-4.7 3.2-4.4-1.4-4.4-3.1"/></symbol>
<symbol id="eos-i-wa" viewBox="0 0 24 24"><path d="M20.6 11.6a8.5 8.5 0 0 1-12.5 7.5L3.3 20.7l1.6-4.4A8.5 8.5 0 1 1 20.6 11.6Z"/><circle cx="9.2" cy="12" r="1"/><circle cx="12.1" cy="12" r="1"/><circle cx="15" cy="12" r="1"/></symbol>
</defs></svg>
SPRITE_HTML;

	/**
	 * Draw an icon by name.
	 *
	 * @param string $name  Name without the prefix.
	 * @param string $class Extra classes.
	 */
	public static function icon( string $name, string $class = '' ): string {
		$cls = '' === $class ? '' : ' class="' . esc_attr( $class ) . '"';
		return '<svg' . $cls . ' aria-hidden="true"><use href="#eos-i-' . esc_attr( $name ) . '"/></svg>';
	}

	/** Echo an icon. */
	public static function ico( string $name, string $class = '' ): void {
		echo self::icon( $name, $class ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built above.
	}

	/**
	 * A small status pill.
	 *
	 * @param string $label Readable label.
	 * @param string $tone  pos | warn | dang | info | neutral
	 */
	public static function badge( string $label, string $tone = 'neutral', string $extra = '' ): string {
		$cls = 'badge' . ( 'neutral' === $tone ? '' : ' badge--' . $tone );
		return '<span class="' . esc_attr( trim( $cls . ' ' . $extra ) ) . '">' . esc_html( $label ) . '</span>';
	}

	/**
	 * Translate a Status::tone() word into a badge colour class.
	 *
	 * Status speaks in good / warn / danger / quiet because that is what the
	 * status engine knows about; the interface speaks in the names of the
	 * badges it draws. This is the only place both are written down.
	 *
	 * @param string $tone good | warn | danger | quiet
	 */
	public static function badge_tone( string $tone ): string {
		$map = array(
			'good'   => 'live',
			'warn'   => 'pending',
			'danger' => 'danger',
			'quiet'  => 'draft',
		);
		return $map[ $tone ] ?? 'draft';
	}

	/** A status pill straight from the status engine. */
	public static function status_badge( string $family, string $value ): string {
		$label = \EstatOS\Support\Status::label( $family, $value );
		if ( '' === $label ) {
			return '';
		}
		return self::badge( $label, self::badge_tone( \EstatOS\Support\Status::tone( $family, $value ) ) );
	}

	/** A completeness / progress bar. */
	public static function meter( int $pct, string $extra = '' ): string {
		$pct = max( 0, min( 100, $pct ) );
		$cls = 'meter__fill ' . ( $pct >= 85 ? 'is-hi' : ( $pct >= 55 ? 'is-mid' : 'is-lo' ) );
		return '<div class="meter ' . esc_attr( $extra ) . '"><div class="' . $cls . '" style="width:' . (int) $pct . '%"></div></div>';
	}

	/** The empty state used when a screen has nothing to show yet. */
	public static function empty_state( string $icon, string $title, string $text, string $action = '' ): string {
		return '<div class="empty">' . self::icon( $icon ) .
			'<h4>' . esc_html( $title ) . '</h4>' .
			'<p>' . esc_html( $text ) . '</p>' .
			$action . '</div>';
	}

	/**
	 * A page heading: title on the left, actions on the right.
	 *
	 * @param string $eyebrow Small line above the title.
	 * @param string $title   Screen heading.
	 * @param string $sub     One line of explanation.
	 * @param string $actions Pre-built buttons.
	 */
	public static function phead( string $title, string $sub = '', string $actions = '', string $eyebrow = '' ): string {
		$h  = '<div class="phead">';
		$h .= '<div class="phead__l">';
		if ( '' !== $eyebrow ) {
			$h .= '<div class="phead__eyebrow">' . $eyebrow . '</div>';
		}
		$h .= '<h1 class="dsp">' . esc_html( $title ) . '</h1>';
		if ( '' !== $sub ) {
			$h .= '<p class="phead__sub mut">' . esc_html( $sub ) . '</p>';
		}
		$h .= '</div>';
		if ( '' !== $actions ) {
			$h .= '<div class="phead__r">' . $actions . '</div>';
		}
		$h .= '</div>';
		return $h;
	}

	/** A button that links somewhere. */
	public static function link_button( string $href, string $label, string $icon = '', string $style = 'ghost' ): string {
		$i = '' === $icon ? '' : self::icon( $icon );
		return '<a class="btn btn--' . esc_attr( $style ) . '" href="' . esc_url( $href ) . '">' . $i . esc_html( $label ) . '</a>';
	}

	/** Initials for an avatar. */
	public static function initials( string $name ): string {
		$parts = preg_split( '/\s+/', trim( $name ) ) ?: array();
		$out   = '';
		foreach ( array_slice( $parts, 0, 2 ) as $p ) {
			$out .= function_exists( 'mb_substr' ) ? mb_substr( $p, 0, 1 ) : substr( $p, 0, 1 );
		}
		return '' === $out ? '?' : strtoupper( $out );
	}
}
