<?php
/**
 * Change Requests — what the field asked the office to change.
 *
 * An agent on a phone can propose a change but not make it; that lands here.
 * Each card shows the old value and the new value side by side with the
 * difference marked, so a yes or a no takes one look rather than a
 * comparison against another screen.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Os\Screens;

use EstatOS\Admin\Os\Shell;
use EstatOS\Admin\Os\Ui;
use EstatOS\Install\Schema;
use EstatOS\Support\Status;

defined( 'ABSPATH' ) || exit;

final class RequestsScreen {

	public static function render(): void {
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( (string) ( is_array( $_GET['status'] ) ? '' : $_GET['status'] ) ) ) : 'pending';
		$rows   = self::rows( $status );

		Shell::open( 'estat-requests' );

		echo '<div class="phead"><div class="phead__l">';
		echo '<div class="phead__eyebrow"><span class="lbl">' . esc_html__( 'People', 'estat-os' ) . '</span></div>';
		echo '<h1>' . esc_html__( 'Change Requests', 'estat-os' ) . '</h1>';
		echo '<p class="phead__sub mut">' . esc_html__( 'What your agents asked to change, waiting on your yes or no.', 'estat-os' ) . '</p>';
		echo '</div></div>';

		echo '<div class="filters">';
		foreach ( array( 'pending' => __( 'Waiting', 'estat-os' ), 'approved' => __( 'Approved', 'estat-os' ), 'declined' => __( 'Declined', 'estat-os' ) ) as $key => $word ) {
			printf(
				'<a class="chipf%1$s" href="%2$s">%3$s</a>',
				$key === $status ? ' is-on' : '',
				esc_url( admin_url( 'admin.php?page=estat-requests&status=' . $key ) ),
				esc_html( $word )
			);
		}
		echo '</div>';

		echo '<div id="reqList" style="display:grid;gap:var(--s4)">';
		if ( ! $rows ) {
			echo '<div class="panel">';
			echo Ui::empty_state(
				'check',
				__( 'Nothing is waiting', 'estat-os' ),
				__( 'When an agent sends a change from their phone, it appears here for you to approve or decline.', 'estat-os' )
			);
			echo '</div>';
		} else {
			foreach ( $rows as $i => $r ) {
				self::card( $r, $i );
			}
		}
		echo '</div>';

		Shell::close();
	}

	/**
	 * Requests out of the office's own table, plus listings left in the
	 * WordPress "pending" state by someone who could not publish.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	private static function rows( string $status ): array {
		$out = array();

		if ( Schema::healthy() ) {
			global $wpdb;
			$table = Schema::table( 'estat_requests' );
			// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$found = $wpdb->get_results(
				$wpdb->prepare( "SELECT * FROM {$table} WHERE status = %s ORDER BY created_at DESC LIMIT 100", $status ),
				ARRAY_A
			);
			// phpcs:enable
			foreach ( (array) $found as $r ) {
				$out[] = array(
					'id'      => (int) $r['id'],
					'kind'    => 'table',
					'record'  => (int) $r['record_id'],
					'who'     => self::person( (int) $r['requested_by'] ),
					'when'    => (string) $r['created_at'],
					'reason'  => (string) ( $r['reason'] ?? '' ),
					'message' => (string) ( $r['message'] ?? '' ),
					'changes' => self::decode( (string) ( $r['changes'] ?? '' ) ),
				);
			}
		}

		if ( 'pending' === $status ) {
			$q = new \WP_Query(
				array(
					'post_type'      => \EstatOS\Data\PostTypes::LISTING,
					'post_status'    => 'pending',
					'posts_per_page' => 50,
					'no_found_rows'  => true,
				)
			);
			foreach ( $q->posts as $p ) {
				$out[] = array(
					'id'      => (int) $p->ID,
					'kind'    => 'listing',
					'record'  => (int) $p->ID,
					'who'     => self::person( (int) $p->post_author ),
					'when'    => (string) $p->post_modified,
					'reason'  => '',
					'message' => __( 'This property is waiting to be published.', 'estat-os' ),
					'changes' => array(),
				);
			}
		}

		return $out;
	}

	private static function decode( string $json ): array {
		if ( '' === $json ) {
			return array();
		}
		$out = json_decode( $json, true );
		return is_array( $out ) ? $out : array();
	}

	private static function person( int $user_id ): string {
		if ( $user_id <= 0 ) {
			return __( 'Someone', 'estat-os' );
		}
		$u = get_userdata( $user_id );
		return $u ? ( $u->display_name ?: $u->user_login ) : __( 'Someone', 'estat-os' );
	}

	/** One request card: old against new, then the two answers. */
	private static function card( array $r, int $i ): void {
		printf(
			'<div class="panel anim" data-id="%1$d" style="--d:%2$dms">',
			(int) $r['id'],
			$i * 50
		);

		echo '<div class="panel__h"><div>';
		echo '<h3>' . esc_html( get_the_title( (int) $r['record'] ) ?: __( 'A property', 'estat-os' ) ) . '</h3>';
		echo '<div class="lbl">' . esc_html(
			sprintf(
				/* translators: 1: person, 2: when. */
				__( '%1$s asked %2$s ago', 'estat-os' ),
				$r['who'],
				human_time_diff( strtotime( (string) $r['when'] ) ?: time(), time() )
			)
		) . '</div>';
		echo '</div><div class="panel__hr">';
		echo Ui::status_badge( Status::REQUEST, isset( $_GET['status'] ) && 'approved' === $_GET['status'] ? 'approved' : ( isset( $_GET['status'] ) && 'declined' === $_GET['status'] ? 'declined' : 'pending' ) );
		echo '</div></div>';

		echo '<div class="panel__b" style="display:grid;gap:var(--s4)">';

		if ( '' !== $r['message'] ) {
			echo '<p class="mut" style="margin:0;font-size:var(--fs-name);line-height:1.6">' . esc_html( $r['message'] ) . '</p>';
		}

		if ( $r['changes'] ) {
			echo '<div class="diff">';
			echo '<div class="diff__h"><span>' . esc_html__( 'Was', 'estat-os' ) . '</span>';
			echo '<span>' . esc_html__( 'Asked for', 'estat-os' ) . '</span></div>';
			foreach ( $r['changes'] as $field => $pair ) {
				$old = is_array( $pair ) ? (string) ( $pair['old'] ?? '' ) : '';
				$new = is_array( $pair ) ? (string) ( $pair['new'] ?? '' ) : (string) $pair;
				$hit = $old !== $new;
				echo '<div class="diff__c' . ( $hit ? ' is-diff' : '' ) . '">';
				echo '<span class="diff__v">' . esc_html( '' === $old ? '—' : $old ) . '</span>';
				echo '<span class="diff__arw">';
				Ui::ico( 'chev-r' );
				echo '</span>';
				echo '<span class="diff__v diff__c--new">' . esc_html( '' === $new ? '—' : $new ) . '</span>';
				echo '</div>';
			}
			echo '</div>';
		}

		if ( 'pending' === ( $_GET['status'] ?? 'pending' ) ) {
			echo '<div style="display:flex;gap:var(--s2);justify-content:flex-end">';
			printf(
				'<button type="button" class="btn btn--ok" data-act="approve" data-id="%1$d" data-kind="%2$s">%3$s</button>',
				(int) $r['id'],
				esc_attr( (string) $r['kind'] ),
				esc_html__( 'Approve', 'estat-os' )
			);
			printf(
				'<button type="button" class="btn btn--danger" data-act="decline" data-id="%1$d" data-kind="%2$s">%3$s</button>',
				(int) $r['id'],
				esc_attr( (string) $r['kind'] ),
				esc_html__( 'Decline', 'estat-os' )
			);
			echo '</div>';
		}

		echo '</div></div>';
	}
}
