<?php
/**
 * Team — the people who work the office and the field.
 *
 * One card per person with the two numbers that say how busy they are: how
 * many properties they hold and how many live enquiries are theirs. Nothing
 * else, because nobody has ever managed a team from a table of columns.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Os\Screens;

use EstatOS\Admin\Os\Shell;
use EstatOS\Admin\Os\Ui;
use EstatOS\Data\Agents;
use EstatOS\Data\PostTypes;
use EstatOS\Install\Schema;
use EstatOS\Leads\Leads;

defined( 'ABSPATH' ) || exit;

final class TeamScreen {

	public static function render(): void {
		$q = new \WP_Query(
			array(
				'post_type'      => PostTypes::AGENT,
				'post_status'    => array( 'publish', 'draft', 'private' ),
				'posts_per_page' => 60,
				'orderby'        => 'title',
				'order'          => 'ASC',
				'no_found_rows'  => true,
			)
		);

		Shell::open( 'estat-team' );

		echo '<div class="phead"><div class="phead__l">';
		echo '<div class="phead__eyebrow"><span class="lbl">' . esc_html__( 'People', 'estat-os' ) . '</span></div>';
		echo '<h1>' . esc_html__( 'Team', 'estat-os' ) . '</h1>';
		echo '<p class="phead__sub mut">' . esc_html__( 'Who works here, what they hold, and how to reach them.', 'estat-os' ) . '</p>';
		echo '</div><div class="phead__r">';
		echo '<button type="button" class="btn btn--primary" data-drawer="agent" data-id="0">';
		Ui::ico( 'plus' );
		esc_html_e( 'Add member', 'estat-os' );
		echo '</button>';
		echo '</div></div>';

		echo '<div class="bento bento--cards" id="teamGrid">';
		if ( ! $q->have_posts() ) {
			echo '<div class="panel b12 anim">';
			echo Ui::empty_state(
				'users',
				__( 'No team members yet', 'estat-os' ),
				__( 'Add the people who take the calls and show the homes. Each one gets an account and a phone app.', 'estat-os' ),
				'<button type="button" class="btn btn--primary" data-drawer="agent" data-id="0">' . esc_html__( 'Add member', 'estat-os' ) . '</button>'
			);
			echo '</div>';
		} else {
			foreach ( $q->posts as $i => $p ) {
				self::card( (int) $p->ID, $i );
			}
		}
		echo '</div>';

		Shell::close();
	}

	private static function card( int $id, int $i ): void {
		$data   = Agents::to_array( $id );
		$name   = (string) ( $data['name'] ?? '' ) ?: get_the_title( $id );
		$role   = (string) ( $data['role'] ?? '' );
		$phone  = (string) ( $data['phone'] ?? '' );
		$photo  = (string) ( $data['photo'] ?? '' );
		$homes  = Agents::listing_count( $id );
		$leads  = Schema::healthy() ? (int) Leads::query( array( 'agent_id' => $id, 'per_page' => 1 ) )['total'] : 0;

		printf(
			'<button type="button" class="panel card card--lift b3 anim" style="--d:%1$dms" data-drawer="agent" data-id="%2$d">',
			$i * 40,
			$id
		);

		echo '<span class="tcard__hd">';
		printf(
			'<span class="tcard__av"%1$s>%2$s</span>',
			$photo ? ' style="background-image:url(' . esc_url( $photo ) . ')"' : '',
			esc_html( $photo ? '' : Ui::initials( $name ) )
		);
		echo '<span class="tcard__id">';
		printf( '<b class="tcard__name">%1$s</b>', esc_html( $name ) );
		printf(
			'<span class="tcard__role mut">%1$s</span>',
			esc_html( '' !== $role ? $role : __( 'Agent', 'estat-os' ) )
		);
		echo '</span></span>';

		printf(
			'<span class="tcard__row">%1$s<span class="num">%2$s</span></span>',
			Ui::icon( 'phone' ),
			esc_html( '' !== $phone ? $phone : __( 'No number yet', 'estat-os' ) )
		);

		echo '<span class="divider"></span>';

		echo '<span class="tcard__stats">';
		printf(
			'<span><span class="lbl">%1$s</span><b class="num">%2$d</b></span>',
			esc_html__( 'Properties', 'estat-os' ),
			(int) $homes
		);
		printf(
			'<span><span class="lbl">%1$s</span><b class="num">%2$d</b></span>',
			esc_html__( 'Enquiries', 'estat-os' ),
			(int) $leads
		);
		echo '</span>';

		echo '</button>';
	}
}
