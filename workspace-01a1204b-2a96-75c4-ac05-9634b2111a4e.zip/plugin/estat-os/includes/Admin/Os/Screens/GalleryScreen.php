<?php
/**
 * Gallery & Media — every photograph, plan, brochure and paper file.
 *
 * Four folders down the side, a wall of files in the middle, and a drop zone
 * that takes a whole folder at once. Tick the files you want and the bar at
 * the bottom of the screen acts on all of them, which is the only way a
 * two-hundred-photo clean-up is ever finished.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Os\Screens;

use EstatOS\Admin\Os\Shell;
use EstatOS\Admin\Os\Ui;
use EstatOS\Data\Media;

defined( 'ABSPATH' ) || exit;

final class GalleryScreen {

	private const PER_PAGE = 40;

	public static function render(): void {
		$kind  = isset( $_GET['kind'] ) ? sanitize_key( wp_unslash( (string) ( is_array( $_GET['kind'] ) ? '' : $_GET['kind'] ) ) ) : '';
		$page  = max( 1, (int) ( $_GET['paged'] ?? 1 ) );
		$result = Media::query(
			array(
				'kind'     => $kind,
				'paged'    => $page,
				'per_page' => self::PER_PAGE,
			)
		);
		$counts = Media::counts();

		Shell::open( 'estat-gallery' );

		echo '<div class="phead"><div class="phead__l">';
		echo '<div class="phead__eyebrow"><span class="lbl">' . esc_html__( 'Inventory', 'estat-os' ) . '</span></div>';
		echo '<h1>' . esc_html__( 'Gallery & Media', 'estat-os' ) . '</h1>';
		echo '<p class="phead__sub mut">' . esc_html__( 'Every photograph, plan and document the office holds.', 'estat-os' ) . '</p>';
		echo '</div><div class="phead__r">';
		echo '<button type="button" class="btn btn--primary" id="galPick">';
		Ui::ico( 'upload' );
		esc_html_e( 'Upload', 'estat-os' );
		echo '</button>';
		echo '</div></div>';

		echo '<div style="display:grid;grid-template-columns:200px minmax(0,1fr);gap:var(--s5);align-items:start">';

		self::folders( $kind, $counts );

		echo '<div style="display:grid;gap:var(--s4)">';

		echo '<div class="dropzone" id="galDrop" data-dropzone style="padding:var(--s6)">';
		Ui::ico( 'upload' );
		echo '<h4>' . esc_html__( 'Drop files here', 'estat-os' ) . '</h4>';
		echo '<p>' . esc_html__( 'or click to choose — photographs, PDFs and plans', 'estat-os' ) . '</p>';
		echo '</div>';
		echo '<div id="galUploads" style="display:grid;gap:var(--s2)"></div>';

		echo '<div style="display:flex;align-items:center;gap:var(--s3)">';
		echo '<label class="cbrow" id="galSelectAllWrap"><i class="cb" id="galSelectAll" role="checkbox" aria-checked="false" tabindex="0"></i>';
		echo '<span style="font-size:var(--fs-name);font-weight:600">' . esc_html__( 'Select all', 'estat-os' ) . '</span></label>';
		echo '<span class="mut" id="galCount" style="font-size:var(--fs-meta)"></span>';
		echo '</div>';

		echo '<div class="masonry" id="galGrid">';
		if ( ! $result['items'] ) {
			echo '<div class="panel" style="grid-column:1/-1">';
			echo Ui::empty_state(
				'image',
				__( 'Nothing here yet', 'estat-os' ),
				__( 'Drop photographs, floor plans, brochures or documents into the box above.', 'estat-os' )
			);
			echo '</div>';
		} else {
			foreach ( $result['items'] as $i => $file ) {
				self::tile( (array) $file, $i );
			}
		}
		echo '</div>';

		self::pager( (int) $result['pages'], $page, $kind );

		echo '</div></div>';

		Shell::close();
	}

	private static function folders( string $kind, array $counts ): void {
		echo '<div id="galTabs" style="display:grid;gap:2px">';
		printf(
			'<a class="setnav__b%1$s" href="%2$s">%3$s<span class="nav__badge">%4$d</span></a>',
			'' === $kind ? ' is-on' : '',
			esc_url( admin_url( 'admin.php?page=estat-gallery' ) ),
			esc_html__( 'Everything', 'estat-os' ),
			(int) array_sum( $counts )
		);
		foreach ( Media::kinds() as $key => $word ) {
			printf(
				'<a class="setnav__b%1$s" href="%2$s">%3$s<span class="nav__badge">%4$d</span></a>',
				$key === $kind ? ' is-on' : '',
				esc_url( admin_url( 'admin.php?page=estat-gallery&kind=' . $key ) ),
				esc_html( $word ),
				(int) ( $counts[ $key ] ?? 0 )
			);
		}
		echo '</div>';
	}

	private static function tile( array $file, int $i ): void {
		$thumb = (string) ( $file['thumb'] ?? '' );
		$url   = (string) ( $file['url'] ?? '' );
		printf(
			'<div class="tile" data-id="%1$d" style="animation:eos-rise 320ms var(--e-out) both;animation-delay:%2$dms">',
			(int) ( $file['id'] ?? 0 ),
			$i * 25
		);
		printf(
			'<span class="tile__img"%1$s>%2$s</span>',
			( ! empty( $file['is_image'] ) && $thumb ) ? ' style="background-image:url(' . esc_url( $thumb ) . ')"' : '',
			( ! empty( $file['is_image'] ) && $thumb ) ? '' : Ui::icon( 'file' )
		);
		echo '<span class="tile__ov">';
		echo '<span class="tile__cb"><i class="cb" data-tilecb role="checkbox" aria-checked="false" tabindex="0"></i></span>';
		printf(
			'<span class="tile__ex">%1$s</span>',
			esc_html( strtoupper( (string) ( $file['kind'] ?? __( 'file', 'estat-os' ) ) ) )
		);
		echo '</span>';
		printf(
			'<span class="tile__nm"><b>%1$s</b><span class="mut">%2$s</span></span>',
			esc_html( (string) ( $file['title'] ?? '' ) ),
			esc_html( (string) ( $file['linked_name'] ?? __( 'Not linked', 'estat-os' ) ) )
		);
		echo '</div>';
	}

	private static function pager( int $pages, int $page, string $kind ): void {
		if ( $pages < 2 ) {
			return;
		}
		echo '<div class="pager">';
		for ( $p = 1; $p <= $pages; $p++ ) {
			printf(
				'<a class="pg%1$s" href="%2$s">%3$d</a>',
				$p === $page ? ' is-on' : '',
				esc_url( admin_url( 'admin.php?page=estat-gallery' . ( '' === $kind ? '' : '&kind=' . $kind ) . '&paged=' . $p ) ),
				$p
			);
		}
		echo '</div>';
	}
}
