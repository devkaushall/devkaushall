<?php
/**
 * Forms — the visual builder for the forms on the website.
 *
 * Three panes: what you can add, what the visitor will see, and what the
 * field you just touched is called. The middle pane is the real preview —
 * it is the same markup the public renderer draws, so what looks right here
 * is what a buyer gets.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Os\Screens;

use EstatOS\Admin\Os\Shell;
use EstatOS\Admin\Os\Ui;
use EstatOS\Forms\Forms;

defined( 'ABSPATH' ) || exit;

final class FormsScreen {

	/**
	 * The tools in the left pane: field type => (icon, label).
	 *
	 * A method and not a constant because the labels are translated, and a
	 * PHP constant expression may not call a function.
	 *
	 * @return array<string,array{0:string,1:string}>
	 */
	private static function tools(): array {
		return array(
			'text'     => array( 'type', __( 'Text', 'estat-os' ) ),
			'email'    => array( 'mail', __( 'Email', 'estat-os' ) ),
			'phone'    => array( 'phone', __( 'Phone', 'estat-os' ) ),
			'select'   => array( 'chev-d', __( 'Dropdown', 'estat-os' ) ),
			'checkbox' => array( 'check', __( 'Checkbox', 'estat-os' ) ),
			'radio'    => array( 'star', __( 'Choice', 'estat-os' ) ),
			'textarea' => array( 'form', __( 'Long text', 'estat-os' ) ),
			'date'     => array( 'calendar', __( 'Date', 'estat-os' ) ),
		);
	}

	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_forms' ) ) {
			wp_die( esc_html__( 'You do not have permission to manage forms.', 'estat-os' ) );
		}

		$all    = Forms::all( 50 );
		$form_id = isset( $_GET['form'] ) ? absint( wp_unslash( (string) ( is_array( $_GET['form'] ) ? 0 : $_GET['form'] ) ) ) : 0;
		if ( ! $form_id && ! empty( $all ) ) {
			$form_id = (int) $all[0]['id'];
		}
		$form   = $form_id ? Forms::get( $form_id ) : null;
		$fields = $form ? Forms::flatten( (array) $form['definition'] ) : array();

		Shell::open( 'estat-forms' );

		echo '<div class="phead"><div class="phead__l">';
		echo '<div class="phead__eyebrow"><span class="lbl">' . esc_html__( 'Build', 'estat-os' ) . '</span></div>';
		echo '<h1>' . esc_html__( 'Forms', 'estat-os' ) . '</h1>';
		echo '<p class="phead__sub mut">' . esc_html__( 'What a visitor fills in when they want to know more.', 'estat-os' ) . '</p>';
		echo '</div><div class="phead__r">';
		if ( count( $all ) > 1 ) {
			echo '<select class="in" style="height:32px;width:220px;font-size:var(--fs-meta)" onchange="if(this.value)location.href=this.value">';
			foreach ( $all as $f ) {
				printf(
					'<option value="%1$s"%2$s>%3$s</option>',
					esc_url( admin_url( 'admin.php?page=estat-forms&form=' . (int) $f['id'] ) ),
					selected( (int) $f['id'], $form_id, false ),
					// The row carries 'name' (see Forms::all()). Reading
					// 'title' drew an empty option in the "which form" menu
					// and raised a warning on every visit to this screen.
					esc_html( (string) ( $f['name'] ?? $f['title'] ?? '' ) )
				);
			}
			echo '</select>';
		}
		echo '<button type="button" class="btn btn--ghost" data-act="form-preview" data-id="' . (int) $form_id . '">';
		Ui::ico( 'eye' );
		esc_html_e( 'Preview', 'estat-os' );
		echo '</button>';
		echo '<button type="button" class="btn btn--primary" id="fbSave">';
		Ui::ico( 'check' );
		esc_html_e( 'Save form', 'estat-os' );
		echo '</button>';
		echo '</div></div>';

		echo '<input type="hidden" id="fbFormId" value="' . (int) $form_id . '">';
		echo '<div class="panel" style="overflow:hidden"><div class="fb">';

		echo '<div class="fb__l"><div class="lbl" style="margin-bottom:var(--s3)">' . esc_html__( 'Add a field', 'estat-os' ) . '</div>';
		echo '<div id="fbTools" style="display:grid;gap:4px">';
		foreach ( self::tools() as $type => $tool ) {
			printf(
				'<button type="button" class="fbtool" data-tool="%1$s">%2$s%3$s</button>',
				esc_attr( $type ),
				Ui::icon( $tool[0] ),
				esc_html( $tool[1] )
			);
		}
		echo '</div></div>';

		echo '<div class="fb__c"><div id="fbCanvas" style="display:grid;gap:var(--s3);max-width:560px;margin:0 auto">';
		foreach ( $fields as $i => $f ) {
			self::field( (array) $f, $i );
		}
		echo '</div>';
		echo '<div id="fbEmpty" class="empty"' . ( $fields ? ' hidden' : '' ) . '>';
		Ui::ico( 'form' );
		echo '<h4>' . esc_html__( 'No fields yet', 'estat-os' ) . '</h4>';
		echo '<p>' . esc_html__( 'Click one on the left to add it.', 'estat-os' ) . '</p>';
		echo '</div></div>';

		echo '<div class="fb__r"><div class="lbl" style="margin-bottom:var(--s3)">' . esc_html__( 'Field settings', 'estat-os' ) . '</div>';
		echo '<div id="fbSettings"><div class="mut" style="font-size:var(--fs-name);line-height:1.6">' . esc_html__( 'Click a field on the canvas to change it.', 'estat-os' ) . '</div></div>';
		echo '</div>';

		echo '</div></div>';

		Shell::close();
	}

	/**
	 * One box on the canvas.
	 *
	 * This is the markup the browser's own half of the builder reads back when
	 * it saves. The two halves used to disagree: a box that was already on the
	 * form was drawn as `.fbfield` with `data-type` and an index, while a box
	 * added in the session was drawn as `.fld` with `data-kind` and an id — so
	 * "Save form" collected only the boxes added since the page was opened and
	 * wrote everything else away, and the ✕ on an existing box did nothing at
	 * all. The class names and the attributes below are now the one contract
	 * both halves speak; `addField()` in admin-os.js builds the same shape.
	 *
	 * @param array<string,mixed> $f Field as stored.
	 * @param int                 $i Position, used when the field has no id yet.
	 * @return void
	 */
	private static function field( array $f, int $i ): void {
		$type  = (string) ( $f['type'] ?? 'text' );
		$label = (string) ( $f['label'] ?? '' );
		$ph    = (string) ( $f['placeholder'] ?? '' );
		$req   = ! empty( $f['required'] );
		$id    = (string) ( $f['id'] ?? '' );
		if ( '' === $id ) {
			$id = 'f' . $i;
		}
		$name  = '' !== $label ? $label : ucfirst( str_replace( '_', ' ', $type ) );

		// The choices a dropdown or a choice list carries are part of the box:
		// they are handed to the save through the same attribute the browser's
		// half reads, so pressing Save cannot empty a list.
		$options = array();
		foreach ( (array) ( $f['options'] ?? array() ) as $option ) {
			if ( is_scalar( $option ) ) {
				$options[] = (string) $option;
			}
		}

		printf(
			'<div class="fbfield fld" data-f="%1$s" data-kind="%2$s" data-type="%2$s" data-label="%3$s" data-ph="%4$s" data-req="%5$s" data-options="%6$s">',
			esc_attr( $id ),
			esc_attr( $type ),
			esc_attr( $label ),
			esc_attr( $ph ),
			$req ? '1' : '',
			esc_attr( (string) wp_json_encode( $options ) )
		);
		echo '<div class="fbfield__h fld__h"><span class="fbfield__grip fld__g">';
		Ui::ico( 'grip' );
		echo '</span><b>' . esc_html( $name ) . '</b>';
		echo '<button type="button" class="fbfield__x fld__x" data-fx="' . esc_attr( $id ) . '" aria-label="'
			. esc_attr__( 'Remove this field', 'estat-os' ) . '">&times;</button></div>';
		echo '<div class="fbfield__b fld__b">' . self::preview( $type, $name, $ph, $req ) . '</div>';
		echo '</div>';
	}

	/**
	 * What the box looks like on the canvas — the same shapes the palette
	 * draws when a box is added in the session.
	 *
	 * @param string $type  Field type.
	 * @param string $name  Label to draw.
	 * @param string $ph    Placeholder.
	 * @param bool   $req   Whether it must be filled.
	 * @return string Escaped markup.
	 */
	private static function preview( string $type, string $name, string $ph, bool $req ): string {
		$label = '<label class="field__lbl">' . esc_html( $name ) . ( $req ? ' <span class="mut">*</span>' : '' ) . '</label>';

		switch ( $type ) {
			case 'textarea':
				return $label . '<textarea class="in" placeholder="' . esc_attr( $ph ) . '" rows="3"></textarea>';
			case 'select':
				return $label . '<select class="in"><option>' . esc_html( $ph ?: __( 'Choose one…', 'estat-os' ) ) . '</option></select>';
			case 'radio':
			case 'checkbox':
				$word = 'checkbox' === $type ? __( 'Tick box', 'estat-os' ) : __( 'Choices, one per line', 'estat-os' );
				return $label . '<div class="in in--fake">' . esc_html( $word ) . '</div>';
			case 'date':
				return $label . '<input class="in" type="date">';
			case 'number':
				return $label . '<input class="in" type="number">';
			case 'email':
				return $label . '<input class="in" type="email" placeholder="' . esc_attr( $ph ) . '">';
			case 'url':
				return $label . '<input class="in" type="url" placeholder="' . esc_attr( $ph ) . '">';
			case 'phone':
				return $label . '<input class="in" type="tel" placeholder="' . esc_attr( $ph ) . '">';
			case 'file':
				return $label . '<div class="in in--fake">' . esc_html__( 'Choose a file', 'estat-os' ) . '</div>';
			default:
				return $label . '<input class="in" type="text" placeholder="' . esc_attr( $ph ) . '">';
		}
	}
}
