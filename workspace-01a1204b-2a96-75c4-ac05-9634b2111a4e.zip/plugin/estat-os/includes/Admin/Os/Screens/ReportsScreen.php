<?php
/**
 * Reports & Analytics — three questions the office actually asks.
 *
 * Where do enquiries come from (bars), what does the inventory consist of
 * (donut), and how is each person doing (lines). Every figure is counted
 * from the office's own records and cached for five minutes, because a
 * report nobody waits for is a report nobody opens.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Os\Screens;

use EstatOS\Admin\Os\Shell;
use EstatOS\Admin\Os\Ui;
use EstatOS\Data\PostTypes;
use EstatOS\Install\Schema;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

final class ReportsScreen {

	private const CACHE = 5 * MINUTE_IN_SECONDS;

	public static function render(): void {
		Shell::open( 'estat-reports' );

		echo '<div class="phead"><div class="phead__l">';
		echo '<div class="phead__eyebrow"><span class="lbl">' . esc_html__( 'Overview', 'estat-os' ) . '</span></div>';
		echo '<h1>' . esc_html__( 'Reports & Analytics', 'estat-os' ) . '</h1>';
		echo '<p class="phead__sub mut">' . esc_html__( 'Where the business is coming from, what you hold, and who is working it.', 'estat-os' ) . '</p>';
		echo '</div><div class="phead__r">';
		echo '<a class="btn btn--ghost" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=estat_export_csv&kind=leads' ), 'estat_export_csv' ) ) . '">';
		Ui::ico( 'download' );
		esc_html_e( 'Export enquiries', 'estat-os' );
		echo '</a>';
		echo '</div></div>';

		echo '<div class="bento">';
		self::sources();
		self::inventory();
		self::agents();
		self::summary();
		echo '</div>';

		Shell::close();
	}

	/* ------------------------------------------------------------ bar chart */

	private static function sources(): void {
		$rows = self::cached( 'sources', array( __CLASS__, 'query_sources' ) );

		echo '<div class="panel b6 anim" style="--d:0ms">';
		echo '<div class="panel__h"><div><h3>' . esc_html__( 'Where enquiries come from', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'Last 90 days', 'estat-os' ) . '</div></div></div>';
		echo '<div class="panel__b chartbox" id="chtBar" style="padding:var(--s4) var(--s5) var(--s5)">';
		echo self::bars( $rows );
		echo '</div></div>';
	}

	private static function query_sources(): array {
		if ( ! Schema::healthy() ) {
			return array();
		}
		global $wpdb;
		$table = Schema::table( 'estat_leads' );
		$since = gmdate( 'Y-m-d H:i:s', time() - 90 * DAY_IN_SECONDS );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT source, COUNT(*) AS c FROM {$table} WHERE created_at >= %s GROUP BY source ORDER BY c DESC LIMIT 8",
				$since
			),
			ARRAY_A
		);
		// phpcs:enable
		$map  = Vocabulary::lead_sources();
		$out  = array();
		foreach ( (array) $rows as $r ) {
			$key       = (string) $r['source'];
			$out[]     = array( (string) ( $map[ $key ] ?? ( '' === $key ? __( 'Not known', 'estat-os' ) : ucfirst( str_replace( '_', ' ', $key ) ) ) ), (int) $r['c'] );
		}
		return $out;
	}

	private static function bars( array $rows ): string {
		if ( ! $rows ) {
			return '<p class="mut" style="font-size:var(--fs-name);margin:0">' . esc_html__( 'No enquiries in this period yet.', 'estat-os' ) . '</p>';
		}

		$max = 0;
		foreach ( $rows as $r ) {
			$max = max( $max, (int) $r[1] );
		}
		$max = $max > 0 ? $max : 1;

		$w    = 720;
		$h    = 260;
		$pad  = 34;
		$base = $h - 34;
		$n    = count( $rows );
		$slot = ( $w - $pad * 2 ) / $n;
		$bw   = min( 54, $slot * 0.56 );

		$svg = '<svg class="chart" viewBox="0 0 ' . $w . ' ' . $h . '" style="width:100%;height:auto" role="img">';
		for ( $g = 0; $g <= 4; $g++ ) {
			$y = $base - $g * ( $base - 14 ) / 4;
			$svg .= '<line class="gl" x1="' . $pad . '" x2="' . ( $w - $pad ) . '" y1="' . round( $y, 1 ) . '" y2="' . round( $y, 1 ) . '"/>';
		}
		foreach ( $rows as $i => $r ) {
			$bh   = (int) $r[1] / $max * ( $base - 20 );
			$x    = $pad + $i * $slot + ( $slot - $bw ) / 2;
			$svg .= '<rect class="bar" x="' . round( $x, 1 ) . '" y="' . round( $base - $bh, 1 ) . '" width="' . round( $bw, 1 ) . '" height="' . round( max( 2, $bh ), 1 ) . '" rx="4" style="--d:' . ( $i * 70 ) . 'ms"/>';
			$svg .= '<text x="' . round( $x + $bw / 2, 1 ) . '" y="' . round( $base - $bh - 7, 1 ) . '" text-anchor="middle" style="font-weight:700;fill:var(--ink-2)">' . (int) $r[1] . '</text>';
			$svg .= '<text x="' . round( $x + $bw / 2, 1 ) . '" y="' . ( $h - 12 ) . '" text-anchor="middle">' . esc_html( self::trim( (string) $r[0], 14 ) ) . '</text>';
		}
		$svg .= '</svg>';
		return $svg;
	}

	/* ---------------------------------------------------------- donut chart */

	private static function inventory(): void {
		$rows = self::cached( 'inventory', array( __CLASS__, 'query_inventory' ) );

		echo '<div class="panel b3 anim" style="--d:60ms">';
		echo '<div class="panel__h"><div><h3>' . esc_html__( 'What you hold', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'Properties by kind', 'estat-os' ) . '</div></div></div>';
		echo '<div class="panel__b chartbox" style="padding:var(--s4)" id="chtDonut">';
		echo self::donut( $rows );
		echo '</div>';
		echo '<div class="lgd" id="donutLgd" style="padding:0 var(--s4) var(--s4)">';
		foreach ( $rows as $r ) {
			echo '<span class="lgd__i"><i class="lgd__sw" style="background:' . esc_attr( (string) $r[2] ) . '"></i>' . esc_html( (string) $r[0] ) . ' <b>' . (int) $r[1] . '</b></span>';
		}
		echo '</div></div>';
	}

	private static function query_inventory(): array {
		global $wpdb;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT pm.meta_value AS kind, COUNT(*) AS c
				 FROM {$wpdb->postmeta} pm
				 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				 WHERE pm.meta_key = %s
				   AND p.post_type = %s
				   AND p.post_status IN ('publish','draft','pending','private')
				 GROUP BY pm.meta_value ORDER BY c DESC LIMIT 6",
				'_estat_property_type',
				PostTypes::LISTING
			),
			ARRAY_A
		);
		// phpcs:enable

		$types  = Vocabulary::property_types_all();
		$shades = array( '#725b2f', '#a68b5b', '#3f6b4f', '#3c5a7a', '#8a6a1f', '#8c3b32' );
		$out    = array();
		$i      = 0;
		foreach ( (array) $rows as $r ) {
			$key   = (string) $r['kind'];
			$label = $types[ $key ] ?? ( '' === $key ? __( 'Not set', 'estat-os' ) : ucfirst( str_replace( '-', ' ', $key ) ) );
			$out[] = array( $label, (int) $r['c'], $shades[ $i % count( $shades ) ] );
			++$i;
		}
		return $out;
	}

	private static function donut( array $rows ): string {
		$total = 0;
		foreach ( $rows as $r ) {
			$total += (int) $r[1];
		}
		if ( $total <= 0 ) {
			return '<p class="mut" style="font-size:var(--fs-name);margin:0">' . esc_html__( 'No properties yet.', 'estat-os' ) . '</p>';
		}

		$r    = 78;
		$circ = 2 * M_PI * $r;
		$svg  = '<svg class="chart" viewBox="0 0 200 200" style="width:100%;max-width:230px;height:auto;margin:0 auto;display:block" role="img">';
		$svg .= '<circle cx="100" cy="100" r="' . $r . '" fill="none" stroke="var(--inset)" stroke-width="14"/>';

		$offset = 0;
		foreach ( $rows as $i => $d ) {
			$len  = (int) $d[1] / $total * $circ;
			$svg .= '<circle class="ring" cx="100" cy="100" r="' . $r . '" stroke="' . esc_attr( (string) $d[2] ) . '" ' .
				'stroke-dasharray="' . round( $len, 2 ) . ' ' . round( $circ - $len, 2 ) . '" ' .
				'stroke-dashoffset="' . round( -$offset, 2 ) . '" style="--len:' . round( $circ, 2 ) . ';--d:' . ( $i * 140 ) . 'ms"/>';
			$offset += $len;
		}
		$svg .= '<text x="100" y="96" text-anchor="middle" style="font-size:26px;font-weight:700;fill:var(--ink)">' . (int) $total . '</text>';
		$svg .= '<text x="100" y="116" text-anchor="middle" style="font-size:10px">' . esc_html__( 'properties', 'estat-os' ) . '</text>';
		$svg .= '</svg>';
		return $svg;
	}

	/* ---------------------------------------------------------- line chart */

	private static function agents(): void {
		$series = self::cached( 'agents', array( __CLASS__, 'query_agents' ) );

		echo '<div class="panel b6 anim" style="--d:120ms">';
		echo '<div class="panel__h"><div><h3>' . esc_html__( 'How each person is doing', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'Properties added, last six weeks', 'estat-os' ) . '</div></div></div>';
		echo '<div class="panel__b chartbox" style="padding:var(--s4) var(--s5) var(--s5)" id="chtLine">';
		echo self::lines( $series );
		echo '</div>';
		echo '<div class="lgd" id="lineLgd" style="padding:0 var(--s5) var(--s5)">';
		foreach ( $series as $s ) {
			echo '<span class="lgd__i"><i class="lgd__sw" style="background:' . esc_attr( $s['color'] ) . '"></i>' . esc_html( $s['name'] ) . '</span>';
		}
		echo '</div></div>';
	}

	private static function query_agents(): array {
		global $wpdb;
		$since = gmdate( 'Y-m-d H:i:s', time() - 6 * WEEK_IN_SECONDS );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$top = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT pm.meta_value AS agent_id, COUNT(*) AS c
				 FROM {$wpdb->postmeta} pm
				 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				 WHERE pm.meta_key = %s AND pm.meta_value > 0
				   AND p.post_type = %s
				   AND p.post_date >= %s
				 GROUP BY pm.meta_value ORDER BY c DESC LIMIT 4",
				'_estat_agent_id',
				PostTypes::LISTING,
				$since
			),
			ARRAY_A
		);
		// phpcs:enable

		$shades = array( '#725b2f', '#3f6b4f', '#3c5a7a', '#8a6a1f' );
		$out    = array();
		$i      = 0;
		foreach ( (array) $top as $t ) {
			$id   = (int) $t['agent_id'];
			$name = get_the_title( $id );
			if ( ! $name ) {
				continue;
			}
			$out[] = array(
				'name'   => $name,
				'color'  => $shades[ $i % count( $shades ) ],
				'points' => self::weekly( $id, $since ),
			);
			++$i;
		}
		return $out;
	}

	/** One agent's properties added per week, six buckets. */
	private static function weekly( int $agent_id, string $since ): array {
		global $wpdb;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT YEARWEEK(p.post_date, 1) AS wk, COUNT(*) AS c
				 FROM {$wpdb->postmeta} pm
				 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				 WHERE pm.meta_key = '_estat_agent_id' AND pm.meta_value = %d
				   AND p.post_type = %s AND p.post_date >= %s
				 GROUP BY YEARWEEK(p.post_date, 1)",
				$agent_id,
				PostTypes::LISTING,
				$since
			),
			ARRAY_A
		);
		// phpcs:enable

		$by = array();
		foreach ( (array) $rows as $r ) {
			$by[ (string) $r['wk'] ] = (int) $r['c'];
		}
		$out = array();
		for ( $i = 5; $i >= 0; $i-- ) {
			$wk    = gmdate( 'oW', time() - $i * WEEK_IN_SECONDS );
			$out[] = (int) ( $by[ $wk ] ?? 0 );
		}
		return $out;
	}

	private static function lines( array $series ): string {
		if ( ! $series ) {
			return '<p class="mut" style="font-size:var(--fs-name);margin:0">' . esc_html__( 'Nobody has been assigned a property yet.', 'estat-os' ) . '</p>';
		}

		$w    = 720;
		$h    = 260;
		$pad  = 34;
		$base = $h - 40;
		$max  = 1;
		foreach ( $series as $s ) {
			$max = max( $max, max( $s['points'] ) );
		}
		$step = ( $w - $pad * 2 ) / 5;

		$svg = '<svg class="chart" viewBox="0 0 ' . $w . ' ' . $h . '" style="width:100%;height:auto" role="img">';
		for ( $g = 0; $g <= 2; $g++ ) {
			$y = $base - $g * ( $base - 20 ) / 2;
			$svg .= '<line class="gl" x1="' . $pad . '" x2="' . ( $w - $pad ) . '" y1="' . round( $y, 1 ) . '" y2="' . round( $y, 1 ) . '"/>';
		}

		foreach ( $series as $si => $s ) {
			$pts = array();
			foreach ( $s['points'] as $i => $v ) {
				$pts[] = array( $pad + $i * $step, $base - $v / $max * ( $base - 20 ) );
			}
			$d  = '';
			foreach ( $pts as $i => $p ) {
				$d .= ( 0 === $i ? 'M' : ' L' ) . round( $p[0], 1 ) . ' ' . round( $p[1], 1 );
			}
			$area = $d . ' L' . round( $pts[ count( $pts ) - 1 ][0], 1 ) . ' ' . $base . ' L' . $pad . ' ' . $base . ' Z';
			$svg .= '<path class="area" d="' . $area . '" fill="' . esc_attr( $s['color'] ) . '" opacity=".10" style="--d:' . ( $si * 140 ) . 'ms"/>';
			$svg .= '<path class="ln" d="' . $d . '" stroke="' . esc_attr( $s['color'] ) . '" style="--len:900;--d:' . ( $si * 140 ) . 'ms"/>';
			foreach ( $pts as $p ) {
				$svg .= '<circle cx="' . round( $p[0], 1 ) . '" cy="' . round( $p[1], 1 ) . '" r="3" fill="var(--panel)" stroke="' . esc_attr( $s['color'] ) . '" stroke-width="2"/>';
			}
		}

		for ( $i = 0; $i < 6; $i++ ) {
			$label = $i === 5 ? __( 'now', 'estat-os' ) : sprintf(
				/* translators: %d number of weeks ago. */
				__( '%dw', 'estat-os' ),
				5 - $i
			);
			$svg .= '<text x="' . round( $pad + $i * $step, 1 ) . '" y="' . ( $h - 12 ) . '" text-anchor="middle">' . esc_html( $label ) . '</text>';
		}
		$svg .= '</svg>';
		return $svg;
	}

	/* ------------------------------------------------------------- summary */

	private static function summary(): void {
		$leads   = \EstatOS\Leads\Leads::counts();
		$visits  = \EstatOS\Leads\Visits::counts();
		$counts  = Shell::counts();

		echo '<div class="panel b3 anim" style="--d:180ms">';
		echo '<div class="panel__h"><div><h3>' . esc_html__( 'At a glance', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'Right now', 'estat-os' ) . '</div></div></div>';
		echo '<div class="panel__b" style="padding:var(--s4)">';
		echo '<div class="kv">';
		foreach ( array(
			__( 'Properties', 'estat-os' )    => (int) $counts['listings'],
			__( 'Open enquiries', 'estat-os' ) => (int) ( $leads['new'] ?? 0 ),
			__( 'Visits pending', 'estat-os' ) => (int) ( $visits['pending'] ?? 0 ),
			__( 'Deals won', 'estat-os' )      => (int) ( $leads['won'] ?? 0 ),
			__( 'In the bin', 'estat-os' )     => (int) $counts['bin'],
		) as $word => $n ) {
			echo '<div class="kv__r"><span class="mut">' . esc_html( $word ) . '</span><b class="num">' . (int) $n . '</b></div>';
		}
		echo '</div></div></div>';
	}

	/* -------------------------------------------------------------- helpers */

	private static function cached( string $key, callable $fn ) {
		$hit = get_transient( 'estat_os_rep_' . $key );
		if ( is_array( $hit ) ) {
			return $hit;
		}
		$out = call_user_func( $fn );
		set_transient( 'estat_os_rep_' . $key, $out, self::CACHE );
		return $out;
	}

	private static function trim( string $s, int $n ): string {
		return function_exists( 'mb_substr' ) && mb_strlen( $s ) > $n ? mb_substr( $s, 0, $n - 1 ) . '…' : ( strlen( $s ) > $n ? substr( $s, 0, $n - 1 ) . '…' : $s );
	}
}
