<?php
/**
 * Properties — every home, plot and shop the office holds.
 *
 * One table: picture, name, price, where it is, what state it is in, and how
 * much of it is filled in. The three things you do to a row — edit, copy,
 * bin — sit on the row itself, because that is where the decision is made.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Os\Screens;

use EstatOS\Admin\Os\Shell;
use EstatOS\Admin\Os\Ui;
use EstatOS\Data\Listings;
use EstatOS\Data\PostTypes;
use EstatOS\Support\Status;
use EstatOS\Support\Format;

defined( 'ABSPATH' ) || exit;

final class PropertiesScreen {

	private const PER_PAGE = 20;

	public static function render(): void {
		/*
		 * An old link or bookmark that still says ?edit= is sent to the
		 * editor rather than silently showing the list.
		 */
		$legacy_edit = isset( $_GET['edit'] ) ? absint( wp_unslash( (string) ( is_array( $_GET['edit'] ) ? 0 : $_GET['edit'] ) ) ) : 0;
		if ( $legacy_edit > 0 && 'estat-listing' === get_post_type( $legacy_edit ) ) {
			wp_safe_redirect( admin_url( 'admin.php?page=estat-add-home&edit=' . $legacy_edit ) );
			exit;
		}

		$filter = isset( $_GET['filter'] ) ? sanitize_key( wp_unslash( (string) ( is_array( $_GET['filter'] ) ? '' : $_GET['filter'] ) ) ) : 'all';
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array( $_GET['s'] ) ? '' : $_GET['s'] ) ) ) : '';
		$order  = isset( $_GET['order'] ) ? sanitize_key( wp_unslash( (string) ( is_array( $_GET['order'] ) ? '' : $_GET['order'] ) ) ) : 'newest';
		$page   = max( 1, (int) ( $_GET['paged'] ?? 1 ) );

		$statuses = array(
			'all'     => array( 'publish', 'draft', 'pending', 'private' ),
			'live'    => array( 'publish' ),
			'draft'   => array( 'draft' ),
			'pending' => array( 'pending' ),
		);
		$want = $statuses[ $filter ] ?? $statuses['all'];

		$args = array(
			'post_type'      => PostTypes::LISTING,
			'post_status'    => $want,
			'posts_per_page' => self::PER_PAGE,
			'paged'          => $page,
			'no_found_rows'  => false,
		);
		if ( '' !== $search ) {
			$args['s'] = $search;
		}
		if ( 'nophoto' === $filter ) {
			$args['meta_query'] = array(
				'relation' => 'OR',
				array(
					'key'     => '_thumbnail_id',
					'compare' => 'NOT EXISTS',
				),
				array(
					'key'     => '_thumbnail_id',
					'value'   => '0',
					'compare' => '=',
				),
			);
		}
		switch ( $order ) {
			case 'price_desc':
				$args['meta_key'] = '_estat_price';
				$args['orderby']  = 'meta_value_num';
				$args['order']    = 'DESC';
				break;
			case 'title':
				$args['orderby'] = 'title';
				$args['order']   = 'ASC';
				break;
			default:
				$args['orderby'] = 'date';
				$args['order']   = 'DESC';
		}

		$q = new \WP_Query( $args );

		Shell::open( 'estat-listings' );

		echo '<div class="phead"><div class="phead__l">';
		echo '<div class="phead__eyebrow"><span class="lbl">' . esc_html__( 'Inventory', 'estat-os' ) . '</span></div>';
		echo '<h1>' . esc_html__( 'Properties', 'estat-os' ) . '</h1>';
		echo '<p class="phead__sub mut">' . esc_html__( 'Every home, plot and shop the office holds. Hover a row for its quick actions.', 'estat-os' ) . '</p>';
		echo '</div><div class="phead__r">';
		/*
		 * Compare sits with Export, not in the menu: it is something done
		 * to the list you are already looking at, not a place of its own.
		 */
		echo '<button type="button" class="btn btn--ghost" data-drawer="compare">';
		Ui::ico( 'columns' );
		esc_html_e( 'Compare', 'estat-os' );
		echo '</button>';
		echo Ui::link_button( admin_url( 'admin.php?page=estat-spreadsheet&tab=export' ), __( 'Export', 'estat-os' ), 'download' );
		echo Ui::link_button( admin_url( 'admin.php?page=estat-add-home' ), __( 'Add a home', 'estat-os' ), 'plus', 'primary' );
		echo '</div></div>';

		self::filters( $filter, $search, $order );
		self::table( $q, $page );

		Shell::close();
	}

	/** The filter row above the table. */
	private static function filters( string $filter, string $search, string $order ): void {
		$counts = self::status_counts();

		echo '<div class="filters">';
		echo '<form class="searchbox" style="width:250px" method="get">';
		echo '<input type="hidden" name="page" value="estat-listings">';
		Ui::ico( 'search' );
		echo '<input class="in" name="s" placeholder="' . esc_attr__( 'Search properties…', 'estat-os' ) . '" value="' . esc_attr( $search ) . '">';
		echo '</form>';

		$tabs = array(
			'all'     => __( 'All', 'estat-os' ),
			'live'    => __( 'Live', 'estat-os' ),
			'draft'   => __( 'Draft', 'estat-os' ),
			'pending' => __( 'Pending', 'estat-os' ),
		);
		foreach ( $tabs as $key => $word ) {
			printf(
				'<a class="chipf%1$s" href="%2$s">%3$s <b>%4$d</b></a>',
				$key === $filter ? ' is-on' : '',
				esc_url( admin_url( 'admin.php?page=estat-listings&filter=' . $key ) ),
				esc_html( $word ),
				(int) ( $counts[ $key ] ?? 0 )
			);
		}

		echo '<div style="margin-left:auto"><select class="in" style="height:32px;font-size:var(--fs-meta)" onchange="if(this.value)location.href=this.value">';
		$orders = array(
			'newest'     => __( 'Newest first', 'estat-os' ),
			'price_desc' => __( 'Price: high to low', 'estat-os' ),
			'title'      => __( 'Title: A to Z', 'estat-os' ),
		);
		foreach ( $orders as $key => $word ) {
			printf(
				'<option value="%1$s"%2$s>%3$s</option>',
				esc_url( admin_url( 'admin.php?page=estat-listings&filter=' . $filter . '&order=' . $key ) ),
				selected( $order, $key, false ),
				esc_html( $word )
			);
		}
		echo '</select></div>';
		echo '</div>';
	}

	/** Counts for the filter chips. */
	private static function status_counts(): array {
		$counts = get_transient( 'estat_os_prop_counts' );
		if ( is_array( $counts ) ) {
			return $counts;
		}
		$out = array( 'all' => 0 );
		foreach ( array( 'all', 'live', 'draft', 'pending' ) as $key ) {
			$statuses = array(
				'all'     => array( 'publish', 'draft', 'pending', 'private' ),
				'live'    => array( 'publish' ),
				'draft'   => array( 'draft' ),
				'pending' => array( 'pending' ),
			);
			$q             = new \WP_Query(
				array(
					'post_type'      => PostTypes::LISTING,
					'post_status'    => $statuses[ $key ],
					'posts_per_page' => 1,
					'fields'         => 'ids',
					'no_found_rows'  => false,
				)
			);
			$out[ $key ] = (int) $q->found_posts;
		}
		set_transient( 'estat_os_prop_counts', $out, MINUTE_IN_SECONDS );
		return $out;
	}

	/** The table itself. */
	private static function table( \WP_Query $q, int $page ): void {
		echo '<div class="tw"><div class="tw__scroll"><table class="tb">';
		echo '<thead><tr>';
		echo '<th style="width:36px"><span class="cbrow"><i class="cb" id="propAll" role="checkbox" aria-checked="false" tabindex="0" data-selectall></i></span></th>';
		echo '<th>' . esc_html__( 'Property', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'Price', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'Location', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'Status', 'estat-os' ) . '</th>';
		echo '<th style="width:170px">' . esc_html__( 'Completeness', 'estat-os' ) . '</th>';
		echo '<th style="width:150px"></th>';
		echo '</tr></thead><tbody id="propRows">';

		if ( ! $q->have_posts() ) {
			echo '<tr><td colspan="7">';
			echo Ui::empty_state(
				'home',
				__( 'No properties yet', 'estat-os' ),
				__( 'Add your first property, or bring your inventory across from a spreadsheet.', 'estat-os' ),
				'<a class="btn btn--primary" href="' . esc_url( admin_url( 'admin.php?page=estat-add-home' ) ) . '">' . esc_html__( 'Add a home', 'estat-os' ) . '</a>'
			);
			echo '</td></tr>';
		} else {
			foreach ( $q->posts as $i => $post ) {
				self::row( (int) $post->ID, $i );
			}
		}

		echo '</tbody></table></div>';
		self::pager( $q, $page );
		echo '</div>';
	}

	/** One property row. */
	private static function row( int $id, int $i ): void {
		$data  = Listings::to_array( $id );
		$done  = Listings::completeness( $id );
		$pct   = (int) ( $done['score'] ?? 0 );
		$title = get_the_title( $id );
		$cover = (string) ( $data['cover'] ?? '' );
		$price = (string) ( $data['price_display'] ?? '' );
		if ( '' === $price ) {
			$price = __( 'On request', 'estat-os' );
		}
		$where = (string) ( $data['locality'][0] ?? '' );
		if ( '' === $where && ! empty( $data['city'] ) ) {
			$where = (string) $data['city'];
		}

		/*
		 * The editor is the Add a home screen. This link used to point at the
		 * list with ?edit= stuck on the end, which the list ignores — so
		 * pressing Edit on a row reloaded the same table of properties and
		 * the property could not be opened at all.
		 */
		$edit = admin_url( 'admin.php?page=estat-add-home&edit=' . $id );

		printf(
			'<tr data-id="%1$d" style="animation:eos-rise 320ms var(--e-out) both;animation-delay:%2$dms">',
			$id,
			$i * 30
		);

		echo '<td><span class="cbrow"><i class="cb" data-rowcb role="checkbox" aria-checked="false" tabindex="0"></i></span></td>';

		echo '<td><div class="tcell"><span class="tthumb">';
		if ( $cover ) {
			echo '<img src="' . esc_url( $cover ) . '" alt="" loading="lazy">';
		} else {
			Ui::ico( 'image' );
		}
		echo '</span><div class="tcell__b"><div class="tcell__t">' . esc_html( $title ) . '</div>';
		echo '<div class="tcell__m">' . esc_html( self::sub_line( $data ) ) . '</div></div></div></td>';

		echo '<td class="num">' . esc_html( $price ) . '</td>';
		echo '<td>' . esc_html( $where ?: '—' ) . '</td>';
		echo '<td>' . Ui::status_badge( Status::PUBLICATION, (string) get_post_status( $id ) ) . '</td>';

		echo '<td><div class="meter"><div class="meter__track">';
		echo '<i class="meter__fill ' . esc_attr( $pct >= 85 ? 'is-hi' : ( $pct >= 55 ? 'is-mid' : 'is-lo' ) ) . '" data-w="' . (int) $pct . '"></i>';
		echo '</div><b>' . (int) $pct . '%</b></div></td>';

		echo '<td><div class="rowact">';
		echo '<a class="btn btn--ghost btn--sm" href="' . esc_url( $edit ) . '">' . esc_html__( 'Edit', 'estat-os' ) . '</a>';
		echo '<button type="button" class="btn btn--quiet btn--sm" data-act="duplicate" data-id="' . $id . '">' . esc_html__( 'Duplicate', 'estat-os' ) . '</button>';
		echo '<button type="button" class="btn btn--quiet btn--sm is-danger" data-act="bin" data-id="' . $id . '">' . esc_html__( 'Bin', 'estat-os' ) . '</button>';
		echo '</div></td>';

		echo '</tr>';
	}

	/** The small grey line under a property name. */
	private static function sub_line( array $data ): string {
		$bits = array();
		if ( ! empty( $data['bedrooms'] ) ) {
			$bits[] = (int) $data['bedrooms'] . ' BHK';
		}
		if ( ! empty( $data['property_type'] ) ) {
			$bits[] = ucfirst( str_replace( '-', ' ', (string) $data['property_type'] ) );
		}
		if ( ! empty( $data['area_sqft'] ) ) {
			$bits[] = number_format_i18n( (float) $data['area_sqft'] ) . ' sq ft';
		}
		if ( ! empty( $data['days_listed'] ) ) {
			$bits[] = sprintf(
				/* translators: %s: how long ago. */
				__( 'listed %s ago', 'estat-os' ),
				human_time_diff( (int) ( $data['days_listed'] ) * DAY_IN_SECONDS, 0 )
			);
		}
		return implode( ' · ', $bits );
	}

	/** Page numbers. */
	private static function pager( \WP_Query $q, int $page ): void {
		$total = (int) $q->found_posts;
		$pages = (int) $q->max_num_pages;
		if ( $pages < 2 ) {
			return;
		}
		$from = ( $page - 1 ) * self::PER_PAGE + 1;
		$to   = min( $total, $page * self::PER_PAGE );

		echo '<div class="pager">';
		echo '<div class="pager__i">';
		printf(
			/* translators: 1: first row number, 2: last row number, 3: total. */
			esc_html__( 'Showing %1$s–%2$s of %3$s', 'estat-os' ),
			'<b>' . (int) $from . '</b>',
			'<b>' . (int) $to . '</b>',
			esc_html( number_format_i18n( $total ) )
		);
		echo '</div>';

		$base = admin_url( 'admin.php?page=estat-listings' );
		printf(
			'<a class="pg%1$s" href="%2$s">%3$s</a>',
			$page <= 1 ? ' is-off' : '',
			esc_url( $base . '&paged=' . max( 1, $page - 1 ) ),
			Ui::icon( 'chev-l' )
		);

		for ( $p = 1; $p <= $pages; $p++ ) {
			if ( $pages > 7 && $p > 2 && $p < $pages - 1 && abs( $p - $page ) > 1 ) {
				if ( 3 === $p || $pages - 2 === $p ) {
					echo '<span class="pg" style="pointer-events:none">…</span>';
				}
				continue;
			}
			printf(
				'<a class="pg%1$s" href="%2$s">%3$d</a>',
				$p === $page ? ' is-on' : '',
				esc_url( $base . '&paged=' . $p ),
				$p
			);
		}

		printf(
			'<a class="pg%1$s" href="%2$s">%3$s</a>',
			$page >= $pages ? ' is-off' : '',
			esc_url( $base . '&paged=' . min( $pages, $page + 1 ) ),
			Ui::icon( 'chev-r' )
		);
		echo '</div>';
	}
}
