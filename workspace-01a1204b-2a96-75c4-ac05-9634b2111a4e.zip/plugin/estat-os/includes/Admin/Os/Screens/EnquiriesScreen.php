<?php
/**
 * Enquiries — everyone who has asked the office about something.
 *
 * One row per person. Opening a row slides out everything the office knows
 * about them: what they asked, when, what happened since, when to call next,
 * and the two buttons you reach for most — call and email.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Os\Screens;

use EstatOS\Admin\Os\Shell;
use EstatOS\Admin\Os\Ui;
use EstatOS\Install\Schema;
use EstatOS\Leads\Leads;
use EstatOS\Support\Status;
use EstatOS\Support\Vocabulary;

defined( 'ABSPATH' ) || exit;

final class EnquiriesScreen {

	private const PER_PAGE = 20;

	public static function render(): void {
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( (string) ( is_array( $_GET['status'] ) ? '' : $_GET['status'] ) ) ) : '';
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array( $_GET['s'] ) ? '' : $_GET['s'] ) ) ) : '';
		$page   = max( 1, (int) ( $_GET['paged'] ?? 1 ) );

		$args = array(
			'per_page' => self::PER_PAGE,
			'page'     => $page,
			'orderby'  => 'created_at',
			'order'    => 'DESC',
		);
		if ( '' !== $status ) {
			$args['status'] = $status;
		}
		if ( '' !== $search ) {
			$args['search'] = $search;
		}
		if ( isset( $_GET['filter'] ) && 'followup' === $_GET['filter'] ) {
			$args['due_followup'] = true;
		}

		$result = Schema::healthy() ? Leads::query( $args ) : array( 'items' => array(), 'total' => 0, 'pages' => 0, 'page' => 1 );
		$counts = Leads::counts();

		Shell::open( 'estat-enquiries' );

		echo '<div class="phead"><div class="phead__l">';
		echo '<div class="phead__eyebrow"><span class="lbl">' . esc_html__( 'Customers', 'estat-os' ) . '</span></div>';
		echo '<h1>' . esc_html__( 'Enquiries', 'estat-os' ) . '</h1>';
		echo '<p class="phead__sub mut">' . esc_html__( 'Everyone who has asked about a property. Open one to see its history.', 'estat-os' ) . '</p>';
		echo '</div><div class="phead__r">';
		echo '<button type="button" class="btn btn--ghost" data-act="export-leads">';
		Ui::ico( 'download' );
		esc_html_e( 'Export', 'estat-os' );
		echo '</button>';
		echo '<button type="button" class="btn btn--primary" data-drawer="enquiry" data-id="0">';
		Ui::ico( 'plus' );
		esc_html_e( 'New enquiry', 'estat-os' );
		echo '</button>';
		echo '</div></div>';

		self::filters( $status, $counts, $search );
		self::table( $result['items'], $result['total'], (int) $result['page'], (int) $result['pages'] );

		Shell::maybe_open_new( 'enquiry' );
		Shell::close();
	}

	private static function filters( string $status, array $counts, string $search ): void {
		echo '<div class="filters">';
		echo '<form class="searchbox" style="width:250px" method="get">';
		echo '<input type="hidden" name="page" value="estat-enquiries">';
		Ui::ico( 'search' );
		echo '<input class="in" name="s" placeholder="' . esc_attr__( 'Name, phone or email…', 'estat-os' ) . '" value="' . esc_attr( $search ) . '">';
		echo '</form>';

		$tabs = array(
			''         => array( __( 'All', 'estat-os' ), (int) ( $counts['total'] ?? 0 ) ),
			'new'      => array( __( 'New', 'estat-os' ), (int) ( $counts['new'] ?? 0 ) ),
			'contacted' => array( __( 'Contacted', 'estat-os' ), (int) ( $counts['contacted'] ?? 0 ) ),
			'scheduled' => array( __( 'Scheduled', 'estat-os' ), (int) ( $counts['scheduled'] ?? 0 ) ),
			'won'      => array( __( 'Won', 'estat-os' ), (int) ( $counts['won'] ?? 0 ) ),
			'lost'     => array( __( 'Lost', 'estat-os' ), (int) ( $counts['lost'] ?? 0 ) ),
		);

		/*
		 * Enquiries the website set aside.
		 *
		 * A form that is sent from one address more than a few times in ten
		 * minutes is filed as spam: the visitor is still thanked, and the
		 * enquiry was reachable from nowhere — there was no tab for it, so a
		 * society's shared connection could have three real buyers in the
		 * bin and the office would never know. The tab appears only when
		 * there is something in it.
		 */
		$set_aside = (int) ( $counts['spam'] ?? 0 );
		if ( $set_aside > 0 ) {
			$tabs['spam'] = array( Vocabulary::lead_statuses()['spam'] ?? __( 'Set aside', 'estat-os' ), $set_aside );
		}
		foreach ( $tabs as $key => $tab ) {
			printf(
				'<a class="chipf%1$s" href="%2$s">%3$s <b>%4$d</b></a>',
				$key === $status ? ' is-on' : '',
				esc_url( admin_url( 'admin.php?page=estat-enquiries' . ( '' === $key ? '' : '&status=' . $key ) ) ),
				esc_html( $tab[0] ),
				$tab[1]
			);
		}
		echo '</div>';
	}

	private static function table( array $items, int $total, int $page, int $pages ): void {
		echo '<div class="tw"><div class="tw__scroll"><table class="tb">';
		echo '<thead><tr>';
		echo '<th>' . esc_html__( 'Client', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'Phone', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'Property of interest', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'Source', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'Status', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'Next call', 'estat-os' ) . '</th>';
		echo '<th style="width:110px"></th>';
		echo '</tr></thead><tbody id="enqRows">';

		if ( ! $items ) {
			echo '<tr><td colspan="7">';
			echo Ui::empty_state(
				'inbox',
				__( 'No enquiries yet', 'estat-os' ),
				__( 'When somebody fills in a form on your website, or calls the office, they land here.', 'estat-os' )
			);
			echo '</td></tr>';
		} else {
			foreach ( $items as $i => $lead ) {
				self::row( (array) $lead, $i );
			}
		}

		echo '</tbody></table></div>';

		if ( $pages > 1 ) {
			echo '<div class="pager"><div class="pager__i">';
			printf(
				/* translators: %s: number of enquiries. */
				esc_html__( '%s enquiries', 'estat-os' ),
				'<b>' . esc_html( number_format_i18n( $total ) ) . '</b>'
			);
			echo '</div>';
			for ( $p = 1; $p <= $pages; $p++ ) {
				printf(
					'<a class="pg%1$s" href="%2$s">%3$d</a>',
					$p === $page ? ' is-on' : '',
					esc_url( admin_url( 'admin.php?page=estat-enquiries&paged=' . $p ) ),
					$p
				);
			}
			echo '</div>';
		}

		echo '</div>';
	}

	private static function row( array $lead, int $i ): void {
		$id      = (int) ( $lead['id'] ?? 0 );
		$name    = (string) ( $lead['name'] ?? '' );
		$email   = (string) ( $lead['email'] ?? '' );
		$phone   = (string) ( $lead['phone'] ?? '' );
		$source  = (string) ( $lead['source'] ?? '' );
		$status  = (string) ( $lead['status'] ?? 'new' );
		$listing = (int) ( $lead['listing_id'] ?? 0 );
		$next    = (string) ( $lead['followup_at'] ?? '' );

		printf(
			'<tr data-id="%1$d" style="animation:eos-rise 320ms var(--e-out) both;animation-delay:%2$dms">',
			$id,
			$i * 30
		);

		echo '<td><div class="tcell"><span class="tthumb" style="background:linear-gradient(140deg,#cbb79c,#a89478);color:rgba(255,255,255,.85)">';
		echo esc_html( Ui::initials( $name ?: __( 'Someone', 'estat-os' ) ) );
		echo '</span><div class="tcell__b"><div class="tcell__t">' . esc_html( $name ?: __( 'No name given', 'estat-os' ) ) . '</div>';
		echo '<div class="tcell__m">' . esc_html( $email ) . '</div></div></div></td>';

		echo '<td class="num">';
		if ( $phone ) {
			echo '<a href="tel:' . esc_attr( preg_replace( '/[^\d+]/', '', $phone ) ) . '">' . esc_html( $phone ) . '</a>';
		} else {
			echo '—';
		}
		echo '</td>';

		echo '<td>' . esc_html( $listing ? get_the_title( $listing ) : ( (string) ( $lead['locality'] ?? '' ) ?: '—' ) ) . '</td>';
		echo '<td>' . esc_html( self::source_word( $source ) ) . '</td>';
		echo '<td>' . Ui::status_badge( Status::LEAD, $status ) . '</td>';

		echo '<td>';
		if ( $next ) {
			$late = strtotime( $next ) < time();
			echo '<span class="' . ( $late ? 'badge badge--danger' : 'mut' ) . '" style="font-size:var(--fs-meta)">';
			echo esc_html( mysql2date( get_option( 'date_format' ), $next ) );
			echo '</span>';
		} else {
			echo '<span class="mut">—</span>';
		}
		echo '</td>';

		echo '<td><div class="rowacts">';
		echo '<button type="button" class="btn btn--ghost btn--sm" data-drawer="enquiry" data-id="' . $id . '">' . esc_html__( 'Open', 'estat-os' ) . '</button>';
		echo '</div></td>';

		echo '</tr>';
	}

	private static function source_word( string $source ): string {
		$map = Vocabulary::lead_sources();
		return $map[ $source ] ?? ( '' === $source ? '—' : ucfirst( str_replace( '_', ' ', $source ) ) );
	}
}
