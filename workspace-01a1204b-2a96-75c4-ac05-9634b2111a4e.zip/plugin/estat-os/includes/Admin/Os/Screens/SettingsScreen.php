<?php
/**
 * Settings — everything that changes how the office runs.
 *
 * Five tabs down the left, one at a time. Office info is plain boxes;
 * integrations talks to other programs; search alerts are what the website
 * emails people about; design tokens recolour the public pages with a live
 * preview; and page blocks decide the order things appear on a property page.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Os\Screens;

use EstatOS\Admin\Os\Shell;
use EstatOS\Admin\Os\Ui;
use EstatOS\Data\Templates;
use EstatOS\Settings\Settings;
use EstatOS\Support\Logo;

defined( 'ABSPATH' ) || exit;

final class SettingsScreen {

	private const TABS = array(
		'office'       => 'home',
		'integrations' => 'shuffle',
		'alerts'       => 'bell',
		'tokens'       => 'palette',
		'blocks'       => 'layout',
	);

	public static function render(): void {
		if ( ! current_user_can( 'estat_manage_settings' ) ) {
			wp_die( esc_html__( 'You do not have permission to change settings.', 'estat-os' ) );
		}
		$tab = isset( $_GET['set'] ) ? sanitize_key( wp_unslash( (string) ( is_array( $_GET['set'] ) ? '' : $_GET['set'] ) ) ) : 'office';
		if ( ! isset( self::TABS[ $tab ] ) ) {
			$tab = 'office';
		}

		$words = array(
			'office'       => __( 'Office info', 'estat-os' ),
			'integrations' => __( 'Integrations', 'estat-os' ),
			'alerts'       => __( 'Search alerts', 'estat-os' ),
			'tokens'       => __( 'Design tokens', 'estat-os' ),
			'blocks'       => __( 'Page blocks', 'estat-os' ),
		);

		Shell::open( 'estat-settings' );

		echo '<div class="phead"><div class="phead__l">';
		echo '<div class="phead__eyebrow"><span class="lbl">' . esc_html__( 'System', 'estat-os' ) . '</span></div>';
		echo '<h1>' . esc_html__( 'Settings', 'estat-os' ) . '</h1>';
		echo '<p class="phead__sub mut">' . esc_html__( 'How the office runs, what the website looks like, and what it tells people.', 'estat-os' ) . '</p>';
		echo '</div></div>';

		echo '<div class="set">';

		echo '<div class="setnav" id="setnav">';
		foreach ( self::TABS as $key => $icon ) {
			printf(
				'<a class="setnav__b%1$s" href="%2$s" data-set="%3$s">%4$s%5$s</a>',
				$key === $tab ? ' is-on' : '',
				esc_url( admin_url( 'admin.php?page=estat-settings&set=' . $key ) ),
				esc_attr( $key ),
				Ui::icon( $icon ),
				esc_html( $words[ $key ] )
			);
		}
		echo '</div>';

		echo '<div class="set__b" id="setBody">';
		switch ( $tab ) {
			case 'integrations':
				self::integrations();
				break;
			case 'alerts':
				self::alerts();
				break;
			case 'tokens':
				self::tokens();
				break;
			case 'blocks':
				self::blocks();
				break;
			default:
				self::office();
		}
		echo '</div>';

		echo '</div>';

		Shell::close();
	}

	/* --------------------------------------------------------------- office */

	private static function office(): void {
		$s = Settings::all();
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'estat_save_settings', 'estat_nonce' );
		echo '<input type="hidden" name="action" value="estat_save_settings">';
		echo '<input type="hidden" name="tab" value="office">';

		echo '<div class="panel anim"><div class="panel__h"><div><h3>' . esc_html__( 'The office', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'What the website and the paperwork say about you', 'estat-os' ) . '</div></div></div>';
		echo '<div class="panel__b" style="display:grid;gap:var(--s4);grid-template-columns:1fr 1fr">';
		foreach ( array(
			'office_name'    => __( 'Office name', 'estat-os' ),
			'tagline'        => __( 'Tagline', 'estat-os' ),
			'contact_person' => __( 'Who people speak to', 'estat-os' ),
			'phone'          => __( 'Phone', 'estat-os' ),
			'whatsapp'       => __( 'WhatsApp', 'estat-os' ),
			'email'          => __( 'Email', 'estat-os' ),
			'city'           => __( 'City', 'estat-os' ),
			'ref_prefix'     => __( 'Reference prefix', 'estat-os' ),
		) as $key => $word ) {
			printf(
				'<div class="field"><label class="field__lbl">%1$s</label><input class="in" name="settings[%2$s]" value="%3$s"></div>',
				esc_html( $word ),
				esc_attr( $key ),
				esc_attr( (string) ( $s[ $key ] ?? '' ) )
			);
		}
		/*
		 * The logo. It is the first thing anyone sees on the office screen and
		 * in the agent's app, and until now the only way to change it was to
		 * set a WordPress Site Identity logo — which most of the offices using
		 * this have never done, so they looked at a placeholder every morning.
		 * One button, one picture, and "use the default" puts it back.
		 */
		$logo_id  = (int) ( $s['logo_id'] ?? 0 );
		$logo_src = $logo_id > 0 ? (string) wp_get_attachment_image_url( $logo_id, 'medium' ) : '';
		if ( '' === $logo_src ) {
			$logo_src = Logo::url( 'lockup' );
		}
		printf(
			'<div class="field" style="grid-column:1/-1"><label class="field__lbl">%1$s</label>'
			. '<div class="logopick" id="estatLogoPick">'
			. '<span class="logopick__well"><img class="logopick__img" src="%2$s" alt="" data-default="%7$s"></span>'
			. '<span class="logopick__acts">'
			. '<button type="button" class="btn btn--ghost btn--sm" data-logo-choose>%3$s</button>'
			. '<button type="button" class="btn btn--ghost btn--sm" data-logo-clear>%4$s</button>'
			. '</span>'
			. '<input type="hidden" name="settings[logo_id]" value="%5$d" data-logo-input></div>'
			. '<div class="lbl">%6$s</div></div>',
			esc_html__( 'Office logo', 'estat-os' ),
			esc_url( $logo_src ),
			esc_html__( 'Choose a picture', 'estat-os' ),
			esc_html__( 'Use the default', 'estat-os' ),
			$logo_id,
			esc_html__( 'Shown at the top of the office screen and in the agent\'s app. Leave it as it is to use the logo this website already has.', 'estat-os' ),
			esc_url( Logo::url( 'lockup' ) )
		);

		printf(
			'<div class="field" style="grid-column:1/-1"><label class="field__lbl">%1$s</label><textarea class="in" name="settings[address]" rows="2">%2$s</textarea></div>',
			esc_html__( 'Address', 'estat-os' ),
			esc_textarea( (string) ( $s['address'] ?? '' ) )
		);
		echo '</div>';
		echo '<div class="panel__f" style="display:flex;justify-content:flex-end;padding:var(--s4);border-top:1px solid var(--line)">';
		echo '<button type="submit" class="btn btn--bronze">' . esc_html__( 'Save', 'estat-os' ) . '</button>';
		echo '</div></div></form>';
	}

	/* -------------------------------------------------------- integrations */

	private static function integrations(): void {
		$s = Settings::all();

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'estat_save_settings', 'estat_nonce' );
		echo '<input type="hidden" name="action" value="estat_save_settings">';
		echo '<input type="hidden" name="tab" value="integrations">';

		echo '<div class="panel anim"><div class="panel__h"><div><h3>' . esc_html__( 'Other programs', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'Send every enquiry somewhere else as well', 'estat-os' ) . '</div></div></div>';
		echo '<div class="panel__b" style="display:grid;gap:var(--s4)">';

		self::switch_row( 'webhook_enabled', __( 'Send enquiries to a web address', 'estat-os' ), __( 'For CRMs and other software that can receive a message.', 'estat-os' ) );

		printf(
			'<div class="field"><label class="field__lbl">%1$s</label><input class="in" name="settings[webhook_url]" value="%2$s" placeholder="https://…"></div>',
			esc_html__( 'Web address', 'estat-os' ),
			esc_attr( (string) ( $s['webhook_url'] ?? '' ) )
		);

		echo '<div class="divider"></div>';

		self::switch_row( 'elementor_forms_to_enquiries', __( 'Take in Elementor form entries', 'estat-os' ), __( 'Forms built with Elementor land in Enquiries like our own.', 'estat-os' ) );

		echo '<div style="display:flex;gap:var(--s2)">';
		echo '<button type="button" class="btn btn--ghost btn--sm" data-act="test-webhook">' . esc_html__( 'Send a test', 'estat-os' ) . '</button>';
		echo '<button type="button" class="btn btn--ghost btn--sm" data-act="test-mail">' . esc_html__( 'Send a test email', 'estat-os' ) . '</button>';
		echo '</div>';

		echo '</div>';
		echo '<div class="panel__f" style="display:flex;justify-content:flex-end;padding:var(--s4);border-top:1px solid var(--line)">';
		echo '<button type="submit" class="btn btn--bronze">' . esc_html__( 'Save', 'estat-os' ) . '</button>';
		echo '</div></div></form>';
	}

	/**
	 * One switch that carries its own answer into the form.
	 *
	 * The switch the eye sees is drawn by JavaScript; this is the honest
	 * answer that travels with the form if the script never arrives.
	 *
	 * @param string $key   Setting name.
	 * @param string $title What it does.
	 * @param string $note  Line underneath.
	 * @return void
	 */
	private static function switch_row( string $key, string $title, string $note ): void {
		$on = ! empty( Settings::get( $key, false ) );
		printf(
			'<div class="cbrow" style="align-items:flex-start">' .
			'<i class="tgl%1$s" data-toggle="%2$s" role="switch" aria-checked="%3$s" tabindex="0"></i>' .
			'<input type="hidden" id="tgl_%2$s" name="settings[%2$s]" value="%4$s">' .
			'<span><b style="font-size:var(--fs-name)">%5$s</b>' .
			'<span class="mut" style="display:block;font-size:var(--fs-meta)">%6$s</span></span></div>',
			$on ? ' is-on' : '',
			esc_attr( $key ),
			$on ? 'true' : 'false',
			$on ? '1' : '0',
			esc_html( $title ),
			esc_html( $note )
		);
	}

	/* --------------------------------------------------------- search alerts */

	private static function alerts(): void {
		echo '<div class="panel anim"><div class="panel__h"><div><h3>' . esc_html__( 'What the website emails people', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'When somebody saves a search and a matching home appears', 'estat-os' ) . '</div></div></div>';
		echo '<div class="panel__b" style="display:grid;gap:var(--s4)">';
		echo '<p class="mut" style="margin:0;font-size:var(--fs-name);line-height:1.6">' .
			esc_html__( 'A visitor can watch a search on your website. When a property that matches goes live, we write to them once — never more than once a day, and they can stop it from any email.', 'estat-os' ) .
			'</p>';
		echo '<div class="divider"></div>';
		echo '<div style="display:flex;gap:var(--s2)">';
		echo '<a class="btn btn--ghost btn--sm" href="' . esc_url( admin_url( 'admin.php?page=estat-search-alerts' ) ) . '">' . esc_html__( 'Open saved searches', 'estat-os' ) . '</a>';
		echo '</div>';
		echo '</div></div>';
	}

	/* ---------------------------------------------------------- design tokens */

	private static function tokens(): void {
		$saved = Settings::get( 'design_tokens', array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		$groups = array(
			__( 'Colour', 'estat-os' ) => array(
				'--estat-primary'      => array( __( 'Main colour', 'estat-os' ), 'color', '#B98A3C' ),
				'--estat-accent'       => array( __( 'Accent', 'estat-os' ), 'color', '#8C6A2E' ),
				'--estat-ink'          => array( __( 'Text', 'estat-os' ), 'color', '#1B1A18' ),
				'--estat-bg'           => array( __( 'Page background', 'estat-os' ), 'color', '#FAF8F5' ),
				'--estat-line'         => array( __( 'Lines', 'estat-os' ), 'color', '#E7E1D8' ),
			),
			__( 'Type', 'estat-os' ) => array(
				'--estat-font-heading' => array( __( 'Headings', 'estat-os' ), 'text', 'Georgia, serif' ),
				'--estat-font-body'    => array( __( 'Body text', 'estat-os' ), 'text', 'system-ui, sans-serif' ),
			),
			__( 'Shape', 'estat-os' ) => array(
				'--estat-radius'       => array( __( 'Corner rounding', 'estat-os' ), 'text', '14px' ),
			),
		);

		echo '<div style="display:grid;grid-template-columns:minmax(0,1fr) 320px;gap:var(--s5);align-items:start">';

		echo '<div class="panel anim"><div class="panel__h"><div><h3>' . esc_html__( 'Colours and fonts', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'These change the public pages, not the office', 'estat-os' ) . '</div></div></div>';
		echo '<div class="panel__b" style="display:grid;gap:var(--s5)">';

		foreach ( $groups as $group => $rows ) {
			echo '<div><div class="lbl" style="margin-bottom:var(--s3)">' . esc_html( $group ) . '</div>';
			echo '<div class="tokgrid">';
			foreach ( $rows as $key => $row ) {
				list( $word, $kind, $fallback ) = $row;
				$value = isset( $saved[ $key ] ) ? (string) $saved[ $key ] : $fallback;
				echo '<div class="tokrow">';
				if ( 'color' === $kind ) {
					echo '<span class="tok" style="background:' . esc_attr( $value ) . '"></span>';
				}
				echo '<span class="tokrow__l">' . esc_html( $word ) . '</span>';
				printf(
					'<span class="tokrow__v"><input class="in" type="%1$s" value="%2$s" data-token="%3$s" data-kind="%4$s" style="width:130px" data-default="%5$s"></span>',
					'color' === $kind ? 'color' : 'text',
					esc_attr( $value ),
					esc_attr( $key ),
					esc_attr( $kind ),
					esc_attr( $fallback )
				);
				echo '</div>';
			}
			echo '</div></div>';
		}

		echo '<div style="display:flex;gap:var(--s2);justify-content:flex-end">';
		echo '<button type="button" class="btn btn--ghost" data-act="tokens-reset">' . esc_html__( 'Put back the defaults', 'estat-os' ) . '</button>';
		echo '<button type="button" class="btn btn--bronze" data-act="tokens-save">' . esc_html__( 'Save', 'estat-os' ) . '</button>';
		echo '</div>';

		echo '</div></div>';

		// Live preview, drawn from the same tokens.
		echo '<div class="panel panel--pad anim" style="--d:80ms;position:sticky;top:0">';
		echo '<div class="lbl" style="margin-bottom:var(--s3)">' . esc_html__( 'How it will look', 'estat-os' ) . '</div>';
		echo '<div id="tokPreview" class="preview">';
		echo '<div class="preview__b">';
		echo '<div class="lbl">Sample locality</div>';
		echo '<div class="tname">3 BHK apartment with a park view</div>';
		echo '<div class="preview__bar"><i></i></div>';
		echo '<div class="mut" style="font-size:var(--fs-meta)">1,750 sq ft · ₹1.85 Cr</div>';
		echo '<button type="button" class="btn btn--bronze btn--sm btn--block" style="margin-top:var(--s3)">' . esc_html__( 'Ask about this home', 'estat-os' ) . '</button>';
		echo '</div></div></div>';

		echo '</div>';
	}

	/* ----------------------------------------------------------- page blocks */

	private static function blocks(): void {
		$type   = isset( $_GET['btype'] ) && 'project' === $_GET['btype'] ? 'project' : 'listing';
		$blocks = Templates::get_blocks( $type );

		echo '<div class="filters">';
		foreach ( array( 'listing' => __( 'Property page', 'estat-os' ), 'project' => __( 'Project page', 'estat-os' ) ) as $key => $word ) {
			printf(
				'<a class="chipf%1$s" href="%2$s">%3$s</a>',
				$key === $type ? ' is-on' : '',
				esc_url( admin_url( 'admin.php?page=estat-settings&set=blocks&btype=' . $key ) ),
				esc_html( $word )
			);
		}
		echo '</div>';

		echo '<div class="panel anim"><div class="panel__h"><div><h3>' . esc_html__( 'In what order', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'Drag a block to move it. Switch one off to leave it out.', 'estat-os' ) . '</div></div>';
		echo '<div class="panel__hr">';
		echo '<button type="button" class="btn btn--bronze btn--sm" data-act="blocks-save" data-type="' . esc_attr( $type ) . '">';
		esc_html_e( 'Save order', 'estat-os' );
		echo '</button></div></div>';

		echo '<div class="panel__b" style="padding:var(--s4)"><div class="blocks" id="blocks" data-type="' . esc_attr( $type ) . '">';
		foreach ( $blocks as $i => $b ) {
			printf(
				'<div class="block%1$s" data-block="%2$s" style="animation:eos-rise 300ms var(--e-out) both;animation-delay:%3$dms">',
				empty( $b['enabled'] ) ? ' is-placeholder' : '',
				esc_attr( (string) ( $b['id'] ?? '' ) ),
				$i * 30
			);
			echo '<span class="block__grip">';
			Ui::ico( 'grip' );
			echo '</span>';
			echo '<div class="block__b"><div class="block__n">' . esc_html( (string) ( $b['label'] ?? '' ) ) . '</div>';
			echo '<div class="block__d mut">' . esc_html( (string) ( $b['id'] ?? '' ) ) . '</div></div>';
			echo '<i class="tgl" data-toggle="block-on" role="switch" aria-checked="' . ( empty( $b['enabled'] ) ? 'false' : 'true' ) . '" tabindex="0"></i>';
			echo '</div>';
		}
		echo '</div></div></div>';
	}
}
