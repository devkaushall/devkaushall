<?php
/**
 * Bin — what was removed, and the last chance to bring it back.
 *
 * Nothing here is gone. Everything still sits in the system, waiting to be
 * put back where it was, or to be destroyed for good. The screen says plainly
 * how long each thing has left.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Os\Screens;

use EstatOS\Admin\Os\Shell;
use EstatOS\Admin\Os\Series;
use EstatOS\Admin\Os\Ui;
use EstatOS\Data\Bin;
use EstatOS\Data\Listings;
use EstatOS\Data\PostTypes;
use EstatOS\Support\Status;

defined( 'ABSPATH' ) || exit;

final class BinScreen {

	public static function render(): void {
		$sum = method_exists( Bin::class, 'summary_counts' ) ? Bin::summary_counts() : array();
		$res = Bin::query( array(
			'page'     => Series::page(),
			'per_page' => 24,
		) );

		$keep = (int) ( \EstatOS\Settings\Settings::get( 'retention_days', 30 ) );

		Shell::open( 'estat-bin' );

		echo '<div class="phead"><div class="phead__l">';
		echo '<div class="phead__eyebrow"><span class="lbl">' . esc_html__( 'Recovery', 'estat-os' ) . '</span></div>';
		echo '<h1>' . esc_html__( 'Bin', 'estat-os' ) . '</h1>';
		echo '<p class="phead__sub mut">' . esc_html__( 'Removed properties and projects. Put them back while they are still here.', 'estat-os' ) . '</p>';
		echo '</div><div class="phead__r">';
		if ( $res['total'] > 0 && Bin::may_empty() ) {
			printf(
				'<button type="button" class="btn btn--danger" data-act="empty-bin" data-confirm="%1$s">%2$s</button>',
				esc_attr__( 'Empty the bin? These can never be brought back.', 'estat-os' ),
				esc_html__( 'Empty bin', 'estat-os' )
			);
		}
		echo '</div></div>';

		echo '<div class="bento bento--stats">';
		$cards = array(
			array( 'in_bin', __( 'In the bin', 'estat-os' ), 'bin', (int) ( $sum['in_bin'] ?? $res['total'] ), __( 'waiting here', 'estat-os' ) ),
			array( 'today', __( 'Removed today', 'estat-os' ), 'clock', (int) ( $sum['today'] ?? 0 ), __( 'in the last few hours', 'estat-os' ) ),
			array( 'week', __( 'Removed this week', 'estat-os' ), 'chart', (int) ( $sum['week'] ?? 0 ), __( 'since Monday', 'estat-os' ) ),
			array( 'oldest', __( 'Oldest item', 'estat-os' ), 'clock', (int) ( $sum['oldest_days'] ?? 0 ), __( 'days in the bin', 'estat-os' ) ),
		);
		foreach ( $cards as $i => $c ) {
			printf(
				'<div class="panel stat b3 anim" style="--d:%1$dms">' .
				'<span class="stat__ico">%2$s</span>' .
				'<span class="stat__v num" data-count="%3$d">0</span>' .
				'<span class="stat__l">%4$s</span>' .
				'<span class="stat__d mut">%5$s</span></div>',
				$i * 60,
				Ui::icon( $c[2] ),
				$c[3],
				esc_html( $c[1] ),
				esc_html( $c[4] )
			);
		}
		echo '</div>';

		printf(
			'<div class="notice anim" style="--d:240ms"><span class="notice__k">%1$s</span>' .
			'<span class="notice__v">%2$s</span></div>',
			esc_html__( 'How long do we keep things?', 'estat-os' ),
			esc_html( sprintf( __( 'Removed records stay for %1$d days, then are destroyed automatically. You will always see a warning before anything is lost.', 'estat-os' ), max( 1, $keep ) ) )
		);

		echo '<div class="panel anim" style="--d:300ms">';
		echo '<div class="panel__h"><div><h3>' . esc_html__( 'What is in here', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'Put back, or destroy for good', 'estat-os' ) . '</div></div>';
		printf( '<div class="panel__hr"><span class="lbl">%1$s</span></div>', esc_html( sprintf( _n( '%d record', '%d records', $res['total'], 'estat-os' ), $res['total'] ) ) );
		echo '</div>';

		if ( empty( $res['items'] ) ) {
			self::empty_state();
			echo '</div>';
			Shell::close();
			return;
		}

		echo '<div class="tw"><table class="tb"><thead><tr>';
		echo '<th style="width:28px"></th>';
		echo '<th>' . esc_html__( 'Record', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'Kind', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'Removed', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'By', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'Was', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'Days here', 'estat-os' ) . '</th>';
		echo '<th></th>';
		echo '</tr></thead><tbody>';

		foreach ( $res['items'] as $i => $post ) {
			$id     = (int) $post->ID;
			$kind   = PostTypes::PROJECT === $post->post_type ? __( 'Project', 'estat-os' ) : __( 'Property', 'estat-os' );
			$at     = Bin::binned_at( $id );
			$when   = $at ? strtotime( $at ) : 0;
			$days   = $when ? (int) floor( ( time() - $when ) / DAY_IN_SECONDS ) : 0;
			$left   = max( 0, $keep - $days );
			$thumb  = get_the_post_thumbnail_url( $id, 'thumbnail' );
			$was    = Bin::previous_state( $id );
			$by     = Bin::binned_by_name( $id );

			printf(
				'<tr class="hlrow" data-id="%1$d" style="animation:eos-rise 320ms var(--e-out) both;animation-delay:%2$dms">',
				$id,
				min( 300, $i * 24 )
			);
			printf( '<td><label class="cb"><input type="checkbox" class="cb__i" data-row="%1$d"><i></i></label></td>', $id );

			echo '<td><div class="tcell">';
			if ( $thumb ) {
				printf( '<span class="tthumb" style="background-image:url(%1$s)"></span>', esc_url( $thumb ) );
			} else {
				echo '<span class="tthumb tthumb--empty">';
				Ui::ico( PostTypes::PROJECT === $post->post_type ? 'building' : 'home' );
				echo '</span>';
			}
			echo '<span class="tname">' . esc_html( get_the_title( $post ) ) . '</span>';
			printf( '<span class="tmeta mut">%1$s</span>', esc_html( (string) get_post_meta( $id, '_estat_locality', true ) ) );
			echo '</div></td>';

			printf( '<td><span class="badge">%1$s</span></td>', esc_html( $kind ) );
			printf( '<td><span class="mut">%1$s</span></td>', esc_html( $when ? sprintf( __( '%s ago', 'estat-os' ), human_time_diff( $when, time() ) ) : '\u2014' ) );
			printf( '<td><span class="mut">%1$s</span></td>', esc_html( '' !== $by ? $by : '—' ) );
			printf( '<td>%1$s</td>', Ui::status_badge( Status::PUBLICATION, '' !== $was ? sanitize_key( $was ) : 'draft' ) );
			printf(
				'<td><span class="badge %1$s">%2$s</span></td>',
				0 === $left ? 'badge--danger' : ( $left <= 7 ? 'badge--warn' : '' ),
				esc_html( sprintf( _n( '%d day', '%d days', $days, 'estat-os' ), $days ) )
			);

			echo '<td><div class="rowacts">';
			printf(
				'<button type="button" class="btn btn--ghost btn--ico btn--sm" data-act="restore" data-id="%1$d" title="%2$s">%3$s</button>',
				$id,
				esc_attr__( 'Put back', 'estat-os' ),
				Ui::icon( 'undo' )
			);
			printf(
				'<button type="button" class="btn btn--ghost btn--ico btn--danger btn--sm" data-act="purge" data-id="%1$d" data-confirm="%2$s" title="%3$s">%4$s</button>',
				$id,
				esc_attr__( 'Destroy this for good? It can never be brought back.', 'estat-os' ),
				esc_attr__( 'Destroy for good', 'estat-os' ),
				Ui::icon( 'trash' )
			);
			echo '</div></td>';
			echo '</tr>';
		}

		echo '</tbody></table></div>';

		if ( $res['pages'] > 1 ) {
			Series::pager( $res, 'estat-bin' );
		}

		echo '</div>';

		Shell::close();
	}

	private static function empty_state(): void {
		echo '<div class="empty"><div class="empty__ico">';
		Ui::ico( 'bin' );
		echo '</div><div class="empty__t">' . esc_html__( 'The bin is empty', 'estat-os' ) . '</div>';
		echo '<div class="empty__d">' . esc_html__( 'Nothing has been removed. When somebody removes a property it waits here before it is destroyed.', 'estat-os' ) . '</div></div>';
	}
}
