<?php
/**
 * Import & Export — bringing a spreadsheet in, and taking one out.
 *
 * Four steps, and the office can only be in one of them at a time:
 * choose the file, say which column means what, watch it go, and then —
 * because the whole import is one recorded job — take it back with one
 * click if the answer was wrong.
 *
 * @package EstatOS
 */

declare( strict_types = 1 );

namespace EstatOS\Admin\Os\Screens;

use EstatOS\Admin\Os\Shell;
use EstatOS\Admin\Os\Ui;
use EstatOS\Csv\Spreadsheet;
use EstatOS\Install\Schema;

defined( 'ABSPATH' ) || exit;

final class ImportScreen {

	public static function render(): void {
		if ( ! current_user_can( 'estat_import_inventory' ) ) {
			wp_die( esc_html__( 'You do not have permission to import.', 'estat-os' ) );
		}

		$tab  = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( (string) ( is_array( $_GET['tab'] ) ? '' : $_GET['tab'] ) ) ) : 'import';
		$jobs = Schema::healthy() ? Spreadsheet::recent_jobs( 8 ) : array();

		Shell::open( 'estat-spreadsheet' );

		echo '<div class="phead"><div class="phead__l">';
		echo '<div class="phead__eyebrow"><span class="lbl">' . esc_html__( 'Build', 'estat-os' ) . '</span></div>';
		echo '<h1>' . esc_html__( 'Import & Export', 'estat-os' ) . '</h1>';
		echo '<p class="phead__sub mut">' . esc_html__( 'Bring your inventory across from a spreadsheet, or take a copy out.', 'estat-os' ) . '</p>';
		echo '</div></div>';

		echo '<div class="filters">';
		foreach ( array( 'import' => __( 'Import', 'estat-os' ), 'export' => __( 'Export', 'estat-os' ) ) as $key => $word ) {
			printf(
				'<a class="chipf%1$s" href="%2$s">%3$s</a>',
				$key === $tab ? ' is-on' : '',
				esc_url( admin_url( 'admin.php?page=estat-spreadsheet&tab=' . $key ) ),
				esc_html( $word )
			);
		}
		echo '</div>';

		if ( 'export' === $tab ) {
			self::export();
		} else {
			self::wizard();
			self::history( $jobs );
		}

		Shell::close();
	}

	/** The four-step wizard. */
	private static function wizard(): void {
		echo '<div class="panel anim" style="--d:0ms">';
		echo '<div class="panel__b" style="padding:var(--s5)">';

		echo '<div class="wiz" id="wiz">';
		$steps = array(
			__( 'Choose the file', 'estat-os' ),
			__( 'Match the columns', 'estat-os' ),
			__( 'Bringing it in', 'estat-os' ),
			__( 'Done', 'estat-os' ),
		);
		// eslint-disable-next-line
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- reading which notice to show.
		$just_imported = isset( $_GET['estat_notice'] ) && 'imported' === sanitize_key( wp_unslash( (string) $_GET['estat_notice'] ) );

		foreach ( $steps as $i => $word ) {
			printf(
				'<div class="wiz__s%1$s" data-step="%2$d" data-s="%2$d"><span class="wiz__n">%3$d</span><span class="wiz__t">%4$s</span></div>',
				$just_imported ? ' is-on' : ( 0 === $i ? ' is-on' : '' ),
				$i + 1,
				$i + 1,
				esc_html( $word )
			);
			if ( $i < count( $steps ) - 1 ) {
				echo '<span class="wiz__line"></span>';
			}
		}
		echo '</div>';

		echo '<div id="wizBody" style="margin-top:var(--s6)">';
		self::step_upload();
		echo '</div>';

		echo '</div></div>';
	}

	/** Step 1 — the file, and what is in it. */
	private static function step_upload(): void {
		echo '<div class="dropzone" id="csvDrop" data-dropzone style="padding:var(--s7)">';
		Ui::ico( 'upload' );
		echo '<h4>' . esc_html__( 'Drop your CSV here', 'estat-os' ) . '</h4>';
		echo '<p>' . esc_html__( 'We read the first row as the column names.', 'estat-os' ) . '</p>';
		echo '<input type="file" id="csvFile" accept=".csv,text/csv" hidden>';
		// The wizard posts the file the way the server expects it. Without
		// this the button had nothing to send.
		echo '<input type="hidden" id="csvNonce" value="' . esc_attr( wp_create_nonce( 'estat_import_csv' ) ) . '">';
		echo '<input type="hidden" id="csvAction" value="' . esc_attr( admin_url( 'admin-post.php' ) ) . '">';
		echo '</div>';

		echo '<div style="display:flex;gap:var(--s3);align-items:center;margin-top:var(--s4);flex-wrap:wrap">';
		echo '<span class="mut" style="font-size:var(--fs-name)">' . esc_html__( 'What is in this file?', 'estat-os' ) . '</span>';
		echo '<select class="in" id="csvKind" style="width:200px">';
		foreach ( array(
			'listings' => __( 'Properties', 'estat-os' ),
			'projects' => __( 'Societies & projects', 'estat-os' ),
			'agents'   => __( 'Team members', 'estat-os' ),
			'leads'    => __( 'Enquiries', 'estat-os' ),
		) as $key => $word ) {
			echo '<option value="' . esc_attr( $key ) . '">' . esc_html( $word ) . '</option>';
		}
		echo '</select>';
		echo '</div>';

		echo '<div style="display:flex;gap:var(--s2);justify-content:flex-end;margin-top:var(--s5)">';
		// What this button does is bring the file in: the columns are matched
		// automatically, and the answer is printed at the top of the screen.
		echo '<button type="button" class="btn btn--bronze" id="csvNext" disabled>' . esc_html__( 'Bring it in', 'estat-os' ) . '</button>';
		echo '</div>';
	}

	/** Past imports, each one still undoable. */
	private static function history( array $jobs ): void {
		if ( ! $jobs ) {
			return;
		}
		echo '<div class="panel anim" style="--d:60ms">';
		echo '<div class="panel__h"><div><h3>' . esc_html__( 'Earlier imports', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'An import can be taken back for as long as you need to', 'estat-os' ) . '</div></div></div>';
		echo '<div class="panel__b" style="padding:0"><table class="tb"><thead><tr>';
		echo '<th>' . esc_html__( 'File', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'Brought in', 'estat-os' ) . '</th>';
		echo '<th>' . esc_html__( 'Records', 'estat-os' ) . '</th>';
		echo '<th style="width:140px"></th>';
		echo '</tr></thead><tbody>';

		foreach ( $jobs as $job ) {
			$meta = self::decode( (string) ( $job['meta'] ?? '' ) );
			echo '<tr data-id="' . (int) $job['id'] . '">';
			echo '<td>' . esc_html( (string) ( $meta['file'] ?? ( $job['file'] ?? __( 'a spreadsheet', 'estat-os' ) ) ) ) . '</td>';
			echo '<td class="mut">' . esc_html( mysql2date( get_option( 'date_format' ) . ', ' . get_option( 'time_format' ), (string) ( $job['created_at'] ?? '' ) ) ) . '</td>';
			echo '<td class="num">' . (int) ( $job['imported'] ?? 0 ) . '</td>';
			echo '<td><div class="rowacts">';
			printf(
				'<button type="button" class="btn btn--quiet btn--sm" data-act="undo-import" data-id="%1$d">%2$s</button>',
				(int) $job['id'],
				esc_html__( 'Undo import', 'estat-os' )
			);
			echo '</div></td></tr>';
		}

		echo '</tbody></table></div></div>';
	}

	private static function decode( string $json ): array {
		if ( '' === $json ) {
			return array();
		}
		$out = json_decode( $json, true );
		return is_array( $out ) ? $out : array();
	}

	/** The export side. */
	private static function export(): void {
		echo '<div class="panel anim" style="--d:0ms">';
		echo '<div class="panel__h"><div><h3>' . esc_html__( 'Take a copy out', 'estat-os' ) . '</h3>';
		echo '<div class="lbl">' . esc_html__( 'A spreadsheet you can open in Excel or Google Sheets', 'estat-os' ) . '</div></div></div>';
		echo '<div class="panel__b" style="display:grid;gap:var(--s4)">';

		$kinds = array(
			'listings' => __( 'Properties', 'estat-os' ),
			'projects' => __( 'Societies & projects', 'estat-os' ),
			'agents'   => __( 'Team members', 'estat-os' ),
			'leads'    => __( 'Enquiries', 'estat-os' ),
		);
		echo '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:var(--s4)">';
		foreach ( $kinds as $key => $word ) {
			echo '<div class="panel panel--pad" style="display:grid;gap:var(--s3)">';
			echo '<b style="font-size:var(--fs-name)">' . esc_html( $word ) . '</b>';
			echo '<div class="mut" style="font-size:var(--fs-meta)">' . esc_html( self::count_word( $key ) ) . '</div>';
			echo '<a class="btn btn--ghost btn--sm" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=estat_export_csv&kind=' . $key ), 'estat_export_csv' ) ) . '">';
			Ui::ico( 'download' );
			esc_html_e( 'Download CSV', 'estat-os' );
			echo '</a></div>';
		}
		echo '</div></div></div>';
	}

	private static function count_word( string $kind ): string {
		switch ( $kind ) {
			case 'listings':
				return sprintf(
					/* translators: %d number of properties. */
					_n( '%d property', '%d properties', (int) wp_count_posts( \EstatOS\Data\PostTypes::LISTING )->publish, 'estat-os' ),
					(int) wp_count_posts( \EstatOS\Data\PostTypes::LISTING )->publish
				);
			case 'projects':
				return sprintf(
					/* translators: %d number of projects. */
					_n( '%d project', '%d projects', (int) wp_count_posts( \EstatOS\Data\PostTypes::PROJECT )->publish, 'estat-os' ),
					(int) wp_count_posts( \EstatOS\Data\PostTypes::PROJECT )->publish
				);
			case 'agents':
				return sprintf(
					/* translators: %d number of people. */
					_n( '%d person', '%d people', (int) wp_count_posts( \EstatOS\Data\PostTypes::AGENT )->publish, 'estat-os' ),
					(int) wp_count_posts( \EstatOS\Data\PostTypes::AGENT )->publish
				);
			default:
				$counts = \EstatOS\Leads\Leads::counts();
				return sprintf(
					/* translators: %d number of enquiries. */
					_n( '%d enquiry', '%d enquiries', (int) ( $counts['total'] ?? 0 ), 'estat-os' ),
					(int) ( $counts['total'] ?? 0 )
				);
		}
	}
}
