=== Estat.OS — Real Estate Operating System ===
Contributors: devil
Tags: real estate, property, listings, enquiries, crm
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 4.1.12
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Run a real-estate office from WordPress: listings, enquiries, site visits, team, forms and reports, in plain language.

== Description ==

Estat.OS is the operating system for a small or medium estate office. WordPress
is the platform it runs on; this plugin is the business system.

It handles the whole cycle an office actually works through: put a property on
the website, a visitor asks about it, the enquiry lands in your inbox, somebody
is made responsible, a site visit is arranged, and it is marked as won or lost.
Reports then tell you how that is going.

The screens are written for someone who does not build websites. There is no
talk of custom post types, meta fields or endpoints anywhere in the interface.
A property is a "property", not a "post".

**What it manages**

* Listings, with photos, price, size, features and a readiness score
* Societies and projects that several listings belong to
* Your team, and who is responsible for what
* Enquiries, with notes, follow-up dates and duplicate protection
* Site visits, and how each one went
* Blogs, articles and market insights
* A gallery of every photo and document in one place
* Forms you design yourself, which feed straight into Enquiries
* Import and export by spreadsheet
* Reports on enquiries, visits and team activity

**What it does not require**

* No page builder. Elementor widgets are included, but if Elementor is switched
  off every part of the office keeps working.
* No ACF or any other field plugin. Estat.OS owns its own data model.
* No Composer, no build step, no external service.
* Maps work out of the box with OpenStreetMap. A Google key is optional.

**Your data stays yours**

Deactivating the plugin changes nothing. Deleting it changes nothing either,
unless you have explicitly ticked the box in Office Settings that says to erase
everything. Nothing is ever thrown away because a plugin was removed.

Every listing, enquiry and visit can be exported to a spreadsheet at any time.

**Languages**

English and Hinglish written in ordinary English letters, the way most Indian
offices actually speak. The language of the office screens and the language of
the public website are set separately. Information you type in — a property
name, a customer's message — is never translated.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/`, or install the ZIP from
   Plugins → Add New → Upload Plugin.
2. Activate it.
3. Open **Office** in the admin menu. A short setup asks four questions and
   builds your website pages for you. You can skip it and do everything by hand.

== Frequently Asked Questions ==

= Do I need Elementor? =

No. Estat.OS renders its own property pages, search and forms. If you do use
Elementor, seventeen widgets are available so you can lay those pages out
yourself instead.

= What happens to my properties if I remove the plugin? =

They stay exactly where they are. Removing the plugin does not delete business
data unless you have deliberately asked for that in Office Settings → Tools.

= Can two people use it at once? =

Yes. There are two roles — Office Owner and Office Agent — and each enquiry can
be handed to a particular person. Permissions are checked on every action, not
just hidden from the menu. A property still belongs to whoever added it: an
agent cannot change somebody else's, but they can propose a correction from the
property itself, which the office approves or turns down.

= How many properties can it handle? =

It is built and tested for a small or medium office on ordinary shared hosting,
comfortably into the thousands. Lists are paged, searches are indexed, and
imports are processed a few rows at a time so a large spreadsheet does not time
the site out.

= Is the information visitors send me protected? =

Enquiries are stored in your own database, never sent anywhere else. Duplicate
submissions are merged, spam is filtered without a third-party service, and a
person's name, phone and email can be erased on request while keeping the
record of the enquiry itself.

== Screenshots ==

1. Today — what needs attention right now
2. Listings, with readiness scores
3. The property editor, grouped into three short chapters
4. Enquiries, with follow-up dates and notes
5. The form studio: seven steps, live preview
6. Reports

== Changelog ==
= 4.1.12 =

* The sitemap was a 500 error wherever Rank Math is installed: the plugin's empty-terms filter cast every item it was handed to a string, and Rank Math hands it taxonomy objects, so each sitemap request died with "Object of class WP_Taxonomy could not be converted to string". The filter now reads a name from whatever it is given (object, string, a mix), ignores junk, and if anything ever still goes wrong it quietly returns the SEO plugin's own answer — a nicety must never be able to take the sitemap down.
* The warning "lookbehind assertion is not fixed length" six times a day: the public-text firewall split content on a regex older PHP refuses to compile, and when compilation fails the split silently stops working (office-only sentences then travel with the whole paragraph instead of being cut per-paragraph). The split needs no lookbehind and now carries none, on every PHP the plugin supports.
* Sites running Yoast instead of Rank Math got the word "Array" inside their robots tag: Yoast passes its directives as a map, and the plugin was stringifying it. Each shape is now kept in the shape it arrived.
* The core-sitemap filter and the public filter fields gained the same protection: an unexpected shape is skipped, never cast.

= 4.1.11 =

* A second enquiry could never be saved: the idempotency column allowed only one empty value, so every walk-in enquiry after the first was refused. The column now allows NULL and an older installation is upgraded in place.
* The office Forms builder stored nothing: its save sent the layout in a shape the writer did not read, so a saved form lost its boxes, and its settings and name were reset to defaults.
* A form built in the office could not be used by anybody: the lead's name was read only from a box called "name", which a builder-made form does not have, so every visitor was refused.
* Approving a change request from the office only flipped a status — the agent's change was never applied. The desk now runs the same approval the phone does.
* Restoring a record that was not in the bin said "Put back where it was". Refusals are now reported as refusals.
* "Check now" on the Duplicates screen answered "That action is not known", and a scan never wrote what it found.
* The phone's visit history and enquiry timeline read a column that does not exist and showed nothing.
* A required box on a website form, if its kind was written differently ("tel", "dropdown"), was dropped from the form without a word.
* Website enquiries set aside by the rate limit could not be seen anywhere in the office; there is now a tab for them.
* Fixed (the "that link has expired" page on Publish): the Add a home screen is one form with two jobs, and it carried one pair of keys for both. A new property posted the key for editing a property the plugin had never seen, so the save refused and showed "Wo link ya form purana ho gaya hai" with the property untouched. The form now carries the key for the job it is doing, and the save accepts either - so a page that was already open in the browser still works after this update.
* Fixed: nothing the office saved or failed to save was ever said out loud. Every save ends by sending the answer back in the address (saved, published, error, and the reason), and nothing read it: sixty-three written messages, including every "give this property a short headline first", were thrown away. A save that worked and a save that was refused looked exactly the same. The answer is now printed at the top of the screen, in green or red.
* Fixed: pressing Edit on a property row reloaded the same table - the link pointed at the list with an edit flag the list ignores. Edit now opens that property, and old links with the flag are forwarded there too.
* Fixed: pressing Duplicate gave a blank form. The button opens the editor with the values of the other property and nothing read the flag it sent; the values are loaded now, and saving makes a second property rather than overwriting the first.
* Fixed: after publishing, the office landed on the properties table with no sign of which property had just been saved. It now opens the property it just saved.
* Added: the standing check now pairs each form with the exact handler its action reaches, and compares the nonce each one carries - the fault above. It finds the previous build's mismatch and nothing in this one.
* Added: one command that runs every check (tests/run_all.sh): nine checks, one line each.
* A property title that contained a tag ran as code in the office: the search results, the
  command palette and the notifications put words from the database straight into the page as
  markup. Titles, names and messages are text now, in every one of those places.
* A page title that contained "<" or a tag was printed into the page as markup on a property,
  a team member's page and the printable sheet. It is escaped now.
* A title containing a tag also broke the property's structured data for search engines: the
  JSON printed inside the page's script block now encodes the characters that end it.
* The one-time column repair could report "finished" when the database had refused it, and
  never try again. It now checks that the change really happened, and asks again on the next
  update if it did not.
* Added two standing checks: JSON printed inside a script block must encode tags, and no page
  title may be printed without escaping. Both are shown failing before being trusted.
* The search box at the top of the office never searched anything. Clicking it opened the
  list of screens, the field then handed the keyboard over, and everything typed went into
  that list — so a property, an enquiry or a person could not be found from it at all. Typing
  now also asks the office for records, and the results open the record.
* "Save form" wiped every box the form already had. The screen drew a box one way and the
  browser read it back another, so a save kept only the boxes added since the page was opened
  and quietly wrote the rest away. Both halves now build and read the same box.
* The same save also dropped what it did not look at: every box became optional, every
  placeholder was emptied, and a dropdown lost its choices. All of it is carried through now.
* The ✕ on a box that was already on a form did nothing, and the panel that says "click a
  field on the canvas to change it" was never wired to anything — there was no way to name a
  box, mark it required, or write its choices. Both work now.
* A form with no boxes in it could be saved, leaving a named shell that asks a visitor for
  nothing. The office's save refuses it and says why.
* Two of the three answers to a visit did nothing: the screen offered "No-show" and "Cancel"
  against a server that only knew "Done" and a word the office never uses, so pressing them
  changed nothing and said nothing. The outcomes now come from the office's own vocabulary.
* Added rounds 7 to 10 of the audit: a real browser at 1440 and 390 (no screen scrolls
  sideways, no alert fires, no console error), the office's three real journeys end to end,
  every instruction button on every screen pressed, and the shape of the stored data checked
  after all of it.

= 4.1.9 =
* Fixed (the reason a property would not save): the Add a home screen posts to WordPress's own admin-post.php with action=estat_save_listing, while the code that receives it only ever read a field named estat_action. Every press of Publish or Save as draft was answered by a handler that had already returned - the page reloaded and not one field was stored. The handler now reads both names, so the same fault is fixed on Settings (Save changes) and on every Export button, which produced a blank page for the same reason.
* Fixed: the two save buttons are name="save" (value publish or draft) and the handler read estat_save_mode, so a property was saved as a draft even when Publish was pressed. Both names are read now.
* Fixed: highlights typed on the Add a home screen vanished on save. Three faults stacked: the button that adds a line was never wired to anything, the sanitiser kept only the highlight codes that exist in the catalogue and deleted every line the office had typed, and the list was then forced through a text field that turned it into a single string. The screen now offers the usual highlights as one-press chips, Add line and the remove cross work, and a typed line is stored and printed as typed.
* Fixed: the screen showed fifteen boxes and ten of them were saved. The photographs, the society, the city and the "price on request" tick were read off the screen and dropped. The whole form is saved now; the gallery has a field of its own, the cover picker works, and "price on request" is carried into the record.
* Fixed: the completeness panel on Add a home was a picture. The percentage, the bar and the five ticks now move as the form is filled.
* Fixed: the Today screen's Worklist tabs (All / Overdue / Leads / Listings) lit up nothing and filtered nothing; the rows carry their kind and the tab now uses it.
* Fixed: the tick beside a worklist row did nothing although the stylesheet already drew it as done. It marks the row done on screen.
* Fixed: ticking rows on the Properties table did nothing, because the tick-boxes are drawn elements rather than real checkboxes, so the bulk bar never appeared. Ticking works, with the keyboard too.
* Fixed: the highlighted "price on request" tick-box and every other drawn switch answered only real checkboxes; they answer a press and the keyboard now.
* Added: a standing check that reads every form in the office against the code that receives it - the exact fault above, where a screen sends one name and the handler reads another. It finds the old build's three silent forms and nothing in this one.
* Added: a check that saves and reads back the highlights, including a line the office typed.

= 4.1.8 =
* Fixed (P1): every request to /wp-json/estat/v1/properties/{id} and /estat/v2/properties/{id} returned HTTP 500 "critical error", which left the website's Compare, Favorites and Saved pages empty for every visitor. The cause was one word: the route's argument said 'validate_callback' => 'is_numeric'. WordPress calls a validation callback with three arguments and PHP's own is_numeric() accepts exactly one, so PHP 8 raised ArgumentCountError before the handler ran. Four routes were affected, including the form submit route. They now hand the check to a method of our own.
* Fixed: the plugin's own website pages (search, alerts, EMI, compare, favourites, amenities, features, localities, locality map, projects-by-stage, team) still carried the office's internal notes and the line "Generated by Estat.OS - you can edit this page like any other. Shortcode: <code>[estat_compare]</code>". Because WordPress runs a shortcode wherever it finds one, even inside <code>, that echoed line made each page draw its widget twice with two identical element ids. The pages are now rebuilt as a heading, one plain sentence and the shortcode once - and this happens by itself on update, instead of waiting for somebody to find a button in Settings.
* Fixed: the widget's own heading was an H1, so Home and the agent pages counted two H1s while the plugin's pages had none. The widget heading is an H2; the page's own heading supplies the H1.
* Fixed: /localities/, /locality-map/, /amenities/ and /features/ listed every term in the database, including the ones with nothing in them, each reading "0 properties". Terms with no properties are no longer shown or linked, and the ones that have properties come first.
* Fixed: those empty term pages are also kept out of the XML sitemap, where thirty URLs were being handed to Google that our own rules mark noindex.
* Fixed: the saved-properties page could show "1 saved" and "Nothing saved yet" at the same time when the server could not answer. The empty state is now decided by what was actually drawn, a failed answer says so plainly, and the hiding is done with a class the stylesheet cannot overrule.
* Fixed: /projects-by-stage/ printed every project in the office on one page - 171 of them, 362 KB of HTML. A stage now shows its first twelve, says how many there are, and links to the rest.
* Fixed: the v2 projects endpoint ignored page, per_page, stage and search, and always answered with the same first fifty.
* Fixed: the SEO title separator was an em dash on every property and project page; it is a plain pipe now.
* Fixed: the office desk can read an enquiry's history. Every change was recorded, but only the phone app drew it; the enquiry card now shows the same list in the same words.
* Removed: three pieces of code nothing called - a second file-upload handler, a spreadsheet-peek endpoint, and the AJAX call that fed the phone-only history.
* Added: a standing check that refuses any REST argument callback naming a PHP internal function, which is exactly how the 500 happened. Also: a check that reads the plugin's own page-repair rule against the live page text, and a browser check of the saved list when the server fails.

= 4.1.8 =
* Fixed (P1): every request to /wp-json/estat/v1/properties/{id} and /estat/v2/properties/{id} returned HTTP 500 "critical error", which left the website's Compare, Favorites and Saved pages empty for every visitor. The cause was one word: the route's argument said 'validate_callback' => 'is_numeric'. WordPress calls a validation callback with three arguments and PHP's own is_numeric() accepts exactly one, so PHP 8 raised ArgumentCountError before the handler ran. Four routes were affected, including the form submit route. They now use a callback of our own.
* Fixed: the plugin's own website pages (search, alerts, EMI, compare, favourites, amenities, features, localities, locality map, projects-by-stage, team) still carried the office's internal notes and the line "Generated by Estat.OS — you can edit this page like any other. Shortcode: <code>[estat_compare]</code>". Because WordPress runs shortcodes anywhere in the content, that echoed shortcode made each page draw its widget twice, with duplicate element ids. The pages are now rebuilt as one plain sentence for the reader plus the shortcode once, and this happens by itself on update — it no longer depends on somebody finding a button in Settings.
* Fixed: /localities/, /locality-map/, /amenities/ and /features/ listed every term in the database, including the 129 localities and amenities with nothing in them, each one reading "0 properties". Terms with no properties are no longer shown or linked, and the ones that have properties come first.
* Fixed: those empty term pages are also kept out of the XML sitemap, where the site was handing Google thirty URLs that our own rules mark noindex.
* Fixed: the saved-properties page could show "1 saved" and "Nothing saved yet" at the same time when the server could not answer. The empty state is now decided by what was actually drawn, a failed answer says so plainly, and the hiding is done by a class the stylesheet cannot overrule.
* Fixed: /projects-by-stage/ printed every project in the office on one page — 171 of them, 362 KB of HTML. A stage now shows its first twelve, says how many there are, and links to the rest.
* Fixed: the v2 projects endpoint ignored page, per_page, stage and search, and always answered with the same first fifty.
* Fixed: the SEO title separator was an em dash on every property and project page; it is a plain pipe now.
* Added: three standing checks - REST argument callbacks (the P1 above), the page-tidying rule, and the saved-list behaviour in a real browser.

= 4.1.7 =
* Fixed: the agent's Today screen collapsed into narrow columns on the live site. The desktop mosaic asked for its cards by one name (estat-pocket-block--quick) while the screen itself wrote them as another (is-quick), so the four cards were never placed and fell into a single column each. The names now agree, and a check has been added that joins every class the stylesheets target to the class the PHP actually writes.
* Fixed: the printed property sheet and every notification email carried no office phone and no email address. Both asked for settings called office_phone and office_email, which this plugin has never saved - the real keys are phone and email. They read the right keys now, with the old names still honoured first.
* Fixed: an enquiry list rule meant to show a field agent only their own clients never ran, because it asked for a capability called estat_agent that no role ever had. The roles are estat_office_owner and estat_office_agent; the rule now checks the role properly, so an agent sees their own leads and the office still sees everything.
* Fixed: the "Send test email" and "Send test webhook" buttons in Settings could only ever answer "That did not work". They checked a nonce field the browser never sent. They now use the same nonce the rest of the interface uses.
* Fixed: a missing interface word (need_title) fell back to English on every other language.
* Fixed: two placeholders left in the preview were removed, so what is measured is what the app draws.

= 4.1.6 =
* New: the app carries your office's own logo. Every mark used to be a coloured square with a letter in it, on the office screen, in the agent's app and on the sign-in page. It now uses the picture you choose under Settings, The office, Office logo; failing that, the logo WordPress already has under Site Identity; failing that, the mark that ships with the plugin. Never a broken image.
* New: the sign-in page draws the whole logo, name and all, because it is the one screen with room for it. The rail and the top bar draw the mark alone, because 252 pixels is not enough for a name that long, and on the dark rail the light-inked version is used so it does not disappear into the black.
* Fixed: the section spacing in both sidebars was a bug, not a matter of taste. In the agent's rail each row was being stretched to an equal slice of the whole column - seven rows in a 594 pixel column came out 84 pixels tall each, with the label floating in the middle of a half empty box. Rows are now their own height (38 pixels), and the spare room sits under them where sign-out is pinned.
* Fixed: the office rail is tightened the same way - 35 pixel rows, 12 pixels between sections instead of 24, and each section heading sitting on the rows it names. All fifteen module names now fit without an ellipsis.

= 4.1.5 =
* Fixed: the whole app was capped at 1400px and centred, left over from the first version of the shell. On a 1920px screen that left 260px of empty page on either side, and a second cap (1280px) on the screen added more. The shell and the screen now fill the window: a desktop uses the desktop.
* New: Today is a bento dashboard on a wide screen. The numbers run across the top, then the next action and the quick actions on the left with today's visits and recent properties beside them, and the task list across the foot. Under 1200px it stays the two-column layout it was, and a tablet and a phone are untouched.
* Card sizes and type scale with the room: stat cards grow from 14px to 18px of padding, numbers from 22px to 28px, quick actions to 64px tall, and the greeting to 30px.
* Fixed: a heart on a society or project card on the website came back as "not found", so it dropped quietly out of the visitor's shortlist. The property reply now answers for a society as well as for a single home, with the same ten questions.
* Fixed: the page never handed the browser its shortlist ticket, so "Send this list on WhatsApp" could only ever answer "this page has been open a while". The ticket is now part of the page's settings, made by the same name the route checks.
* Checked at 1920, 1600, 1568, 1440, 1280, 1100, 1024, 820, 768, 390 and 360 pixels across all fourteen screens: the app fills the window at every size, nothing overlaps, nothing scrolls sideways, no JavaScript errors. Content uses 84% of a 1920px window (the rest is the 252px rail and 32px gutters).

= 4.1.4 =
* New: the visitor's own shortlist on the website. A heart on every property card and a Compare button beside it. Both are kept on the visitor's own device — no account, no cookie wall, nothing personal stored.
* New: the comparison table asks the same ten questions the office and the agent's phone ask — price, size, bedrooms, bathrooms, floor, furnishing, parking, where, availability, society. The list is written down once, in Support/Comparison.php, and all three surfaces read it from there. A question with no answer prints "Not said" instead of vanishing, so a gap in the data is a gap the office can see and fill.
* New: "Send this list on WhatsApp". A visitor who has put three homes together leaves a name and a number; that becomes an ordinary enquiry — the same Leads::create() the contact forms use, source "comparison" — so it appears in the office list and is chased like any other. WhatsApp then opens with the same list written out, prices and links included.
* New: the saved properties are drawn as cards with their photographs, with Compare and Remove on each.
* The comparison holds four at a time: a visitor adding a fifth is told so rather than having one quietly dropped.
* Guards on the shortlist handoff: a nonce, a honeypot field and five sends per address per ten minutes.
* Everything added is scoped to .estat-public and uses new class names only — no Elementor style, no theme style and no existing public CSS rule is touched. No new libraries.
* Checked against the plugin's own public.js on a stand-in page: heart saves, the saved list draws, the table fills with ten rows and "Not said" in the right cells, the fifth is refused, an empty name is refused, the form posts the right ids with the nonce and no honeypot value, and removing a column works. No JavaScript errors.

= 4.1.3 =
* New: a shortlist for the field agent. Every property row carries a star; the starred homes sit together under "My shortlist", the star is a plain form so it works with no script at all, and the list is the agent's own — two agents starring the same flat do not overwrite each other.
* New: "Side by side". Two to four shortlisted homes are compared on ten questions — price, size, bedrooms, bathrooms, floor, furnishing, parking, where, availability, society. The same ten for every home, in the same order, and a question with no answer says "not said" rather than vanishing. On a phone the columns fall one under the other; on a wide screen they sit beside each other.
* New: Compare in the office. The Properties screen has a Compare button that opens a pick list; tick two to four homes and they are laid out side by side in the drawer, with a way to open any one of them in full.
* Fixed: /agent/queue/ — the waiting screen — was never reachable. The address, the links and the two scripts that draw it were all in place, but the one line that hands the screen its body was missing, so the address fell through to Today. A phone holding unsaved work now has a screen to show it on. Verified with the plugin's own scripts: rows draw, the offline line counts correctly, sending clears the phone, and taking one off asks first.
* The admin icon set gained a columns mark.

= 4.1.2 =
* Today screen, measured and tidied: the fifth number card no longer sits alone on a half-empty line. On a computer all five are in one line; on a tablet and a phone two share a line and the fifth takes the whole line under them.
* Quick actions are all the same height, so the grid reads as a grid. They used to run 44px in one row and 57px in the next.
* The name in the dark rail was 16px wider than its own column and was being clipped. It now sits as the word over the small line, inside the column.
* 1024–1279px (a laptop with the rail, or a narrow browser window): the work column was being squeezed to 440px, which shrank the number cards to 80px and pushed quick actions onto three lines. The work column now takes the full width and the right-hand column moves beneath it, two blocks wide. Two columns return at 1280px and above.
* Spacing between the blocks on Today is now one number throughout.
* The preview no longer draws a small switcher bar over the app — it is a plain page.

= 4.1.1 =
* Fixed: "Add a project" in the quick-add menu used to reload the page and do nothing. It now opens the drawer for a new society or project straight away.
* Fixed: the Add buttons on Enquiries and Site visits opened a drawer that only worked for records that already existed, so they failed with "no longer here". They now open a real blank form: name, phone, email and what they are after for an enquiry; who is coming, which property and when for a visit.
* Added: a cover photo and a photo gallery to the society/project drawer, picked from the WordPress media library the office already uses. Cover and gallery save with the record.
* Fixed: the project drawer had no way to attach photographs at all, so a project could be edited but never illustrated.
* Fixed: the Agent Pocket was drawing two search boxes on some screens — one in the top bar and one in the page. Only the one in the top bar remains.

= 4.1.0 =
* Agent Pocket rebuilt against the approved screen designs.
* A computer now has a dark left rail (252px) carrying Today, Leads, Add, Properties, Visits, Societies & projects and Your details, with Sign out pinned at the bottom. There is no bottom bar on a computer.
* A tablet and a phone keep the same five doors along the bottom, with Add in the middle, dark and raised. The tablet is two columns; the phone is one.
* One top bar everywhere: the name, a search box, and the person. On a phone the search drops to its own line.
* Today is a dashboard: five numbers, one "next action" card, eight quick actions, today's tasks, today's visits and your recent properties.
* Everything else stays in a reading column so forms and lists are never stretched on a wide screen.
* Checked at 360, 390, 768, 820, 1024, 1280 and 1440 pixels: no overlap and no sideways scrolling on any screen.


= 4.0.6 =
* The phone app now has the same five doors in every size: Today, Leads,
  Add, Properties and Visits. Add is always the middle one and always dark.
* Desktop: the five doors sit across the top, evenly spaced, and the left
  column became a narrow tool rail with tighter rows.
* Tablet: no longer a shrunken computer. The bottom bar is sized for a
  tablet, the reading column opens out, and the Add door sits raised and
  centred in the bar.
* Phone: the demo device marks and other desktop-only furniture are gone,
  the type and spacing are set for a phone, and the controls are thumb
  sized.
* Nothing overflows at any width from 360px to 1920px.

= 4.0.5 =
* Fixed: the phone app's dark sidebar on a computer was being overridden by
  a later rule, so it still came out white. It is dark now.

= 4.0.4 =
* Societies and projects can finally be edited. Every card carries an Edit
  button and opens a real form — name, builder, stage, kind, locality,
  price range, units, possession, address and description — with Save.
* Adding a society or project now works too; the button used to open an
  empty panel.
* Fixed: saving a team member never worked.
* Fixed: the Filter button on Societies & Projects opened Add project.
* Fixed: the office no longer hides behind WordPress's top toolbar. The
  toolbar's real height is measured, so a wrapped toolbar or a phone's
  taller one cannot cover headings or buttons any more.
* The phone app's sidebar on a computer is dark again.

= 4.0.3 =
* The office no longer moves when WordPress's own menu is scrolled; the
  plugin's content now has its own scrolling area.
* Layout stays put when the browser is zoomed from 67% to 125%.
* Team, project, gallery, bin and report cards keep all of their content
  inside their borders at every screen size.
* The bin's four counters are now even square tiles instead of tall strips.
* Every card in a row is now the same height as its neighbours.
* Tables scroll sideways inside their panel instead of pushing the page out.

= 4.0.2 =
* **Three columns, in the right order: WordPress's menu, then the office's own navigation, then the screen.** This is the Elementor arrangement, and it is now what the plugin does. WordPress's left menu is untouched and visible at all times. Immediately to its right, still inside the content area, sits the office's own module navigation. To the right of that is the screen you are working on.
* **The two sidebars are deliberately different materials.** WordPress's menu is dark; the office's navigation is light, with a hairline down its right edge. Two dark columns side by side read as one confused column, so the contrast is what tells you at a glance which menu is whose.
* **The office navigation is ours alone.** It lists only the fifteen modules — Today, Properties, Societies, Enquiries, Pipeline, Site Visits, Team, Change Requests, Gallery, Duplicates, Bin, Reports, Import & Export, Forms and Settings — grouped the way the day runs, with counts against Properties, Enquiries, Visits, Duplicates, Change Requests, Bin and the rest.
* **It can be narrowed to icons**, with a Collapse button at the foot of it. The choice is remembered in the browser, so it stays as you left it. On a narrow window it narrows on its own; on a phone it steps aside entirely and leaves WordPress's menu as the only navigation.
* **Both our navigation and the top bar stay put while the page scrolls**, so the screen you are on never loses its own menus.

= 4.0.1 =
* **The office now sits properly inside WordPress.** The plugin used to hide WordPress's own left menu and draw a sidebar of its own in its place, which made it feel like a separate program that happened to be on your website. That is undone. WordPress's menu stays exactly where it is, untouched, and the office is drawn in the content area to its right like any other admin page.
* **Every module is an ordinary WordPress menu line.** Today, Properties, Societies, Enquiries, Pipeline, Site Visits, Team, Change Requests, Gallery, Duplicates, Bin, Reports, Import & Export, Website Forms and Settings all appear under one **Office** menu in the sidebar. Settings is a line in that menu rather than a second menu of its own.
* **Counts on the menu lines.** Properties, Societies, Enquiries, Site Visits, Change Requests, Duplicates, Team and Bin each show how many are waiting, so the sidebar answers "how much have we got" without opening a screen. Each count respects what the person signed in is allowed to see.
* The plugin's own sidebar, its brand block and its collapse button are gone from the code, not just switched off.

= 4.0.0 =
* **A completely new office.** Every screen in wp-admin has been rebuilt from the ground up and the old interface has been taken out of the plugin for good — not switched off and left lying around, but removed from the code, the menus and the stylesheet. Twenty-two old screens are now fifteen, and three of those live as tabs inside Settings rather than as their own menu lines.
* **One place for everything, and one sidebar to reach it.** A fixed rail down the left with a clear mark on where you are, a top bar with search, notifications and a Quick Add button, and a canvas that fades in rather than jumping.
* **Records open beside you, not instead of you.** A property, a society, an enquiry, a visit or a team member opens in a drawer that slides in from the right with the page behind it dimmed. Nothing you were looking at is lost, and nothing reloads.
* **Motion with a purpose.** Numbers count up when a screen opens, cards lift when you pick them up, and every save, delete and move answers with a small toast at the corner of the screen. The pipeline is dragged, not edited: take a card from one stage to the next and it stays where you put it.
* **Today** is one screen that answers "what needs me" — visits, follow-ups, what arrived overnight and what is nearly ready, in that order.
* **Settings** is one screen with five tabs: office info, integrations, search alerts, design tokens and page blocks. Colours and fonts have a live preview; page blocks are dragged into order and switched on and off.
* **Fifteen modules, no hidden screens.** Today, Properties, Societies & Projects, Enquiries, Pipeline, Site Visits, Team, Change Requests, Gallery & Media, Forms, Import & Export, Duplicates, Reports, Settings and Bin — all in the sidebar, all reachable with Ctrl/⌘ + K.

= 3.9.0 =
* **A smaller plugin.** Five things that were never earning their place are gone, and they are gone properly — not switched off and left lying around, but taken out of the code, out of the menus and out of the database.
* **Insights is gone.** The Articles screen, the writing tools, the two categories that came with them, the pages on the website, the Elementor widget and every setting that mentioned it. If you had written anything there, the update removes those records as part of installing, so nothing is left in your database that no screen can open.
* **The Documents record type is gone.** Nothing used it — documents have always lived on the Gallery screen as files, not as records. Everything it could ever have held is cleared out on update.
* **The PC dashboard under /dashboard/ is gone.** It was a second way to reach screens that already sit in the menu, and it was the only part of the plugin that needed a password of its own on top of WordPress. Its address, its QR code on the Settings screen and the link in the overview are all removed, and any page on your website using its shortcode is cleaned up rather than left showing square brackets.
* **Two shortcodes are gone.** `[estat_office]` and `[estat_public_pages]` drew a homepage and a page list without Elementor, which is not how the plugin builds pages. A page using either one keeps everything else on it and simply loses the shortcode.
* **A dead half of the property screen is gone.** The screen carried a second, older list of properties that nothing opened any more. Only the editor is left, which is the part the menu actually uses.

= 3.8.0 =
* **A project page you can explore instead of read.** The page was a photograph, a list of facts, a wall of text and a form. Each part can now be worked with: the photographs open and can be moved through with the arrows, the keyboard or a swipe; long writing folds to a screenful and unfolds at one press, with every word still in the page; a fact that is a term of the trade — *super built-up*, *under offer*, *possession* — carries a short explanation that opens on the spot; and the amenities can be narrowed by kind. Nothing else about the page moved, and **Page blocks** still decides what appears and in what order.
* **The jump list.** A bar under the header carries a link to every section this particular project actually has — a project with no photographs is not offered a link to photographs. It stays put as the page moves, marks where you are, scrolls sideways on a phone without widening the page, and works as plain links whether or not any script has loaded. A hairline under it shows how far through the project you are.
* **The photographs behave like photographs.** One large frame, a strip of thumbnails, and *View all 9 photographs* when there are more than the strip holds. Any of them opens the full-size picture with a counter, previous and next, close, Escape, arrow keys and a sideways swipe. A project with no photograph at all gets an editorial plate, never a broken frame. Only the picture you are looking at is fetched at full size; the rest are listed as addresses until asked for.
* **Media cards for the film, the walkthrough, the brochure and the plans.** A card is drawn for a link the record actually holds, and no card at all for one it does not — so this is never a row of buttons that lead nowhere. A film or a walkthrough opens here, on the page, rather than sending the visitor to another site.
* **The homes inside the project can be narrowed.** All / Available / Under offer / Sold, with the number after each one counted on the server from the properties really listed there — so a filter can never promise six and show two. Property types appear only when the project holds more than one.
* **Share is three actions, not a wall of buttons.** WhatsApp, copy the link — which says *Link copied* — and the phone's own share sheet where there is one. Nothing else.
* **The enquiry answers in place.** On success the form is replaced by a proper acknowledgement, with a way to send another; on failure the form stays exactly as it was, everything the visitor typed still in it, and the whole block gives a short shake. Only one lead system exists and this does not add a second: the form still posts where it always did and the enquiry still lands in the same inbox.
* **A bar that follows a phone screen.** WhatsApp and Enquire, at the bottom of a phone screen and nowhere else. It stops above the home gesture so it never sits on top of it, and it is not drawn when there is nowhere to send somebody.
* **The same thinking on the property page, in the property's own shape.** Photographs open the same way; a long description folds and unfolds the same way; the facts that carry a term of the trade carry the same explanation; a film or a walkthrough opens here; *What stands out* is the same scannable grid. The properties directory gains the same kind of light filter over what is already on the page.
* **One small script, and only where it is used.** Every behaviour lives in one file and is switched on by the component that needs it, so a page with no gallery never loads a gallery script. The markup is complete before any script runs — real links, real buttons, every word present — so nothing stops working if the script is slow, blocked or switched off. Movement respects *reduce motion*.
* **Two leaks closed.** A description was being dropped in full — every public sentence with it — when it contained a single office sentence, because the cleaner was judging the whole block rather than the paragraph. It now works paragraph by paragraph: the office paragraph goes, the rest stays. And the description published to search engines was the raw text, so an office note that had been removed from the screen was still being printed in the structured data for every crawler to read; that is cleaned the same way now.
* **Designed from the smallest screen up.** 320, 390, 480, 768, 1024, 1280 and 1440 each have their own rules. No horizontal scrolling, no clipped cards, nothing hidden behind the phone bar.

= 3.7.0 =
* **The office's notes stay in the office.** A project page on the website was printing a line that read *"Rate on the office sheet: 92,000 per sq ft (unit not confirmed in the source sheet)"* under **What stands out**. The highlights box is written by three hands — the office, the spreadsheet import and whoever researched the project — and only one of them is writing for a customer. Everything the public templates print now goes through one door that knows the difference: a line that is about the record rather than about the property is dropped, and a line about the property that carries an office aside keeps its meaning and loses the aside. Nothing is invented in its place — a line that cannot be shown is simply not shown. Offices can add their own wording to the list.
* **A project page is a page, not a database row.** The project record was printed as a title, one line of subtitle, a photograph, ten facts in a grid, a WhatsApp button, a bullet list and a wall of text. It is now drawn in the order the office already sets under **Page blocks → project** — a header with breadcrumb, badges, locality, developer, price and the enquiry button; a cover photograph with a clean plate when there is none; **At a glance**; **About this project**; **What stands out** as a scannable grid; floor plans and brochures; a map and locality links; the homes listed inside the project; the share row; and the enquiry form. A block with nothing to show is not drawn at all.
* **The projects directory.** The page was a list of titles and links. It is now a directory: a header that says what the page is, a filter bar offering only the filters the records can actually answer — locality, developer, stage, type and budget, each drawn from values at least one project really holds — result counts, project cards, pagination and a designed empty state. The same directory reaches the website through `[estat_projects]`, so an Elementor page gets the whole thing without the plugin taking the page over.
* **Project cards.** A project card now carries its stage, its type, its locality, its developer, its price where the office set one, how many homes are listed inside it, and a clear way in — instead of one string of joined text that lost whichever of those was missing. A project with no photograph gets an editorial plate, not a broken image.
* **Structured data for projects.** Project pages carried none. They now publish a Residence graph and a breadcrumb graph, built only from what the record holds: no price is written when the office set no price, and no image when there is no image.
* **One card, five places.** The same property card markup had been written out in the properties archive, the three taxonomy pages and the search results, so a change to a card meant finding all five. They all draw the one component now, and the same for project cards.
* **The colours come from one place again.** Fifty-six style declarations were written straight into PHP — including the project grid's own 10px corners and pill-shaped tags, against a design language of 2px corners and squared tags — and the repayment estimate carried thirty-four. All of it now comes from the existing tokens. Several class names the templates print had no stylesheet rules at all, which is why pages drawn from them looked unfinished while the property page beside them did not; each of those names is now mapped onto the component it was always meant to be.
* **Designed for the phone.** 390, 480, 768, 1024, 1280 and 1440 each have their own rules for the header, the cover, the cards, the facts grid, the filters, the gallery, the buttons and the footer, rather than the desktop layout being allowed to collapse.

= 3.6.6 =
* **Societies & Projects now uses the whole window.** The page was held at a reading width built for a paragraph, and the form inside it at less than two thirds of that — so on a wide screen the office worked in a narrow column on the left with the rest of the window empty, and eighteen questions ran off the bottom of it. The screen now asks for the full width, in the same shapes as Properties.
* **The form is in groups, two questions abreast.** Name and About; where it is and who built it; how far along it is; money and inventory; what is in it; the office's own numbers; and the main photo. Related questions sit together and the whole thing is roughly half as long to look at. Below nine hundred pixels wide it falls back to one column, so a phone is never asked to read two.
* **A table with room for every column.** Society or project, **Location**, **Stage**, **Properties listed**, **Updated** and Actions, each in proportion, with the society's name and its unit types on one line and a quiet **Draft** mark where a project is not on the website yet. Search and the stage filter sit together in one toolbar with the count.
* **Page links in a row.** Previous, the numbers and Next were stacked one above the other on every screen that had more than one page of records: the row was laid out sideways but the list inside it was not, so the numbers fell down the page like a column of buttons. They now sit in one line, as boxes.

= 3.6.5 =
* **One press clears the lot.** Two hundred and thirty properties that arrived by mistake used to mean two hundred and thirty walks into a record, because the only way to remove more than one at a time was to tick the rows and press a bar that would only reach a hundred of them. Properties now carries **Clean up in one press**: it counts what is there — the drafts, and everything the last spreadsheet brought in — and each has one button that moves the whole set to the bin in a single go. No ticking, no page by page, no ceiling at a hundred. Nothing is destroyed: everything lands in the bin and the answer comes back with an **Undo** that puts all of it back where it was.
* **The bar that would not come.** The selection bar — and with it every button that acts on more than one row — was drawn hidden and then shown by a script, while the same script also caught each press and sent the form itself. One fault anywhere in that file and the ticks still took, the bar never appeared, and a press that did land did nothing at all, which is exactly what it looked like: ticking that did nothing. The bar now runs from a script of its own, so a problem in the rest of the office's JavaScript can no longer take it away, and every press still works as an ordinary form even if no script runs at all.
* **A place on the spreadsheet that had no column.** The setting that says what to do with a row that looks like a duplicate was put on the import record in 3.6.4 but never added to tables that already existed. Table shape is now re-checked on every update, so the column is there whichever version a site came from.

= 3.6.4 =
* **The office is told when a property looks like one it already has.** A home put in twice is two listings on the website, two lots of enquiries and one office explaining itself. As a property or a society is saved it is quietly held against everything the office already holds — by its name, its area, its size, its rooms, its money and what the description actually says, never by the name alone — and when the answer comes back that this is the same one, the record says so on its own screen: what matched, how alike, and two plain choices, **These are different — keep both** or **Move this to the bin**. Nothing is blocked; the record is saved either way, and an answer given once is remembered rather than asked for twice.
* **A screen for the mess that is already there.** Office now has **Duplicates**, which goes through the whole inventory once and writes down every pair that looks alike, in three tones — **Looks like the same one**, **Very similar** and **Worth a look**. The last of the three is said only there and never holds anything up. Every pair opens on both sides, and each can be kept as two or have one moved to the bin.
* **Spreadsheets are asked on the way in.** A file that arrives every month carries the same properties again, and nothing in the file says so. Each row is now asked the same question before it is written, and a row that answers "already in the office" is left out and named rather than quietly added. The choice sits on the confirm screen — leave them out and tell me which, or put them in anyway — and a dry run counts them before a single thing is saved.
* **One judgement, asked from five places.** What "the same" means is decided in one place, and the property screen, the society screen, the spreadsheet and the Duplicates screen all ask it there. It is deliberately slow to accuse: a different kind of property, a different area, or a name and a description that share almost nothing is each enough on its own to stop a record being called a duplicate, and a record that has hardly been filled in can never be more than **Worth a look**. Two flats in one tower with different rooms and different sizes are two flats.

= 3.6.3 =
* **"Waiting to go up" now shows what it says it does.** The screen opened and answered *"Nothing is waiting"* even when the phone was holding work: the list was being asked for before it had been put where the screen could reach it, and an empty answer was taken for the truth. The screen now waits for the list and then draws it — what each save is, how long ago it was filled in, how many times the phone has tried, and the same two words on the right. Nothing about what is kept, or how it goes up, has changed; what was saved was always saved, and it now shows.
* **A sheet of societies is no longer read as a sheet of properties.** The importer decides what a file is by counting its column headings, and the words a builder actually puts at the top of a list — *Society*, *Sector*, *Tower*, *Phase*, *Total units*, *Possession* — were not being counted on the societies' side, while *BHK*, *Floor* and *Parking* were counted as properties. Those words are now counted where they belong, and a verdict is only reached when the headings are clearly one thing and not the other. When they are not, the office's own answer stands, and the preview still says out loud when a file has been read as something else, with a way back.
* **The count of tries is kept properly.** A save that failed to go up used to lose its count of attempts; it is now written down before the next try, so "tried 3 times" means what it says.

= 3.6.2 =
* **Several photographs in a row, without the phone having to be told again.** The photo box used to be one shot per trip: the camera opened, the picture came back, you pressed again. It now keeps a small pile. The button says **"Open the camera"**, and after a picture it says **"Take another"** and a line counts for you — **"2 ready"** — so a listing with eight pictures is eight taps in one place instead of eight walks back through the phone. A picture you did not mean to take comes off with its little **×**, and the **"Worth shooting"** list above ticks itself off as you go. No reload, nothing to press twice, and the save below still sends the same set it always did.
* **A property's papers are now asked for once, under one heading.** The plan and the brochure were two separate questions with two separate boxes, which read as two separate jobs on a phone. They now sit together under **"Papers"** — *"The plan, the brochure, anything the office should keep. A photo of the paper is fine."* — with the same two choosers underneath. Nothing about where those pictures are kept has changed; the office reads them exactly as before.
* **A screen for the work the phone is still holding.** Pocket's **More** list now has **"Waiting to go up"**, and the quiet line at the bottom of the form carries a **"See them"** link to it. Each save that is stuck on the phone is one row: what the property is (or *"A new property"*), how long ago it was filled in (*"just now"*, *"12 minutes ago"*), and how many times the phone has tried — with two plain words on the right, **"Send now"** and **"Take it off this phone"**. Nothing is ever dropped in silence: taking one off asks first. When the last one goes up the screen says so — *"Nothing is waiting. Everything you filled in has gone up."*

= 3.6.1 =
* **Saving with no network now works the way the field works.** Fill a form in a cellar, a lift, the back of a parking lot and press **Save**: the whole thing — every answer, every photograph, the voice note — stays on the phone, and a quiet line says so (*"1 waiting to go up"*). The moment the bars come back the phone sends it up by itself, through the same door a normal save uses, and tells you: **"Sent. It went up."** with a link to open it. Nothing is a second way of storing a property, and a save that is tried twice lands on **one** record — the phone keeps its own name for the piece of work, and the second arrival simply carries on with the same property.
* **A note can be written when it cannot be spoken.** Some phones refuse the microphone and some rooms are too loud to talk in: under **Record** there is now **"Write it instead"**, and the office reads that note in the same place it hears the others.
* **Smaller:** a property carrying a voice note or a written one opens that part of the office editor by itself, the way a property with photographs already does.

= 3.6.0 =
* **Delete and restore got simpler, because they had one choice too many.** The bar used to offer a second, cleverer thing — **Select all 240 properties** — which changed records that were not on the screen. It worked, and it was exactly the part nobody could be sure of. It is gone. **The bar now acts on what is ticked, and nothing else**; the footer already tells you what the whole list holds ("Showing 1 to 20 of 240 properties"). One press carries up to **100 records**, and if more than that is ticked the bar says so in red before you press it. Nothing is ever dropped in silence.
* **Pocket 2.2 — field capture.** A **voice note** can now be recorded on the phone and saved with the property: tap **Record**, talk for as long as it takes, tap **Stop**, and it goes up with the same Save as the photographs. The office hears it on the property screen — *"Recorded on the phone while looking at the property"* — and it is playable on the phone too. A new **"Worth shooting"** list sits above the photo box (the front of the building, the kitchen, a balcony view…), and a line under it counts as you go: *"Three so far. Six or more is what makes a listing look real."*
* **The phone now says when it is offline.** No network and a quiet line appears: *"No network. What you type is kept on this phone; photographs and voice notes will go up when the network is back."* Typing is kept on the phone as it happens (not only when a step is turned), and if a half-filled form is opened again it says so — *"Picked up where you left off."*

= 3.5.2 =
* **Fixed: the bar did nothing until the page was reloaded — and the question it asked was unreadable.** Ticking a row left the bar hidden and the count at zero, because the tick boxes sit outside the form (a form inside a form is thrown away by the browser) and the page was listening for ticks on the form. It now listens on the page and matches each tick to the list it belongs to. And when the bar did open, the question read **"Move %1$d %2$s to bin?"** — the raw pattern instead of a sentence. It now reads **Move 2 properties to bin?** / **Move 1 property to bin?**, with the right word for one and for many.
* **Fixed: one row's button used to take the ticked records with it.** The row buttons (Move to bin, Restore, Delete permanently) carried their own little form *inside* the bulk form; the browser throws an inner form away, so its hidden fields spilled into the outer one and a single **Delete permanently** could grab everything that was ticked. Every form is now a form of its own — the bulk form is printed after the list — and a row button moves that row and nothing else. Tested both by hand in the bar and end to end in a real browser.
* **Sharp corners on tag buttons.** Tags, chips, filters and counts are now squared off and read as buttons; only dots, avatars and progress bars stay round. Office, Pocket and the dashboard all follow the same rule.
* **New tests:** a real browser now walks the whole sweep — tick two, read the bar, move them to the bin, find them in the bin, restore them, empty the bin — and a separate one proves a row's button moves only its own record while others are ticked.

= 3.5.1 =
* **Fixed: the bulk bar's buttons said "that link has expired" on every press.** The bar and the row buttons carried one kind of security key and the code behind them checked another, so **Move to bin**, **Restore** and **Delete permanently** from the bar were refused — while the same actions worked from a single row. Both buttons and the code behind them now use the same key, and every swing of the bar is tested end to end over real HTTP, not only in the office's own tests.
* **Fixed: the "Undo" that the notice promised had no button.** After moving something to the bin the notice read "Mistake? Press Undo and they come straight back." — and there was no Undo to press, because the key that offers it was being handed in and quietly dropped. It now travels with the answer, and pressing it puts the whole sweep back (a live property comes back live).
* **Fixed: Empty bin sent you to the wrong screen.** Pressing **Empty bin** — or restoring from the bin — landed you on the Properties list instead of back on the Bin screen, because newer WordPress ignores a referer that is the same page as the request. The forms now say where to return, and after emptying you see **Recycle bin is empty** where you are standing.
* **Smaller:** the record columns in the bin read **Original status** (not "Was"), the same word the filter uses; and the phone's Pocket screen says "restored" everywhere instead of "brought back".

= 3.5.0 =
* **Deleting a property is safe now, and the office can get it back.** The list of properties has tick boxes: tick a few, and a bar appears at the bottom saying how many are ticked, with **Move to bin** on it. Moving them takes them off the website at once — a visitor gets a 404, not a half-deleted page — but nothing is thrown away. There is no one-press way to lose a record: every destructive button first asks, in words, with the exact number in it ("Move 7 properties to bin?").
* **A real recycle bin, not a decorative trash page.** The new **Bin** screen (heading: *Recycle bin*) lists what was set aside with its picture, title, locality, price, **Deleted by**, **Deleted on** and **Original status** — "Moved to bin by Aman · 2 Oct 2026". Every one of them can be **Restored** or **Deleted permanently**, one at a time or in a batch.
* **Restore puts it back exactly where it was.** A live property comes back live; a draft comes back a draft; one waiting for approval comes back waiting; a paused one comes back paused. Availability and verification are not quietly overwritten on the way back.
* **Move to bin is not the same as Delete.** **Paused** means an active property hidden from the website; **In bin** means it has been taken out of the working list and can be brought back. Two different things, two different words, in every screen and filter — and **Deleted** is never used as a status a property can sit in.
* **Permissions are separated, on the server.** An agent may move the properties they handle to the bin and restore their own. Permanent deletion needs the office's own permission — a manager or the owner. Hiding a button is not security, so every single one of these actions is checked again on the server, for every record in the batch.
* **Half-done sweeps say so.** Large selections go to the server in one batch (up to 100 at a time); the bar says **Moving 48 properties to bin…**, and the answer afterwards is either "48 properties moved to bin" or "45 properties moved to bin · 3 could not be moved", with the reasons. Nothing is done one browser request per record, so a slow shared host cannot leave a selection half-done and silent.
* **Undo, and an audit trail.** Just after a sweep, a notice offers **Undo** — a wrong press can be taken back for thirty minutes without hunting through the bin. Every move, restore and permanent deletion is written into the audit trail with who did it, which records, when, and what state they were in before; a bulk move also gives each property its own line in its own history.
* **Enquiries, visits, notes and history stay where they are.** Moving a property to the bin never touches the people who asked about it, the visits that were booked, the notes or the audit trail — they are kept, and they come back with the property. Media is never deleted on the way to the bin; a permanent delete only removes files that nothing else is using, and never a shared one.
* **The list is organised the way an office thinks.** **All · Needs attention · Live · Drafts · Waiting for approval · Paused**, and then, set apart, **Bin** — binned records are not mixed into any count or into any search. The menu shows **Properties 128** and **Bin 7**, permission-aware, down to the honest **Bin 0**.
* **On a phone it becomes a selection mode, not a wide table.** Ticking a row turns the bottom bar into **7 selected** with **Restore / Move to bin / Cancel**, and the same words are used in the phone app. Nothing destructive is ever done by a swipe.
* **Fixed: the older, second way of changing many records is gone.** The properties screen used to have one way of changing records in a batch (the tick boxes) and a second, older one hidden in a form of its own; they could mean slightly different things. There is one path now — the same permission checks, the same confirmation, the same audit line.
* **Fixed: restoring never changes a property's state behind your back.** A property brought back from the bin used to come back as a draft no matter what it was, which took live properties off the website in the middle of a restore. It comes back as it was.

= 3.4.0 =
* **The phone app has a working day in it now.** The first screen is **Today**, and it is built from what is actually unfinished — a site visit this afternoon, a follow-up whose day has passed, a new enquiry nobody has answered, a property the office sent back, a live property nobody has checked with its owner for two weeks. Every job carries its reason under it ("The follow-up was set for 2 October and has passed.") and the one button that finishes it, usually **Call now**. Nothing is listed twice: one client is one job.
* **Five doors and one button.** The bar reads **Today · Leads · Properties · Visits · More**, with a single **＋ Add** in the middle where a thumb already rests. The five doors are the same on a phone and on a desk; everything that is not part of a normal day (ask the office for a change, societies, search, your own details) sits under **More**, named in full instead of hidden behind a guessable icon.
* **Add-anything sheet.** ＋ Add asks one question — "What are you adding?" — and offers the five things an agent actually starts in the field: a property, an enquiry, a visit, what a client wants, and an owner update. Nothing is created until a form is filled in and its own button is pressed, so backing out can never leave half a record behind.
* **An enquiry can be written down in a minute.** Name, phone, what they want (buy/rent, area, budget, a line of notes) and the day to ring them back. It lands in the office the moment it is saved, and the follow-up date appears in Today when the day comes.
* **Visit Mode: before, during, after — on one screen.** *Before you go* ticks the three things that decide whether the visit is worth going to (the owner knows, the client has confirmed, the keys are arranged). *After the visit* asks three questions — did it happen, what did the client think, what happens next — and writes the answers where the office already looks: the visit, the client's own record, and the audit trail. Say the client is not interested and the enquiry moves to **Lost** with the reason the office needs; say they want to go ahead and it moves to **Won**; say "call them tomorrow" and a follow-up date is set by itself.
* **Owner update: thirty seconds after the phone call.** Pick the property, answer three questions (is the money still right, is it still available, what did the owner say) and the office knows the owner was checked today. The property is marked **Checked by agent** — never higher, because only the office may say **Verified by office**. A price or availability change is not quietly written onto a live page: it goes to the office as a change request, through the same path every other change takes.
* **One search box for everything.** Type a name, a number, a sector or a property — "Rahul", "Sector 49", "3 BHK", "98765" — and the answer comes back grouped into **People**, **Properties** and **Visits**, only from what that phone already has the right to see.
* **Every day starts with why.** Jobs are ordered by urgency and each one says where it came from, so "open it and see" is never the answer to "why am I doing this?". Ten new screens read as an app, not as the WordPress admin in a smaller window: 44px tap targets, a sticky search, big thumb-sized choices, and not one WordPress word anywhere in the phone.
* **Fixed: "the follow-up date has passed" was said about people nobody had promised to ring.** The office to-do list asked for overdue follow-ups and was quietly handed the newest enquiries instead — a promise made for tomorrow could sit next to a client nobody had ever scheduled to call. Overdue now means overdue.
* **Fixed: "Add to calendar" on an enquiry never worked.** Pressing it answered "That link has expired. Please go back, refresh the page and try once more." every single time, because the link carried its security key under one name and the check read another. The visit now downloads as a real .ics file — and the link says **Add to calendar** instead of ".ics", which is what a person can actually read.

= 3.3.0 =
* **One state, one word, everywhere.** A property was being described with one word doing four jobs. It now has four separate facts, each with its own word, on every screen, in every email and on the website: where it stands online (**Draft / Waiting for approval / Live / Paused / In bin**), whether it can still be offered (**Available / Under offer / Rented / Sold**), whether anybody checked it (**Not checked yet / Checked by agent / Verified by office**), and how far the building is (**New launch / Under construction / Ready to move**). The same property can honestly be "Live, Available, Not checked yet, Ready to move" — and now it says so.
* **The phone and the office finally read from the same sheet.** One shared vocabulary decides every label (Office → Support → Status), so the office list, the property card, the phone, the flash messages and the website can no longer drift apart.
* **Two words were simply wrong.** A rental that has been let was called **Booked** — it now says **Rented**, and "Booked" is kept for a real booking if that day comes. Paused inventory was called **Hidden**, **Private** or **Inactive** depending on the screen — it is **Paused** everywhere, with the explanation "Paused — kept in the office, hidden from the website."
* **A site visit is no longer "Pending".** A visit is **Scheduled**, then **Completed**, **No-show** or **Cancelled**. An office request is **Waiting for office / Approved / Declined** — and "Approved and applied" stays where it belongs, in the message after the office says yes, not on the badge.
* **The client journey is enforced, not just drawn.** An enquiry goes New → Contacted → Scheduled → Won or Lost (a client can go cold from any step). A visit can be finished, missed or cancelled — but not quietly reopened. A brand-new enquiry can no longer be marked "Won" without anybody speaking to the client: the server refuses the jump, whoever posts the form. The office itself may still put any record right by hand, and every such change is written to the audit trail.
* Pocket now offers only the steps that are actually open (the current state plus the legal moves), so the phone can never present a button the server would refuse.

= 3.2.9 =
* **A sheet of societies is no longer brought in as properties.** The upload box asks "What is in this file?" and "Properties (listings)" is the first answer — so a builder's master sheet left on the default turned every society into a property, and the office's property list filled up with names like "DLF The Camellias". The file's own columns are now read first: a sheet with Developer, Possession, Total units or a RERA number is brought in as Societies / Projects, and the preview screen says so in one line before anything is saved.
* **If we read it the other way round, you are told and can put it back with one click.** The preview carries a notice naming what you picked and what the columns say, and a button that reads the file again as the kind you picked — no second upload.
* Undoing an import now names what it removes ("Societies and projects it added will go to the bin") instead of always saying "Properties".
* The upload box says what happens if you are unsure: leave the answer as it is, and the next screen tells you what the columns said.

= 3.2.8 =
* **A property can no longer go on the website without saying what it is.** "Apartment" was quietly filled in when the question was never answered — a plot could be published as an apartment. A blank now stays blank, a draft may still be unfinished, and putting a property on the website asks for the type (and sale/rent) first. The phone app now asks for the type on the same step as sale/rent, and the office form marks both as required instead of "optional".
* **An older or imported type is never lost.** A record holding a name the shortened list no longer offers ("Flat", or something imported from elsewhere) opens with that same name still chosen, marked "(as written before)", in both the office and the phone app — instead of quietly switching the answer on the next save.
* **Reports: a rental's average price was always "₹0".** The figure sits in the rent column, and the report only read the price column. It now reads the right one, and writes a monthly figure the way the website does ("₹75,000 a month") rather than shortening a rent to "₹75 K".
* **Insights: the line under the list says what the list is.** It read "Newest first." — that explains the sorting, not the writing. Each of Blogs, Articles and Insights now gets its own sentence, and the button says what it will create ("Write a new article").
* Every one of the 48 property answers now has a home: 41 can be typed in the office, 38 on the phone, the rest are marked as filled in by the plugin itself or as another name for the same figure. Two gaps closed: **Company** (shown when the office runs more than one company) and the registration number.
* The same figure under a second name (a rent kept in `_estat_rent`, prices in `_estat_price_min`/`max`) is now written down as such, so nothing looks like a missing question.

= 3.2.7 =
* **Fix: the website could go down on the 3.2.6 update.** With the newest Elementor installed, every page of the website could answer with "There has been a critical error on this website" while the office and the phone app kept working normally. 3.2.6 asked Elementor for its page templates in a way that the newest Elementor no longer accepts. The question is now asked only on a property page, only when it matters, only once per page — and it is wrapped so that **no answer from Elementor, and no trouble inside Elementor, can stop the website from opening**. The office, the phone app, the sitemap and search were never affected.
* If anything unexpected ever happens while the plugin is choosing a page's design, WordPress now draws the page in the normal way and leaves a line in the site's log instead of showing an error to visitors.
* The WhatsApp button's edit-time check in Elementor goes through the same safe path.

= 3.2.6 =
* **A WhatsApp button on every property and society page.** One tap and the message is already written — the property's name, its price and its link — so the chat does not start with "which property?". Turn it off from Settings if you would rather not have it. It is also available as the **WhatsApp Button** widget in Elementor and as `[estat_whatsapp]`. Taps are counted on the property itself, not written into Enquiries, because a tap arrives with no name and no number to call back on.
* **The pages an older version made have been tidied.** They were carrying the office's own notes ("Team directory — agents with phone, WhatsApp, listings count", "Advanced EMI — ... (F10)") and a search engine was printing those lines under the site in Google. Every page now opens with one plain sentence for the visitor, and a page called "office" that had no job left has been put aside as a draft. Settings → Advanced → Tools → **Tidy the pages the plugin made earlier**. A page the office has written itself is never touched.
* **Cache clears itself on every update**, and there is a **Clear the website's saved copy** button for the times you changed something and the site still shows yesterday.
* **A property page can be left entirely to your theme or Elementor.** Settings → Listings → "Who draws a property page" is set to *My website* by default, and on that setting the plugin will not replace a page you built.
* **The sitemap and the noindex list now agree.** /search/, /alerts/, /favorites/, /compare/ and /thank-you/ were in the sitemap while being kept out of Google — they are out of the sitemap now. The /notes/ page is a real page of yours, so it is no longer kept out of search.
* A description that was only the page name ("Notes") is no longer used as the meta description; the plugin writes a proper line instead.
* 17 more lines of interface language, and plainer wording where a developer's shorthand had been left on screen.

= 3.2.5 =
* Societies and projects no longer sit inside the property list. The phone app's list now has two chips — **Properties** and **Societies & Projects** — and only ever shows one of them.
* A society or project has its own page on the phone: stage, builder, price, possession, and a link to the website. No property form, no "carry on editing", nothing that would write flat details onto a society.
* The property form now refuses a society twice over — the screen will not open it, and the server will not save it — so a typed URL cannot mangle an office record either.
* The bin and the office's "waiting for approval" list are split the same way.
* Counts ("N of your listings are live", the numbers on **You**) count properties only, because a society is not a flat.

= 3.2.4 =
* The staff phone app now has its own **You** screen: your name, phone, WhatsApp and email, the language you read, and your own password — all in one place, from the phone.
* The office's own settings stay with the office. The app only shows what the office decided, read-only.
* Changing the password signs you out on other devices, but keeps the phone you are holding signed in.
* Fix: the new screen's link had no page behind it (404) — one list in the plugin was missing the name; caught by the tests, now fixed and guarded.
* No office data moves: your details are saved on your own team record, the same one the office already sees.

= 3.2.3 =
* Fixed: the boxes on the staff phone app had no border at all. Cause: the shorter colour names ("card", "line-strong") were spelled out inside the office stylesheet only, and the phone app loads a smaller set of files — so a colour came out as nothing and CSS threw the whole line away. Those names now live in tokens.css, once, for every surface: office screens, the phone app, the PC dashboard and the website.
* Fixed: a couple of rounded corners on the PC dashboard were also nothing, because two more names were missing there.
* Fixed: the little badge at the top of the phone app read "Mobile Mobile" (the word was written in the page and drawn again by the stylesheet). It reads "Mobile" once now.
* New: a test (css_vars_check.py) that reads every surface's stylesheets and reports any colour name that would come out empty, so this quiet kind of fault cannot come back.
* New: a test (har_button_check.py) that opens every office screen and the whole staff app and presses every button the way a person would, then reports any button that does nothing or breaks the page. It now reports none.
* New: a test (pocket_look.js) that opens the staff app on a phone-sized screen and checks the boxes, the labels and the gaps between sections.
* The test bed now really starts fresh: every rebuild puts the settings back on their default and re-fills the office details, so one test can no longer make another one fail.

= 3.2.2 =
* New: a Settings section in the plugin menu. One place with ten lines — Overview, Office details, Properties, Enquiries & emails, Staff app (Pocket), Integrations, Advanced & tools, Website forms, Page blocks, Colours & fonts. Every switch that changes the office or the staff phone app is on one of its tabs.
* New: a working "Send a test email to me" button on Settings — Enquiries & emails, so you can find out in one press whether your emails actually go out.
* New: forms now look like forms. Every box has a visible border, a white background and a comfortable height, labels are darker, and the property editor's chapters sit in their own cards with a clear gap between them. The grey WordPress background is gone from these screens.
* New: a new society saved with nothing chosen is stored as Residence / Planning, and "not said yet" still means not said yet.
* Fixed: lists sent to the server were being thrown away. Settings' "Save changes", the website-forms form, the ticks on Add a home, ticks in bulk actions, the pages chosen in Setup and the colour names all arrived as an empty string, so nothing was saved. They arrive whole now.
* Fixed: saving one settings tab no longer switches off the other tabs' switches (print sheet, EMI calculator, share buttons).
* Fixed: a change request sent from the staff pocket app carried no changes, because the agent's answers were flattened on the way in. The office side of the same form had the same fault.
* Fixed: "Repair broken localities + draft pages" crashed instead of repairing, because it called a class by a name that does not exist.
* Fixed: the version the browser is told to ask for was two releases old, so an old stylesheet could stay on screen after an update.
* Fixed: the Settings lines were listed in the wrong order and WordPress added its own duplicate of the first line.

= 3.2.1 =
* New: a master sheet of projects now imports in one go. A 171-row file used to be read 50 rows at a time — four visits to the screen, and anything you did not come back for waited a day. The whole file is read while the request still has time, and the daily job only takes what is left.
* New: the import screen works out what the file is on its own. A builder's master sheet, a 99acres export and a plain CSV are told apart from the column names, so nothing has to be chosen before the first look.
* New: before anything is written, the preview lists every column in your file in the sheet's own order and says what will happen to it — "Read" with the box it goes into, or "Not used" with the reason. A column we leave alone is never a silence again.
* Fixed: a "Dry run" only looked at the first 50 rows of a large file and called that the whole picture. It now reads the entire file and reports the true count.
* Fixed: a project's "as written" price column was thrown away after the price was read from it. "On request", "Poss. Oct 2027" and a per-square-foot rate are the office's own words — a price is now read out of that column, a possession date out of it, and whatever is left is kept as a highlight.
* Fixed: a master sheet's second area column ("Sector 62 / GCER") was becoming its own area page beside the micro-market that is the same place. The sector is folded into the address line instead, and the city is written once at the end of it.
* Fixed: the stage was missed on rows where the sheet had written it in another column in a form we did not recognise ("Upcoming / Pre-launch", "Ready (Operational)"). Stages are read as whole words now, so "OC received" is ready to move while the "oc" inside "block" is still nothing.
* Fixed: a project's kind ("Affordable / DDJAY", "Group Housing", "Office + Retail") is turned into one of the five the record holds, instead of every imported project landing on "other".
* Fixed: undoing an import of 171 rows reported 342 records put back — each record was counted twice, once for its words and once for its fields.
* Fixed: the project page's search-engine line now starts with the project's own name ("DLF The Camellias is a Residential Apartment + Penthouse project in Golf Course Road"), and the facts on the page come out of the record the import actually wrote.

= 3.2.0 =
* New: the plugin now decides what a search engine is told about its own pages, and writes it down in one place. A published property, and an area or amenity page that actually holds something, may be indexed. A filtered view of the properties list (?offer=rent&bedrooms_min=3) points at the clean address instead of competing with it. Search, saved properties, compare and thank-you are kept out of the index.
* New: an area page, a project page or the properties list with nothing to show is kept out of the index until something is listed there — nobody wants to land on an empty directory.
* New: titles and one-line descriptions are built from the office's own records. The properties list says how many are for sale and how many to rent; an area page says how many properties it holds and the cheapest one; a property says its bedrooms, type, area and price. If the office (or the SEO plugin) has written its own title or description for a page, that wins and nothing is overwritten.
* New: "these records need filling in" — a card on Listings that lists what is missing from each property and links straight to it, the same list inside the property's own editor, and a CSV to fix in Excel and import back. It catches a name that says 4 BHK while the record says 1 bedroom, a size of 0, a missing price, no locality, no photo, no owner, no verification, and a description too short to mean anything.
* New: area names that an import cut in half ("Sohna Road (Sector 49") are pointed out on Import & export with a merge tool — every property moves onto the name that stays, then the broken name is removed. Nothing else is deleted.
* Fixed: a property whose availability was never filled in was published to search engines as "SoldOut". A blank answer was being turned into a claim nobody made. Availability is only stated when the office stated it, and an unknown answer is now simply left out of the structured data.
* Fixed: the structured address now carries the region and country as well as the locality.
* New: a test for all of it (wp_test/seo_check.php): indexing rules, titles, descriptions, structured data and the data health list — 79 checks.

= 3.1.9 =
* New: the staff phone app now asks for a property the same way the office does, one short step at a time — what it is and where, the price, size and rooms, photos and video, the description, then a last look at everything you typed before you save. An office user also gets a seventh step for the answers only the office may give.
* New: the property form shows a review step. It lists every answer you gave, step by step, with an "Ise theek kijiye" link back to the box that needs changing, and it never shows a question you have not reached yet.
* New: photos on the phone: the first photo is the one the website leads with, a star button on any photo moves it to the front, and a cross takes a photo out of the list.
* New: deleting a property is one clear step with a plain question behind it. It goes to the office bin, comes off the website, and "Wapas laiye" on the listings screen brings it back — straight onto the website for the office, and back to draft for an agent.
* New: the office listing editor has a "Manage this property" card at the end of the form, so the same remove, undo and delete-for-good buttons are reachable from the record you are looking at.
* Fixed: empty money boxes on the phone were coming up as 0, and a saved blank deposit was stored as "0" — the website then said "Deposit 0". A blank box now stays blank.
* Fixed: the last step of the phone form was blank, with no Save button and nothing to review; it now shows the full review and the save buttons.
* Changed: "New listing" on the phone's Add button is "Add a property", and a row with no price says where the property stands ("Abhi adhoori hai", "Office ke paas", "Website par hai", "Rok di gayi") instead of "Price not set yet".
* New: the import screen's sample file is now four files — properties, societies, team and enquiries — so a sheet of Gurgaon societies no longer comes with a property's columns on it. The society column names are printed on the same screen.
* New: four tests for this work — one compares the office form's fields with the phone's (46 and 45, every one in one step), one saves a property from the phone and checks the office record comes out identical, one drives the whole workflow over real HTTP with real photo uploads, and one opens the phone form in a headless browser and walks through all seven steps.

= 3.1.8 =
* Changed: the last English corners of the office read Hinglish now. Every setting on Office > Colours and fonts had an English name ("Ink (main text)", "Gap MD"); they say what they do in Hinglish instead. The list of pages on the website and in Finish setup had names that never followed the language setting; now they do.
* Fixed: the enquiry form on the website kept the English field names it was born with ("Your name", "Send enquiry") even after the office switched the language. The form now follows the language setting, and a name the office typed itself is left exactly as typed.
* Fixed: the staff app's property form printed a developer line at the top — "Step 1 of 4 - Mobile - 4-step wizard". It now reads "Step 1 / 4 - Kya aur kahan", and the lines it uses to nag you ("Title needed") are Hinglish too.
* Fixed: the staff app's enquiry screen printed the raw stored values — "sell - form". It now reads "Bechna - Website form", and a set-aside enquiry says "Alag rakha: ..." instead of "lost: ...".
* Fixed: the page list on the website printed each page's machine name ("- /properties") and the name of its icon in large letters ("map-pin"). It now shows the real icon and one of two plain lines: "Website par hai" or "Abhi nahi bana".
* Fixed: the "Preview" button beside each export on Import & export now says "Pehle dekhiye".
* New: a test that reads every screen and the whole website twice — once in Hinglish, once in English — and complains about any line that stayed English. The lines that should stay English (names, addresses, "Listings", "Enquiries") are written down in wp_test/hinglish-keep.txt.

= 3.1.7 =
* Fixed: the website never loaded the plugin's colour and font file (tokens.css) — only the office did. Every colour, size and font on the plugin's own pages was quietly falling back to the browser's defaults, and "Colours and fonts" in Office Settings changed the office screens but not the website. The website now loads that file first, and the setting works on both.
* Changed: no colour is written down twice any more. The public pages, the forms and the share buttons read every colour from that one file (the WhatsApp button keeps WhatsApp's own green, on purpose).
* Changed: Reports says what is inside it instead of offering advice — "How the office is doing" is now "Enquiries, visits and deals", "What you have to sell" is "The properties you have", and the sentence about a healthy office turning one in twenty enquiries into a deal is gone.

= 3.1.6 =
* Changed: the property form now asks "Is this for sale, rent or lease?" before anything else, and the money box is named after that answer — Price for a sale, Monthly rent for a rental, from one box rather than two.
* Changed: fields that cannot apply are hidden instead of filling the page — a plot has no bedrooms or bathrooms, a sale has no deposit or maintenance, and a plot is never asked which floor it is on. Nothing is deleted: the answer stays in the record and comes back the moment the first answer changes.
* Changed: the property form is three short parts. The everyday answers are open; the rest sits behind grey lines that say how many boxes are inside them (23 of the 46 on an ordinary listing), and each line opens by itself when it already holds something.
* New: "Add a home" follows the same order and hides the bedroom box for a plot, a shop, an office or a warehouse.
* Fixed: nothing. This release only makes the form shorter; every field that existed before it still exists, which a test checks against the previous build.

= 3.1.5 =
* New: every code you need to skip typing — the staff phone app, the office PC dashboard and the office location sit together on Office → Overview, and each team member has his own QR sheet on Team (the QR button beside his name).
* New: "Print this sheet" on a team member's QR screen. The sheet carries two codes — the app on his own phone, and the page a client should open — and prints without the WordPress menu around it.
* Fixed: the printed property page used to fetch its QR picture from an outside website (api.qrserver.com). That meant every print sent the property link to somebody else's server, and with the internet down the sheet came out with an empty box. The code is now drawn by the plugin itself, so it always appears.
* Changed: the plugin draws QR codes on its own — no account, no key, no outside service, and it works with the internet switched off. Codes hold up to 213 characters, which covers any page address on this site.

= 3.1.3 =
* Fixed: switches in Office Settings could be turned on but never off. Every tick box on the settings screens now saves both ways.
* Fixed: the Pipeline screen printed a PHP warning line at the bottom ("Undefined variable $deleted") in place of its footer.
* Fixed: the single price box on a property form. A monthly rent typed into it was saved as a sale price, so the property lost its rent. Sales and rentals both store the right number now.
* Fixed: Page blocks showed two headings and printed the machine name of every block beside its label.
* Fixed: Reports listed "Website form" twice when messages arrived through two kinds of form; the counts are added together on one line.
* Fixed: property cards showed "apartment" and "farm_house" instead of Apartment and Farm House, and the count banners said "Everything on the books", "Public" and "Confidential".
* Fixed: the Office Settings breadcrumb read "Office / Office / Office overview".
* Removed: "Add custom block" on Page blocks, which asked for a "hook" or a "child theme" and could not work without a developer.
* New: "Put them all on the website" on Listings, so drafts do not have to be opened one at a time.
* New: the Elementor message switch also sits on the Forms screen, next to the forms it collects from.
* Changed: Insights described itself as what visitors look at most; it now describes what it holds — blog posts, articles and market notes.

= 3.1.4 =
* Changed: the office now gets four emails and no more — a new enquiry, a property waiting for approval, a summary every morning at 8, and a report every Monday at 8. The other fifteen notification switches are gone from the settings screen, and those emails are not sent at all any more.
* New: the morning summary and the weekly report. Both are plain text, both can be switched off, and both are also on the screens.
* Fixed: the "Emails — templates" boxes on the settings screen saved subject and body text that nothing ever read. They are gone; the From name, From address and footer line, which do work, are still there.
* Removed: the hourly job that mailed the office a day before every site visit — that reminder is on the Today screen instead.

= 3.1.2 =
* Changed: the icons on the office screens now come from the plugin itself instead of Google Fonts. The twelve requests to fonts.googleapis.com are gone, and an icon can no longer show up as the word "add_home" when the network is slow or blocked.
* Changed: the translation template was 700 strings behind the code. It now matches exactly (2,228 strings), and 189 new Hinglish lines were added for the words you see every day on Today, Listings, Enquiries and Change requests.
* New: help text for the five screens that had none (Change requests, Pipeline, Search alerts, Page blocks, Colours and fonts).
* Fixed: Team and Today showed the machine word for a record's state ("publish", "draft"). They now say Live, Draft, Waiting, Hidden, Scheduled or Bin.
* Changed: the "Ledger" view toggle is now called "Table".
* Changed: the technical details for support are folded away behind "Asking someone for help?" instead of sitting open in every screen's help panel.

= 3.1.1 =
* Fixed: every property page returned a 500 error because the enquiry form it asked for did not exist. The form now renders, and falls back to a call/WhatsApp/email strip when no form is set up yet.
* Fixed: the Today screen stopped with a fatal error, and its work list would have shown buttons with no text.
* Fixed: the forms API endpoint (/wp-json/estat/v2/forms) stopped with a fatal error.
* New: messages sent through Elementor forms now also arrive in Enquiries (Office -> Integrations).
* New: the office's own name, phone, WhatsApp, email, address, hours and city come pre-filled; existing values are never overwritten.
* Fixed: 21 stylesheet values that screens asked for were never defined, so some gaps, text sizes, chips and focus rings did nothing.
* Changed: Listings, Listings (new) and Team tables become cards on a phone, like the other screens.
* Changed: the last hard-coded colour in the admin now uses the shared chip style.

= 3.1.0 =
* The older screens (Enquiries, Change requests, Spreadsheet, Search alerts, Import history, Templates) now wear the new design: same header, chips, cards, tables, buttons and fields as the rest.
* Search alerts stopped showing internal words. Columns are Person, What they are watching, How often, Status, Last email, Actions.
* An import's state reads Finished, Undone, In progress or Waiting instead of the machine word.
* Every colour on those screens now comes from one place. The last inline colours are gone.
* On a phone, the lists that have labels turn into one card per row.
* A duplicate setting on the Office screen was removed, so the two copies stop overwriting each other.

= 3.0.9 =
* The old interface and the on-off switch are gone. One list decides the menu and the screens.
* One property now shows three separate things: Website (Live / Draft / Hidden), Availability (Available / Under offer / Booked / Sold) and Freshness (Just listed / Ready to move).
* All admin colours come from one file. The dark theme now works. Three screen sizes, and tables become cards on a phone.
* Ten settings that had gone missing from the office screen are back. Four more (city, from name, from address, email footer) now actually save and are used.
* No client name, British agency wording or internal release codes anywhere the office can see them.


= 2.8.0 =
* The agent pocket: yoursite.com/agent opens a phone-first screen where team
  members add listings (as drafts for approval), ask for changes on live
  ones, log visits, and answer enquiries — signed in with their normal
  WordPress account, no app, no new passwords. Owners and managers also get
  an Approvals tab, so a change can be said yes to from a phone, through the
  same paths (audit, index, undo) as the dashboard.
* Approval honesty fix: approving a change request no longer touches the
  record's publication state. Previously the write-through quietly returned a
  live listing to draft; no screen asked for that, and now nothing does.

= 2.7.0 =
* Agents can now propose a correction to a property that belongs to a
  colleague. The office approves or turns it down on the new Change Requests
  screen; nothing on the website changes until they do.
* A leftover entry in the action permission map is gone. Removing a property was
  (and remains) available on every listing row; the dead entry made an auditor
  believe deletion had no route at all.

= 2.3.0 =
* Twelve listing fields were being collected and shown to nobody. All are now
  on the property page, including deposit, maintenance, video and 360 tour.
* Projects had no reader at all; the builder, price range, unit counts and
  possession date now appear on the project page.
* "Export site visits" produced an empty listings sheet. It now exports visits.
* Erasing everything on uninstall missed Insights and its two taxonomies.
* One caller typing "9876543210" and "+919876543210" became two enquiries.
* Titles are capped and control characters stripped.
* Today and Listings now check permission themselves rather than relying on
  the menu alone.

= 2.2.0 =
* Act on many records at once, with permission checked per record.
* Undo the last edit to a listing, society or team member.
* Keyboard shortcuts, with a visible list under "?".
* Hinglish finished: 1,504 strings.

= 2.1.0 =
* Dropdowns no longer hide records past the two hundredth without saying so.
* Societies and Team can be searched and paged.
* Nonsense numbers are refused with an explanation.

= 2.0.0 =
* A real type scale, a real icon set, and no pure black or white.

Earlier releases are listed in CHANGELOG.md inside the plugin folder.

== Upgrade Notice ==

= 2.3.0 =
Fixes twelve property fields and seven project fields that were saved but never
displayed. If you have been filling in deposit, video links or possession dates,
they will start appearing on your website after this update.
