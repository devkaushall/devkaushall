/**
 * Estat.OS — shared interaction layer.
 *
 * One file, no dependencies, no framework. Every behaviour here is driven by
 * data attributes a PHP component writes, which buys three things:
 *
 *   1. Nothing runs on a page that does not contain the component. Each
 *      module looks for its own root element and returns immediately when it
 *      is not there, so a projects page never pays for a lightbox it does not
 *      use and a property page never pays for an amenity filter.
 *   2. The markup is usable before this file loads and without it. Every
 *      control is a real button or a real link with a real href; JavaScript
 *      only adds behaviour on top.
 *   3. A component can be dropped into a shortcode, an Elementor widget or a
 *      template and behaves identically, because there is nothing to wire up.
 *
 * Registered as 'estat-ui'. Templates enqueue it with wp_enqueue_script().
 *
 * @package EstatOS
 */
( function () {
	'use strict';

	var strings = ( window.estatUi && window.estatUi.i18n ) || {};

	/**
	 * A translated string with a plain-English fallback.
	 *
	 * @param {string} key      Key.
	 * @param {string} fallback Fallback.
	 * @return {string}
	 */
	function t( key, fallback ) {
		return strings[ key ] || fallback;
	}

	/**
	 * Has this element already been wired up?
	 *
	 * `estatUi.refresh()` can be called again after a shortcode or a widget
	 * injects markup. Without this, every call would add a second click
	 * handler to everything already on the page, and a control would then
	 * open and close in the same press. An element remembers that it has
	 * been wired, so a re-run only ever touches what is new.
	 *
	 * @param {Element} el Element.
	 * @return {boolean} True when it should be skipped.
	 */
	function done( el ) {
		if ( ! el || el.getAttribute( 'data-estat-wired' ) ) {
			return true;
		}
		el.setAttribute( 'data-estat-wired', '1' );
		return false;
	}

	/**
	 * Has the visitor asked for less movement?
	 *
	 * @return {boolean}
	 */
	function calm() {
		return !!( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches );
	}

	/**
	 * Build an element from an HTML string.
	 *
	 * @param {string} html Markup.
	 * @return {Element}
	 */
	function node( html ) {
		var box = document.createElement( 'div' );
		box.innerHTML = html.trim();
		return box.firstElementChild;
	}

	/* ======================================================================
	 * Lightbox
	 * ----------------------------------------------------------------------
	 * Markup:
	 *   <div data-estat-lightbox>
	 *     <button data-estat-lightbox-item data-full="…" data-caption="…">
	 *   </div>
	 *
	 * The dialog is not created until the first photograph is opened, so a
	 * page with thirty photographs costs nothing until somebody looks at one.
	 * ==================================================================== */
	var Lightbox = ( function () {
		var dialog = null;
		var items = [];
		var index = 0;
		var opener = null;
		var root = null;
		var img = null;
		var caption = null;
		var counter = null;
		var stage = null;
		var frame = null;

		/*
		 * 'photo' or 'frame'. In frame mode the stage holds a film or a
		 * walkthrough instead of a picture, so the counter and the arrows
		 * are meaningless and are hidden.
		 */
		var mode = 'photo';

		/**
		 * Create the dialog once.
		 *
		 * @return {void}
		 */
		function build() {
			dialog = node(
				'<div class="estat-lb" hidden>' +
					'<div class="estat-lb-veil" data-estat-lb-dismiss></div>' +
					'<div class="estat-lb-panel" role="dialog" aria-modal="true" aria-label="' + t( 'photos', 'Photographs' ) + '">' +
						'<div class="estat-lb-bar">' +
							'<span class="estat-lb-counter" aria-live="polite"></span>' +
							'<button type="button" class="estat-lb-btn" data-estat-lb-close aria-label="' + t( 'close', 'Close' ) + '">' +
								'<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false">' +
								'<path d="M5 5l14 14M19 5L5 19" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>' +
							'</button>' +
						'</div>' +
						'<div class="estat-lb-stage"><img alt="" /></div>' +
						'<p class="estat-lb-caption"></p>' +
						'<button type="button" class="estat-lb-arrow is-prev" data-estat-lb-prev aria-label="' + t( 'previous', 'Previous' ) + '">' +
							'<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true" focusable="false">' +
							'<path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
						'</button>' +
						'<button type="button" class="estat-lb-arrow is-next" data-estat-lb-next aria-label="' + t( 'next', 'Next' ) + '">' +
							'<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true" focusable="false">' +
							'<path d="M9 5l7 7-7 7" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
						'</button>' +
					'</div>' +
				'</div>'
			);

			document.body.appendChild( dialog );
			stage = dialog.querySelector( '.estat-lb-stage' );
			img = dialog.querySelector( '.estat-lb-stage img' );
			caption = dialog.querySelector( '.estat-lb-caption' );
			counter = dialog.querySelector( '.estat-lb-counter' );

			dialog.addEventListener( 'click', function ( event ) {
				if ( event.target.closest( '[data-estat-lb-close]' ) || event.target.closest( '[data-estat-lb-dismiss]' ) ) {
					close();
				} else if ( event.target.closest( '[data-estat-lb-prev]' ) ) {
					step( -1 );
				} else if ( event.target.closest( '[data-estat-lb-next]' ) ) {
					step( 1 );
				}
			} );

			// Touch: a sideways drag longer than a tap moves the photograph.
			var startX = 0;
			var startY = 0;
			dialog.addEventListener( 'touchstart', function ( event ) {
				startX = event.changedTouches[ 0 ].clientX;
				startY = event.changedTouches[ 0 ].clientY;
			}, { passive: true } );
			dialog.addEventListener( 'touchend', function ( event ) {
				var dx = event.changedTouches[ 0 ].clientX - startX;
				var dy = event.changedTouches[ 0 ].clientY - startY;
				if ( Math.abs( dx ) > 45 && Math.abs( dx ) > Math.abs( dy ) ) {
					step( dx < 0 ? 1 : -1 );
				}
			}, { passive: true } );
		}

		/**
		 * Show the current photograph.
		 *
		 * @return {void}
		 */
		function paint() {
			if ( 'frame' === mode ) {
				return;
			}
			var item = items[ index ];
			if ( ! item ) {
				return;
			}
			img.src = item.full;
			img.alt = item.caption || '';
			caption.textContent = item.caption || '';
			caption.hidden = ! item.caption;
			counter.textContent = ( index + 1 ) + ' / ' + items.length;

			dialog.querySelector( '.estat-lb-arrow.is-prev' ).hidden = items.length < 2;
			dialog.querySelector( '.estat-lb-arrow.is-next' ).hidden = items.length < 2;
			counter.hidden = items.length < 2;

			// Warm the neighbours so prev/next is instant.
			[ index + 1, index - 1 ].forEach( function ( i ) {
				if ( items[ i ] ) {
					var pre = new Image();
					pre.src = items[ i ].full;
				}
			} );
		}

		/**
		 * Move through the photographs.
		 *
		 * @param {number} delta -1 or 1.
		 * @return {void}
		 */
		function step( delta ) {
			if ( ! items.length || 'frame' === mode ) {
				return;
			}
			index = ( index + delta + items.length ) % items.length;
			paint();
		}

		/**
		 * Open the lightbox at a photograph.
		 *
		 * @param {number} at     Index.
		 * @param {Element} trigger The element that was pressed.
		 * @return {void}
		 */
		function open( at, trigger ) {
			index = at;
			opener = trigger || null;
			mode = 'photo';

			if ( ! dialog ) {
				build();
			}

			dropFrame();
			dialog.querySelector( '.estat-lb-stage img' ).hidden = false;
			dialog.hidden = false;
			document.documentElement.classList.add( 'estat-lb-open' );
			paint();

			var closeBtn = dialog.querySelector( '[data-estat-lb-close]' );
			if ( closeBtn ) {
				closeBtn.focus();
			}
			document.addEventListener( 'keydown', onKey );
		}

		/**
		 * Close the lightbox and give focus back.
		 *
		 * @return {void}
		 */
		function close() {
			if ( ! dialog || dialog.hidden ) {
				return;
			}
			dialog.hidden = true;
			document.documentElement.classList.remove( 'estat-lb-open' );
			document.removeEventListener( 'keydown', onKey );
			if ( img ) {
				img.removeAttribute( 'src' );
			}
			dropFrame();
			if ( opener && opener.focus ) {
				opener.focus();
			}
		}

		/**
		 * Remove the film frame and give the stage back to the picture.
		 *
		 * @return {void}
		 */
		function dropFrame() {
			if ( frame && frame.parentNode ) {
				frame.parentNode.removeChild( frame );
			}
			frame = null;
		}

		/**
		 * Open a film or a walkthrough in the same dialog.
		 *
		 * The visitor stays on the page rather than being sent to another
		 * site, and the control they pressed gets focus back on close.
		 *
		 * @param {string}  url     Address of the film or the tour.
		 * @param {string}  label   What is being opened, for the dialog name.
		 * @param {Element} trigger The control that was pressed.
		 * @return {void}
		 */
		function openFrame( url, label, trigger ) {
			if ( ! url ) {
				return;
			}
			opener = trigger || null;
			items = [];
			mode = 'frame';

			if ( ! dialog ) {
				build();
			}

			dropFrame();
			img.hidden = true;
			caption.hidden = true;
			counter.hidden = true;
			dialog.querySelector( '.estat-lb-arrow.is-prev' ).hidden = true;
			dialog.querySelector( '.estat-lb-arrow.is-next' ).hidden = true;

			frame = document.createElement( 'iframe' );
			frame.className = 'estat-lb-frame';
			frame.src = url;
			frame.title = label || t( 'photos', 'Photographs' );
			frame.setAttribute( 'allowfullscreen', 'allowfullscreen' );
			frame.setAttribute( 'allow', 'autoplay; fullscreen; xr-spatial-tracking; encrypted-media; picture-in-picture' );
			frame.setAttribute( 'referrerpolicy', 'no-referrer-when-downgrade' );
			stage.appendChild( frame );

			dialog.querySelector( '.estat-lb-panel' ).setAttribute( 'aria-label', frame.title );
			dialog.hidden = false;
			document.documentElement.classList.add( 'estat-lb-open' );

			var closeBtn = dialog.querySelector( '[data-estat-lb-close]' );
			if ( closeBtn ) {
				closeBtn.focus();
			}
			document.addEventListener( 'keydown', onKey );
		}

		/**
		 * Keyboard: escape closes, arrows move, tab stays inside.
		 *
		 * @param {KeyboardEvent} event Event.
		 * @return {void}
		 */
		function onKey( event ) {
			if ( 'Escape' === event.key || 'Esc' === event.key ) {
				close();
				return;
			}
			if ( 'ArrowLeft' === event.key ) {
				step( -1 );
				return;
			}
			if ( 'ArrowRight' === event.key ) {
				step( 1 );
				return;
			}
			if ( 'Tab' === event.key ) {
				var focusable = dialog.querySelectorAll( 'button:not([hidden])' );
				if ( ! focusable.length ) {
					return;
				}
				var first = focusable[ 0 ];
				var last = focusable[ focusable.length - 1 ];
				if ( event.shiftKey && document.activeElement === first ) {
					event.preventDefault();
					last.focus();
				} else if ( ! event.shiftKey && document.activeElement === last ) {
					event.preventDefault();
					first.focus();
				}
			}
		}

		return {
			/**
			 * Open a film or a walkthrough in the dialog.
			 *
			 * @param {string}  url     Address.
			 * @param {string}  label   What is being opened.
			 * @param {Element} trigger Control pressed.
			 * @return {void}
			 */
			openFrame: openFrame,

			/**
			 * Wire up every lightbox group on the page.
			 *
			 * @return {void}
			 */
			init: function () {
				var groups = document.querySelectorAll( '[data-estat-lightbox]' );
				if ( ! groups.length ) {
					return;
				}

				Array.prototype.forEach.call( groups, function ( group ) {
					var triggers = group.querySelectorAll( '[data-estat-lightbox-item]' );
					if ( ! triggers.length ) {
						return;
					}

					Array.prototype.forEach.call( triggers, function ( trigger, i ) {
				if ( done( trigger ) ) {
					return;
				}

						// A real URL, so the item still works with no script.
						if ( ! trigger.getAttribute( 'href' ) ) {
							trigger.setAttribute( 'href', trigger.getAttribute( 'data-full' ) || '#' );
						}
						if ( 'A' !== trigger.tagName && ! trigger.getAttribute( 'type' ) ) {
							trigger.setAttribute( 'type', 'button' );
						}

						trigger.addEventListener( 'click', function ( event ) {
							event.preventDefault();

							items = Array.prototype.map.call( triggers, function ( el ) {
								return {
									full: el.getAttribute( 'data-full' ) || el.getAttribute( 'href' ) || '',
									caption: el.getAttribute( 'data-caption' ) || ''
								};
							} );
							root = group;
							open( i, trigger );
						} );
					} );
				} );

				// Keep the reference honest for the closure above.
				root = root || null;
			}
		};
	}() );

	/* ======================================================================
	 * Read more / read less
	 * ----------------------------------------------------------------------
	 * The whole description stays in the document and in the markup — this
	 * only shortens what is *visible*, so a search engine and a screen reader
	 * both still get every word.
	 * ==================================================================== */
	var ReadMore = {
		/**
		 * Wire up every collapsible block.
		 *
		 * @return {void}
		 */
		init: function () {
			var blocks = document.querySelectorAll( '[data-estat-readmore]' );
			if ( ! blocks.length ) {
				return;
			}

			Array.prototype.forEach.call( blocks, function ( block ) {
				if ( done( block ) ) {
					return;
				}

				var toggle = block.querySelector( '[data-estat-readmore-toggle]' );
				var panel = block.querySelector( '[data-estat-readmore-panel]' );
				if ( ! toggle || ! panel ) {
					return;
				}

				/*
				 * The height a short piece of writing is allowed before it
				 * is folded comes from the component, which knows how much
				 * room the page has. It is written as a custom property so
				 * the stylesheet owns the number and this file owns only
				 * the decision.
				 */
				var limit = parseInt( block.getAttribute( 'data-estat-readmore-height' ) || '0', 10 );
				if ( limit > 0 ) {
					block.style.setProperty( '--estat-readmore-h', limit + 'px' );
				}

				/*
				 * Clamp first, then measure. Measured the other way round
				 * the panel is still at its full height, the two numbers
				 * match, and the control is hidden from every description —
				 * including the long ones it exists for.
				 */
				panel.classList.add( 'is-clamped' );

				// Short content needs no control at all.
				if ( panel.scrollHeight <= panel.clientHeight + 24 && ! block.hasAttribute( 'data-estat-readmore-force' ) ) {
					panel.classList.remove( 'is-clamped' );
					toggle.hidden = true;
					return;
				}

				toggle.hidden = false;
				toggle.setAttribute( 'aria-expanded', 'false' );
				toggle.setAttribute( 'aria-controls', panel.id || '' );

				toggle.addEventListener( 'click', function () {
					var open = panel.classList.toggle( 'is-clamped' );
					toggle.setAttribute( 'aria-expanded', open ? 'false' : 'true' );
					toggle.querySelector( '.estat-readmore-label' ).textContent = open
						? toggle.getAttribute( 'data-label-more' ) || t( 'readMore', 'Read more' )
						: toggle.getAttribute( 'data-label-less' ) || t( 'readLess', 'Show less' );
					if ( ! open ) {
						// Keep the heading in view when the panel collapses.
						var top = block.getBoundingClientRect().top;
						if ( top < 0 ) {
							window.scrollBy( { top: top - 16, behavior: calm() ? 'auto' : 'smooth' } );
						}
					}
				} );
			} );
		}
	};

	/* ======================================================================
	 * Filters
	 * ----------------------------------------------------------------------
	 * Counts are written by the server, so this never has to recount.
	 * ==================================================================== */
	var Filter = {
		/**
		 * Wire up every filter group.
		 *
		 * @return {void}
		 */
		init: function () {
			var bars = document.querySelectorAll( '[data-estat-filter-bar]' );
			if ( ! bars.length ) {
				return;
			}

			Array.prototype.forEach.call( bars, function ( bar ) {
				if ( done( bar ) ) {
					return;
				}

				var scope = document.getElementById( bar.getAttribute( 'data-estat-filter-scope' ) || '' );
				if ( ! scope ) {
					return;
				}
				var buttons = bar.querySelectorAll( '[data-estat-filter]' );
				var cards = scope.querySelectorAll( '[data-estat-filter-item]' );

				/**
				 * Show only the cards in one group.
				 *
				 * @param {string} value Group value.
				 * @return {void}
				 */
				function apply( value ) {
					Array.prototype.forEach.call( buttons, function ( button ) {
						var on = button.getAttribute( 'data-estat-filter' ) === value;
						button.classList.toggle( 'is-on', on );
						button.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
					} );

					Array.prototype.forEach.call( cards, function ( card ) {
						var groups = ( card.getAttribute( 'data-estat-filter-item' ) || '' ).split( /[\s,]+/ );
						card.hidden = 'all' !== value && -1 === groups.indexOf( value );
					} );

					scope.setAttribute( 'data-estat-filter-active', value );
				}

				Array.prototype.forEach.call( buttons, function ( button ) {
					button.addEventListener( 'click', function () {
						apply( button.getAttribute( 'data-estat-filter' ) );
					} );
				} );

				// Keyboard: left and right move along a filter row.
				bar.addEventListener( 'keydown', function ( event ) {
					if ( 'ArrowRight' !== event.key && 'ArrowLeft' !== event.key ) {
						return;
					}
					var list = Array.prototype.slice.call( buttons );
					var at = list.indexOf( document.activeElement );
					if ( -1 === at ) {
						return;
					}
					event.preventDefault();
					var next = list[ ( at + ( 'ArrowRight' === event.key ? 1 : -1 ) + list.length ) % list.length ];
					next.focus();
				} );

				apply( 'all' );
			} );
		}
	};

	/* ======================================================================
	 * Sticky section navigation
	 * ----------------------------------------------------------------------
	 * The links are real anchors, so with no script they still jump. With
	 * script they scroll smoothly and the current section is marked as the
	 * page moves.
	 * ==================================================================== */
	var SectionNav = {
		/**
		 * Wire up section navigation and the reading progress line.
		 *
		 * @return {void}
		 */
		init: function () {
			var navs = document.querySelectorAll( '[data-estat-section-nav]' );
			if ( ! navs.length ) {
				return;
			}

			Array.prototype.forEach.call( navs, function ( nav ) {
				if ( done( nav ) ) {
					return;
				}

				var links = Array.prototype.slice.call( nav.querySelectorAll( 'a[href^="#"]' ) );
				if ( ! links.length ) {
					return;
				}

				/*
				 * The row that actually scrolls sideways is the track, not
				 * the nav around it — on a phone the chip has to be brought
				 * into view *inside* the track.
				 */
				var scroller = nav.querySelector( '.estat-sectionnav-track' ) || nav;

				var targets = links.map( function ( link ) {
					return document.getElementById( link.getAttribute( 'href' ).slice( 1 ) );
				} );

				/**
				 * Mark one link as current.
				 *
				 * @param {number} at Index.
				 * @return {void}
				 */
				function mark( at ) {
					links.forEach( function ( link, i ) {
						var on = i === at;
						link.classList.toggle( 'is-current', on );
						if ( on ) {
							link.setAttribute( 'aria-current', 'true' );
							// Keep the active chip visible on a phone.
							var box = scroller.getBoundingClientRect();
							var chip = link.getBoundingClientRect();
							if ( chip.left < box.left || chip.right > box.right ) {
								scroller.scrollLeft += chip.left - box.left - ( box.width - chip.width ) / 2;
							}
						} else {
							link.removeAttribute( 'aria-current' );
						}
					} );
				}

				links.forEach( function ( link, i ) {
					link.addEventListener( 'click', function ( event ) {
						if ( ! targets[ i ] ) {
							return;
						}
						event.preventDefault();
						mark( i );
						targets[ i ].scrollIntoView( { behavior: calm() ? 'auto' : 'smooth', block: 'start' } );
						// Move focus without a second jump.
						if ( targets[ i ].hasAttribute( 'tabindex' ) ) {
							targets[ i ].focus( { preventScroll: true } );
						}
						if ( window.history && window.history.replaceState ) {
							window.history.replaceState( null, '', link.getAttribute( 'href' ) );
						}
					} );
				} );

				if ( ! ( 'IntersectionObserver' in window ) ) {
					return;
				}

				var visible = new window.IntersectionObserver(
					function ( entries ) {
						entries.forEach( function ( entry ) {
							if ( ! entry.isIntersecting ) {
								return;
							}
							var at = targets.indexOf( entry.target );
							if ( -1 !== at ) {
								mark( at );
							}
						} );
					},
					{ rootMargin: '-45% 0px -50% 0px', threshold: 0 }
				);

				targets.forEach( function ( target ) {
					if ( target ) {
						visible.observe( target );
					}
				} );
			} );

			// The reading progress line, if a page carries one.
			var bar = document.querySelector( '[data-estat-progress]' );
			var track = bar ? document.getElementById( bar.getAttribute( 'data-estat-progress' ) || '' ) : null;
			if ( ! bar || ! track ) {
				return;
			}

			var queued = false;

			/**
			 * Draw the progress line.
			 *
			 * @return {void}
			 */
			function paint() {
				queued = false;
				var box = track.getBoundingClientRect();
				var total = box.height - window.innerHeight;
				var done = total > 0 ? ( -box.top ) / total : 0;
				bar.style.setProperty( '--estat-progress', Math.max( 0, Math.min( 1, done ) ).toFixed( 4 ) );
			}

			window.addEventListener(
				'scroll',
				function () {
					if ( queued ) {
						return;
					}
					queued = true;
					window.requestAnimationFrame( paint );
				},
				{ passive: true }
			);
			window.addEventListener( 'resize', paint, { passive: true } );
			paint();
		}
	};

	/* ======================================================================
	 * Media — a project film or a 360 walkthrough, opened here
	 * ----------------------------------------------------------------------
	 * Markup:
	 *   <button data-estat-media="video" data-media-url="…">
	 *
	 * The cards carry a real URL as well, so without this file the visitor
	 * is still one press away from the film — they just leave the page.
	 * ==================================================================== */
	var Media = {
		/**
		 * Wire up every media card.
		 *
		 * @return {void}
		 */
		init: function () {
			var buttons = document.querySelectorAll( '[data-estat-media]' );
			if ( ! buttons.length ) {
				return;
			}

			Array.prototype.forEach.call( buttons, function ( button ) {
				if ( done( button ) ) {
					return;
				}

				button.addEventListener( 'click', function ( event ) {
					event.preventDefault();
					Lightbox.openFrame(
						button.getAttribute( 'data-media-url' ) || '',
						( button.querySelector( '.estat-mediacard-label' ) || {} ).textContent || '',
						button
					);
				} );
			} );
		}
	};

	/* ======================================================================
	 * Copy to clipboard
	 * ==================================================================== */
	var Copy = {
		/**
		 * Put a value on the clipboard and say so.
		 *
		 * @param {string}  value  The text to copy.
		 * @param {Element} button The control pressed, if any.
		 * @return {void}
		 */
		run: function ( value, button ) {
			var done = function () {
				if ( ! button ) {
					return;
				}
				var label = button.querySelector( '.estat-copy-label' );
				var original = button.getAttribute( 'data-label' ) || ( label ? label.textContent : '' );
				if ( label ) {
					label.textContent = t( 'copied', 'Link copied' );
				}
				button.classList.add( 'is-done' );
				window.setTimeout( function () {
					if ( label ) {
						label.textContent = original;
					}
					button.classList.remove( 'is-done' );
				}, 2400 );
			};

			if ( navigator.clipboard && navigator.clipboard.writeText ) {
				navigator.clipboard.writeText( value ).then( done, function () {
					Copy.fallback( value, done );
				} );
				return;
			}
			Copy.fallback( value, done );
		},

		/**
		 * Older browsers: a temporary textarea and the copy command.
		 *
		 * @param {string}   value The text to copy.
		 * @param {Function} done  Called on success.
		 * @return {void}
		 */
		fallback: function ( value, done ) {
			var field = document.createElement( 'textarea' );
			field.value = value;
			field.setAttribute( 'readonly', 'readonly' );
			field.style.position = 'fixed';
			field.style.top = '-1000px';
			document.body.appendChild( field );
			field.select();
			try {
				document.execCommand( 'copy' );
				done();
			} catch ( e ) {
				// Nothing to say — the link is still on screen to copy by hand.
			}
			document.body.removeChild( field );
		},

		/**
		 * Wire up every copy control.
		 *
		 * @return {void}
		 */
		init: function () {
			var buttons = document.querySelectorAll( '[data-estat-copy]' );
			if ( ! buttons.length ) {
				return;
			}
			Array.prototype.forEach.call( buttons, function ( button ) {
				if ( done( button ) ) {
					return;
				}

				button.addEventListener( 'click', function () {
					Copy.run( button.getAttribute( 'data-estat-copy' ) || window.location.href, button );
				} );
			} );
		}
	};

	/* ======================================================================
	 * Share — native where it exists, copy where it does not
	 * ==================================================================== */
	var Share = {
		/**
		 * Wire up every share control.
		 *
		 * @return {void}
		 */
		init: function () {
			var buttons = document.querySelectorAll( '[data-estat-share]' );
			if ( ! buttons.length ) {
				return;
			}

			var supported = !! ( navigator.share );

			Array.prototype.forEach.call( buttons, function ( button ) {
				if ( done( button ) ) {
					return;
				}

				if ( ! supported ) {
					// No native sharing: the button simply copies the link.
					button.setAttribute( 'data-estat-copy', button.getAttribute( 'data-estat-share' ) || window.location.href );
					button.setAttribute( 'data-label', button.getAttribute( 'data-label' ) || t( 'copy', 'Copy link' ) );
					return;
				}

				button.addEventListener( 'click', function () {
					var payload = {
						title: button.getAttribute( 'data-share-title' ) || document.title,
						url: button.getAttribute( 'data-estat-share' ) || window.location.href
					};
					if ( button.getAttribute( 'data-share-text' ) ) {
						payload.text = button.getAttribute( 'data-share-text' );
					}
					navigator.share( payload ).catch( function () {
						// Cancelled, or the platform refused. Nothing to report.
					} );
				} );
			} );

			if ( ! supported ) {
				Copy.init();
			}
		}
	};

	/* ======================================================================
	 * Enquiry — turn the form's own message into a proper inline panel
	 * ----------------------------------------------------------------------
	 * The form already posts to the Estat.OS REST endpoint and already writes
	 * its own success and error text. Nothing here sends anything: it watches
	 * the message box the form produces and presents it properly, so there is
	 * still exactly one lead system.
	 * ==================================================================== */
	var Enquiry = {
		/**
		 * Wire up enquiry wrappers.
		 *
		 * @return {void}
		 */
		init: function () {
			var wrappers = document.querySelectorAll( '[data-estat-enquiry]' );
			if ( ! wrappers.length ) {
				return;
			}

			Array.prototype.forEach.call( wrappers, function ( wrapper ) {
				if ( done( wrapper ) ) {
					return;
				}

				var form = wrapper.querySelector( '.estat-form' );
				var box = wrapper.querySelector( '.estat-form-messages' );
				if ( ! form || ! box ) {
					return;
				}

				/**
				 * React to the form's own message.
				 *
				 * @return {void}
				 */
				function react() {
					if ( box.classList.contains( 'is-success' ) && box.textContent.trim() ) {
						wrapper.classList.add( 'is-sent' );
						wrapper.setAttribute( 'data-estat-enquiry-state', 'sent' );
						var again = wrapper.querySelector( '[data-estat-enquiry-again]' );
						if ( again && again.focus ) {
							again.focus();
						}
						return;
					}
					if ( box.classList.contains( 'is-error' ) && box.textContent.trim() ) {
						wrapper.classList.remove( 'is-sent' );
						wrapper.setAttribute( 'data-estat-enquiry-state', 'error' );
						wrapper.classList.add( 'is-shaking' );
						window.setTimeout( function () {
							wrapper.classList.remove( 'is-shaking' );
						}, 320 );
					}
				}

				if ( 'MutationObserver' in window ) {
					new window.MutationObserver( react ).observe( box, { attributes: true, childList: true, characterData: true, subtree: true } );
				} else {
					form.addEventListener( 'submit', function () {
						window.setTimeout( react, 900 );
					} );
				}
				react();

				var again = wrapper.querySelector( '[data-estat-enquiry-again]' );
				if ( again ) {
					again.addEventListener( 'click', function () {
						wrapper.classList.remove( 'is-sent' );
						wrapper.removeAttribute( 'data-estat-enquiry-state' );
						box.className = 'estat-form-messages';
						box.textContent = '';
						var first = form.querySelector( 'input, textarea, select' );
						if ( first && first.focus ) {
							first.focus();
						}
					} );
				}
			} );
		}
	};

	/* ======================================================================
	 * Accordion — for the "what does this mean" extras
	 * ==================================================================== */
	var Accordion = {
		/**
		 * Wire up accordions.
		 *
		 * @return {void}
		 */
		init: function () {
			var toggles = document.querySelectorAll( '[data-estat-accordion]' );
			if ( ! toggles.length ) {
				return;
			}
			Array.prototype.forEach.call( toggles, function ( toggle ) {
				if ( done( toggle ) ) {
					return;
				}

				var panel = document.getElementById( toggle.getAttribute( 'aria-controls' ) || '' );
				if ( ! panel ) {
					return;
				}
				panel.hidden = true;
				toggle.setAttribute( 'aria-expanded', 'false' );
				toggle.addEventListener( 'click', function () {
					var open = 'true' === toggle.getAttribute( 'aria-expanded' );
					toggle.setAttribute( 'aria-expanded', open ? 'false' : 'true' );
					panel.hidden = open;
				} );
			} );
		}
	};

	/**
	 * Start everything the page actually contains.
	 *
	 * @return {void}
	 */
	function boot() {
		Lightbox.init();
		ReadMore.init();
		Media.init();
		Filter.init();
		SectionNav.init();
		Share.init();
		Copy.init();
		Enquiry.init();
		Accordion.init();
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', boot );
	} else {
		boot();
	}

	// Exposed so a shortcode or widget can re-run after it injects markup.
	window.estatUi = window.estatUi || {};
	window.estatUi.refresh = boot;
	window.estatUi.copy = Copy.run;
}() );
