# Current State

**Phase 1 (office) is FINISHED and shipped as `Estate_OS-4.0.0.zip` (1.9 MB, 175 files, root `estat-os/`).** Awaiting the user's review before Phase 2 (Pocket) begins. Do not start Pocket PHP until the user has looked at Phase 1.

**What was built (all `php -l` clean, JS `node --check` clean):**
- `includes/Admin/Os/` — `Ui.php` (sprite 56 icons, badges, meter), `Shell.php` (rail/topbar/drawer/cmdk/toasts/pop/bulkbar), `Series.php` (listings/leads/visits/spark/**page()/pager()**), `Ajax.php` (6 endpoints: drawer/act/save/preview/upload/search).
- 18 screens in `Os/Screens/`: Today, Properties, AddHome, Projects, Enquiries, Pipeline, Visits, Team, Requests, Gallery, Forms, Import, Duplicates, Reports, Settings, Bin, Setup, Alerts.
- `assets/css/admin-os.css` (77 KB) + `assets/js/admin-os.js` (vanilla, no libraries).
- `Admin.php` rewritten: new routing table, menus, `route()`, `assets()` (one CSS + one JS, localized `estatOs` with modules/quick/notes/palette/i18n).

**Old UI hard-deleted:** entire `includes/Admin/Screens/` (22 files), `assets/css/{admin,admin-new,dashboard,fields}.css`, `assets/js/{admin,bulk,form-builder}.js`. Zero remaining references (verified). `forms.css`, `ui.js`, `forms.js`, `share.js`, `whatsapp.js`, `public.js` untouched — they are public/shared.

**SetupScreen and SearchAlertsScreen were REBUILT as OS screens** (`Os/Screens/SetupScreen.php`, `Os/Screens/AlertsScreen.php`) because they depended on the deleted `Partials.php`. `Actions.php` and `Admin.php` repointed to `EstatOS\Admin\Os\Screens\SetupScreen`.

**Version bumped to 4.0.0** in `estat-os.php` + `readme.txt` (with a full changelog entry in plain language). DB version left at 13 (no schema change).


# Navigation correction (4.0.1) — the user reversed a design decision

**The user explicitly rejected the plugin's own left sidebar.** Their words: WordPress's default left sidebar must stay untouched, and the plugin's whole interface must render inside the content area to the right of it. It must feel integrated into wp-admin, not like a separate application replacing it.

**Standing rule now:** never hide, replace or restyle `#adminmenumain` / `#adminmenuback` / `#wpcontent`. Navigation is WordPress's. The plugin adds ONE top-level menu ("Office", slug `estat-today`) and every module is a `add_submenu_page` line under it. Settings is a submenu line, NOT a second top-level menu.

**What changed in 4.0.1:**
- `assets/css/admin-os.css`: removed the `display:none` rules for `#adminmenumain/#adminmenuback` and the `#wpcontent{margin-left:0}` reset. `.estat-os` is now `position:relative` in normal flow (was `position:fixed` full-bleed). `.app` is `display:block` (was a 2-column grid). Deleted every `.rail`, `.brand`, `.nav`, `.rail__collapse`, `.rail-collapsed` rule and the `--rail-*`/`--sidebar-w` variables. `.canvas` no longer scrolls internally — the page scrolls. `.top` is `position:sticky; top: var(--wp-admin--admin-bar--height, 32px)`. `.pop` moved from `absolute` to `fixed` (JS positions it from viewport coordinates). `.bulkbar` no longer offsets by the sidebar width. Added `#adminmenu .estat-menu-count` styling (counts live outside `.estat-os`, so these are the only unscoped rules — all carry our own class name).
- `includes/Admin/Os/Shell.php`: `rail()` method deleted; `grouped()` deleted; `open()` no longer calls the rail or the `.main` wrapper; top-bar title is now an `<h1 class="dsp">`.
- `includes/Admin/Admin.php`: second `add_menu_page` (Settings) removed; the SETTINGS_MENU submenu-rename block removed; the kept first submenu entry is titled "Today"; menu counts now come from one cached `Shell::counts()` read for 8 modules instead of two ad-hoc queries.
- `assets/js/admin-os.js`: rail-collapse handler and `localStorage('estatRail')` removed.

**Verified with puppeteer** (installed to /tmp/shot, needs `libnspr4 libnss3 libatk1.0-0 libatk-bridge2.0-0 libcups2 libdrm2 libxkbcommon0 libxcomposite1 libxdamage1 libxfixes3 libxrandr2 libgbm1 libpango-1.0-0 libcairo2 libasound2 libatspi2.0-0`): at 1440/1280/1024/820/600 px the menu occupies x 0–160, the app starts at exactly x=160 and fills the rest, no horizontal overflow, no overlap, top bar sticky at y=32 after scrolling, drawer fixed to the window.
- `/home/user/preview-admin.html` — self-contained static preview of the office inside a mock wp-admin, built by `/home/user/build-preview.py`. Rebuild with: extract sprite + `assets/css/admin-os.css` to `/tmp/sprite.html` + `/tmp/os.css`, then `python3 build-preview.py`.

**Harness gotchas:** the mock wp-admin CSS needs `html.wp-toolbar{padding-top:32px}` (class on `<html>`, not `<body>`) and `#wpbody-content{float:left;width:100%}` with NO `clear:both` — with `clear:both` the content drops below the floated menu.

**Environment:** `php` and `node` are NOT persisted — reinstall each session with `sudo apt-get install -y --no-install-recommends php-cli` (node survives).


# FINAL navigation structure (4.0.2) — the user's exact requirement

**Required layout, stated by the user with Elementor as the reference:**
`WordPress sidebar → plugin sidebar → plugin main dashboard/content`.
All three on one screen, WordPress's menu as-it-is and untouched, the plugin's own navigation INSIDE the content area (not instead of the WP menu).

This supersedes both earlier attempts: 4.0.0 hid the WP menu (wrong), 4.0.1 removed the plugin's rail (also wrong). **The correct answer is both sidebars.**

**How it is built:**
- `assets/css/admin-os.css`: `.estat-os` is `position:relative` in normal flow inside `#wpbody-content` (never `fixed`, never hides `#adminmenumain`/`#adminmenuback`, never zeroes `#wpcontent{margin-left}`). `.app` is `display:grid; grid-template-columns:var(--sidebar-w) minmax(0,1fr)`. `.rail` is `grid-column:1; position:sticky; top:var(--wp-admin--admin-bar--height,32px); height:calc(100vh - 32px); align-self:start`. `.main` is `grid-column:2; display:block` (NOT a grid — a sticky element inside a grid row the same height as itself cannot move). `.top` is `position:sticky; top:32px; min-height:var(--topbar-h)`.
- **The plugin rail is LIGHT** (`--panel` background, `--line` right border), on purpose: WordPress's menu is dark and two dark columns read as one confused column. Nav items are `.nav` / `.nav.is-active` (bronze-soft fill + 3px bronze bar at `left:-12px`) / `.nav__txt` / `.nav__badge`; header is `.brand` + `.brand__mark` + `.brand__name` + `.brand__dot` + `.brand__sub`; footer is `.rail__foot` + `.rail__collapse#railToggle`.
- Collapse: `.app.rail-collapsed{--sidebar-w:68px}` toggled by JS, remembered in `localStorage('estatRail')`, `aria-pressed` kept in sync. Auto-collapses under 1180px via media query; `display:none` under 782px where `.main` moves to `grid-column:1`.
- `includes/Admin/Os/Shell.php`: `open()` = `.estat-os > .app#app > rail() + .main > (.top + .canvas > .screen)`; `close()` unwraps and calls `overlays()`. `rail()` and `grouped()` both restored (they were deleted in 4.0.1).
- `includes/Admin/Admin.php`: ONE top-level menu ("Office", `estat-today`); all 15 modules are `add_submenu_page` lines under it; Settings is a line, not a second menu; counts on 8 menu lines from one cached `Shell::counts()` read.
- Drawer/scrim/cmdk/toasts stay `position:fixed` to the window; `.pop` is `fixed` (JS places it from viewport coordinates); `.bulkbar` is `left:auto; right:var(--s5)`.

**Verified with puppeteer at 1600/1440/1280/1100/900/600 px:** WP menu x 0–160, rail 160–392 (68px when collapsed), main 392→window right edge, zero gaps, zero overlap, no horizontal overflow; rail and top bar stay at y=32 while scrolling; drawer fixed at y=0; collapse 232→68 and main 392→228, remembered after reload; no JS errors.

**Preview:** `/home/user/preview-admin.html`, built by `/home/user/build-preview.py` from `/tmp/sprite.html` + `/tmp/os.css` + `/tmp/os.js` + `/tmp/modules.json`. It inlines the real CSS and the real JS. Preview gotchas: `.app` needs `id="app"` or the collapse handler finds nothing; `window.estatOs` must be stubbed or the script returns early.

**Environment (repeats, because it keeps resetting):** `php` and `/tmp` are wiped between sessions. Reinstall with `sudo apt-get update -qq && sudo apt-get install -y --no-install-recommends php-cli`. Puppeteer: `mkdir -p /tmp/shot && cd /tmp/shot && npm init -y && npm i puppeteer` plus `libnspr4 libnss3 libatk1.0-0 libatk-bridge2.0-0 libcups2 libdrm2 libxkbcommon0 libxcomposite1 libxdamage1 libxfixes3 libxrandr2 libgbm1 libpango-1.0-0 libcairo2 libasound2 libatspi2.0-0`. `node` survives.

# Errors & Dead Ends (additions)

- `private const X = array( ... __() ... )` is a PHP fatal — translated arrays must be built in a method.
- `Listings::cover_url()` and `Meta::get()` **do not exist**. Use `get_the_post_thumbnail_url( $id, 'size' )` / `get_post_meta( $id, '_estat_locality', true )`.
- `Agents::all()` does not exist — use `Agents::to_array( $id )`.
- `Forms::save( array $input, int $form_id = 0 )` — definition FIRST, id second.
- `DesignTokens` has no per-token getter; tokens live in `Settings::get('design_tokens')` as a flat `--css-var => value` map.
- `Actions::save_settings()` reads `$_POST['settings'][key]` and `$_POST['tab']` — flat field names silently save nothing.
- **Prototype CSS state class is `is-on`, never `is-open`.** Drawer/scrim/cmdk/pop/bulkbar all use `is-on`.
- `.scrim` in the prototype CSS has no `pointer-events:none` — it must carry `hidden` (JS sets it) or it swallows every click.
- Toast markup is `.toast > .toast__ico + .toast__b(.toast__t + .toast__m) + .toast__undo + .toast__x(svg)`, not `.toast__a`.
- No MySQL/PDO extension in this sandbox and WordPress is not installed — **runtime testing is impossible**; verification was static (php -l, node --check, method-resolution audit, CSS-class coverage audit, icon-name audit).
- `php-xml` 404s. `node` IS available for `node --check`.


# Agent Memory — Estat.OS (devkaushall)

## User ka style (BOHOT ZAROORI)
- User developer NAHI hai. Technical bhasha nahi samajhte.
- Hamesha **simple Hinglish**, chhoti lines, seedhi baat.
- User **files nahi padhte**, data nahi padhte. Unhe analysis ka **matlab** chat mein batao.
- File deliverable mat banao unke liye (unhe koi fayda nahi). Sirf agent ke apne backup ke liye file allowed hai (ye wali).
- Final goal hamesha: **ek installable ZIP** jo seedha WordPress me chala jaye.

## Project
- Plugin: **Estat.OS** — Real Estate Operating System (WordPress plugin).
- Repo: https://github.com/devkaushall/dev_vault (isme sirf ZIPs hain; tests/source nahi).
- Current version: **3.6.2** (DB version 11).
- Live site par abhi **3.6.1** chal raha hai → 3.6.2 seedha upar install hoga (Plugins → Add New → Upload).
- Pocket = "Field Agent OS" (WP jargon screen par nahi dikhna chahiye).

## Hamesha ki shartein (rules)
- ZIP naam: `Estate_OS-{version}.zip`, andar root folder `estat-os/`.
- Template sirf **Elementor** se.
- Ek hi REEP logic — duplicate logic nahi. Har action auditable.
- Status words fix: Live / Paused / Rented / Needs changes…
- Bin words fix: Move to bin / Restore / Empty bin.
- Tag buttons **squared** (gol nahi).
- Workspace saaf: koi faltu .md/.html/CSV nahi. /home/user me **sirf ek ZIP** + plugin source.
- User ko Hinglish + simple.

## File structure (expected)
- `/home/user/plugin/estat-os/` — plugin source
- `/home/user/wp_test/` — test scripts (rebuild_testbed.sh, sync_to_wp.sh, pocket_22_look.js, run_all.sh, build_zip.sh, import_kind_check.php, societies_import_check.php)
- `/home/user/Estate_OS-{version}.zip` — final deliverable
- Login (test site): admin/adminpass @ http://localhost:8080 · agent1/agentpass123

## Known issues / pending
1. **Queue screen 0 rows** (open): `/agent/queue/` khulta hai par save ki hui row nahi dikhti.
   Do shak: (1) network aate hi wizard ka auto-flush (600ms) navigation se pehle entry bhej deta hai → test ka tareeka galat;
   (2) `queue_rows_script()` chala nahi / `window.estatQueueAll` missing.
   Code: `includes/Pocket/Screens.php` (queue_page, queue_rows_script), CSS `assets/css/pocket.css` (.estat-q-*).
2. **230 societies properties hatani hain** (user ka personal kaam, site par):
   Office → Import & export → Recent imports → us row ka **Undo** → phir Bin → Empty bin.
   (Undo na mile to: Properties → Search → top-left tick → "Bin me daaliye".)
   Bug ka lead: societies CSV ko importer ne "listings" samajh liya.
   Test scripts: `import_kind_check.php`, `societies_import_check.php`.
3. `run_all.sh` abhi 3.6.2 par nahi chala (shell 306s par kat ta hai → start_process se chalana hai).
   Flaky tests: `reports_insights_check.php`, `master_import_check.php`.

## Test status (3.6.2)
- Camera flow (A) — 12/12 PASS
- Papers heading (B) — 4/4 PASS
- Photo record ke saath save — PASS
- pocket21 / fields / bin / pocket_save — 127/127, 9/9, 91/91, 22/22
- Queue screen (C) — OPEN (0 rows)
- Poora run_all.sh — pending

## Session log
### 2026-10-04
- Workspace `/home/user` **khaali mila** (naya sandbox — /tmp wipe, wp_test + plugin source gayab).
- GitHub se `Estate_OS-3.6.2.zip` download: 1,931,975 B, md5 `82f973291fce2d761df823a2d7f09695` (source se match).
- Extract → 180 entries (146 files), root `estat-os/`.
- Verify: Version 3.6.2 ✔, Stable tag 3.6.2 ✔, changelog ✔, camera (11 estat-pk-shoot hits) ✔,
  Papers group ('group' => 'papers' ×2) ✔, queue_page + queue_rows_script + "Waiting to go up" + "See them" ✔,
  .pot 3014 msgid / Hinglish .po 3015, .mo me camera+queue+Papers strings ✔.
- Source restore kiya: `/home/user/plugin/estat-os/` (zip se).
- ZIP present: `/home/user/Estate_OS-3.6.2.zip`.
- NOTE: `wp_test/` aur /tmp ka PHP+Playwright setup **gayab** — dobanana padega browser test ke liye. Repo me tests nahi hain.
- User se poocha: next step kya (code-debug / testbed rebuild / ruk jao).

### 2026-10-04 (analysis #2) — poore plugin ka static audit (bina browser ke)
Tooling installed this session: `php` 8.4 (apt), python3 available. Node NOT checked (js syntax check skipped).

#### CONFIRMED BUG #1 — Queue screen hamesha 0 rows (root cause mil gaya)
- `includes/Pocket/Screens.php` `shell()`: `self::queue_script()` ko **andar** daala gaya hai
  `document.addEventListener("DOMContentLoaded", function(){ ... })` ke closure me.
- Isliye `estatQueueAll / estatQueueDel / estatQueueFlush / estatQueuePaint / estatQueuePut / estatQueueDb`
  sirf **us closure ke andar** exist karte hain → `window.estatQueueAll` KABHI define hi nahi hota.
- `queue_page()` → `queue_rows_script()` ka pehla line: `if(!window.estatQueueAll){return;}` → hamesha return → 0 rows.
- Doosri wajah (ORDERING): queue page ka `<script>` body me hai (pehle), shell ka script baad me.
  DOMContentLoaded listeners registration order me chalte hain → queue page ka handler PEHLE chalta hai,
  jab tak shell ka handler functions expose karta hi nahi. Dono milkar bug pakka.
- FIX (plan, abhi apply nahi kiya): shell() me `self::queue_script()` ko DOMContentLoaded wrapper se BAHAR nikaal kar
  apne `<script>` tag me `$out .= $body;` se PEHLE emit karo; aur end me
  `window.estatQueueAll=estatQueueAll;window.estatQueueDel=estatQueueDel;window.estatQueueFlush=estatQueueFlush;window.estatQueuePaint=estatQueuePaint;` add karo.
  (Already global: `window.estatQueueKeep` — isliye SAVE to queue me jaata hai, sirf DIKHAI nahi deta.)

#### CONFIRMED BUG #2 — test ka tareeka (user ka "shak 1" bhi sahi tha)
- Wizard ka submit handler: `if(navigator.onLine){ return; }` → **sirf network OFF hone par** entry queue me jaati hai.
- Online browser test me kuch queue hota hi nahi → 0 rows expected. Test me offline toggle zaroori hai.

#### BUG #3 — Public REST me agents ka personal data (privacy)
- `/wp-json/estat/v1/agents` aur `/estat/v2/agents` → `permission_callback => '__return_true'` (no login).
- `Agents::to_array()` return karta hai: name, role, **phone, whatsapp, email**, photo, url, listings (100 agents tak).
- Fix: public payload se phone/whatsapp/email hata do (ya capability check lagao).

#### BUG #4 — societies CSV ko listings samajh liya (230 galat properties)
- `includes/Csv/Spreadsheet.php::guess_kind()` — signals gin kar verdict; condition: best>=2 AND (best-next)>=2.
- `kind_signals()['projects']` me **'society','society_name','sector','tower','locality' NAHI hain**,
  jabki real society sheets me aksar bhk/floor/parking/area_type columns hote hain → 'listings' score zyada → galat verdict.
- Fix: projects signals me society/society_name/sector/tower/locality/phase add karo;
  aur office ne khud kind choose kiya ho to guess_kind override na kare.

#### BUG #5 — Hinglish me 3 entries sach me khaali (site par English)
- 'A voice note from the field' (ListingsScreen.php:573)
- '%d voice note' (Pocket/Screens.php:2220)
- 'One so far. Six or more is what makes a listing look real.' (Pocket/Screens.php:2957-2958)

#### BUG #6 — 1 string code me hai par .pot me nahi
- 'Search for a box, for example "date"' (includes/Admin/Screens/FormsScreen.php) → kabhi translate nahi hoga.

#### Chhoti (optional)
- `estatQueueFlush()` catch block: `item.tries=...; estatQueuePut(item);` await nahi hota (minor).
- `uninstall.php` me ABSPATH guard missing (WP uninstall.php me normal).

#### CLEAN (koi dikkat nahi)
- 146/146 PHP files syntax OK (php -l).
- 0 TODO/FIXME/HACK.
- 0 deprecated PHP functions (strftime/mysql_/create_function/each nahi).
- 0 duplicate function/class names.
- Version 3.6.2 consistent; kahin 3.6.1 leftover nahi (sirf Migrator comment me 3.5.0 = historical).
- ABSPATH guard sab me hai (sirf uninstall.php chhod kar).
- 37 unprepared $wpdb queries = sirf constant table names / literals, koi user input nahi → safe.
- $_GET/$_POST: sanitize + nonce + capability lagbhag sab jagah.
- Sirf 1 `wp_ajax_nopriv` (WhatsApp tap, public tracking — by design).
- 2902 unique translatable strings code me, 2958 POT me.

### 2026-10-04 (fix round) — 3.6.3 release
User ne kaha: **sirf queue + societies import fix karo**, baaki (privacy/Hinglish) baad mein.

#### APPLIED FIXES (both verified)
1. `includes/Pocket/Screens.php::shell()` — `self::queue_script()` ko DOMContentLoaded wrapper se BAHAR nikaal kar
   apne `<script>` tag me `$out .= $body;` se PEHLE emit kiya.
   + `queue_script()` end me `window.estatQueueAll/Del/Put/Flush/Paint` assignments add kiye.
   + `queue_rows_script()` guard ab `function start(){...}` named handler + 40×50ms retry (`window.estatQueueWait`).
   + flush catch: `return estatQueuePut(item).then(function(){return false;});` (tries counter ab save hota hai).
2. `includes/Csv/Spreadsheet.php::kind_signals()['projects']` me society words add:
   society, society_name, society_names, societies, project_society, society_address, group_housing,
   sector, sector_no, sector_number, tower, towers, total_towers, no_of_towers, phase, launch, launch_date,
   handover, handover_date.
   + `guess_kind()` bar badhaya: `$best < 3 || ( $best - $next ) < 3` (pehle 2/2 tha) → kam galat overrides.

#### VERIFICATION (browser ke bina, /tmp/queue_sim.js = node + vm sandbox)
- PURANA code  → rows = 0 (bug reproduce hua)
- NAYA code    → rows = 1 → "3 BHK in Sector 49 | 5 minutes ago · tried 2 times" ✔
- guess_kind: societies→projects (3 cases), listings→listings (3 cases), agents→agents, leads→leads, ambiguous→''
- php -l OK; node --check OK on generated scripts; **ZIP ke andar se extract kar ke dobara test kiya** ✔

#### RELEASED
- Version 3.6.3: estat-os.php header + ESTAT_VERSION; readme Stable tag 3.6.3; changelog "= 3.6.3 =" (3 bullets).
- `/home/user/Estate_OS-3.6.3.zip` — 1,933,097 B, 180 files, root `estat-os/`.
- Purana `Estate_OS-3.6.2.zip` DELETE kar diya (rule: /home/user me sirf ek zip).
- DB version 11 unchanged (koi schema change nahi).

#### TEST NOTE (user ko bataya)
Queue sirf tab bharti hai jab `navigator.onLine === false` (wizard submit handler). Isliye asli test me
browser ko OFFLINE karna padega — warna 0 rows normal hai. (User ka "shak 1" bhi sahi tha.)

#### STILL OPEN (user ne aage ke liye chhod diya)
- BUG #3 privacy: public REST /agents → phone/whatsapp/email (v1+v2).
- BUG #5 3 Hinglish entries khaali; BUG #6 1 string .pot me nahi.
- 230 galat societies properties (site par manual Undo + Bin → Empty bin); ab aage se import sahi hoga.

### 2026-10-04 (feature) — 3.6.4: DUPLICATE / NEAR-DUPLICATE DETECTION
User ki maang: property/unit/society/project ka duplicate detection — sirf naam se nahi, balki
name + description + location + specifications + overall meaning se; flag kare + admin ko report/warning de;
purpose = publish hone se PEHLE pakadna.

User ke faisle: (1) **Chetavni + "Haan ye alag hai" (warn_confirm — block nahi)**,
(2) **Teeno jagah** = entry screen + alag Duplicates report screen + CSV import, (3) **Balanced strictness**.

#### NAYI FILE
- `includes/Data/Duplicate.php` (~1000 lines) — EK HI jagah faisla (REEP).
  Pure (testable) functions: normalise, tokens, sector_of, name_score, meaning_score, metres, score, fingerprint.
  Weights: name 32 · area 24 · specs 26 · money 10 · meaning 8 = 100.
  Unknown fields are SKIPPED (penalty nahi). "known" guard: known<=2 → cap 65; known==3 → cap 84; known>=4 → no cap.
  Refusals (caps): different property type → 55; different locality → 58; name<0.35 && meaning<0.4 → 48;
  (bedrooms differ AND size ratio<0.85) → 60; size ratio<0.6 → 60.
  Bands: same >=85, near >=65, maybe >=45. `stops()` true only for same/near.
  Meta: _estat_duplicate_score/of/band/reasons/decided/seen. `keep_both()` → AuditLog 'duplicate.kept_both'.
  Performance: per-page fingerprint cache `self::$known`, candidate cache `self::$looked_up`,
  `forget_cache()` (import ke har write ke baad call, taaki ek hi file ke andar ke duplicate bhi pakde jayein),
  `candidates(..., $narrow=true)` import ke liye; <=500 records → sab compare.
  Extras: synonyms (flat→apartment, sec→sector, gurugram→gurgaon…), NOISE stopwords,
  trigram Dice (typos), digit-sequence bonus, haversine map distance, project specs (builder/units/possession/price_min).

#### INTEGRATION (3 jagah, ek hi engine)
1. `Actions::save_listing()` / `save_project()` → `Duplicate::remember()` → verdict meta me save.
   `Partials::duplicate_warning( $id, $kind )` → box on ListingsScreen editor + ProjectsScreen.
   Buttons: "Open the other one" / "These are different — keep both" / "Move this to the bin".
2. Naya screen `includes/Admin/Screens/DuplicatesScreen.php` + Admin::pages() entry `estat-duplicates` (menu: true).
   "Look through everything" → action `duplicate_scan` → `Duplicate::scan()` (blocking by type|bedrooms|locality|price-band,
   18s budget, 500 max) → transient `estat_duplicate_scan_{user_id}` (1 hour). Pairs grouped same/near/maybe.
   Actions: keep both / move second to bin. Naye notices: duplicate_kept, duplicate_binned, duplicate_kept_many, duplicate_scanned.
3. Import: `estat_import_jobs.duplicate_mode` column (Schema; dbDelta add karega), `create_job(..., $duplicate_mode='skip')`,
   `process_batch` sets `self::$duplicate_mode`, `import_row()` → `duplicate_stop()` → WP_Error 'estat_duplicate_row'
   (counted as skipped + listed in job errors). SpreadsheetScreen confirm form me dropdown (skip/keep).
   Dry run me bhi count hota hai.

#### ACTIONS ADDED (Actions::handle)
`duplicate_keep`, `duplicate_bin`, `duplicate_rescan`, `duplicate_scan` (+ helper `duplicate_kind()`).
`estat-duplicates` ko `pages_we_may_return_to()` me add kiya.

#### LANGUAGES
56 naye shabd → .pot (refs ke saath) + Hinglish .po (anuvad) + .mo RECOMPILE (msgfmt nahi tha →
`/tmp/compile_mo.py` Python MO writer; gettext.GNUTranslations se verify kiya).
Bonus (pehle pending the): 3 khaali Hinglish entries bhar diye — 'A voice note from the field',
'%d voice note' (plural), 'One so far. Six or more…'. .mo ab 3071 entries.

#### VERSION
3.6.4 (ESTAT_DB_VERSION 11 → 12, import_jobs me column). ZIP: `/home/user/Estate_OS-3.6.4.zip`
(1,961,868 B, 182 files, root estat-os/). Purana 3.6.3 ZIP delete kiya → workspace me sirf ek ZIP.

#### TESTS (ZIP ke andar se chalaye — sab pass)
- 115/115 PHP files lint OK
- Duplicate engine: 5/5 true duplicates → 'same'; 4/5 non-duplicates ko chetavni NAHI;
  sparse records → jhoothi 'same' nahi; societies: same→92, typo→78(near), doosri society→63(maybe), alag→25
- .mo: 15/15 naye shabd Hinglish me; plurals OK
- import guess_kind (3.6.3 fix) intact; queue fix (3.6.3) intact

#### BAAKI (user ne abhi nahi kaha)
- Pocket (field agent app) me duplicate warning — engine ready hai, wiring baaki
- Privacy: public REST /agents → phone/whatsapp/email
- 230 galat societies properties (site par manual Undo + Bin)

---

## 3.6.5 — ek press mein safai (bulk cleanup) — 4 Oct 2026

**User ki report:** Office → Properties mein upar bayen kone ka "select all" tick karne par
sirf tick hote hain, "Move to bin" wali bar kabhi nahi aati. Delete sirf ek-ek record khol kar
milta hai. 230+ imported drafts hataane hain, "itna time thode na hai mere paas".
Unhone option 1 chuna: **ek press wala button**.

### Asli wajah (ROOT CAUSE — mil gayi, theek kar di)

1. **Select-all ka box form ke BAHAR hai.** `Partials::bulk_open()` sirf setting save karta hai;
   `<form>` poori tarah `bulk_close()` mein, list ke *baad* chhapti hai. Tick (`bulk_cell`) aur
   select-all (`bulk_header`) dono `form="estat-bulk-{page}"` se us form ki taraf ishara karte
   hain. Lekin admin.js mein `var all = form.querySelector('.estat-bulk-all')` — form ke andar
   to wo box hai hi nahi, isliye `all` hamesha **null**. Natija: select-all se kuch bhi nahi
   hota, na hi `indeterminate`. *Tick lene par* bar dikhni chahiye thi…
2. **Bar aur press dono admin.js par nirbhar the.** Bar `hidden` chhap-ti hai aur sirf JS se
   dikhti hai; `data-estat-ask` wala handler `preventDefault()` karke khud `form.submit()` karta
   hai. admin.js mein kahin bhi ek fault → tick to chalte hain, bar nahi aati, press bekaar.
   (Pocket queue ke baad yah doosri baar hua — isliye "does nothing" ko hamesha asli defect
   maano.)

### Jo badla (3.6.5)

* **`assets/js/bulk.js` — naya file.** Bar, tick-all, count, cancel, aur press se pehle ka
  sawal — sab ismein. `Admin.php:488` par `estat-bulk` handle se alag enqueue (footer, bina
  dependency). Ab admin.js mar bhi jaye to bar chalti hai.
  - `all` ko `ownedBy(form,'.estat-bulk-all')` se dhoondha (document-level, `[form="id"]` se).
  - Confirm: pehle `window.estatAsk` (admin.js wala sundar dialog), warna browser ka
    `confirm`/`prompt` — koi bhi press kabhi "chup-chap" na ho.
* **admin.js:** selection-bar wala poora block hata diya; `[data-estat-ask]` handler ab
  `.estat-bulk-form` / `.estat-sweep-form` ko chhod deta hai (do sawal na poochhe jaayen);
  `window.estatAsk = ask;` expose.
* **Naya action `sweep_records`** (Actions.php: CAPS ⇒ `estat_bin_listings`, case line 176,
  method 702, `sweep_ids()` 753). Server par set ka naam (draft / import-N) se ids dhoondhta
  hai, **koi 100 ki chhat nahi**, `Bin::batch('move')` + `Bin::remember_undo()` → bade Undo ke
  saath wapas. Junk scope → empty.
* **`Partials::sweep_card()`** — server-se bana card, **zero JS** (tick/bar ke bina bhi chalta
  hai). `ListingsNew.php` ise drafts aur "pichhle import" ke saath bulata hai
  (`last_import_set()` sirf *abhi khade* records ginati hai — "230 bole, 96 hataaye" nahi).
  Form par `data-estat-count` PHP hi likh deti hai.
* **CSS:** `.estat-sweep*` admin-new.css ke ant mein.
* **Migrator `step_12()`** — 3.6.4 ka khula khatra band: `Schema::install()` (dbDelta) chala kar
  `estat_import_jobs.duplicate_mode` pakka karta hai. (Schema::install() update par chalta hi
  tha, ab seedha step bhi hai.)
* Version 3.6.5 (estat-os.php + readme Stable tag + changelog); .po mein 10 naye Hinglish
  shabd, .mo dobara banaaya (**3081 entries**).

### Test (sab ZIP ke andar se chalaye)

* `sweep_ids`: 8/8 pass (230 drafts, 7 pending, import se 231 khade, khaali import, galat job,
  khaali/galat scope, ids integer).
* `bulk.js` (Node + chhota DOM shim): **10/10 pass** — bar shuru mein chhupi, 3 tick par dikhti
  hai "3 selected", **select-all se 20 ke 20 tick** (yahi toota tha), sab untick par chhup,
  press par submit + `estat_action=bin_records`, one-press card 230 ginti + submit.
* PHP lint 115/115, `node --check` dono js, .mo 3081 entries (naye shabd Hinglish mein).
* Regression: Pocket queue fix (1/2), kind detection 9/9, duplicate bands (85/65/45) jaise the.

**Shipped:** `/home/user/Estate_OS-3.6.5.zip` — 1,972,046 B, **183 files**, root `estat-os/`.
`Estate_OS-3.6.4.zip` hata diya.

### Agli baar yaad rakho

* Bulk UI ka structure: `<form>` list ke **baad**, tick/select-all **bahar**, `form="estat-bulk-{page}"`
  se jude. JS mein kisi bhi bulk element ko dhoondhna ho to document-level `[form=...]` se
  dhoondho — `form.querySelector` se nahi.
* Naye interactive cheezein alag JS file mein daalo, admin.js ke bojh se door.
* "Press se kuch nahi hota" = code defect, user ki galti nahi.
* Test scripts `/tmp/sweeptest/` mein hain (sweep_test.php, bulk_sim.js) — dobara chalane layak.

---

## 3.6.6 — Societies & Projects screen ka layout (4 Oct 2026)

User ne screenshot bheja: Office → Societies & Projects. Interface screen ke left/middle mein
compressed, right side khali; 18 fields ka form ek narrow column; table ke column be-tarteeb
(Name bahut wide, Stage lagbhag khali); pagination ek chhoti **vertical** block mein.

### Wajah (code mein mil gayi)

* **`.estat-screen .wrap { max-width: 1240px }`** (admin.css:28) — poori page 1240px par atak ti
  thi. Wide monitor par right side khaali dikhti thi. Sirf form studio (`estat-wrap-wide`) ko
  chhoot thi.
* **`.estat-form-admin { max-width: 780px }`** (admin.css:382) — form 780px par, isliye 18 sawal
  ek lambi line mein.
* **`.estat-pagination`** flex thi par andar wali `<ul>` block → `<li>` ek ke neeche ek,
  "vertical pagination".
* Table purani `widefat estat-table` thi jisme 4 hi column the (Location/Updated the hi nahi).

### Jo banaya (3.6.6)

* **`Admin.php`**: pages() mein naya `'wide' => true` flag (projects ke liye); route() ab
  `$wide_screen = ! empty($entry['wide'])` se wrapper ko `estat-wrap-wide` deta hai.
  (Doosre screens par koi asar nahi.)
* **`ProjectsScreen.php` poora dobara likha**:
  - `.estat-ui-team estat-projects-screen` wrapper, 3 metric tiles (kul / website par / drafts).
  - Form: **7 groups**, har group `.estat-form-section` (sirf-lekh + note) aur andar
    `.estat-form-grid` (2 column). Groups: The basics · Where, and who built it · How far along
    it is · Money and inventory · What is in it · Office details · The main photo.
    `Partials::field()` waise hi use kiya (`wrap_class => 'is-wide'` sirf About aur Highlights ko).
    Field **names bilkul waise hi** — save_project handler ko chhune ki zarurat nahi.
  - Form par `.estat-form-wide` (max-width hata diya).
  - Naya toolbar: search + stage filter + Search button + Clear link (`estat-projects-toolbar`).
    Purana `Partials::toolbar()` ab is screen par nahi (doosri screens par waise hi hai).
  - Table: `estat-ui-table estat-table-cards estat-projects-table`, **6 column** —
    Society / Project (icon + naam + Draft flag + unit types) · Location (area · address,
    repeat nahi hota) · Stage (badge ya "Not said yet") · Properties listed · Updated · Actions
    (Edit button + record_actions).
  - `Partials::pagination()` waisa hi, CSS se theek kiya.
* **CSS (admin-new.css ke ant mein, ~200 lines)**: `.estat-ui-metrics.is-3`,
  `.estat-form-admin.estat-form-wide`, `.estat-form-section/-head/-title/-note`,
  `.estat-form-grid` (+ `is-wide`, 900px par 1 column), projects toolbar, table column widths
  (30/20/12/12/12/14%), `.estat-projects-flag/-count/-quiet`, aur **`.estat-pagination ul`
  ko flex row + `.page-numbers` ko box** (ye sabhi screens ke liye theek hua).
* 15 naye Hinglish shabd + 'Locality'→'Ilaaka', 'Society / Project'→'Society ya project'.
  **.mo = 3096 entries** (3.6.5 mein 3081 the).
* Version 3.6.6 + readme changelog.

### Test

* `/tmp/projtest/render.php` — poora screen stub WP ke saath render: 18,136 bytes,
  **div 82/82 balanced**, 7 sections, 18 fields (2 wide), 6 headers, 8 rows, pagination, toolbar,
  metrics, `estat-form-wide` — sab maujood. ZIP ke andar se bhi chalaya, same natija.
* PHP lint 115/115, dono js `node --check`, .mo 3096 entries, 3.6.5 ka sweep kaam surakshit.

**Shipped:** `/home/user/Estate_OS-3.6.6.zip` — 1,976,814 B, **183 files**, root `estat-os/`.
`Estate_OS-3.6.5.zip` hata diya.

### Agli baar

* Kisi bhi screen ko full width chahiye → `pages()` mein `'wide' => true`, CSS hack nahi.
* Naye form banao to `Partials::field()` + `.estat-form-grid` use karo; naye component admin.js
  mein mat daalo.
* Pagination ab sabhi screens par horizontal hai.
* Test stub: `/tmp/projtest/render.php` (ProjectsScreen ko bina WordPress ke chala deta hai).

---

## Gurugram projects research (171 rows) — chal raha hai

**Kaam:** user ki `GURUGRAM-PROJECTS-MASTER-REPORT.csv` (171 rows: Reference, Name, Area, Kind,
Stage, Price, Possession, Registration, What stands out, Add this to your sheet) ko research karke
**directly importable** CSV banana, sabko live karne ke liye.

**Files (sab /home/user mein):**
- `GURUGRAM-PROJECTS-IMPORT-READY.csv` — 24 plugin columns, 171 rows (deliverable)
- `GURUGRAM-PROJECTS-RESEARCH-NOTES.md` — sources + conflicts + kya confirm nahi hua
- `GURUGRAM-PROJECTS-MEDIA.csv` — Reference, Name, photos/brochure kahan milenge
- `/home/user/research/research.json` — researched data (keyed by Reference); `sources` aur `media`
  CSV mein nahi jaate (importer notes ko public highlights bana deta hai)
- `/home/user/research/build.py` — CSV banata hai; `probe2.php` — plugin ke apne importer se test

**Import ke niyam (code se verify kiye):**
- `columns('projects')` = 24 fields; `guess_mapping` sab pehchanta hai (unmapped: 0).
- `import_row()` case 'projects': `Projects::find_by_external_id()` se match → **update, duplicate
  nahi**; duplicate check sirf naye record par. **external_id = unka Reference (1..171) zaroor
  rakho.**
- `Projects::save()` → `post_status = publish` by default → import ke baad **live**.
- `price_min/price_max` plain numbers + `price_unit` (cr/lakh) → `translate_row` multiply karta hai.
  **Kabhi ₹ symbol free text mein mat likhna** — `rescue_project_row()` unit bhool kar "40 - 100 Cr"
  ko 40 rupees bana deta hai, aur DDJAY "₹23,000" ko 23,000 rupees ki property.
- `notes` cell ka bacha-khucha **public highlights** ban jaata hai → isliye sources/conflicts CSV
  se bahar.
- Multi-value delimiter = ` | ` (pipe; `cell_parts()` bullet/pipe/newline pe kaat-ta hai).
- Projects CSV mein **photo/image column hai hi nahi** → media alag file mein.

**Progress:** 171/171 DONE (refs 1-171). CSV verified: 171 rows, 24 cols, unmapped 0. Media CSV 163 rows.

**Docs task (done):** `/home/user/estat-os-docs/` — 21 chapters + `Estat-OS-Documentation.html` (single self-contained HTML book, ~304 KB, sidebar TOC, no external assets). Written from the real 3.6.6 source, not invented. Rebuild the HTML with `python3 /home/user/estat-os-docs/build.py`.
Batch ka pattern: 8 parallel web_search -> research.json mein likho -> python3 build.py -> probe2.php se verify.
Har entry mein: developer, address, project_type, unit_types, total_units, description, highlights,
sources, media. Jahan data confirm na ho wahan box KHALI chhodo + sources mein likh do.
Kabhi bhi RERA number CSV mein mat daalo (sirf notes/markdown mein) — confirm nahi hai.
Latitude/longitude aur available_units abhi 0/171 — aakhir mein sochenge.
**Price policy (user ne kaha):** approx chalega; jahan na mile wahan blank + "Price on request".


---

## TURN UPDATE — 18 Oct 2025 (naya interface project shuru)

**USER KA HUCM: abhi KUCH BANANA NAHI. User layout describe karenge, tab tak WAIT.**

**Lock decisions (binding):**
1. **Scope = Admin (wp-admin office screens) + Pocket (field-agent phone app).**
   Public website / Elementor templates / public CSS — **bilkul nahi chhoona**.
2. **Features = FEWER screens, simpler.** 20 admin screens hain; unhe mila kar kuch kam,
   simple screens banane hain. Naye features add nahi karne.
3. **Favorites (#9) + Compare (#10) = HOLD**, abhi kuch nahi karna (pehle "baad mein dekhta hoon"
   tha, ab redesign ke chalte freeze).
4. **Process:** user pehle layout describe karenge → main design/preview banaunga →
   approve ke baad code. **Seedha code mat likhna.**

**Chess website = CANCEL.** User ne galti se bheja tha; teen baar roka.
Chess par dobara kaam NAHI karna. chess-dev folder delete kar diya gaya tha.

**Workspace cleanup ho gaya:** 33 MB → 7.8 MB. Sirf bache hain:
`plugin/` (source), `Estate_OS-3.9.0.zip` (shipped), `estat-os-docs/`,
`faltu-sections-list.md`, `REDESIGN-BRIEF.md`, `agent_memory.md`.
Gurugram research CSVs + research.json + uploads + .wp-cli cache — sab delete (user ne kaha).

**Environment note:** sandbox reset hota hai — `php`, `node`, `gettext`, `msgfmt` har baar
dobara install karne padte hain (`sudo -n apt-get update -qq` phir `apt-get install -y -qq ...`).
WP test rig: /tmp bhi reset ho jata hai; WP 7.1.2 + SQLite + wp-cli dobara banana padta hai.
SQLite driver ke liye `DB_NAME` bhi define karna zaroori hai, aur `php-mysql` bhi chahiye
(SQLite driver mysqli functions check karta hai).


---

## TURN UPDATE — naya interface prototype BAN GAYA (18 Oct 2025)

**Deliverable: `/home/user/Estat-OS-Interface.html`** — 208 KB, single self-contained
file, zero network. Build source (editable parts) in `/home/user/ui-build/` and
concatenated: 01-head.html, 02-css-components.css, 03-body-a.html, 04-body-b.html,
05-js-core.js, 06-js-screens-a.js, 07-js-screens-b.js. Rebuild after any edit.

Scope honoured: Admin + Pocket surface, **public website untouched** (per user).
15 screens A–O exactly per the user's spec. Design tokens carried over from the
plugin's real tokens.css (linen #fbf9f4 / panel #fff / ink #1b1c19 / bronze #725b2f)
so it reads as one product.

**Two REAL bugs found and fixed by testing (not test-harness artefacts):**
1. `matchMedia` / `elementFromPoint` / `requestAnimationFrame` unguarded → one
   missing browser API killed the whole interface. Now all guarded (`raf` helper,
   `elementAt()`, `REDUCED` guard).
2. **Listener duplication:** every `VIEWS[x].mount()` re-ran on each visit and
   re-attached click handlers → one click fired twice, the import wizard advanced
   TWO steps per click. Fixed in `Router.mount` with `v.built` (mount once per
   screen); `runCounts()` still re-runs every visit so numbers re-animate.

**Test harness:** jsdom at /tmp/domtest (test.js = full walkthrough, stress.js =
276 clicks + drag sim, wiz.js = wizard focus). Needs `beforeParse` stubs for
matchMedia/performance. jsdom has NO elementFromPoint and no layout, so drag
drop targets are null there by design — that is why the guard matters.

**User's process rule, still binding:** describe → I design → they approve →
then code. Do NOT start porting into the plugin until they say so.


## 2026-10-06 — icon visibility fix (turn after first delivery)

**User report:** "sach mein wala bahut badhiya hai lekin abhi bhi isme kuch problems hain" — sidebar icons invisible, wanted better/larger icons.

**Root cause (code defect, not user error):** sprite `<symbol>` shapes had no `fill`/`stroke`, so the UA default *black fill* applied and they vanished on the dark rail (`--rail #1b1c19`).

**Fixes applied (all in the ui-build fragments):**
- `01-head.html`: global icon base `svg{fill:none;stroke:currentColor;stroke-width:1.75;stroke-linecap:round;stroke-linejoin:round}` + opt-outs `svg text{fill:currentColor;stroke:none}`, `.chart .bar,.chart .area{stroke:none}`.
- Rail icons 18→20px, `stroke-width:1.8`, colour `--rail-ink-2`; active = `#e5c98a` + `stroke-width:2` + `scale(1.06)`. Brand mark 21px/1.9, collapse 20px/1.8.
- `--rail-ink-2` `#a7a69c` → `#bcbbaf`; `.rail__collapse` base colour `--rail-ink-3` → `--rail-ink-2`.
- `.cb svg` `stroke-width:3.2` so the tick reads at 12px.
- `03-body-a.html`: **entire SVG sprite rewritten** — 51 icons, all drawn on a strict 24×24 grid, uniform 1.75–2 stroke, rounded joins, consistent optical size; a few lighter-but-clearly-visible glyphs (calendar, home, clock, phone, restore).
- `05-js-core.js`: `history.replaceState` wrapped in `try/catch` — Chrome can throw a SecurityError when the file is opened straight off disk (`file://`), which would have killed the whole interface.

**New verification tooling built this turn (all in /tmp, not in the saved workspace):**
- `/tmp/domtest/` — jsdom harness (`harness.js` + `test.js`/`stress.js`/`wiz.js`/`bin.js`). **Must pass `url: 'https://preview.local/'` to `new JSDOM`** — with the default `about:blank` the newer jsdom throws `targetURL.path.join is not a function` inside `history.replaceState` and *every* screen silently fails to render.
- `/tmp/shot/` — puppeteer (Chromium installed via `npm i puppeteer`; needed `sudo apt-get install libnspr4 libnss3 libatk1.0-0 libatk-bridge2.0-0 libcups2 libdrm2 libxkbcommon0 libxcomposite1 libxdamage1 libxfixes3 libxrandr2 libgbm1 libpango-1.0-0 libcairo2 libasound2`). `ink.js`/`audit.js` rasterise each icon to a canvas and compute **ink coverage %** + **contrast vs its local background** — the only reliable way to prove an icon is actually visible, since I cannot see images.

**Verified results:**
- Rail: 16/16 icons, ink coverage 17–39 %, contrast 8.86–17.12 (was invisible). Collapse 3.74 → now `--rail-ink-2`.
- Whole interface: 231 icons across all 15 screens + 5 settings tabs → 0 JS errors, every icon has ink ≥ 5.58 %.
- jsdom: 15/15 nav routing, 318-click stress ×2 passes → 0 errors, no stuck drawer/scrim, toasts capped at 4.
- Import wizard advances **one** step at a time and Undo works; Bin bulk-select works and `#binAll` sits outside any `<form>` (brief requirement).

**False positive to remember:** `.wl__tick svg` has `opacity:0` when a worklist row is *not* done — the audit flags it as white-on-white, but it is hidden by design. Clicking it sets `.is-done`, tick goes green `rgb(63,107,79)` with a white check at contrast 6.13. Do not "fix" this.


## 2026-10-06 (later) — highlights icons + form builder fixes

**User report:** Properties → Add/Edit form ke **Highlights** section mein "bada-bada icon... bekaar lag raha hai, thoda minimal rakha". Plus "Form builder mein bhi thodi bahut problems dikh rahi hain" (unspecified).

**Three REAL bugs found and fixed (all confirmed in headless Chromium, not guessed):**

1. **Giant icons — root cause: no default `<svg>` size.** `ico(name)` emits `<svg><use href="#i-x"/></svg>` with no width/height, so the browser falls back to its default **300×150** box. Hit the Highlights check marks (3 × 300×150) and the form-field grip handles (4 × 300×150, sticking 300px out to the left of every field). Fix: base rule now `svg{width:16px;height:16px;fill:none;stroke:currentColor;...}` — any later class or inline style still overrides it (charts use inline `width:100%`, sparklines `.spark{width:100%}`).
   - **Guard added:** the sprite tag is now `<svg width="0" height="0" style="position:absolute;width:0;height:0;overflow:hidden">` — inline style, so the new 16px default cannot make the sprite visible.
2. **Form builder: focus died while typing.** `drawSettings()` rebuilt the whole settings panel on every `input` event, destroying the very input being typed into — `document.activeElement` fell back to `BODY` after the first keystroke. Fix: split `draw()` into `redrawCanvas()` (canvas + bind only) and `draw()` (canvas + settings). Settings `input`/`req` handlers now call `redrawCanvas()`, so the caret and focus survive. Verified: `activeIsLabel:true, bodyFocus:false`.
3. **Form builder: drag was completely broken.** `.fbfield.is-ghost` had **no CSS rule at all** (kanban `.kcard.is-ghost` and settings `.block.is-ghost` both had one). Two consequences: (a) the lifted copy was static-positioned so `left/top` did nothing and it got dumped at the bottom of the page instead of following the pointer; (b) it had no `pointer-events:none`, so `elementFromPoint` hit the ghost itself and `closest('.fbfield')` returned the ghost → drop target === source index → **reorder silently did nothing**. Fix: added `.fbfield.is-drag{opacity:.35}` and `.fbfield.is-ghost{position:fixed;z-index:100;pointer-events:none;...}` + `.is-snap` spring transition.

**Highlights section redesigned to be minimal** (user asked): no icon at all now — a 5×5 bronze dot (`#725b2f`), a **borderless** input (border only appears on hover/focus), and a 26×26 remove button at `opacity:.28` that goes to 1 on hover/focus. New classes `.hlrow`, `.hlrow__dot`, `.hlrow__in`, `.hlrow__x`; `field()` markup in `06-js-screens-a.js` → `paintHl()`.

**Verified after the fixes:** 15/15 nav routing; 318-click stress ×2 passes → 0 errors; no stuck drawer/scrim; toasts capped at 4; form-builder reorder `Text|Phone|Dropdown|Checkbox` → `Phone|Dropdown|Text|Checkbox`; kanban card moved New→Contacted (2:1 → 1:4); page blocks reorder works; ghost is `position:fixed` + `pointer-events:none` and is cleaned up after drop. SVG size audit across all 15 screens + 5 settings tabs → **no SVG wider than 60px except the 4 sparklines (253×34) and 3 charts (785×347, 230×230, 678×300), which are meant to be that size.**

**Standing lesson:** any bare `ico('x')` with no sizing rule will render 300×150. The 16px base default now prevents it, but when adding new icons still prefer an explicit size rule.


## 2026-10-06 (later still) — Quick Add top-bar button dead

**User report:** "Upar top bar mein jo koi ek add wala option hai, wo theek se work nahi kar raha hai."

**Bug (reproduced, then confirmed fixed in both jsdom and headless Chromium):** Quick Add opened and then **vanished ~180 ms later**.

**Root cause — listener ordering on `document`:** three bubble-phase `click` listeners on `document` fire in registration order.
1. `if (!e.target.closest('#pop')) hidePop();` — registered FIRST.
2. Router's `[data-nav]` handler.
3. The `[data-quickadd]` handler — registered LAST.

On the click that OPENS Quick Add, listener 1 ran first, saw a target outside `#pop`, and called `hidePop()`, which queues `setTimeout(() => pop.hidden = true, 180)`. Listener 3 then opened the popover. The queued timer fired afterwards and killed it.

**Why bell and profile never showed this:** their handlers are bound to the button element itself (`$('#bellBtn')` / `$('#meBtn')`) and call `e.stopPropagation()`, so the event never reaches the `document` listener. Quick Add used delegation on `document`, where `stopPropagation()` is useless — listener 1 has already run.

**Fix (both parts, in `05-js-core.js`):**
- The outside-close listener now skips the buttons that own a popover: `if (e.target.closest('#bellBtn, #meBtn, [data-quickadd]')) return;`
- `hidePop()`'s delayed `hidden = true` is tokenised (`popCloseT`) and `showPop()` calls `clearTimeout(popCloseT)` — a stale close can never kill a freshly opened popover again.
- `showPop()` switched from raw `requestAnimationFrame` to the guarded `raf()`.

**Verified:** popover stays open at +60 ms / +460 ms / +1.3 s; renders 214×166, 8 px below the button, right-aligned; all 4 menu items (add-home / enquiries / visits / team) navigate correctly and close it; second click toggles closed; outside click closes; bell and profile unaffected; switching directly between popovers works. Top bar also re-checked: global search opens the palette and moves focus to `#cmdkIn` (26 items, filters correctly, Enter navigates), Ctrl/Cmd+K works, bell's "Open change requests" → requests screen, profile → settings. Regression: 15/15 nav, 318-click stress → 0 errors.

**Lesson for any future popover/menu:** if you open a popover from a **delegated `document` listener**, the "click outside closes it" guard will fire first on the same click. Either exempt the trigger in that guard, or bind the handler to the element with `stopPropagation()` — and always tokenise the delayed `hidden` flip.
