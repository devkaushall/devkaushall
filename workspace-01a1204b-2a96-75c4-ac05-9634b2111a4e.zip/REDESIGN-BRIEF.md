# Estat.OS — Naya Interface (0 se)

**Status: WAIT** — user layout describe kar rahe hain. Kuch banana abhi nahi.

## Lock ho chuki baatein (18 Oct 2025)

| Sawal | Jawab |
|---|---|
| Kaunsa hissa badlega? | **Admin (PC office) + Pocket (field agent phone app)** |
| Public website (Elementor)? | **Nahi chhoona** — jo abhi hai wahi rahega |
| Features? | **Kam screens, simple.** Bahut saari screens hain — inko mila kar kuch kam, simple screens banane hain |
| Favorites / Compare? | **HOLD** — interface final hone ke baad dekhenge |
| Process | User pehle layout describe karenge → phir design preview → phir code |

## Abhi ke screens (jinse kam banane hain)

**Admin — 20 screens:** Today, Add a Home, Properties, Bin, Duplicates, Enquiries, Projects, Team,
Import & Export, Settings, Pipeline, Site visits, Change requests, Forms, Search alerts, Reports,
Gallery & media, Page blocks, Colours and fonts, Setup

**Pocket — field agent app** (`/agent/` route): Today, Homes, Add, Leads, Visits

## BAN GAYA — poora interface prototype

**File: `Estat-OS-Interface.html`** (208 KB, ek hi file, internet ki zaroorat nahi).
Browser mein kholo — 15 screens, sab kuch click karne layak.

**Layout:** Left sidebar (6 groups, 15 modules) + Top bar (search ⌘K, notifications,
profile, Quick Add) + Main canvas. Bento grid. Screen badalne par fade + slide-up.

**15 screens:** Today (bento + worklist) · Properties (table, hover actions) ·
Add a home (4 sections + completeness + duplicate warning) · Societies & Projects
(cards + drawer) · Enquiries (table + drawer with timeline) · Pipeline (Kanban,
drag-drop, spring snap) · Site Visits (calendar + list) · Team (cards + drawer) ·
Change Requests (old vs new diff) · Gallery (masonry + drag-drop upload + bulk) ·
Forms (3-pane builder) · Import (4-step wizard) · Duplicates (compare + score) ·
Reports (SVG charts, animated) · Settings (5 inner tabs, tokens live preview,
page blocks reorder) · Bin (bulk select + restore/delete/empty)

**Motion:** count-up numbers, staggered rise, drawers right se slide + background
dim, toast har action par, drag uthate waqt lift + chhodte waqt spring snap,
charts load hote hi grow. `prefers-reduced-motion` ka poora respect.

**Test:** jsdom se 276 clicks + har screen do baar → **0 errors**.

## Agla step
1. Isme dekho, batao kya badle.
2. Approve ke baad isko plugin ke andar daalunga (Admin + Pocket),
   real database se jod kar. Public website nahi chhooni.
