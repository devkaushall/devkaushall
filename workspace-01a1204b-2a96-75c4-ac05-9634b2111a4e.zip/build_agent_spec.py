#!/usr/bin/env python3
"""Write the Agent (Pocket) specification as a Word document.

The audience is the person who will design the agent's interface, not an
engineer, so everything is written in plain Hinglish and describes what
the app does and what it looks like rather than how it is built.
"""

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor, Cm

INK = RGBColor(0x1B, 0x1C, 0x19)
MUTED = RGBColor(0x6B, 0x6A, 0x63)
BRONZE = RGBColor(0x72, 0x5B, 0x2F)

doc = Document()

# ------------------------------------------------------------------ styles
st = doc.styles['Normal']
st.font.name = 'Inter'
st.font.size = Pt(10.5)
st.font.color.rgb = INK
st.paragraph_format.space_after = Pt(6)
st.paragraph_format.line_spacing = 1.25

for name, size, colour, before in (
        ('Title', 26, INK, 0),
        ('Heading 1', 17, INK, 18),
        ('Heading 2', 13, BRONZE, 13),
        ('Heading 3', 11.5, INK, 10)):
    s = doc.styles[name]
    s.font.name = 'Inter'
    s.font.size = Pt(size)
    s.font.color.rgb = colour
    s.font.bold = True
    s.paragraph_format.space_before = Pt(before)
    s.paragraph_format.space_after = Pt(5)

for sec in doc.sections:
    sec.top_margin = Cm(2.0)
    sec.bottom_margin = Cm(2.0)
    sec.left_margin = Cm(2.2)
    sec.right_margin = Cm(2.2)


def para(text='', size=10.5, bold=False, italic=False, colour=INK,
         space_after=6, align=None, style=None):
    p = doc.add_paragraph(style=style)
    r = p.add_run(text)
    r.font.size = Pt(size)
    r.bold = bold
    r.italic = italic
    r.font.color.rgb = colour
    p.paragraph_format.space_after = Pt(space_after)
    if align is not None:
        p.alignment = align
    return p


def rich(parts, space_after=6, style=None):
    """parts: list of (text, bold, colour)."""
    p = doc.add_paragraph(style=style)
    for text, bold, colour in parts:
        r = p.add_run(text)
        r.bold = bold
        r.font.size = Pt(10.5)
        r.font.color.rgb = colour
    p.paragraph_format.space_after = Pt(space_after)
    return p


def bullets(items, style='List Bullet'):
    for it in items:
        if isinstance(it, tuple):
            p = doc.add_paragraph(style=style)
            r = p.add_run(it[0])
            r.bold = True
            r.font.size = Pt(10.5)
            r2 = p.add_run(it[1])
            r2.font.size = Pt(10.5)
        else:
            p = doc.add_paragraph(it, style=style)
            for r in p.runs:
                r.font.size = Pt(10.5)
        p.paragraph_format.space_after = Pt(3)


def table(rows, widths=None, head=True):
    t = doc.add_table(rows=0, cols=len(rows[0]))
    t.style = 'Table Grid'
    t.alignment = WD_TABLE_ALIGNMENT.LEFT
    for i, row in enumerate(rows):
        cells = t.add_row().cells
        for j, val in enumerate(row):
            cells[j].text = ''
            p = cells[j].paragraphs[0]
            r = p.add_run(str(val))
            r.font.size = Pt(9.5)
            if head and i == 0:
                r.bold = True
                r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
                shade(cells[j], 'F2EDE4')
            p.paragraph_format.space_after = Pt(2)
    if widths:
        for row in t.rows:
            for j, w in enumerate(widths):
                row.cells[j].width = Cm(w)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return t


def shade(cell, hex_fill):
    el = OxmlElement('w:shd')
    el.set(qn('w:fill'), hex_fill)
    cell._tc.get_or_add_tcPr().append(el)


def rule():
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(10)
    pb = OxmlElement('w:pBdr')
    b = OxmlElement('w:bottom')
    b.set(qn('w:val'), 'single')
    b.set(qn('w:sz'), '6')
    b.set(qn('w:color'), 'E6E2D9')
    pb.append(b)
    p._p.get_or_add_pPr().append(pb)


# =====================================================================
# Cover
# =====================================================================
para('Agent Pocket', size=26, bold=True, space_after=2)
para('Field Agent OS — interface specification', size=13, colour=MUTED, space_after=4)
para('Mayfair Properties  ·  Version 4.1.6  ·  October 2026', size=9.5,
     colour=MUTED, space_after=10)
rule()

para('Ye document kis liye hai', size=11.5, bold=True, space_after=4)
para('Ye document Agent Pocket ka poora naksha (blueprint) hai. Isse aap kisi bhi '
     'designer ko de sakte hain — usse ye samajh aa jayega ki app kya karta hai, '
     'usmein kaun-kaun se screen hain, har screen par kya dikhta hai, aur har cheez '
     'ka rang, size aur jagah kya honi chahiye. Designer ko code padhne ki zarurat nahi.',
     space_after=8)
para('Language simple rakhi gayi hai, taaki non-technical insaan bhi padh le.',
     italic=True, colour=MUTED, space_after=4)

doc.add_page_break()

# =====================================================================
# 1. What it is
# =====================================================================
doc.add_heading('1. Agent Pocket kya hai', level=1)

para('Ye ek mobile-first app hai jo property ke field agent (jo ghoom-ghoom kar '
     'property dekhte hain aur client se milte hain) apne phone par use karte hain.',
     space_after=6)

rich([('Seedha matlab: ', True, INK),
      ('Agent Pocket wo jagah hai jahan agent property ki photo khinchta hai, price '
       'likhta hai, client ka enquiry note karta hai, aur site visit ka record rakhta '
       'hai — sab kuch phone se, field mein khade hokar.', False, INK)], space_after=8)

doc.add_heading('Ye app kya nahi hai', level=2)
bullets([
    ('Ye koi naya software nahi. ', 'Ye Mayfair ki website aur office dashboard ke saath '
     'judha hua hai. Jo bhi agent phone se daalta hai, wo seedha wahin save hota hai.'),
    ('Ye public website nahi. ', 'Aam log isse nahi dekh sakte. Sirf login karne wale '
     'log dekh sakte hain.'),
    ('Ye office dashboard nahi. ', 'Office wala dashboard alag hai (WordPress admin ke '
     'andar). Agent Pocket sirf field ke kaam ka hai.'),
])

doc.add_heading('Teen important baatein', level=2)
bullets([
    ('Koi app install nahi karni. ', 'Agent phone ke browser mein ek link kholta hai. '
     'Koi Play Store / App Store ki zarurat nahi.'),
    ('Bina network ke bhi chalta hai. ', 'Agar network nahi hai, agent jo bhi bhar raha '
     'hai wo phone mein save ho jata hai. Network aate hi apne aap upar chala jata hai.'),
    ('Jo bhi agent bhejta hai, office check karta hai. ', 'Agent ki bhari hui cheez '
     'seedha website par nahi jati — pehle office wale use dekhte hain aur approve '
     'karte hain.'),
])

rule()

# =====================================================================
# 2. Who uses it
# =====================================================================
doc.add_heading('2. Kaun use karta hai', level=1)

table([
    ['Kaun', 'Kya kar sakta hai'],
    ['Field Agent\n(asli user)',
     'Apni property add karna, photo/price/owner number dalna, client ka enquiry '
     'likhna, visit book karna ya khatam mark karna, apni detail badalna, apni '
     'property ko bin mein dalna aur wapas lana.'],
    ['Office Owner',
     'Agent wala sab kuch, plus: doosron ki property edit karna, changes approve ya '
     'reject karna, sabke lead aur visit dekhna, team manage karna, settings badalna.'],
], widths=[4.2, 12.0])

rich([('Note: ', True, BRONZE),
      ('Agent sirf apni property hata sakta hai (bin mein). Kisi ki property '
       'permanently delete karna sirf office ka kaam hai.', False, INK)], space_after=6)

doc.add_heading('Login kaise hota hai', level=2)
bullets([
    'Agent ko alag account banane ki zarurat nahi. Wo wahi username/password dalta hai '
    'jo uska office wala hai.',
    'Agent apna phone number bhi username ki jagah use kar sakta hai (agar wo number '
    'uski team record mein saved hai).',
    'Login ke baad app usi bhasha mein khulti hai jo agent ne chuni hai.',
])

doc.add_heading('Bhasha', level=2)
para('App do bhashaon mein chalti hai: English aur Hinglish. Agent apni bhasha '
     '"You" screen se badal sakta hai. Ye setting sirf usi login ke liye hai — '
     'website ya office ki bhasha alag rehti hai.')

rule()

# =====================================================================
# 3. Navigation
# =====================================================================
doc.add_heading('3. Navigation — paanch darwaze', level=1)

para('Poore app mein sirf paanch main sections hain. Inhe hum "darwaze" (doors) '
     'kehte hain. Ye paanch darwaze har screen size par maujood hote hain — bas '
     'unki jagah badalti hai.', space_after=8)

table([
    ['#', 'Darwaza', 'Icon', 'Kya milta hai'],
    ['1', 'Today', 'Home', 'Aaj ka kaam — kitne enquiry hain, kitne follow-up late '
     'hain, aaj kitne visit hain. Sabse upar "Next" (abhi kya karna hai).'],
    ['2', 'Leads', 'Inbox', 'Client ki list — naam, kya chahiye, phone, WhatsApp, '
     'status.'],
    ['3', 'Add', 'Plus (+)', 'Naya kuch dalne ka — property, enquiry, visit, '
     'client ki pasand, owner ki baat.'],
    ['4', 'Properties', 'List-checks', 'Agent ki saari property — live, draft, '
     'office ke paas pending.'],
    ['5', 'Visits', 'Calendar', 'Site visit — aane wale aur abhi-abhi hue.'],
], widths=[1.0, 2.6, 2.0, 10.6])

rich([('Sabse important rule: ', True, BRONZE),
      ('"Add" hamesha beech mein hota hai — paanch mein se teesra. Ye hamesha dark '
       '(kaala) hota hai aur baaki chaaron se thoda upar utha hua dikhta hai. '
       'Kyunki kaam shuru karne wala button sabse pehle nazar aana chahiye.', False, INK)],
     space_after=8)

doc.add_heading('Teeno size par navigation kahan dikhti hai', level=2)
table([
    ['Screen', 'Chaudai', 'Navigation kahan'],
    ['Phone', '768px se chhoti', 'Niche, bottom bar mein — paanch button, ek line mein'],
    ['Tablet', '768px – 1023px', 'Niche, bottom bar mein — bade button aur bada text'],
    ['Desktop / PC', '1024px se badi', 'Left mein dark rail (252px) — niche wali bar '
     'bilkul nahi hoti. Top bar mein sirf naam, search aur aadmi.'],
], widths=[2.6, 3.4, 10.2])

doc.add_heading('Desktop par left column (sidebar)', level=2)
para('Desktop par screen ke left mein ek dark column (rail) hota hai. Usme paanch '
     'darwaze upar se niche, aur unke niche wo cheezein jo "darwaza" nahi hain:', space_after=4)
bullets([
    'Today · Leads · Add · Properties · Visits (paanch darwaze, Add beech mein, dark)',
    'Societies & projects',
    'Your details',
])
para('Sabse niche: "Sign out" aur /agent ka patla nishaan. Rail 252px chaudi hoti hai '
     '(1280px se chhoti screen par 224px), aur har cheez usi chaudai ke andar rehti hai.', space_after=6)

doc.add_heading('Naya — apna logo aur saaf rail (4.1.6)', level=2)
para('Do cheezein theek ki gayi hain, dono aapne hi pakdi thi:', space_after=5)
bullets([
    'Logo: pehle har jagah ek rangeen dabba tha jisme ek letter likha hota tha — '
    'top par, sign-in screen par, sab jagah. Ab wahan office ka apna logo dikhta hai. '
    'Wo logo Settings → The office → Office logo se chuna ja sakta hai, ya jo website '
    'par pehle se laga hai wahi use hota hai. Sign-in par poora logo dikhta hai (naam '
    'ke saath), aur rail/top bar par sirf nishaan — kyunki 252px mein poora naam '
    'fit nahi hota.',
    'Spacing: ye sirf design ki baat nahi thi, ek bug tha. Rail ke har link ko poori '
    'column ki barabar hissa mil raha tha, is liye saat links 594px ki column mein '
    '84px-84px lambe ho gaye the — text beech mein, upar-neeche khaali. Ab har link '
    'apni asli unchaai ka hai (38px), aur khaali jagah neeche chali gayi jahan Sign '
    'out baitha hai. Office wale rail mein bhi wahi: rows 35px, sections ke beech '
    '12px, aur heading apne rows ke saath chipki hui.',
])
para('Tablet aur phone par layout waisa hi hai. Sirf logo badla hai aur spacing sahi hui hai.', space_after=6)

doc.add_heading('Naya — desktop ab poori screen leta hai (4.1.5)', level=2)
para('Pehle app ek 1400px ke column mein baitha tha, is liye badi screen par dono taraf '
     'khaali jagah dikhti thi. Ab wo cap hata diya gaya hai: shell poori window leta hai '
     'aur desktop par Today ek bento (mosaic) hai — jaise ek dashboard. Tablet aur phone '
     'par kuch nahi badla.', space_after=5)
table([
    ['Row', 'Left', 'Right'],
    ['1', 'Greeting aur date — poori chaudai', '—'],
    ['2', 'Paanch numbers — poori chaudai', '—'],
    ['3', 'Next best action', "Aaj ki visits"],
    ['4', 'Quick actions', 'Recently added'],
    ['5', "Aaj ke tasks — poori chaudai", '—'],
], widths=[1.2, 7.6, 7.4])
bullets([
    '1200px se badi screen par hi bento lagta hai. 1200px se chhoti par wahi purana '
    'do-column layout chalta hai.',
    '1024px se 1199px tak content 1040px ke reading column mein rehta hai — sirf Today '
    'poori chaudai leta hai.',
    '1600px se badi screen par side wale card thode bade ho jate hain aur quick actions '
    'chaar ek line mein aate hain.',
    'Card ke andar padding 14px se 18px, numbers 22px se 28px, quick buttons 64px unche.',
])

doc.add_heading('Naya — shortlist aur tulna (4.1.3)', level=2)
para('Agent ka apna chhota panel: jo ghar client ko pasand aaye, un par sitara (star) laga '
     'deta hai. Ye sirf usi agent ka apna list hota hai — doosre agent ka list kharab nahi '
     'hota, aur property par koi asar nahi padta.', space_after=5)
bullets([
    'Har property row ke saath ek star button — bina internet/script ke bhi chalta hai.',
    'My shortlist: sirf star ki hui properties, jis order mein star ki gayi.',
    'Side by side: do se chaar ghar, das sawaal — price, size, bedrooms, bathrooms, floor, '
    'furnishing, parking, where, availability, society. Jiska jawab nahi hai wahan "not said" '
    'likha aata hai, taaki khali jagah nazar aaye.',
    'Phone par columns ek ke niche ek ho jate hain (chaar columns 390px par padhne layak nahi hote).',
    'Office mein bhi wahi: Properties → Compare → do-chaar tick → drawer mein side by side.',
])

rule()

# =====================================================================
# 4. Screens
# =====================================================================
doc.add_heading('4. Har screen kya dikhati hai', level=1)

SCREENS = [
    ('Today (pehli screen)',
     'Subah kholte hi ye screen dikhti hai. Agent ko bina soche samajh jana chahiye: '
     'aaj kya karna hai.',
     [('Greeting', 'Upar "Good morning, Anita" — time ke hisaab se'),
      ('Search bar', 'Sabse upar, har screen par'),
      ('Count line', '"7 things need attention"'),
      ('4 chips', 'New enquiries (4) · Follow-ups late (2) · Visits today (1) · '
       'Listings need work (0). Har chip dabane se usi screen khulti hai.'),
      ('"Next" card', 'Ek card: kya karna hai, kyun karna hai, aur Call / Open button'),
      ('"Then" list', 'Baaki kaam niche'),
      ('Khali hone par', 'Agar kuch nahi bacha to "Nothing is waiting on you" likha '
       'aata hai aur Add ka button')]),

    ('Leads (client)',
     'Client ki list. Phone par table nahi — insaan ke card.',
     [('Filter chips', 'Open · Won · Closed · "Add an enquiry"'),
      ('Har client card', 'Naam ka pehla akshar (avatar), naam, kya chahiye '
       '(jaise "3 BHK, Sector 57, up to 1.9 Cr"), kab follow-up hai, status pill'),
      ('Actions', 'Call · WhatsApp · Open')]),

    ('Visits (site visit)',
     'Aaj aur aane wale visit.',
     [('Chips', '"Coming up" · "Book a visit"'),
      ('Har visit card', 'Calendar icon, client ka naam, tarikh+samay+property, '
       'status pill. Dabane se visit ki detail khulti hai.'),
      ('"Just finished"', 'Jo visit abhi-abhi hue, niche alag heading ke neeche')]),

    ('Properties',
     'Agent ki saari property.',
     [('Search', 'Title ya locality se dhundhne ka box'),
      ('Do chips', 'Properties · Societies & Projects'),
      ('Har row', 'Chhoti photo (ya empty icon), naam, price, status pill '
       '("On the website" / "With the office" / "Not finished yet")'),
      ('Neeche', 'Bin section — jo property hatayi gayi ho')]),

    ('Property detail',
     'Ek property ki poori jankari.',
     [('Upar', 'Back link, naam, locality, reference number'),
      ('Pills', 'Status · Available · Verified'),
      ('Photos', 'Photo grid'),
      ('"The facts" card', 'Price, size, bedroom, bathroom, facing, floor, '
       'furnishing, reference'),
      ('"What the office said"', 'Office ka note, agar kuch missing ho'),
      ('Buttons', 'Edit this listing · Ask the office for a change · Move it to the bin')]),

    ('Add (capture sheet)',
     '"Add" darwaza dabane par ye khulta hai — ek list: kya dalna hai?',
     [('5 rows', 'Add a property · Add an enquiry · Log a visit · Add what a client '
       'wants · Owner update'),
      ('Har row', 'Icon (bronze), bada naam, neeche chhoti line mein kya hoga'),
      ('Neeche note', '"Nothing is saved until you press the button on the form itself."')]),

    ('Add a property (6 step form)',
     'Property add karne ka form — 6 chhote step mein, ek saath nahi.',
     [('Step 1 — What and where', 'Naam, locality, address'),
      ('Step 2 — The price', 'Price, offer type (sale/rent)'),
      ('Step 3 — Size and rooms', 'Size, bedroom, bathroom'),
      ('Step 4 — Photos and video', 'Camera se photo, photo count dikhata hai'),
      ('Step 5 — The description', 'Property ke baare mein likhna'),
      ('Step 6 — Look it over', 'Sab kuch ek saath dekh kar final Save')]),

    ('Search',
     'Ek hi box se sab dhundho — client, property, visit, society.',
     [('Upar', 'Search bar'),
      ('Results', 'Category ke hisaab se rows — icon se pehchano (insaan / ghar / '
       'calendar / building)')]),

    ('More',
     'Jo roz ka kaam nahi, wo sab yahan.',
     [('Work group', 'Waiting for you · Ask the office for a change · Waiting to go '
       'up · Societies and projects'),
      ('You group', 'Your details · Search everything'),
      ('Office group', 'Approvals (sirf office owner ke liye)')]),

    ('You (meri jankari)',
     'Agent ki apni detail.',
     [('Info banner', 'Upar ek box: "Your own details live here…"'),
      ('My details form', 'Naam · Phone · WhatsApp · Email · Save button'),
      ('Language', 'English / हिन्दी — pills mein')]),

    ('Waiting to go up (queue)',
     'Wo sab jo bina network ke bhara gaya tha aur abhi upar jana hai.',
     [('Upar line', '"Filled in where there was no network…"'),
      ('Har row', 'Kya tha, kab bhara, kitni baar try kiya · "Waiting" pill')]),

    ('Sign in',
     'Login screen. Isme koi navigation nahi hoti.',
     [('Upar', 'Key icon, "Agent pocket" title, chhoti line app ke baare mein'),
      ('Form', 'Username / email / phone number · Password · Remember me · Sign in'),
      ('Neeche note', '"This is your office WordPress account…"')]),
]

for title, intro, items in SCREENS:
    doc.add_heading(title, level=2)
    para(intro, space_after=5)
    bullets(items)

rule()

# =====================================================================
# 5. Responsive
# =====================================================================
doc.add_heading('5. Teen screen size — alag-alag design', level=1)

rich([('Ye sabse zaroori rule hai: ', True, BRONZE),
      ('har size ko apne aap design karo. Desktop ko chhota kar dena "mobile design" '
       'nahi hai.', False, INK)], space_after=8)

doc.add_heading('Phone (768px se chhoti)', level=2)
bullets([
    'Ek column. Sab kuch upar se niche.',
    'Navigation niche, bottom bar mein. Paanch button, har button kam se kam 40px '
    'uncha (ungli ke liye).',
    'Add button beech mein, dark, bar se 10px upar utha hua, neeche shadow ke saath.',
    'Device marks (Mobile/Tablet/PC wale chips) bilkul nahi dikhte — wo sirf demo ke '
    'liye the.',
    '"Sign out" sirf icon mein dikhta hai — shabd chhup jate hain.',
    'Photos 3 column mein. Facts (jaankari) 2 column mein.',
    'Buttons poori chaudai ke. Cards ke andar 13px padding.',
    'Title 20px, headings 14px, body 13px.',
])

doc.add_heading('Tablet (768px – 1023px)', level=2)
bullets([
    'Navigation niche hi rehti hai, par badi: har button lagbhag 149px chauda aur '
    '69px uncha.',
    'Add button beech mein, dark, bar se 12px upar utha hua, badi shadow ke saath.',
    'Content 820px tak khulta hai — phone jaisa patla nahi.',
    'Facts 2 column, photos 4 column, pair wale field 2 column.',
    'Bottom bar ko upar gol kone (20px) aur halki shadow — taaki wo "ek alag '
    'elevated cheez" lage, content ka hissa nahi.',
    'Title 24px, headings 16px.',
])

doc.add_heading('Desktop / PC (1024px se badi)', level=2)
bullets([
    'Paanch darwaze left ke dark rail mein (252px, 1280px se chhoti screen par 224px) — '
    'Add beech mein, dark.',
    'Niche wali bottom bar bilkul nahi hoti. Top bar mein sirf naam, search aur aadmi.',
    'Rail ke niche wo cheezein jo darwaza nahi hain: Societies & projects, Your details, '
    'aur sabse niche Sign out.',
    'Content poori window leta hai — 32px ka gap dono taraf, aur kuch nahi (4.1.5).',
    'Today 1200px se upar 12-column bento hai; baaki screens 1040px ke reading column '
    'mein rehti hain.',
    'Numbers ke card 18px padding, numbers 26px (1600px se upar 28px), quick buttons '
    '64px unche, greeting 30px.',
])

doc.add_heading('Kabhi bhi nahi hona chahiye', level=2)
bullets([
    'Koi bhi cheez screen ke bahar na jaye (horizontal scroll na aaye).',
    'Navigation items ek doosre se na takraye, na squeeze ho, na ajeeb se wrap ho.',
    'Text kisi card se bahar na nikle.',
    '360px se le kar 1920px tak sab kuch theek dikhe.',
])

rule()

# =====================================================================
# 6. Design kit
# =====================================================================
doc.add_heading('6. Design kit — rang, font, size', level=1)

doc.add_heading('Rang (colours)', level=2)
table([
    ['Naam', 'Code', 'Kahan use hota hai'],
    ['Sand (background)', '#F9F7F2', 'Poori screen ka background'],
    ['Paper (card)', '#FFFFFF', 'Cards, rows, panels'],
    ['Raised', '#F2EDE4', 'Hover, active row'],
    ['Inset', '#F0EEE9', 'Andar wale dabbe, thumbnail'],
    ['Line', '#E6E2D9', 'Patli lakeer (border)'],
    ['Ink', '#1B1C19', 'Main text'],
    ['Ink 2', '#444748', 'Doosri line ka text'],
    ['Muted', '#6B6A63', 'Chhota/meta text'],
    ['Bronze', '#725B2F', 'Main accent — active tab, primary button'],
    ['Bronze light', '#A68B5B', 'Chips, rules'],
    ['Bronze soft', '#F2EDE4', 'Active tab ka background'],
    ['Positive', '#3F6B4F', '"On the website", success'],
    ['Warning', '#8A6A1F', '"With the office", pending'],
    ['Danger', '#8C3B32', 'Bin, delete'],
    ['Dark (sidebar / Add)', '#16171A', 'Desktop sidebar ka background, Add button'],
], widths=[4.2, 3.4, 8.6])

rich([('Contrast rule: ', True, BRONZE),
      ('Har text ko uske background se saaf alag dikhai dena chahiye. Dark background '
       '(#16171A) par text halka (#FBF9F4 ya #B6B8BD) hona chahiye. Kabhi bhi gehre '
       'bronze ko dark background par mat rakho — wo dikhta nahi.', False, INK)],
     space_after=8)

doc.add_heading('Font (type)', level=2)
table([
    ['Kya', 'Font', 'Size', 'Weight'],
    ['Big title (H1)', 'Inter', '24px (desktop) / 20px (phone)', '700'],
    ['Section heading', 'Inter', '16px / 14px', '700'],
    ['Card title', 'Inter', '16px', '600'],
    ['Body text', 'Inter', '13px', '400'],
    ['Meta / chhota', 'Inter', '12px', '400'],
    ['Label (UPPERCASE)', 'Inter', '11px', '600, letter-spacing .06em'],
], widths=[4.0, 3.0, 5.6, 3.6])

doc.add_heading('Gap aur golai (spacing & radius)', level=2)
table([
    ['Token', 'Value', 'Kahan'],
    ['xs', '4px', 'Icon aur text ke beech'],
    ['s2', '8px', 'Chips ke beech, chhote gap'],
    ['s3', '12px', 'Card ke andar ke elements ke beech'],
    ['s4', '16px', 'Cards ke beech'],
    ['s5', '24px', 'Sections ke beech'],
    ['Radius — chip/pill', '99px', 'Chips, pills, tags (gol)'],
    ['Radius — card', '14–16px', 'Cards, rows, buttons'],
    ['Radius — sheet', '16px', 'Sheet (list ke andar)'],
], widths=[3.4, 3.4, 9.4])

doc.add_heading('Shadow (parchhai)', level=2)
bullets([
    'Card: bahut halki — "paper raised" jaisa, tez nahi.',
    'Add button: gehri aur saaf (0 6–8px, 20–22px blur, 30% opacity) — taaki wo '
    'baaki buttons se upar utha hua lage.',
    'Tablet bottom bar: upar ki taraf halki shadow — taaki bar content se alag '
    'elevated dikhe.',
])

rule()

# =====================================================================
# 7. Components
# =====================================================================
doc.add_heading('7. Components — tayyar tukde', level=1)

para('Designer ko har cheez naye sir se banane ki zarurat nahi. Ye tukde (components) '
     'pehle se tayyar hain — bas inhe use karna hai.', space_after=8)

COMPONENTS = [
    ('Button', '3 tarah: Primary (bronze, bhara hua) · Secondary (sirf border) · '
     'Danger (laal text). Har button kam se kam 40px uncha (phone), 44px (tablet).'),
    ('Chip', 'Gol (99px), filter ke liye. States: normal · is-on (bronze bhara hua) · '
     'is-loud (count ke saath) · is-quiet (0 count).'),
    ('Pill', 'Status batane ka chhota label. Jaise "On the website" (hara), '
     '"With the office" (peela), "Not finished yet" (bhura).'),
    ('Card', 'Safed dabba, 14–16px gol, halki shadow. Andar 13–20px padding.'),
    ('Row (property)', 'Chhoti photo + naam + price + status pill. Poori row clickable.'),
    ('Sheet row', 'Icon + bada naam + neeche chhoti line + right mein arrow. '
     'Menu/list ke liye.'),
    ('Person card', 'Avatar (naam ka pehla akshar) + naam + kya chahiye + kab '
     'follow-up + Call/WhatsApp/Open.'),
    ('Task card', 'Icon + bada text (kya karna hai) + italic mein kyun + actions. '
     '"Next" wala card thoda alag dikhta hai (highlight).'),
    ('Field', 'Label upar, input niche. Focus par bronze border + halki ring.'),
    ('Meter (bar)', 'Patli line jo completeness dikhayi hai (0–100%). Rang: laal '
     '(kam) · peela (beech) · hara (zyada).'),
    ('Toast', 'Neeche beech mein chhota dark dabba — "Saved", "Calling…". '
     '2 second baad apne aap gayab.'),
    ('Empty state', 'Jab kuch na ho: bada faded icon + ek line + ek button '
     '("Add a property").'),
    ('Avatar', 'Gol, naam ka pehla akshar. 30px (top bar) / 40px (person card).'),
]
for name, desc in COMPONENTS:
    rich([(name + ' — ', True, INK), (desc, False, INK)], space_after=4)

rule()

# =====================================================================
# 8. States
# =====================================================================
doc.add_heading('8. States — har halat mein kya dikhe', level=1)

table([
    ['Halat', 'Kya dikhana hai'],
    ['Khali (empty)', 'Faded icon + ek saaf line + ek kaam ka button. Kabhi bhi '
     'khali jagah mat chhodo.'],
    ['Load ho raha hai', 'Puraani cheezein waise hi rahein, koi blank flash nahi.'],
    ['Offline (network nahi)', 'Upar ek patti: "No network. What you type is kept on '
     'this phone…"'],
    ['Wapas online', 'Wahi patti: "Back online. Press Save when you are ready."'],
    ['Kuch upar jana baaki hai', 'Ek line: "2 waiting to go up" + "Send now" button. '
     'Jab kuch na ho to ye line dikhti hi nahi.'],
    ['Galti (error)', 'Laal text field ke paas, ya ek notice box. Kabhi bhi sirf '
     'technical error mat dikhao.'],
    ['Office ne band kiya', 'Agar office ne phone par enquiry band ki hai to Leads '
     'ka darwaza dikhta hi nahi, aur jagah par ek line.'],
    ['Ijazat nahi', 'Agent wo button dekhta hi nahi jo wo nahi kar sakta. '
     'Disabled button dikhana bekaar hai.'],
], widths=[4.4, 11.8])

rule()

# =====================================================================
# 9. Rules
# =====================================================================
doc.add_heading('9. Rules — design Karte waqt yaad rakhein', level=1)

doc.add_heading('Bhasha aur lafz (tone)', level=2)
bullets([
    'Simple Hinglish ya English — aam insaan ki bhasha.',
    'WordPress ke shabd kabhi mat use karo: "post", "CPT", "taxonomy", "meta", '
    '"admin", "dashboard", "plugin".',
    'Logon ko "Client", "Owner", "Office" kaho — "user", "author", "subscriber" nahi.',
    'Har line chhoti. Lambi technical explanation nahi.',
    'Kisi ko ulta mat bolo. Galti ho to batao ki kya theek karna hai.',
])

doc.add_heading('Kaam karne ka tareeqa', level=2)
bullets([
    'Ek hi sahi tareeqa (one logic). Har kaam ka ek hi raasta — do alag jagah se '
     'ek hi cheez mat karwao.',
    'Har action ka nishaan (audit trail). Jo bhi agent kare, office dekh sake ki '
     'kisne kab kya kiya.',
    'Status ke shabd fixed hain — "On the website", "With the office", '
     '"Not finished yet", "Paused". Naye shabd mat banao.',
    'Tag/square buttons: filter wale buttons gol nahi, square (thoda gol kone) '
     'hote hain.',
    'Agent ko wo button dikhao hi mat jo wo nahi kar sakta.',
])

doc.add_heading('Photos aur media', level=2)
bullets([
    'Camera seedha khulna chahiye — gallery se dhoondhne ki majboori nahi.',
    'Kitni photo lagi hain, dikhao (jaise "3 photos").',
    'Photo ka ratio fix rakho (4:3 ya square) — taaki card kabhi na badle.',
    'Photo na ho to ek halka icon wala empty box dikhao — khali jagah nahi.',
])

rule()

# =====================================================================
# 10. Out of scope
# =====================================================================
doc.add_heading('10. Ismein kya nahi hai', level=1)
para('Designer ko ye cheezein banane ki zarurat nahi — ye doosri jagah hain:', space_after=5)
bullets([
    'Public website (jo aam log dekhte hain) — alag design hai.',
    'Office dashboard (WordPress admin ke andar) — alag design hai.',
    'Property ka public page (listing page) — website ka hissa hai.',
    'Reports / analytics — sirf office dashboard par.',
    'Team management, settings, import/export — sirf office dashboard par.',
    'Societies & projects ko edit karna — Pocket sirf dikhata hai, edit office '
    'dashboard par hota hai.',
])

rule()

# =====================================================================
# 11. Checklist
# =====================================================================
doc.add_heading('11. Designer ke liye checklist', level=1)

para('Kaam khatam karne se pehle ye sab check kar lein:', space_after=5)

doc.add_heading('Waiting screen (jo phone mein ruka hai)', level=2)
para('Jab network nahi hota, save kiya hua phone mein ruk jata hai. /agent/queue/ par har '
     'ruka hua kaam ek line mein dikhta hai — kab ruka, kitni baar try hua — aur do button: '
     '"Send now" aur "Take it off this phone".', space_after=5)
bullets([
    'Upar wali patli line par: "N waiting to go up" — asli ginti ke saath.',
    'Network aate hi apne-aap chala jata hai, aur jaate hi phone se hat jata hai.',
    'Hataane se pehle ek baar poochta hai.',
    '4.1.3 mein ek bug tha: ye screen khulti hi nahi thi (address Today par gir jata tha). Ab theek hai.',
])

CHECKS = [
    ('Navigation', 'Paanch darwaze hain? Add beech mein aur dark hai?'),
    ('Phone', '360px se 767px — sab kuch ek column, navigation niche, device marks '
     'gayab, buttons 40px+?'),
    ('Tablet', '768px se 1023px — bottom bar bada, content 820px, Add bar se upar '
     'utha hua?'),
    ('Desktop', '1024px+ — navigation upar, sidebar left mein 244px dark, '
     'bottom bar gayab?'),
    ('Overflow', '360px se 1920px tak kahin bhi horizontal scroll to nahi aa raha?'),
    ('Zoom', '80% se 125% zoom par layout to nahi tootta?'),
    ('Text', 'Koi bhi text card se bahar to nahi nikal raha?'),
    ('Contrast', 'Har text apne background par saaf padhne layak hai?'),
    ('Empty', 'Har screen ka khala (empty) version bana hai?'),
    ('Offline', 'Offline aur "waiting to go up" wali pattiyan design hain?'),
    ('Tone', 'Kahin bhi WordPress ka shabd to nahi ghus gaya?'),
    ('Icons', 'Sirf Phosphor Regular icon set use hua hai (ek hi family)?'),
]
for name, q in CHECKS:
    p = doc.add_paragraph(style='List Bullet')
    r = p.add_run(name + ': ')
    r.bold = True
    r.font.size = Pt(10.5)
    r2 = p.add_run(q)
    r2.font.size = Pt(10.5)
    p.paragraph_format.space_after = Pt(3)

rule()

para('Ye document Agent Pocket v4.1.6 par based hai. App badle to ye document bhi '
     'badlega.', size=9.5, italic=True, colour=MUTED)

doc.save('/home/user/Agent-Pocket-Specification.docx')
print('written /home/user/Agent-Pocket-Specification.docx')
