#!/usr/bin/env python3
"""Build a preview of the Agent Pocket (/agent) exactly as it stands today.

The Pocket has no WordPress around it, so its own two stylesheets and its
own markup are enough to draw it truthfully: this puts the real shell, the
real screen bodies and the real icons into three device frames — phone,
tablet and desktop — so a design decision can be looked at instead of
imagined. Nothing here is written back into the plugin.
"""

import json

SRC = '/home/user/plugin/estat-os'
# The office's own mark, inlined: the preview must render with no network.
LOGO_ON_DARK  = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAgc0lEQVR42u1deXiTVdY/9943SfcWKC1N2iL7JogCKupYcAZHcEHBpLI6shRcQBARHZUkOAgzDqgfKBZcQBAkQUVE2XRYVJChKDtlaWkL3aWU0jbJe5fz/ZEEC8Nugarc5+Hhad71nuV3fufc5QW41q61S20IQBCBXJPE1RD+qYK/poQr2ex2OwUASEy8NXRgjx7hNX+71i5zc1mtDADgiUdTGv342aP/2b70b18AgIkQALsdrinhSgh/wD33RG1abNtQtnkQFmcMwh+/HPjpPffcY6KUXPOEywc7futO69cy9rsFf/2mdN3DeGjNQzz3exuv3jkc93w1aAkAGH5rnvCbCF4ul5XZbG751it/SurSOmp1fJShta7rkoWamKaFgsHAZHRECCs4Spc+9a/cR1atXOmbaLdTp9Opzh7ArRTcgR+sbfHkQfce4gYAq9WNAICEAP6hFWC3A3U6QbVt2zZi1njL8ubJESnHK6gwmqRmMCppMIQRqhkpJUzExoZpuT9Xfzll7g5bevpWj8NhJ2dTwjUPuAjL//uIWy3dbwpbmBBrulNSIkM0YAbNqCKiwig1AOi6UhozUqScxzWIMOzL5Z+0/vPOfpRu5S+/7FdgkCk5nU417+0hN3a8jr6oqo6qap9OvR4f9fo4SKHQ69FVdfUJKQUJLSrD+S+m71nislqZze2Wl6OPWl22fJvNLVNS2kbc3iFkQZNG7M6KSiKoiWpK00V0ZKyWk+9zmaL0iJZJ0b2OV/oEIWgoP+YTzRuH9v1xVZsFN/3VM8jh2M0BHNTpdKp27fYQAIB6EeWNk+Pq9fVWMNA5A59XA48HgXMFnmodqkIMoKECIXxbAQAati25bIaq1WXYeWHoXfG3tlcfJkRp3crKudCMmqYRIiJiIrUDpd7lt9pcqQvffcQcE2PYGBthbHzCoytBqHbsmFe0TQ6xbV91PRBC+hMCsmZgRi8XFccrhbdaR92nE13n4PNy4FxBVbUA3acEVcJApdAvd1/rHFtwWa3M6QTVr1/L2Ds6Vn/bpD652+eTEjXUqEGX0dEmLeuI+Ghg+o8PI9pp/2EfF3y8orBzVn71coMRqFRcAGpaVSWX7VvUt2V/l7aoWbPmJocDsemxehQAgHDUqQJN04waZVSjjGqEMg2BagSIplBqCpFJVPiHUoDdDtTmdssGDVpF9moXNb9BZFWLCm+lUJpiGpMi0qSxnVmVc7v1+3xw1sqDPofDHyeedS7/ud/4NY8UHeMb4mIjNKBSKARWXqaLJgkG6+ezuy4ipJ2hU1qCBAAICzcxg8EIQLjfIxSCUgqUlICIJ0MjI0j+MAoIWr61V9tGb4yNWpEQg/dUe6gU1KgBBRkVGaNlH8a5vUasHIqIuNhlZU6nU9lsbulyWdnOHcVVHy79+ZHMnMq1oSahCSEkl1IrKTsmWiSFPrRlxQ3vEeKkBAC4UFQpCUIKQETAMzJNBETyx/CAoOV36tQprO/tYfNaNMLbUSoBEMoMSEW9kAh24Ij6oMcTq4ciArrdNmqzueWtt94aarfbY2w2t/zPWrv26hurCl94c0efw8V8S0w0YYhSEDBq5RUnxPUtogduWfHYXAQAkBU+oXzAiD8EEkKAEHLS8gkhgAjApfj9KyAYcJ9Jaxk7qpfX3TBU3X28QgmqhTANjDIqPEzLLfQs7DXiq4DwXTQ1dYlMS0sLW/LJkk/S0tIWAgDr3n2SyMhIN3z++fby7Dw2tLTSWBgZEalpSikQSqss84lOrRsM+HHFoKmFJSeUphGglAGjDAgQAPCXVxERlFSACmtA0PrfpwKsVmBOJ6gHHmgV2aa+WhMfyXpVeVBwBE0hqvCwEHagUL7V8+n/DEIEcDjsLDU1VSYnJ4c4HI6PLWZLT7PZ3LOkpHil3T6xfpcuI3lGRrrh3iELdy5ce+LWnMKK741GRYliUgOmnSgvU4n15YQ/3Zw8j0sGqJAopUAhAiIAAoJCBQgIBkKAIQ0oIOX3pwC7HajbDbJt27YRD7fTFifXC+3o8SghqWIaVSKEIss8fOL1PuO+fspv+VbqdDrFX9r/JXzDd98tTEhIuF9KKaSUsmHDuL+MTBv+6Z13tono3HkEz8hINzz/vDtv6lv7e+cdM26v3yCSKfRIyXUKCiAmMiwRkYICBUopfxxAP9pQQgPlCgRF4PcZhK1WYJOcoDp1ahr91N3iywYhvKenWkhiJCzEhCo6NFzLKYJ/DXhp0zOIdupw2JktdYmcMHVC9NyVc9ckJyY+pAsulUICgCClFI3MlpSPFq5wT5kypV5QCfOXbjn69Vb9oazDFdtCwoAJSSTIEKj26KiwGiTqwXh7si7gjwUAl5+AXiUFBC0fAbQBdxjnJNSHOyt9KHyEUkF0FRYSxnJK8I1BkzZPQATqdrcjTqdTJFosoU8OemKBOcHcVQghNMqYwaAxxjQGCFQpKS3m5HuGDh22bNUnn8R16TKSY0a6YfT4BYe+2lDa+2iVKSc8RmMchdQIEAIEADUghAKhBCgFAFSAqKAGE6W/KwXY7XY6aRKoNOtfot/7e/svmsSC1atLiZrGKFDFwMR253ln95u4cSzagTocdpqamiqHDBkSuXnLliVJ5uT7hBScEEI551BQUPBhaWmpm2mMIiqQXOcNG8be0f72ru/ecsstoaTzSO5y2Y1jnF/n7ctXtpIT5Eh4pIEpIIqgMdB9BKUQpJSg1JWv29ErafmTJjkVYnPT9Um58+PD1T2CE2EwGWl4KJX1I0ystJS9+sTUbSMQgbrbuYjT6RQWiyXU+Q/HQnOjRr10IQQhlDLG6L59+16xWCyPxsXF2QoKCz5mzMAIJUwIXSTEJ9y/9PPPVrz66oQGNtskPSMj3dCj79wt36z33lF6DHdGRRkpAgoA4sf+AP4H4eekcAj5fXiA3Q50khMUNkoImz5azUuIVPcfLxfCKxSjClVMeLhWdAKmjZj204t+2HGR1NRUOX78+MiNGzd+nJiQdJ+UkjNCKSCygwcPvj9kyJBXEJEhIrWYLYMPHTr0nkSghFAihBDxcY1SHn101JKUlDsjOncewXftshuHjV+Yu25zXmphmafIGMo1obxKUQpAGAAhAMQfDmig7qmo+u17QJDnWxJvDf0/m2mZJVql+nQqlQGYgShFAdjuQ9WTBzgzng3Cjs1mkxMnTowaM2bMqqSkpAekkJwAIYQA3bNnz4gWLVoMzcjIEIQQ5ScsKJo2bTps7569TsY0RggBwYU0m83dFi9a9Hl6enrC9dc7dcxINwx//uu967cUdy8tI3ujI8MpJUxohIEGyh+NlQYgKYBSwMXlV8BlrYYiAiEEVEpKSsgjHQrmJ9bDP1f6qKSMUaNBqAhmYgeL+OSnZu56CRGo22YlTrdTjBs3LjwtLe1js9kfcAkhGmWUlJSULOjQocNsRGQAfokR4h8HRkRKCPnHkSNHWlosln7AQCgpRXxCwl0P9+2zPDY2tCfpPLhkl8tuvN7mzJz7Zur9XVoa1kdHSsvPx71S6QaGgoNSHBQFMFIGRsq036wHWK3AKAUc9KC5wSNd8tfFRcm+lZUoJVLKCMVwYwjLPaqmPjVz/0voArbOYaepS5bIKVOm1Hvm2XFfm83mnlIpTiklQgg9MzPz6bfffvuxoPAJ+aVOExj1UogoExMTB2ZlZTn8xkWAC8HrN4i9KSWl55L58+cnXG9z6i6X3fi3pxdn/XTwRM/cYn0PDQEmFUgKDAjjAJQAoQw0zaR+kzMt7HagARpneO3xpktdLzXHec824fPGX4cfvpAkFjva4MwxHV4GAEA70OBsBwAwHT6ctwwR0ce5zqWUiIi7d+92BJIjcm6PQxI8Jzs7ew4iIhdceSXniIglRcX/nT59egIhFFwuuxEA4JEHbjQvfavrto3zbsGvZ3Thy1/rgB+/3JYvm9QcZzyZ9CYAAK5N0X4zHuBnO6A63dQ0+s3RbeYlxbDeVVVKIEVmMBpEdFg4O3LM89ZTb+x4Ba3A3O1cJHXJEvn88883KCjIdycmJt0vlOCUUqakpJkHDswcPHjwZERkDofjnAoghKDD4SCISJo2bTp8/8GDb0ohlUYJ0bnkDePjuvR5qPcsRGWyBTzh42U/FWTs0QeV+7QiUyjVFKeSomInPBwjDNrwFwe1HES6rxdr7Snab8PyAQCgrfH1J5ut+/TlVrjg2ebigwmJ6qMXrxOrXu2E7z9747/81mqnLpeLAQAMHDgwvKS4+AdERM51nQsuEBF37tk57EIs/0y6QEQKALBz924nIqKQgnMpBCJiQX7B2kWLFiUBwElPmDT6zhZLp9+2d82/b0LXy83F/BeuU4vHN8b3n22mJg5rMsB/7klPrbVGajng4sAePcI7t8yZGxfJH+YcJDBKGeMq1BDKjlaFv5I27aeJ/mkhSAghavz48ZGjx4xakGhOekBKKRhjDABIcWHx+43MjYaeCfMv7H2QAAC12WzwxhtvzDabzUOUUgIRCWOMHT9evvurr1b8uX///sUZGemGzp1H8AmP3nBdmzi5JirE07zC55OAjIaYCECIgR+tChv65JTtC9baU7TuzvWiTkFQMOD2u69l7J3tstZaYvSHqwRKTghlQFRkSATLL6OOtGk/TQxQTUYpVfaxY+s/99yzaxLNSQ8IITgAkOrqan379u3Dfo3wg3AEAMrlcimLxTI0MzPzRUqpxhhDKSWPjo5p16PHXZ+kp09P6Nx5BHe5rMZ/ztuec7CA3CcgJjMuKoppRk0JCIEwMBobx8D86eNuHNnduV6srcWYQGsDdtxukIig3RgrZzQ0yC7eahCUGZmJgTJRYAcL1cujZ2Y6XQHMdzqd4pZbbgkdOvbpubGxcbdIybmmaRpjjGVlHZjWsWPH9xCREUIuSfinKQEQkbZp0+bVgwcPvhOg3oxzLmJj42+/t/cjS+32cXE2m1t3uezGf3y0c9+PWeTeMp+2O9QEDKWuhNegmKDYxqK9me682dq9+3qBlwGOLkn4BAAe6to0btrwlu55zzTHuaOT+Nwxieqj8c358lduwFljW88Ksh273a4RQmDChAnRhUVFX/oxn+tSSuHxeOTBgwf/DQDGQIZbi/CIJ2PCnj27/okoUQjOdcF1RMSc7JzP4uPjwwEAXHarEQBg8P1J7d4Z2zT784nNcKm9jVj+2o3qu/TbcMv8e7h7eo9HAQACnkCuasBt27at8bXh5g2Lxidh+jPJYs6EeLXguQThfrElznj6hsn+8V5gNQNuXn7BGkREKYWOiAIRcf/+/UMvMeBejBIYAEBW1oG3/c/XJWKAohaXbDo9ML84uFOzpZO7ZK+d2QU/f/0GseatO9SO+feqvZ/1RdeM+x7z3/cqeEJQ+P3vTa73+sgmX344zoKzR5n5O2OS1Adjk+THE1rh64+3n3SS57tcjBAC9mnT6ucXFq5ARPToPs6FUFJKLCgoeC8gpMtqUTU8gRw+nDtTcIEohRDCyxERy8p+3jFv3owGNZXw/qR7Wyx/MyV709yu+P27fxKbP+whd33aU+1b9qD+xawHBvg9wX7lKKrVCowAQEpK45jX067b+vGY6/CdJxPErDHJau7oJnzRmJY4+W+tXjrd8vv371+vsLg4AxERhdCFEMLj8fBNmzYNDOL0FXLnk8nanl17Jvhfx8O50DkiYmlp6bf//Oc/zadQ1Kdva7Xyre47fvrwLtyy4C6xzfVXlfdlH1X03SBcvbDvyACt1q6Y5QM0Dpk8pNHSBaMTcc6IZD5ztBnfHWMRSyY0wymPXffqGWEnLy+I+VxKqRAR9+7d+3pA+OxKYmlNONqbuXsGBqxCSsEREfPz83+YMePVUzzh8dTOSavT/5J5YNnduOfTe0X2Kqss/DZV5W8YLNbM69P/ssOR1QoMAOCuW5rEvzo0+bP3n0rE2WlJYvaTjdW7Y5qIxc+1xNefaDmrJuwAADz99NMxRUVFqxARdZ+uc865rus8Ozt7cvPmzU21HXAvJTBnZe2bgogoheS6ruuIiHl5h5bY7fYIAICMjHQDAMA7zr923eq+Pzd3dW88sPohkfXNQ+ro94+pwu+GiBXzew+7bEoIWv4DD7SKnDKy0ea5YxNwdloyf+fxZJX+hEV8MCoZnYOSJ54u/AlTJ0QXFBR8489EpS6EPxPNzc391+UMuJeihJycnLf8gVlKXfgDc3n50Yyvv/7CAgCwK+AJH/27T+s9X6XmFm9MxSPrHhGF6wepss2P4eFv++Ens/48uNaVEBT+0Luuj5+e1uQ/7z1twVkjEvjbj1vUrNENxbtjk9AxMHny6cKfPHlyw4JCP9vhfrYjvT6fysvLm/3BBx+EIKJWF5YT1VTCkby813VdV1wI4eUeHRGx7GjZT6/b7TE14WjRjAdbHlg9KKvqx2FYsGmQLNg4QBWv6y9zVz4ivppzb1oNivorhR9I1Lp0ad3gtSHJ2+Y+mYTvDE/2zn7cwt990sznjb8OHUMbvxIUPgaE37t375iigsIMf1VT14WUwuP1qu9/+GFQjaG/urQ24aQS9u/f/7LfE7w659yLiFhYUPj1o48+GlOT8cyZZm1+aMPwnZW7h2HB9wP1w9/04/lr+ujZK/qga1q3C6bU5Fy1HQCAEQ81b9o6Xv/sunrQvrKSAKEASCRoVIO8Y3Tq83OzX3C5gAG4wGazyVGjRkX9/cUX3I3iE+7WBRdMY5QBpZn797/dplWrJ39NeeFye4J/GJio7Kyst5s0bTqy5vHCgoJtm3744f4+ffrkb509Qus8Yjb/v1fub3J/Sv31jRuypPLjXqjWvYA+CdXVBHYc0p+Z+VnVjHXduilyjlU62rlUQwDo4w9CV13A9wfyxVqFIZoQOkeGJqG0gkmLDr6CAMQNVrDZbHLq1KnRjz322KdxcXF36bouGGOguITsnCz7wP79p9RV4QfLFoioCCHYtFmzx3fv3r0jPDy8uT9RlBIRIjTUGhNCjtjtdokuKyM296H6/9en3/HGYf0rK3VRzSXoPlQhBCiXtIWlgW4hTmdusFB5maipH8ftdntMUVHRWkREXddPUs0jeUferMHzr4Ql0wCz0k77d8FU9/TZEefr+3m86pxNO3+HgLhtZy7aWV2oAADNZnP0vffe64qPj+/GOeeaphl8Pp/v8OHDMz/66KO/I6LmcDjUFbJkVRtwdBaDOdNQ6HmLgb9KAQHXOeMCNQxg5qpVX15vsVh6KKUUY0zjnOv//e9/H01JSVmMiOQKQA4BAHz88cfrPfjgg71btGjR0mg0VnPOkTFGGGNaZWVl1dKlS9957rnnKgMWfq53QkKIPJ+SKKW4cuXXd3do2/oOKbmuKwCGKE3hoZEnTpwgu3dv/+bBBx/++lwyqJX0WSmqfD6fMhgMSCmlxcXFGwPCD85euOzIAwDQsWPHyuPHj/9H1/X6TZo0mXb6SXd0vaOIEDI/UOqWv1LhgIja9de3fq2R2dyh5sHSsrJ9lZWeiVJW77gYSLskvAUAWLFiRVefz4dSSoGIePDgwSU1B8ivRtu2bdtgn89XLaX0cZ17EVGUlpbunDFjRoNf+27BMsbWrVsH6twnUEqfTwhdIPLyiqM5o14Y1fBKUTcKALB69epbfV7vSQVkZWV9drUy3eAcIQCA0tLSXYESgwy+265du8b5V8Agu8Q+E0Qk9913X1hJyc+ZiIjcx6UUyBERc3Ky3wqcZ7iQoF97zITUjbwqEBgREYkQIl/XdSmV5EH5xcTE3B1YC3Cp0EgBAF577bXBISHG5vv37/uEapTSgDo9Hl9+wPDUeeJM7SoguMChLvF6QoipoqJic3Z29kf+aS5KxcbGpnzxxRc3U0oxWDa52JBHCMHY2NhRFRUVXxw6lLOIUgpSSgQAEELwiyEdtaIAKSUhpA7ueoBgMJlM3q1bt77m9Xp1BASTyWTq3LnzBEQEq9V6sTMtKCEEv/3223ZAoNXevXsnJSYmnt5xftHu9GsbYwwBACilAYpQR5RBQCilogcMGJBZUVHxPmOMSin12NjYPjt37uxLCFGXEgtatWkzp7yiwtWjR4+fjJoxuibTuVh2RS9Tx+sEHkkppVJKISL5uejnZX75EKJpGsTFxT0PABdMkwPDqiojI+NPoaGhXfft2TsTEQnnPCBIGnymuvoKqDtxgDDKKCEES7JLNpWVlW2llGpCCFGvXr3OGzZs6BYU7vnuZbVasVOnToYEs9lRXV2Vs2zZsm2EEAQKgYiugmhwUe+o/Z4VwBhjhPohoftD3cvXr1//3G233fYNpRQopRAfH38/IeSb8xGIoPV/+eWXN5sTEu46cODAE7Nnz64OxAUJ58ur/7AegIQopYKTs1hKSsq6kpKSryilmlIKGzZs2HfWrFkWSqk8V85itVoBALBx48a9Tpw4UbBt27aFwdhBKcVfcuO6ooA6spkqIUTVsEwCAGrjxo2TqqurOQCoevXqJd59992TAx5AzlHxVHPmzImPi4tLKy4uftJmsx0/cOCAVrMsESQgeJF8vFYUoGkaIqpfanZ1pNyvUAHSk1VNJISAy+XaXV1dfYRSyqSUqlGjRqkul6t9gBH9jzwcDgchhOBtt932JAAUtmjRYiki0vz8fFmzDnV6XeoaBAEAAhIKwe0GQCmlqNvtrszPz387iN9hYWEhN954Y/+a1lzT+imlcvny5Y0TExNHHT92fHaAbtJu3brhuQp1V1QB/mVcdZIF4f/mUkhGjhz5VklJyX5N0zQAwPr16/cGAEOAkpIa1k8REdq3bz+UUhrx08afliAinGlsQ8lLq2zUigKUUpQQCsF1zqRubaiNNVgpAgD94YcfPMXFxVMBgEghVb169drs2rXrb4FhSVrDkiUAkLCwsAeKi4tn2R6zFSHimbfDJFcRgiilChEgWJFCqFNjvqSmYAghEhFphw4d5lVUVPyXaf48oXHjxq8uW7YsFgBUsKJKKcXDhw8PkFImzpgxY2KAKeFpyR7UDMJXBYLqcBA4GyMjAKBKS0s/AQAipdQjIiJib7jhhuGBdWY0SGhCQkImHD169N0333yzHPwjgHharhFEgYBGroIHSCnr5P6jBAiVQRM91TIVIQQyMzOXVFVVlhFCNPCXqkevXbu2EQBIQojavHmzjRDSbu/evXMBgDgcDjwHCgTkf3EDbbWSCftjmd8KKKVn2YPtqrAgJPR/6UEQ6wkh2fv3Z77XokWr8UpxERkZ2YhzfjOldNnYsWNDmzVrNgkAdi1evPgA+ueWqDNk2+f8+48NQQBIKTWcja8jItmw4bs3KirKc2mgZtS6devBiAg9e/a8OSIiotXx48dfcPt3zaVn8f5TIehqxACsa6Mxwc4xGn62gYogIxo2bFjBoUMHp4F/xyBlsVj6zpkz5/amTZv2PXbs2MpmzZp9eTGD+IQQdtU8IIiDjLCrqpDg+AQhRDtPgoKISHbt2rcuUJ6glFJls9k+jI6Ofjg/P9+BiMTtdp8jAJ7a94udgPZ7DMIksAccMZlMYYSQs64/CGL6nDlz9h49enQFABCllIiKimpaVVW1snPnzpsBgNhstrNbPzuV/1NKTRcDQ7U6IlYXmt1uJ/7EkCAiRkopwwNwc7apKHT9+vVi//79b3DOgQZM+ejRo6sC559RmFu3bqWIyJRSpxw3Go3B513++FpzWorX60VE/9SP7OzsTwLHr5pnbN++vZ+u615d1z3btm275wL6QQ8fPvwxImJxUfGG+fPnR13I/KHMzMx/IaIQQlQjIi8rK9t05SjGKQrwIKIIKCDrqijAbrdrq1atijtw4MAwrNE8Hg/u2rVrwPLly+ud6Z2CI2KbNm1qU1FR4Vu3bl2PwPuzszwnZPXq1W1ycnIm4xlabm7uh2vWrGk/c+bMiCuSB9SRcgMWFhaGV1RUpHDOG2dnZ0/inCsAAAMzMCFEs5KSkhsdDse60ylpEOO7du26d8PaDQO2ZGzZGJjPKU8zOEIIQZPJlKxpWg8ppZaXlzfJ5/OpABVFTdMUISQyJCTkz7qufwcAGVccgg5lZy+52hD0W2m14gG/zAsKTkuhV03wwZUuZzl83sUhgQxZXaDxnaufeCH3qRUFnM6CFKirpoCAgOWvuF7V5nlXJw+49oHNa7WgKwl5drudBsYQLtrwLgsLqivV0CsIeQgA4HQ6LyqOXLYYAH+gz8vOnTvX0rJly3gpJRFCVHXv3n3fxcQH7RqIXLLlAyJC165dp/t8Po/X6y2Oj4+PKywsbFdSUvLCDTfc8M2FeMLlUsDvHoMCFXhmNBq9GRkZYwcMGHAMAGDbtm1D6tev/1J6evoGADjv5n6XKwj/USAIhRDSbDafNLiOHTsuEkIYKaWRgYIguUIegOCfVkOB0l8Slbo6WHO+5na7idVqPW/ixhgzNWzY8Kbdu3cXayFaeER4xEQlVO7w4cPLrhgE+fMA/4cQKAWQUvHaSlTqeAxQoSGhDaKiot7zeDxlzMDCCcHs7Tt2PgcA4HA4rhwLIoQApf4d+ENCQuN37NjRyWAwEM45apqGwYUMNZvB4B+uFUL8j6cEFlKccp3BYIAz3afmvc52/PRzg+edfk9CCDEYDCClZCdOnMjt2rVr8ZkWWgdel1Z7qkuKc4qfAoD8TZs2wbhx4zzBcy7kU7q1ogB/5wlAAHwsFsufzGZzxoVaUo0Onfp74NNSeJYvXASvO/33M6He+eZOBu9DCAEpJTDGoKSk5AUAmAr+ca8zBVSilJLl5eXHe/Xq5alRI8ILXahXKwrgnIOUSjFGgNLAZqkKTwnFNWaOnfKtlrOFCBL4ogUB8suXjQLTXmreh1L6P99+qXnOmZ55RjZS4xrCiAgwnPPWlAzMYIyLi9OCo2cXC71aLeEhCQkJOaXXlNEL6uxF1U1Ouy7494Xc72KeScE/x5IxFnK+c8sryktKSkpEgPFcdJ9+lQKCQaa6urqquKj4J4PRIALud5KKBl4KT09gLjbg1Qj4J1elXCj0BDD8lPrN2QxJKUXBX7bWPB5P3nnyGjlv3ry/T58+3VujLHFV+HqwBo81Xpj8BpMyUuP/IK++Ig+sFVr2+0mv/JK5QE8lv8bISF1UZh1TxbX2e27/D6SQwXf/o0k3AAAAAElFTkSuQmCC'
LOGO_ON_LIGHT = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAPN0lEQVR42u1be3SV1ZX/7X3O9+WGvAghChSSYMJbkKpAVWqAEbCW6prapL5R1xRHp84AyqhFjXEorZ0yVmc6q+pygIHxkWvr8gFChGLAZ0VxdESLoKi85OWDvO79vrP3/JHvakwTyFOzxjlrfSsr97v3O2fv/du/3z773At8jUMrwFoBxjdxVDQz/BvnhKqqMgMAy24+acxDt4yfAAAbKkrtN8r4u386cej/3Ddh9xvLTvnsgVvGTQKADRv+jztBI+Mf+9Xkca8vnbhj5wMTdPtDJ+u2ZRMPPr741DaRQASoglq7urom/iqNp/K4+4+bxw8rzpPVOX3MCXWBuKDRU5MR5o0o0jWPL/72aVMra8KWTlAFiKCtXV1dF32Vxt+5YOyIaSNiT2ekuyFJ50JyykatII3I98hIgEOvfJCcXnbT61s2bCi106bVhKrA8/eMW9ovzTvxcB2chGrDQJ1PIR/8uKH63EXbF6qCiSC9EgEp41dUjB89Zbi/KifNDnGhBDHfsx8eDC7cUycXZcTSDBIUehZ54wpiT/3+jlNOnjq1JpQ/NiHBsJnYL9uc2i/TTcrN0lOy0t3EvCxzqs80BgAQL6NemQIVFaWWyuPurutLik8s8NfnpWlxGLgAFLNvf6iXz1jwVtWUa1+Lb/2g4QJhAxUJY7Hk8ScNwZqnFo09mabWhBUVYFY6UJ8Q15DUZG1DKPWNYXCkIekCDeoAII547+OADRWltrKyJrxn/mkjv1vcrzrTTw6oEw3EOu/9veHscxa8stwywTBh+rwtD287YGaLMlMDJ2MW+cML7ZpHFw0bX1kJMcZLA6uBqiGAmZiJyIDJ9EoSrCorM1Mra8L75n2nZPww92RWpjshSGhorfW27aNLZ9yweYU1BBZvJIueYg3h7LnPPfD+fjsnLWb8xlACLyb544pzV907f8JwTSbqPSWofsF5CkCUtdc5oKoKpjwed/9648jhY0vCjVkxLW6UIGTy6d2d7opZ/7h5pWFCaP2SkMJqx/w0yEwyhlA698X739zrriJYK07DbJ8GnTEuWOv5GNnQSCAmJqSoX0HaJBZlKOsdDqiqKjPl5XBLrhldcvKA2BPZaW6gCznwgj5m50d68cybX11mDcGJPdGEYTUIQ1S1r6o+RU7PMAxMu/bVe9/7iK/0bczWJhvD7JhflJHhDWqQAASQQgFtkkZ0XQW7zwFVZTDl5XH3m78fXTBxuP9U35gObwgkVA29nXv1wrN/tvlhawih0+HM4WpRGZqSYlHJFcurrGemWUM4a95Ly975SK/OyOhjnXIojRAGR6pNoGjh3A0izt0W+Tjcv103qnBSSfr6vn1sSagaEIV4c1/tFWff8tLDhgmh0RHMtppAQ8AMUV1MRLcRMUgpJwz49yGZ0w0DpX/38u927sUCtdayIVVhVRCICIZJAYWQfP0cUFXVFPmKSwcWnJiXtirdC0oSYX3A5Js9e7yLLrz1z8sME1jsWOO4miGFSgRW3AvVhSJSqYLFUDiFyzHQNeTbUmOAiVe98OsPd4fz09JhxA+FocowCBWkxFDir7cUripryvlFc747cOqYvOp+WcGYhmQYUmC993bppbNufy1uDMFYb6QYrRZFgRJBRX7hnLsKgAfAU3ULiekGIiJxkqmBPgaYGdYQzpz74p079oYLctIzjOWYiCQVAKx6ME66vB/grsE+7pbMKy45o+TwM9npNKJRJPDYx4597sJzF73ygGGAWU9yzj0N1QFN2Yufq+qtAAyAMLpMGIZLiGgBEZGI5ED1MbU8wzCh9NpXf71jX/I6WBhD5AyFYkwAAtURQZG/v9NOMJ1n+7ibe/HIgZMHZ6zKyQhH1YcSGGu89w/wJeU/f+MhwwRj/dHisFpUhoAAIvqtc+76iL61BY0bEXmOmS2AM4WUjdL5RLyJIB8sW73nhbMm9a0f2DdtpktCGgQcOOcNzgmqpt+0ra6qDCa+teOyYDrF9pVbXcXFYwfPGGPW52S60QlBmEZp3vt77RXli7esNExwoicCqCaiwQBBgFtU5EYAthXjU8Oq6noiOkjE31dVH5DvwzOvG8WOB9ftf37W5MJk/0yZUVvf6HJi/sBB/bP+qn//5CPXxRP1nXGC6bDxcbgl1xSXTBjqrcqJ8ajQucAnn3YfwCU/uuNz48cx85OqOhiAEtHdKvKzKOXkKAKuAIyqvkREARFNU0UmKZWD5E9M2LGietez07+dF/TP9KcnwmQyu48/ZEh+3ykjijKeuHrlJ0c66gTTUeOvKSscMKUwrTo3i0Y1iCR9tf6OveFF5f/8xkO2yfjhzLxWVYcQEYhoiXPuumgubWf1YlR1ozEmVNVposqkdD6peZkZ7z5Ys3/TzAmFn+Vn0zn1jXWJ/tlphfl900qPz8momhv/uKEjTjDtZvv4VvdPV44qLC3y12ZlyqhGSYZM7O36NLzigl+99V9R5IcbpmqACpgZRLTIOXdzNI90sHTzROQZImogohkg8on5eyDvZSa386Ga3S9OHZ8vA/LTpjcmE4n+2WkFJYPSzxx03HF/+OkDHzVUlZWZ+Nat2mUHNEV+q/vF7BFFJw2m1TkZMiZwHPiG6b2DuOSiO/6cgv0Yj3k1wEUKgIjudc7NbwbtjhJUKh2eNcYogFKF9CHFhSDawoR34pv2bzxv6pDkgJzYzEToErnZGFpwvJ42tij3iSuXbWwXMZr2wH7OX48ceGaJtyEvnUbUuSAgZfv+R+6Sy+7cloL9MGZaD0UBmKCqt4vIdZHOC7pWtFsR2UBEnwL0PVUxRHQeiF5lwo6V1XuenfWd44/k55hz6kMk8nPTi/Ny087MpsyqeY8eajyWE8wxYf/jMcVnFodP9kmXUQknQR/P93Yd0qsuvWvbfzZJnTeMiNaqogBNOf9baWJ76gbjU0iwqvoCEdUx8wwR8YnoPGJ5hkG7Vqzb+8KsMwbqkPzYWfWNlMjJ5qITijK/W1joP3n10sO1VVVlJh5vPR3M0WC/8IejCk8epmvyYhgdBmHghMyej2n2Jb95e6lhgrM6Up2uVdWhqgpmXu6cm9Ni8d3SWYvS4TljjACYClWPYC9Qsq8xue0rnt5bc/7UokR+f29mGNQncrL8EwZkxib3yy76wz/cuqa+ogJcU/OX66HWTmwqKyF3zxk+sigXG/pl0IDagKDi9INDweyrfrdzhWHAWX84i1uvqoPRtCepVNXbIp133Wh887UaACEzzwH4HgKg5EKy/AMEssaJ4pl7J88vzveXBPV1yMxg7DmsW7dtb5hRvvi/d6uCWnaSTQs305RngGDrsG8V5MjS9HQM+CQRHIx5pnbPJ/68n/z7tuVNOY9ihq4hpSIFgVnvF9H57dD59pTm1OxqOSRCwmZDnFS4ExSoJ6WzjJU/hmHFoaGnrnj+3NICl5VBow/Wy+F01v4OsXFFo0etnTJzR2Nl5Zef22oNfU3Z6MwRmcn0Z9/1GwYMTvK+Xb7Ea7bWRh4sNsasEZHiJp3X+5zTOZ2Uuq6gQQGkR//70Z6iTivAVAlR3ewBMQLiAtSmAZkJosqw0zOWlcEcD2QY5i1sjDJzaIy5IzLcdMMZQ4bneWMAFAAYDKAIQOwoaGhrI0clJUgD8C0AAwEMAjAaQG5HWYdSV0U0WUZGxnFMfIiIHDNv6KYDlpSBWcx8GTPvJ6KPmbneGHPXMdSqZboYAGDmCsNUbw0+TbPmcMzahX2anEGdXWvqQ3kg2s3Maq19MIqC6U5sM/NPmFmJSI0x9Z7njY3m5/bwRywWK2TDtcSkZIySsfd1Zz+ACWBVhYjYbs55A4A9z1sHIKGqoYikh2E4O5qD28MLQRDMheIIFEdIVUmpJvqs1y0Nkea9+e4+RQMgIpIFYDsRVUWbqR8CyIyklY5ivADIYObTAdwGIK3pdSfRPflaT4c7MISIyPO82wAcADDUGHPjMVDAANRaez2AdSKykYh8bZKtxu5uiRGaNjs9AgUiElXNTCaT76jquggF10RsLq2gIBX9vgAuD4LgPs/z+hB9/jbX3Q7QY1WTXRnJZDJlkLHW/lJVwzAMc5n5B6mSuBXuUGvt3wD4BMBOY0xmTzVFtQfq/NbmUACZQRC8rqrLmVlV9W/b4AIBwER0rqouBEBBEHB718mdgX9PDt/3U4smAGSMWd6UGTSemS9rgQIDQHzfPxdArXNuNQB1zgUi0q419zoSjFLg8z1FGIZ/IqJNEedc3iyvU6kCEakkovvbmbLdlgI9KYfN/yastbdHxo43xkyP7nkAYK2dpKoumUyuSSHDWks9xQHNS0nqwRRo/nyTSCTWiciGyOhFzRFCRNcz878AqGuWGtTetOVuiFD3hl+VqJmGpUpca+3K6P5EZv4RAGetnUxEI4IgqIoMdR3lra6kQI8gIAgCqGrzZ7vo9UeIaGu0hh9Hf29yzq0HkGxhi37Zhz2TAj3FB94XZezn83AE8Zuj12cyczmAmHPu1uaE2MbzuhUBPUmEFDU3vFa0npxz64loj6pmENFKEVkO4EiqFG4lSFBV72jb4N4kgxRVdB4RpUUdnubdHwbwGTMvJSKo6iERebSV6CuARgCOiMLImd32jdL+APZGe/WH23O20MHUyjPGbLLWqjHml1EqmBbvybXW1lprb2hlfgaQQ0T3p3oKzLwlWje3hgLTQQdkALiaiDKJ6E1VfaQF/LrUbLHWlhNRjqq+CCCXmRtUdXuzyBKABmvtW0EQPB7xQvNnZDFzGTMPVdWXAWw2xhxg5oEi8iGAT7vaEeopBHREVag779keXGhn6ouWrS/Xxvu4DULWNtpnbXaubC8xvrkBrj1Nk3YoFbWnhLedXGRvH+3+6rztgvG90REpKT0DwHgRCYhon3Pu8WZy2ut7gl0ZHG2PJ6vqOyKyEcAsAKe31VPsMAc0q7Ep+rzBV/TLkw5wxhHn3A4AHzLzZwCynXOtclhXfqWVxBff8+tdMGDOYeZbiKhWRALn3NNt7RY7K4OqqqcS0W1oOq2VCB5R+a3UooxtqSLaDFKpmr3N97Q2PwDDzG+LyMpm/QFEKfCJiCwCsL07yQUA8onoML78Rcev7WLmTS2KsdTZ4PUAitsT5M6owKfRBiNsI0qtaTC1ce9Y/QZtIxgOgE9Eu1qTPxF5FsDhoxRTnS5sGE2nrHwUY74KB6Q6w3UADuL/R6uBoo7kdoe1tpeMLjdo/heEJS8leBivUwAAAABJRU5ErkJggg=='
TOKENS = open(SRC + '/assets/css/tokens.css').read()
POCKET = open(SRC + '/assets/css/pocket.css').read()
def _icons():
    import re
    src = open(SRC + '/includes/Support/Icon.php').read()
    i = src.index('public static function paths')
    body = re.search(r'return array\((.*?)\n\t\t\);', src[i:], re.S).group(1)
    return {m.group(1): m.group(2)
            for m in re.finditer(r"^\t\t\t'([a-z0-9-]+)'\s*=>\s*'((?:[^'\\]|\\.)*)'", body, re.M)}

ICONS = _icons()

BRAND = 'Mayfair Properties'


def ico(name, size=20):
    p = ICONS.get(name, '')
    return (f'<svg class="estat-icon estat-pocket-ico" width="{size}" height="{size}" '
            f'viewBox="0 0 256 256" fill="currentColor" aria-hidden="true" focusable="false">{p}</svg>')


NAV = [('today', 'home', 'Today'),
       ('leads', 'inbox', 'Leads'),
       ('listings', 'buildings', 'Properties'),
       ('visits', 'calendar', 'Visits')]

AGENT_NAME = 'Dev Kumar'
AGENT_INIT = 'DK'
AGENT_ROLE = 'Field Agent'
PLACE = 'Gurugram, Haryana'


def tab_link(slug, icon, label, door):
    on = ' is-on' if door == slug else ''
    return (f'<a class="estat-pocket-tab{on}" href="#" data-go="{slug}">'
            f'{ico(icon, 22)}<span>{label}</span></a>')


def add_door(door, cls):
    on = ' is-on' if door == 'capture' else ''
    return (f'<a class="{cls} estat-pocket-door estat-pocket-door--add{on}" href="#" '
            f'data-go="capture" aria-label="Add something new">'
            f'{ico("plus", 24)}<span>Add</span></a>')


def doors(door, add_cls):
    """The same five doors, in the same order, wherever they are placed."""
    split = len(NAV) // 2
    out = ''.join(tab_link(s, i, l, door) for s, i, l in NAV[:split])
    out += add_door(door, add_cls)
    out += ''.join(tab_link(s, i, l, door) for s, i, l in NAV[split:])
    return out


def topnav(door):
    """Across the top — kept for the tablet, where the brand needs room."""
    return ('<nav class="estat-pocket-topnav" aria-label="Sections">'
            + doors(door, 'estat-pocket-tab') + '</nav>')


TITLES = {'today': 'Today', 'leads': 'Leads', 'listings': 'My listings',
          'projects': 'Societies & projects',
          'visits': 'Site visits', 'listing': 'Listing', 'capture': 'Add something',
          'more': 'More', 'you': 'You', 'queue': 'Waiting to go up', 'login': 'Sign in'}


def tabs(door):
    """Along the bottom, for a phone and a tablet."""
    return ('<nav class="estat-pocket-tabs" aria-label="Sections">'
            + doors(door, 'estat-pocket-capture') + '</nav>')


# The desktop rail: the five doors first, then the two quieter places, with
# Add sitting where it sits on the bar — between Leads and Properties.
RAIL_BEFORE = [('today', 'home', 'Today'),
               ('leads', 'inbox', 'Leads')]
RAIL_AFTER = [('listings', 'buildings', 'Properties'),
              ('visits', 'calendar', 'Visits'),
              ('projects', 'compass', 'Societies & projects'),
              ('you', 'person', 'Your details')]


def sidebar(door):
    rows = ''.join(tab_link(s, i, l, door) for s, i, l in RAIL_BEFORE)
    on = ' is-on' if door == 'capture' else ''
    rows += (f'<a class="estat-pocket-tab estat-pocket-door estat-pocket-door--add{on}" href="#" '
             f'data-go="capture">{ico("plus", 18)}<span>Add</span></a>')
    rows += ''.join(tab_link(s, i, l, door) for s, i, l in RAIL_AFTER)
    return f"""<aside class="estat-pocket-sidebar" aria-label="Navigation">
      <a class="estat-pocket-sidebar-brand has-logo" href="#" data-go="today">
        <img class="estat-logo estat-logo--rail is-on-dark" src="{LOGO_ON_DARK}" alt="" aria-hidden="true">
        <span class="estat-pocket-sidebar-brandtxt">Mayfair Properties &amp; Developers<small>Office</small></span></a>
      <nav class="estat-pocket-sidebar-nav" aria-label="Sections">{rows}</nav>
      <div class="estat-pocket-sidebar-foot">
        <a class="estat-pocket-out" href="#" data-do="Signed out (preview only)">{ico("lock", 16)}
          <span class="estat-pocket-out-word">Sign out</span></a>
        <div class="estat-pocket-hint" style="margin:0">/agent</div>
      </div>
    </aside>"""


def head(door):
    """One bar for every size: the name, a search box, and the person."""
    return f"""<header class="estat-pocket-head">
    <a class="estat-pocket-brand has-logo" href="#" data-go="today">
      <span class="estat-pocket-brandmark is-logo"><img class="estat-logo" src="{LOGO_ON_LIGHT}" alt="" aria-hidden="true"></span>
      <span class="estat-pocket-brandtext"><span>Mayfair Properties</span></span>
    </a>
    <form class="estat-pocket-search" method="get" action="#" role="search">
      {ico("search", 18)}<input class="estat-pocket-input" type="search" name="q" value=""
      placeholder="Search leads, properties, clients..." enterkeyhint="search">
    </form>
    <div class="estat-pocket-headend">
      <a class="estat-pocket-bell" href="#" data-do="Nothing new to tell you" aria-label="Notifications">{ico("bell", 18)}</a>
      <span class="estat-pocket-user">
        <span class="estat-pocket-avatar">{AGENT_INIT}</span>
        <span class="estat-pocket-usernames"><b>{AGENT_NAME}</b><i>{AGENT_ROLE}</i></span>
      </span>
    </div>
  </header>"""


def search_bar():
    return (f'<form class="estat-pocket-search" method="get" action="#" role="search">'
            f'{ico("search", 18)}<input type="search" name="q" value="" '
            f'placeholder="Search a client, a property, a visit" enterkeyhint="search"></form>')


# ---------------------------------------------------------------- screens --
def stat(icon, number, word, go):
    return (f'<a class="estat-pocket-stat" href="#" data-go="{go}">{ico(icon, 18)}'
            f'<span class="estat-pocket-statnum"><b>{number}</b><i>{word}</i></span></a>')


def block(title, link, go, body, cls=''):
    head = f'<h3>{title}</h3>'
    if link:
        head += f'<a class="estat-pocket-blocklink" href="#" data-go="{go}">{link}</a>'
    # Same class the PHP writes (`is-quick`), not a private spelling of it:
    # a preview that invents its own class names measures a page that does
    # not exist, which is exactly how the 4.1.5 bento passed its checks and
    # still arrived broken on the live site.
    c = f' {cls}' if cls else ''
    return (f'<section class="estat-pocket-block{c}"><div class="estat-pocket-blockhead">'
            f'{head}</div>{body}</section>')


def taskrow(icon, when, title, detail, go):
    # The real rows carry a title and a detail line, and no clock — the
    # preview used to draw one, which is the same drift that hid the bento
    # bug: a preview richer than the app measures a page that does not exist.
    clock = ''
    return (f'<a class="estat-pocket-taskrow" href="#" data-go="{go}">'
            f'<span class="estat-pocket-well">{ico(icon, 16)}</span>{clock}'
            f'<span class="estat-pocket-taskrowtext"><b>{title}</b><i>{detail}</i></span></a>')


def visitrow(when, name, project, pill, tone):
    return (f'<a class="estat-pocket-visitrow" href="#" data-go="visits">'
            f'<span class="estat-pocket-visitwhen">{when}</span>'
            f'<span class="estat-pocket-taskrowtext"><b>{name}</b><i>{project}</i></span>'
            f'<span class="estat-pocket-pill {tone}">{pill}</span></a>')


def propcard(name, place, unit, price, pill, tone):
    tag = f'<span class="estat-pocket-pill {tone}">{pill}</span>' if pill else ''
    return (f'<a class="estat-pocket-prop" href="#" data-go="listing">'
            f'<span class="estat-pocket-propmedia">{ico("image", 22)}</span>'
            f'<span class="estat-pocket-taskrowtext"><b>{name}</b>'
            f'<span class="estat-pocket-propfacts"><span>{ico("map-pin", 12)} {place}</span>'
            f'<span>{ico("bed", 12)} {unit}</span></span></span>'
            f'<span class="estat-pocket-propprice"><b>{price}</b>{tag}</span></a>')


def screen_today():
    """Today, laid out the way the approved design shows it."""
    stats = ''.join(stat(*s) for s in [
        ('inbox', 12, 'New enquiries', 'leads'),
        ('phone', 8, 'Follow-ups due', 'leads'),
        ('calendar', 3, 'Site visit today', 'visits'),
        ('buildings', 24, 'Your properties', 'listings'),
        ('clock', 5, 'Waiting for approval', 'queue')])

    nxt = f"""<section class="estat-pocket-next">
      <div class="estat-pocket-nexttop">
        <span class="estat-pocket-well is-initial"><b>RS</b></span>
        <span class="estat-pocket-nexttext"><b>Rahul Sharma</b>
          <i>Looking for 3 BHK in Sector 57</i></span>
        <span class="estat-pocket-pill is-accent">New enquiry</span>
      </div>
      <div class="estat-pocket-nextmeta">
        <span>{ico("phone", 14)} +91 98765 43210</span>
        <span>{ico("map-pin", 14)} Sector 57, Gurugram</span>
      </div>
      <div class="estat-pocket-nextacts">
        <a class="estat-pocket-btn is-go" href="#" data-do="Calling Rahul Sharma (preview)">{ico("phone", 14)} Call now</a>
        <a class="estat-pocket-btn" href="#" data-go="leads">View details</a>
      </div>
    </section>"""

    quick = ''.join(
        f'<a class="estat-pocket-quickbtn" href="#" {how}="{to}">{ico(ic, 18)}<span>{word}</span></a>'
        for ic, word, how, to in [
            ('plus', 'Add property', 'data-go', 'capture'),
            ('inbox', 'Add enquiry', 'data-go', 'capture-lead'),
            ('camera', 'Take photos &amp; details', 'data-do', 'Camera opened (preview)'),
            ('person', 'New client enquiry', 'data-go', 'capture-lead'),
            ('calendar', 'Book visit', 'data-go', 'visits'),
            ('list-checks', 'Add preference', 'data-do', 'Preferences opened (preview)'),
            ('clock', 'Schedule site visit', 'data-go', 'visits'),
            ('form', 'Client requirements', 'data-do', 'Requirements opened (preview)')])
    quick = f'<div class="estat-pocket-quick">{quick}</div>'

    tasks = ''.join(taskrow(*t) for t in [
        ('phone', '11:00 AM', 'Follow up with Priya Singh', '2 BHK in Sector 56', 'leads'),
        ('map-pin', '3:00 PM', 'Site visit with Amit Verma', 'Mayfair Residency', 'visits'),
        ('camera', '', 'Add photos for property', 'DLF Phase 5', 'listings'),
        ('phone', '4:00 PM', 'Call Neha Gupta', 'Independent house in Sector 46', 'leads')])

    visits = ''.join(visitrow(*v) for v in [
        ('10:30 AM', 'Amit Verma', 'Mayfair Residency', 'Confirmed', 'is-good'),
        ('1:00 PM', 'Neha Gupta', 'DLF Phase 4', 'Reschedule', 'is-warn'),
        ('3:30 PM', 'Rajesh Mehta', 'Golf View Apartments', 'Pending', 'is-quiet')])

    props = ''.join(propcard(*p) for p in [
        ('Mayfair Residency', 'Sector 57', '3 BHK', '&#8377;1.8 Cr', '', ''),
        ('DLF Phase 5', 'Sector 53', '4 BHK', '&#8377;2.4 Cr', 'Pending', 'is-warn'),
        ('Ardee City Villa', 'Sector 52', '5 BHK', '&#8377;4.5 Cr', 'Draft', 'is-quiet')])

    lead = (f'<p class="estat-pocket-greet">Good morning, Dev</p>'
            f'<p class="estat-pocket-daymeta"><span>{ico("calendar", 14)} Tue, 7 Oct 2026</span>'
            f'<span>{ico("map-pin", 14)} {PLACE}</span></p>'
            f'<p class="estat-pocket-daylead">Here is your work for today</p>')

    head = f'<div class="estat-pocket-dayhead">{lead}</div>'
    left = (head
            + f'<div class="estat-pocket-stats">{stats}</div>'
            + nxt
            + block('Quick actions', '', 'capture', quick, 'is-quick')
            + block("Today's tasks", 'View all', 'today', tasks, 'is-tasks'))

    more = ''.join(
        f'<a class="estat-pocket-taskrow" href="#" data-go="{go}">'
        f'<span class="estat-pocket-well">{ico(ic, 16)}</span>'
        f'<span class="estat-pocket-taskrowtext"><b>{w}</b></span></a>'
        for ic, w, go in [
            ('search', 'Search everything', 'search'),
            ('menu', 'Waiting for you', 'more'),
            ('clock', 'Waiting to go up', 'queue'),
            ('buildings', 'Societies &amp; projects', 'projects'),
            ('person', 'Your details', 'you')])

    right = (block("Today's visits", 'See all', 'visits', visits, 'is-visits')
             + block('Your recent properties', 'See all', 'listings', props, 'is-props')
             + f'<div class="estat-pocket-moreblock">' + block('More', '', 'more', more) + '</div>')

    return (f'<div class="estat-pocket-day"><div class="estat-pocket-daymain">{left}</div>'
            f'<div class="estat-pocket-dayaside">{right}</div></div>')


def lead_card(initial, name, wants, meta, pill, tone, phone=''):
    call = (f'<a class="estat-pocket-btn is-go" href="#" data-do="Calling this client (preview)">{ico("phone", 14)} Call</a>' if phone
            else f'<a class="estat-pocket-btn is-go" href="#" data-do="Calling this client (preview)">{ico("phone", 14)} Call</a>')
    return f'''<div class="estat-pocket-person">
      <a class="estat-pocket-person-head" href="#">
        <span class="estat-pocket-avatar" aria-hidden="true">{initial}</span>
        <span class="estat-pocket-person-text"><b>{name}</b><i>{wants}</i>
          <span class="estat-pocket-person-meta">{meta}</span></span>
        <span class="estat-pocket-pill is-{tone}">{pill}</span></a>
      <div class="estat-pocket-person-acts">{call}
        <a class="estat-pocket-btn" href="#" data-do="WhatsApp opened (preview)">{ico("whatsapp", 14)} WhatsApp</a>
        <a class="estat-pocket-btn" href="#" data-do="Enquiry opened (preview)">Open</a></div></div>'''


def screen_leads():
    cards = (lead_card('A', 'Anita Rao', '3 BHK, Sector 57, up to 1.9 Cr',
                       'Follow-up 2 days ago', 'New', 'accent')
             + lead_card('S', 'Suresh Dey', 'Office space, 2,000 sq ft, Golf Course Road',
                         'Last contact 4 days ago', 'Contacted', 'accent')
             + lead_card('M', 'Meera Kapoor', 'Anything ready to move, Sohna Road',
                         'Follow-up yesterday', 'Scheduled', 'accent')
             + lead_card('R', 'Rohit Malhotra', '4 BHK penthouse, budget 3.5 Cr',
                         'Last contact 1 week ago', 'New', 'accent')
             + lead_card('K', 'Kavita Joshi', 'Rent, 2 BHK near the metro',
                         'Follow-up 3 days ago', 'Contacted', 'accent'))
    chips = (f'<a class="estat-pocket-chip is-on" href="#" data-do="Showing open leads">Open</a>'
             f'<a class="estat-pocket-chip" href="#" data-do="Showing won leads">Won</a>'
             f'<a class="estat-pocket-chip" href="#" data-do="Showing closed leads">Closed</a>'
             f'<a class="estat-pocket-chip" href="#" data-go="capture-lead">{ico("plus", 14)} Add an enquiry</a>')
    return ('<h1 class="estat-pocket-title">Leads</h1>'
            + f'<div class="estat-pocket-chips">{chips}</div>'
            + '<p class="estat-pocket-hint" style="margin:10px 0 0">5 open</p>' + cards)


def visit_card(name, when, title, word, tone):
    return f'''<a class="estat-pocket-task" href="#" data-go="visits">
      <div class="estat-pocket-tasktop"><span class="estat-pocket-well">{ico("calendar", 18)}</span>
        <div class="estat-pocket-tasktext"><b>{name}</b><i>{when} &middot; {title}</i></div>
        <span class="estat-pocket-pill is-{tone}">{word}</span></div></a>'''


def screen_visits():
    chips = (f'<a class="estat-pocket-chip is-on" href="#" data-do="Showing visits coming up">Coming up</a>'
             f'<a class="estat-pocket-chip" href="#" data-go="capture">{ico("plus", 14)} Book a visit</a>')
    out = ('<h1 class="estat-pocket-title">Site visits</h1>'
           + f'<div class="estat-pocket-chips">{chips}</div>'
           + visit_card('Meera Kapoor', 'Today, 4:00 pm', '2 BHK corner unit, Sushant Lok', 'Scheduled', 'accent')
           + visit_card('Suresh Dey', 'Tomorrow, 11:00 am', '3 BHK park facing, Sector 57', 'Scheduled', 'accent')
           + visit_card('Rohit Malhotra', 'Thu 9 Oct, 5:30 pm', '4 BHK penthouse, Golf Course Road', 'Scheduled', 'accent'))
    out += ('<h2 class="estat-pocket-h2">Just finished</h2>'
            + visit_card('Anita Rao', 'Yesterday, 4:00 pm', '3 BHK park facing, Sector 57', 'Done', 'positive'))
    return out


def row(title, line, facts, pill, tone, thumb='', starred=False):
    ph = thumb or f'<span class="estat-pocket-thumb is-empty">{ico("image", 18)}</span>'
    star = (f'<span class="estat-pocket-starform"><button type="button" '
            f'class="estat-pocket-star{" is-on" if starred else ""}" '
            f'data-do="{"Star taken off" if starred else "Starred. It is on your shortlist."}">'
            f'{ico("star", 17)}</button></span>')
    return f'''<div class="estat-pocket-rowwrap"><a class="estat-pocket-row" href="#" data-go="listing"><span class="estat-pocket-thumbwrap">{ph}</span>
      <span class="estat-pocket-rowmain"><b>{title}</b><i>{line}</i>{facts}</span>
      <span class="estat-pocket-pill is-{tone}">{pill}</span></a>{star}</div>'''


def screen_listings():
    rows = (row('3 BHK park facing', '1.85 Cr',
                '<span class="estat-pocket-facts">Available &middot; Verified</span>', 'On the website', 'positive')
            + row('2 BHK corner unit', '1.20 Cr',
                  '<span class="estat-pocket-facts">Available &middot; Unverified</span>', 'With the office', 'warn')
            + row('4 BHK penthouse with a terrace', '3.40 Cr',
                  '<span class="estat-pocket-facts">Available &middot; Verified</span>', 'On the website', 'positive')
            + row('Builder floor, 3 BHK', '98 L',
                  '<span class="estat-pocket-facts">Available</span>', 'Not finished yet', 'quiet')
            + row('Studio near the metro', '42 L',
                  '<span class="estat-pocket-facts">Available &middot; Verified</span>', 'On the website', 'positive'))
    chips = (f'<a class="is-on" href="#" data-do="Showing properties">Properties</a>'
             f'<a href="#" data-do="Showing societies &amp; projects">Societies &amp; Projects</a>')
    return (f'<h1 class="estat-pocket-title">My listings</h1>'
            + f'<form method="get" action="#" class="estat-pocket-search">'
              f'<input type="hidden" name="show" value="properties">'
              f'<input class="estat-pocket-input" type="search" name="q" value="" placeholder="Search title or locality">'
              f'<button class="estat-pocket-btn" type="submit">{ico("search", 16)}</button></form>'
            + f'<div class="estat-pocket-chips">{chips}</div>' + rows)


def screen_projects():
    """The same list, with the Societies & projects chip picked."""
    body = screen_listings()
    body = body.replace('<a class="is-on" href="#" data-do="Showing properties">Properties</a>',
                        '<a href="#" data-do="Showing properties">Properties</a>')
    body = body.replace('<a href="#" data-do="Showing societies &amp; projects">Societies &amp; Projects</a>',
                        '<a class="is-on" href="#" data-do="Showing societies &amp; projects">Societies &amp; Projects</a>')
    return body.replace('My listings', 'Societies &amp; projects')


def screen_listing():
    photos = ''.join(f'<span class="estat-pocket-photo" style="background:linear-gradient(140deg,#d9d5cb,#b9b4a6)"></span>'
                     for _ in range(4))
    facts = ''.join(f'<div class="estat-pocket-fact"><span>{k}</span><b>{v}</b></div>'
                    for k, v in [('Price', '1.85 Cr'), ('Size', '1,750 sq ft'),
                                 ('Bedrooms', '3'), ('Bathrooms', '3'),
                                 ('Facing', 'Park'), ('Floor', '4 of 12'),
                                 ('Furnishing', 'Semi'), ('Reference', 'MP-1042')])
    return f'''<a class="estat-pocket-back" href="#" data-go="listings">{ico("arrow-left", 14)} Back</a>
    <h1 class="estat-pocket-title">3 BHK park facing</h1>
    <p class="estat-pocket-sub">Sector 57, Gurugram &middot; MP-1042</p>
    <div class="estat-pocket-chips">
      <span class="estat-pocket-pill is-positive">On the website</span>
      <span class="estat-pocket-pill is-quiet">Available</span>
      <span class="estat-pocket-pill is-quiet">Verified</span></div>
    <div class="estat-pocket-photos">{photos}</div>
    <div class="estat-pocket-card">
      <h2 class="estat-pocket-h2">The facts</h2>
      <div class="estat-pocket-facts">{facts}</div></div>
    <div class="estat-pocket-card">
      <h2 class="estat-pocket-h2">What the office said</h2>
      <p class="estat-pocket-quote">Photographs of the balcony are still missing. Everything else is fine.</p></div>
    <a class="estat-pocket-btn is-go estat-pocket-big" href="#" data-do="Editor opens here (preview)">{ico("pencil", 16)} Edit this listing</a>
    <a class="estat-pocket-btn estat-pocket-big" href="#" data-do="Change request sent (preview)">Ask the office for a change</a>
    <a class="estat-pocket-btn is-danger estat-pocket-big" href="#" data-do="Moved to the bin (preview)">Move it to the bin</a>'''


def sheet_row(icon, title, detail, accent=False, go='capture'):
    well = 'estat-pocket-well is-accent' if accent else 'estat-pocket-well'
    return f'''<a class="estat-pocket-sheet-row" href="#" data-go="{go}">
      <span class="{well}">{ico(icon, 18)}</span>
      <span class="estat-pocket-rowmain"><b>{title}</b><i>{detail}</i></span>
      {ico("chevron-right", 16)}</a>'''


def screen_capture():
    rows = (sheet_row('buildings', 'Add a property', 'Photographs, price, the owner’s number — the full listing.', True, 'capture-lead')
            + sheet_row('inbox', 'Add an enquiry', 'Somebody asked about a property. Write it down before it is forgotten.', True, 'capture-lead')
            + sheet_row('calendar', 'Log a visit', 'Book a site visit, or write down one that has just happened.', True)
            + sheet_row('target', 'Add what a client wants', 'Their budget, areas and size — so the app can find matches later.', True)
            + sheet_row('key', 'Owner update', 'You have just spoken to the owner. Say what they said.', True))
    return ('<p class="estat-pocket-lead">What are you adding?</p>'
            + f'<div class="estat-pocket-sheet">{rows}</div>'
            + '<p class="estat-pocket-hint">Nothing is saved until you press the button on the form itself.</p>')


def screen_more():
    work = (sheet_row('check-circle', 'Waiting for you', '3 change requests', go='more')
            + sheet_row('pencil', 'Ask the office for a change', 'A price, a photograph, a status — reviewed by a person.', go='more')
            + sheet_row('clock', 'Waiting to go up', 'Filled in where there was no network. The phone sends them when it can.', go='queue')
            + sheet_row('buildings', 'Societies and projects', 'Society pages, apart from the property list.', go='listings'))
    you = (sheet_row('person', 'Your details', 'Name, numbers, language, password.', go='you')
           + sheet_row('search', 'Search everything', 'Clients, properties and visits in one box.', go='search'))
    office = sheet_row('list-checks', 'Approvals', 'New listings and changes sent up from the phones.', go='more')
    return (f'<h1 class="estat-pocket-title">More</h1>'
            f'<h2 class="estat-pocket-h2">Work</h2><div class="estat-pocket-sheet">{work}</div>'
            f'<h2 class="estat-pocket-h2">You</h2><div class="estat-pocket-sheet">{you}</div>'
            f'<h2 class="estat-pocket-h2">Office</h2><div class="estat-pocket-sheet">{office}</div>')


def field(label, name, kind, value, ph=''):
    return (f'<label class="estat-pocket-label" for="f-{name}">{label}</label>'
            f'<input class="estat-pocket-input" id="f-{name}" name="{name}" type="{kind}" '
            f'value="{value}" placeholder="{ph}">')


def screen_you():
    langs = ''.join(f'<a class="estat-pocket-pill {"is-accent" if on else "is-quiet"}" href="#" data-do="Language changed (preview)">'
                    f'{ico("check", 12) + " " if on else ""}{w}</a>'
                    for w, on in [('English', True), ('हिन्दी', False)])
    return f'''<h1 class="estat-pocket-title">You</h1>
    <div class="estat-pocket-banner">{ico("person", 14)}
      <div>Your own details live here. The office's settings live on the office screens &mdash;
      this page only changes what belongs to you.</div></div>
    <form class="estat-pocket-card" method="post" action="#">
      <h2 class="estat-pocket-h2">My details</h2>
      <p class="estat-pocket-hint">The office sees these, and your number is the one a client calls about your properties.</p>
      {field("My name", "name", "text", "Anita Verma")}
      {field("My phone", "phone", "tel", "9811122335", "Where clients should call")}
      {field("My WhatsApp", "whatsapp", "tel", "9811122335", "Same as the phone number, if that is easier")}
      {field("My email", "email", "email", "anita@mayfairproperties.in")}
      <button class="estat-pocket-btn is-go" type="submit" data-do="Details saved (preview)">Save my details</button></form>
    <div class="estat-pocket-card">
      <h2 class="estat-pocket-h2">{ico("globe", 16)} The language I read</h2>
      <p class="estat-pocket-hint">This changes the app on this login only.</p>
      <div class="estat-pocket-chips">{langs}</div></div>'''


def favrow(title, line, facts, pill, tone, starred=True):
    return row(title, line, facts, pill, tone, starred=starred)


def screen_favourites():
    rows = (favrow('3 BHK park facing', '1.85 Cr',
                   '<span class="estat-pocket-facts">Available &middot; Verified</span>', 'On the website', 'positive')
            + favrow('4 BHK penthouse with a terrace', '3.40 Cr',
                     '<span class="estat-pocket-facts">Available &middot; Verified</span>', 'On the website', 'positive')
            + favrow('2 BHK corner unit', '1.20 Cr',
                     '<span class="estat-pocket-facts">Available &middot; Unverified</span>', 'With the office', 'warn'))
    chips = (f'<a class="is-on" href="#" data-go="compare">{ico("columns", 14)} Side by side</a>'
             f'<a href="#" data-go="listings">All properties</a>')
    return ('<a class="estat-pocket-back" href="#" data-go="listings">'
            f'{ico("arrow-left", 14)} Back</a>'
            '<p class="estat-pocket-lead">3 properties are on your shortlist.</p>'
            f'<div class="estat-pocket-chips">{chips}</div>' + rows
            + '<form class="estat-pocket-card estat-pocket-clearform">'
              f'<button type="button" class="estat-pocket-btn is-quiet" data-do="Shortlist emptied">'
              'Empty the shortlist</button>'
              '<p class="estat-pocket-hint" style="margin:8px 0 0">This only clears your own list. '
              'Nothing about the properties themselves changes.</p></form>')


def cmpcol(name, price, facts):
    rows = ''.join(
        f'<div class="estat-pocket-cmprow"><span>{k}</span><b>{v}</b></div>' for k, v in facts)
    return (f'<div class="estat-pocket-cmpcol"><a class="estat-pocket-cmphead" href="#" data-go="listing">'
            f'<span class="estat-pocket-thumbwrap"><span class="estat-pocket-thumb is-empty">{ico("image", 18)}</span></span>'
            f'<b>{name}</b></a>{rows}</div>')


def screen_compare():
    a = cmpcol('3 BHK park facing', '1.85 Cr', [
        ('Price', '1.85 Cr'), ('Size', '1,450 sq ft'), ('Bedrooms', '3'), ('Bathrooms', '3'),
        ('Floor', '7'), ('Furnishing', 'Semi-furnished'), ('Parking', '2'),
        ('Where', 'Sector 57'), ('Availability', 'Available now'), ('Society', 'Mayfair Residency')])
    b = cmpcol('4 BHK penthouse', '3.40 Cr', [
        ('Price', '3.40 Cr'), ('Size', '2,600 sq ft'), ('Bedrooms', '4'), ('Bathrooms', '4'),
        ('Floor', '14'), ('Furnishing', 'Furnished'), ('Parking', '3'),
        ('Where', 'Golf Course Road'), ('Availability', 'Available now'), ('Society', 'DLF Phase 5')])
    c = cmpcol('2 BHK corner unit', '1.20 Cr', [
        ('Price', '1.20 Cr'), ('Size', '1,050 sq ft'), ('Bedrooms', '2'), ('Bathrooms', '2'),
        ('Floor', '3'), ('Furnishing', '<i class="estat-pocket-none">not said</i>'), ('Parking', '1'),
        ('Where', 'Sushant Lok'), ('Availability', 'Available now'), ('Society', 'Ardee City')])
    return ('<a class="estat-pocket-back" href="#" data-go="favourites">'
            f'{ico("arrow-left", 14)} Back</a>'
            '<p class="estat-pocket-lead">These 3, side by side.</p>'
            f'<div class="estat-pocket-cmp" style="--cols:3">{a}{b}{c}</div>')


def screen_queue():
    rows = ''.join(f'''<div class="estat-pocket-row"><span class="estat-pocket-rowmain">
      <b>{t}</b><i>{w} &middot; {n}</i></span>
      <span class="estat-pocket-pill is-quiet">Waiting</span></div>'''
        for t, w, n in [('3 BHK, Sector 62', 'Filled 2 hours ago', 'Tried 3 times'),
                        ('Owner update — Arize Tessoro', 'Filled yesterday', 'Tried 1 time')])
    return (f'<a class="estat-pocket-back" href="#" data-go="today">{ico("arrow-left", 14)} Back</a>'
            '<p class="estat-pocket-lead">Filled in where there was no network. Each one goes up '
            'by itself as soon as the phone can send it.</p>'
            + f'<div class="estat-pocket-sheet">{rows}</div>')


def screen_login():
    return f'''<div class="estat-pocket-login"><div class="estat-pocket-login-mark has-logo"><img class="estat-logo estat-logo--login" src="{LOGO_ON_LIGHT}" alt="" aria-hidden="true"></div>
      <h1 class="estat-pocket-login-title">Agent pocket</h1>
      <p class="estat-pocket-lead">Add and update listings from anywhere. Everything you send is
        checked by the office before it reaches the website.</p>
      <form class="estat-pocket-card estat-pocket-login-card" method="post" action="#">
        <label class="estat-pocket-label" for="estat-p-log">Username, email or your phone number</label>
        <input class="estat-pocket-input" id="estat-p-log" name="log" type="text" autocomplete="username" required>
        <label class="estat-pocket-label" for="estat-p-pwd">Password</label>
        <input class="estat-pocket-input" id="estat-p-pwd" name="pwd" type="password" autocomplete="current-password" required>
        <label class="estat-pocket-check"><input type="checkbox" name="rememberme" value="forever"> Remember me</label>
        <button class="estat-pocket-btn is-go" type="submit">Sign in</button></form>
      <p class="estat-pocket-hint">This is your office WordPress account &mdash; the same one that
        opens the dashboard.</p></div>'''


def screen_capture_lead():
    return ('<a class="estat-pocket-back" href="#" data-go="leads">'
            + ico('arrow-left', 14) + ' Back</a>'
            + '<h1 class="estat-pocket-title">Add an enquiry</h1>'
            + '<p class="estat-pocket-lead">Somebody asked about a property. Write it down '
              'before it is forgotten.</p>'
            + '<form class="estat-pocket-card" method="post" action="#">'
            + field('Their name', 'name', 'text', '')
            + field('Their phone', 'phone', 'tel', '', 'Where to call them back')
            + field('What they want', 'want', 'text', '', '3 BHK, Sector 57')
            + field('Their budget', 'budget', 'text', '', 'Up to 1.9 Cr')
            + '<button class="estat-pocket-btn is-go" type="submit" '
              'data-do="Enquiry saved (preview only)">Save the enquiry</button></form>')


def screen_search():
    rows = ''.join(
        f'''<a class="estat-pocket-row" href="#" data-go="{go}">
          <span class="estat-pocket-well">{ico(ic, 18)}</span>
          <span class="estat-pocket-rowmain"><b>{t}</b><i>{d}</i></span></a>'''
        for ic, t, d, go in [
            ('person', 'Anita Rao', 'Client &middot; 3 BHK, Sector 57', 'leads'),
            ('home', '3 BHK park facing', 'Property &middot; 1.85 Cr', 'listing'),
            ('calendar', 'Site visit, today 4 pm', 'Visit &middot; Meera Kapoor', 'visits'),
            ('buildings', 'Arize Tessoro', 'Society &middot; Sector 69', 'listings')])
    return ('<h1 class="estat-pocket-title">Search</h1>'
            + '<p class="estat-pocket-hint" style="margin:10px 0 0">Four things match</p>'
            + f'<div class="estat-pocket-sheet">{rows}</div>')


SCREENS = [('today', screen_today), ('leads', screen_leads), ('visits', screen_visits),
           ('listings', screen_listings), ('projects', screen_projects), ('listing', screen_listing),
           ('capture', screen_capture), ('capture-lead', screen_capture_lead),
           ('search', screen_search), ('more', screen_more),
           ('you', screen_you), ('queue', screen_queue),
           ('favourites', screen_favourites), ('compare', screen_compare),
           ('login', screen_login)]

# Which door lights up on the bar for each screen — a property page still
# reads "Properties", the way it does in the plugin.
DOORS = {'today': 'today', 'leads': 'leads', 'visits': 'visits', 'listings': 'listings',
         'projects': 'listings', 'listing': 'listings', 'capture': 'capture',
         'capture-lead': 'capture',
         'search': '', 'more': 'more', 'you': 'more',
         'queue': 'more', 'favourites': 'listings', 'compare': 'listings',
         'login': 'today'}


# ---------------------------------------------------------------- chrome
# A thin bar for choosing which screen to look at, and nothing else. There
# is deliberately no device switcher: the page is the browser window, so
# narrowing the window is what shows the phone.
CHROME = """
<style>
  html, body { margin: 0; padding: 0; }
  body { background: #20211f; font: 13px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
  .pkbar { position: fixed; top: 0; left: 0; right: 0; height: 46px; z-index: 99999;
    display: flex; align-items: center; gap: 8px; padding: 0 14px; overflow-x: auto;
    background: #16171a; border-bottom: 1px solid #2f3134; color: #b6b8bd; }
  .pkbar b { color: #f2f0eb; font-size: 13px; font-weight: 600; margin-right: 6px; white-space: nowrap; }
  .pkbar .lbl { font-size: 9px; text-transform: uppercase; letter-spacing: .09em; color: #7d7f85; white-space: nowrap; }
  .pkbar .sep { width: 1px; height: 22px; background: #33353a; margin: 0 4px; flex: none; }
  .pkbar .chip { padding: 4px 10px; border-radius: 99px; border: 1px solid #33353a; background: #1e2023;
    color: #b6b8bd; font: 12px/1 inherit; cursor: pointer; white-space: nowrap; flex: none; }
  .pkbar .chip:hover { border-color: #4a4d52; color: #f2f0eb; }
  .pkbar .chip.is-on { background: #a68b5b; border-color: #a68b5b; color: #16171a; font-weight: 700; }
  .pkwrap { padding-top: 46px; }
  .pktoasts { position: fixed; left: 50%; bottom: 22px; transform: translateX(-50%);
    z-index: 999999; display: flex; flex-direction: column; gap: 8px; align-items: center;
    pointer-events: none; width: max-content; max-width: calc(100vw - 32px); }
  .pktoast { background: #16171a; color: #f6f5f1; font-size: 12.5px; font-weight: 500;
    padding: 9px 15px; border-radius: 10px; box-shadow: 0 10px 28px rgba(0,0,0,.38);
    opacity: 0; transform: translateY(8px); transition: opacity .22s ease, transform .22s ease; }
  .pktoast.is-in { opacity: 1; transform: translateY(0); }
  /* The bar takes the top 46px, so the pocket's sticky furniture starts below it. */
  .pkwrap .estat-pocket-head { top: 46px; }
  .pkwrap .estat-pocket-main { min-height: calc(100vh - 46px); }
  .pkwrap .estat-pocket-sidebar { top: 46px; height: calc(100vh - 46px); }
</style>
"""

SCREEN_NAMES = {s: n for s, n in [
    ('today', 'Today'), ('leads', 'Leads'), ('visits', 'Visits'),
    ('listings', 'Properties'), ('projects', 'Societies'), ('listing', 'Listing'), ('capture', 'Add'),
    ('capture-lead', 'Add enquiry'), ('search', 'Search'),
    ('more', 'More'), ('you', 'You'), ('queue', 'Waiting'),
    ('favourites', 'Shortlist'), ('compare', 'Side by side'),
    ('login', 'Sign in')]}

def section(slug):
    """One screen, as the plugin draws it, ready to drop into the page."""
    door   = DOORS[slug]
    body   = dict(SCREENS)[slug]()
    bare   = slug == 'login'
    wide   = ' is-wide' if slug == 'today' else ''
    return ('' if bare else sidebar(door)) \
        + '<main class="estat-pocket-main"><div class="estat-pocket-screen">' \
        + ('' if bare else head(door)) \
        + f'<div class="estat-pocket-page{wide}">' + body + '</div></div></main>' \
        + ('' if bare else tabs(door))

sections = "\n".join(
    f'<div class="pkscreen" data-screen="{slug}" style="display:none">'
    f'<div class="estat-pocket"><div class="estat-pocket-app">{section(slug)}</div></div></div>'
    for slug, _ in SCREENS)

chips = "\n".join(
    f'<button type="button" class="chip{" is-on" if i == 0 else ""}" data-go="{slug}">'
    f'{SCREEN_NAMES[slug]}</button>'
    for i, (slug, _) in enumerate(SCREENS))

HTML = f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Agent Pocket — /agent</title>
<style>{TOKENS}</style>
<style>{POCKET}</style>
{CHROME}</head><body class="pk-dark">

<!-- the preview is a plain page: the switcher lives out of sight, so the
     keyboard still moves between screens but nothing is drawn over the app -->
<span id="chips" hidden>{chips}</span>

<div class="pkwrap estat-pocket">{sections}</div>

<script>
(function () {{
  var slug = 'today';
  var bar  = document.getElementById('chips');

  /* ---- a toast, so an action answers back --------------------------- */
  var holder = document.createElement('div');
  holder.className = 'pktoasts';
  document.body.appendChild(holder);

  function toast(text) {{
    var t = document.createElement('div');
    t.className = 'pktoast';
    t.textContent = text;
    holder.appendChild(t);
    requestAnimationFrame(function () {{ t.classList.add('is-in'); }});
    setTimeout(function () {{
      t.classList.remove('is-in');
      setTimeout(function () {{ t.remove(); }}, 260);
    }}, 2200);
  }}

  /* ---- the router --------------------------------------------------- */
  function show(next) {{
    if (!document.querySelector('.pkscreen[data-screen="' + next + '"]')) {{ return; }}
    slug = next;
    document.querySelectorAll('.pkscreen').forEach(function (sec) {{
      sec.style.display = sec.getAttribute('data-screen') === slug ? '' : 'none';
    }});
    bar.querySelectorAll('.chip').forEach(function (c) {{
      c.classList.toggle('is-on', c.getAttribute('data-go') === slug);
    }});
    window.scrollTo(0, 0);
    document.title = slug + ' — Agent Pocket';
  }}

  /*
   * Anything that means "take me somewhere" carries data-go; anything
   * that means "do this" carries data-do. Both answer, so nothing in the
   * preview is a dead end.
   */
  document.addEventListener('click', function (e) {{
    var go = e.target.closest('[data-go]');
    if (go) {{ e.preventDefault(); show(go.getAttribute('data-go')); return; }}

    var act = e.target.closest('[data-do]');
    if (act) {{ e.preventDefault(); toast(act.getAttribute('data-do')); return; }}

    var dead = e.target.closest('a[href="#"], button:not([type]), form');
    if (dead) {{
      e.preventDefault();
      toast('This part talks to the server — it works on the live site.');
    }}
  }});

  bar.addEventListener('click', function (e) {{
    var c = e.target.closest('.chip[data-go]');
    if (c) {{ show(c.getAttribute('data-go')); }}
  }});

  document.querySelectorAll('.chip[data-theme]').forEach(function (c) {{
    c.addEventListener('click', function () {{
      var light = c.getAttribute('data-theme') === 'light';
      document.body.classList.toggle('pk-light', light);
      document.body.classList.toggle('pk-dark', !light);
      document.querySelectorAll('.chip[data-theme]').forEach(function (x) {{
        x.classList.toggle('is-on', x.getAttribute('data-theme') === (light ? 'light' : 'dark'));
      }});
      toast(light ? 'Sidebar: white (the old one)' : 'Sidebar: black');
    }});
  }});

  /* Which layout is on screen, following the real window width. */
  function mark() {{
    var w = window.innerWidth;
    var d = w < 768 ? 'mobile' : w < 1024 ? 'tablet' : 'desktop';
    document.body.setAttribute('data-device', d);
    
  }}
  window.addEventListener('resize', mark);

  /* Keyboard: 1..9 jump between screens, Esc goes home. */
  document.addEventListener('keydown', function (e) {{
    if (e.key === 'Escape') {{ show('today'); return; }}
    if (e.target.matches('input, textarea, select')) {{ return; }}
    var all = Array.prototype.slice.call(bar.querySelectorAll('.chip[data-go]'));
    var n = parseInt(e.key, 10);
    if (n >= 1 && n <= Math.min(9, all.length)) {{ show(all[n - 1].getAttribute('data-go')); }}
  }});

  mark();
  show('today');
  window.__showScreen = show;
}})();
</script>
</body></html>"""

open('/home/user/preview-pocket.html', 'w').write(HTML)
print('written', len(HTML), 'bytes')
