#!/usr/bin/env python3
"""Build a self-contained preview of the office inside wp-admin.

It renders every screen the layout had to be fixed on — Today, Properties,
Societies & Projects, Team, Gallery, Reports and the Bin — using the same
markup the PHP emits, so the preview can be measured instead of guessed at.
"""

import json
import re

SRC = '/home/user/plugin/estat-os'
SPRITE = re.search(r"<<<'SPRITE_HTML'\n(.*?)\nSPRITE_HTML;",
                   open(SRC + '/includes/Admin/Os/Ui.php').read(), re.S).group(1)
# The office's own mark, inlined: the preview renders with no network.
MD_LOGO = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAPN0lEQVR42u1be3SV1ZX/7X3O9+WGvAghChSSYMJbkKpAVWqAEbCW6prapL5R1xRHp84AyqhFjXEorZ0yVmc6q+pygIHxkWvr8gFChGLAZ0VxdESLoKi85OWDvO79vrP3/JHvakwTyFOzxjlrfSsr97v3O2fv/du/3z773At8jUMrwFoBxjdxVDQz/BvnhKqqMgMAy24+acxDt4yfAAAbKkrtN8r4u386cej/3Ddh9xvLTvnsgVvGTQKADRv+jztBI+Mf+9Xkca8vnbhj5wMTdPtDJ+u2ZRMPPr741DaRQASoglq7urom/iqNp/K4+4+bxw8rzpPVOX3MCXWBuKDRU5MR5o0o0jWPL/72aVMra8KWTlAFiKCtXV1dF32Vxt+5YOyIaSNiT2ekuyFJ50JyykatII3I98hIgEOvfJCcXnbT61s2bCi106bVhKrA8/eMW9ovzTvxcB2chGrDQJ1PIR/8uKH63EXbF6qCiSC9EgEp41dUjB89Zbi/KifNDnGhBDHfsx8eDC7cUycXZcTSDBIUehZ54wpiT/3+jlNOnjq1JpQ/NiHBsJnYL9uc2i/TTcrN0lOy0t3EvCxzqs80BgAQL6NemQIVFaWWyuPurutLik8s8NfnpWlxGLgAFLNvf6iXz1jwVtWUa1+Lb/2g4QJhAxUJY7Hk8ScNwZqnFo09mabWhBUVYFY6UJ8Q15DUZG1DKPWNYXCkIekCDeoAII547+OADRWltrKyJrxn/mkjv1vcrzrTTw6oEw3EOu/9veHscxa8stwywTBh+rwtD287YGaLMlMDJ2MW+cML7ZpHFw0bX1kJMcZLA6uBqiGAmZiJyIDJ9EoSrCorM1Mra8L75n2nZPww92RWpjshSGhorfW27aNLZ9yweYU1BBZvJIueYg3h7LnPPfD+fjsnLWb8xlACLyb544pzV907f8JwTSbqPSWofsF5CkCUtdc5oKoKpjwed/9648jhY0vCjVkxLW6UIGTy6d2d7opZ/7h5pWFCaP2SkMJqx/w0yEwyhlA698X739zrriJYK07DbJ8GnTEuWOv5GNnQSCAmJqSoX0HaJBZlKOsdDqiqKjPl5XBLrhldcvKA2BPZaW6gCznwgj5m50d68cybX11mDcGJPdGEYTUIQ1S1r6o+RU7PMAxMu/bVe9/7iK/0bczWJhvD7JhflJHhDWqQAASQQgFtkkZ0XQW7zwFVZTDl5XH3m78fXTBxuP9U35gObwgkVA29nXv1wrN/tvlhawih0+HM4WpRGZqSYlHJFcurrGemWUM4a95Ly975SK/OyOhjnXIojRAGR6pNoGjh3A0izt0W+Tjcv103qnBSSfr6vn1sSagaEIV4c1/tFWff8tLDhgmh0RHMtppAQ8AMUV1MRLcRMUgpJwz49yGZ0w0DpX/38u927sUCtdayIVVhVRCICIZJAYWQfP0cUFXVFPmKSwcWnJiXtirdC0oSYX3A5Js9e7yLLrz1z8sME1jsWOO4miGFSgRW3AvVhSJSqYLFUDiFyzHQNeTbUmOAiVe98OsPd4fz09JhxA+FocowCBWkxFDir7cUripryvlFc747cOqYvOp+WcGYhmQYUmC993bppbNufy1uDMFYb6QYrRZFgRJBRX7hnLsKgAfAU3ULiekGIiJxkqmBPgaYGdYQzpz74p079oYLctIzjOWYiCQVAKx6ME66vB/grsE+7pbMKy45o+TwM9npNKJRJPDYx4597sJzF73ygGGAWU9yzj0N1QFN2Yufq+qtAAyAMLpMGIZLiGgBEZGI5ED1MbU8wzCh9NpXf71jX/I6WBhD5AyFYkwAAtURQZG/v9NOMJ1n+7ibe/HIgZMHZ6zKyQhH1YcSGGu89w/wJeU/f+MhwwRj/dHisFpUhoAAIvqtc+76iL61BY0bEXmOmS2AM4WUjdL5RLyJIB8sW73nhbMm9a0f2DdtpktCGgQcOOcNzgmqpt+0ra6qDCa+teOyYDrF9pVbXcXFYwfPGGPW52S60QlBmEZp3vt77RXli7esNExwoicCqCaiwQBBgFtU5EYAthXjU8Oq6noiOkjE31dVH5DvwzOvG8WOB9ftf37W5MJk/0yZUVvf6HJi/sBB/bP+qn//5CPXxRP1nXGC6bDxcbgl1xSXTBjqrcqJ8ajQucAnn3YfwCU/uuNz48cx85OqOhiAEtHdKvKzKOXkKAKuAIyqvkREARFNU0UmKZWD5E9M2LGietez07+dF/TP9KcnwmQyu48/ZEh+3ykjijKeuHrlJ0c66gTTUeOvKSscMKUwrTo3i0Y1iCR9tf6OveFF5f/8xkO2yfjhzLxWVYcQEYhoiXPuumgubWf1YlR1ozEmVNVposqkdD6peZkZ7z5Ys3/TzAmFn+Vn0zn1jXWJ/tlphfl900qPz8momhv/uKEjTjDtZvv4VvdPV44qLC3y12ZlyqhGSYZM7O36NLzigl+99V9R5IcbpmqACpgZRLTIOXdzNI90sHTzROQZImogohkg8on5eyDvZSa386Ga3S9OHZ8vA/LTpjcmE4n+2WkFJYPSzxx03HF/+OkDHzVUlZWZ+Nat2mUHNEV+q/vF7BFFJw2m1TkZMiZwHPiG6b2DuOSiO/6cgv0Yj3k1wEUKgIjudc7NbwbtjhJUKh2eNcYogFKF9CHFhSDawoR34pv2bzxv6pDkgJzYzEToErnZGFpwvJ42tij3iSuXbWwXMZr2wH7OX48ceGaJtyEvnUbUuSAgZfv+R+6Sy+7cloL9MGZaD0UBmKCqt4vIdZHOC7pWtFsR2UBEnwL0PVUxRHQeiF5lwo6V1XuenfWd44/k55hz6kMk8nPTi/Ny087MpsyqeY8eajyWE8wxYf/jMcVnFodP9kmXUQknQR/P93Yd0qsuvWvbfzZJnTeMiNaqogBNOf9baWJ76gbjU0iwqvoCEdUx8wwR8YnoPGJ5hkG7Vqzb+8KsMwbqkPzYWfWNlMjJ5qITijK/W1joP3n10sO1VVVlJh5vPR3M0WC/8IejCk8epmvyYhgdBmHghMyej2n2Jb95e6lhgrM6Up2uVdWhqgpmXu6cm9Ni8d3SWYvS4TljjACYClWPYC9Qsq8xue0rnt5bc/7UokR+f29mGNQncrL8EwZkxib3yy76wz/cuqa+ogJcU/OX66HWTmwqKyF3zxk+sigXG/pl0IDagKDi9INDweyrfrdzhWHAWX84i1uvqoPRtCepVNXbIp133Wh887UaACEzzwH4HgKg5EKy/AMEssaJ4pl7J88vzveXBPV1yMxg7DmsW7dtb5hRvvi/d6uCWnaSTQs305RngGDrsG8V5MjS9HQM+CQRHIx5pnbPJ/68n/z7tuVNOY9ihq4hpSIFgVnvF9H57dD59pTm1OxqOSRCwmZDnFS4ExSoJ6WzjJU/hmHFoaGnrnj+3NICl5VBow/Wy+F01v4OsXFFo0etnTJzR2Nl5Zef22oNfU3Z6MwRmcn0Z9/1GwYMTvK+Xb7Ea7bWRh4sNsasEZHiJp3X+5zTOZ2Uuq6gQQGkR//70Z6iTivAVAlR3ewBMQLiAtSmAZkJosqw0zOWlcEcD2QY5i1sjDJzaIy5IzLcdMMZQ4bneWMAFAAYDKAIQOwoaGhrI0clJUgD8C0AAwEMAjAaQG5HWYdSV0U0WUZGxnFMfIiIHDNv6KYDlpSBWcx8GTPvJ6KPmbneGHPXMdSqZboYAGDmCsNUbw0+TbPmcMzahX2anEGdXWvqQ3kg2s3Maq19MIqC6U5sM/NPmFmJSI0x9Z7njY3m5/bwRywWK2TDtcSkZIySsfd1Zz+ACWBVhYjYbs55A4A9z1sHIKGqoYikh2E4O5qD28MLQRDMheIIFEdIVUmpJvqs1y0Nkea9+e4+RQMgIpIFYDsRVUWbqR8CyIyklY5ivADIYObTAdwGIK3pdSfRPflaT4c7MISIyPO82wAcADDUGHPjMVDAANRaez2AdSKykYh8bZKtxu5uiRGaNjs9AgUiElXNTCaT76jquggF10RsLq2gIBX9vgAuD4LgPs/z+hB9/jbX3Q7QY1WTXRnJZDJlkLHW/lJVwzAMc5n5B6mSuBXuUGvt3wD4BMBOY0xmTzVFtQfq/NbmUACZQRC8rqrLmVlV9W/b4AIBwER0rqouBEBBEHB718mdgX9PDt/3U4smAGSMWd6UGTSemS9rgQIDQHzfPxdArXNuNQB1zgUi0q419zoSjFLg8z1FGIZ/IqJNEedc3iyvU6kCEakkovvbmbLdlgI9KYfN/yastbdHxo43xkyP7nkAYK2dpKoumUyuSSHDWks9xQHNS0nqwRRo/nyTSCTWiciGyOhFzRFCRNcz878AqGuWGtTetOVuiFD3hl+VqJmGpUpca+3K6P5EZv4RAGetnUxEI4IgqIoMdR3lra6kQI8gIAgCqGrzZ7vo9UeIaGu0hh9Hf29yzq0HkGxhi37Zhz2TAj3FB94XZezn83AE8Zuj12cyczmAmHPu1uaE2MbzuhUBPUmEFDU3vFa0npxz64loj6pmENFKEVkO4EiqFG4lSFBV72jb4N4kgxRVdB4RpUUdnubdHwbwGTMvJSKo6iERebSV6CuARgCOiMLImd32jdL+APZGe/WH23O20MHUyjPGbLLWqjHml1EqmBbvybXW1lprb2hlfgaQQ0T3p3oKzLwlWje3hgLTQQdkALiaiDKJ6E1VfaQF/LrUbLHWlhNRjqq+CCCXmRtUdXuzyBKABmvtW0EQPB7xQvNnZDFzGTMPVdWXAWw2xhxg5oEi8iGAT7vaEeopBHREVag779keXGhn6ouWrS/Xxvu4DULWNtpnbXaubC8xvrkBrj1Nk3YoFbWnhLedXGRvH+3+6rztgvG90REpKT0DwHgRCYhon3Pu8WZy2ut7gl0ZHG2PJ6vqOyKyEcAsAKe31VPsMAc0q7Ep+rzBV/TLkw5wxhHn3A4AHzLzZwCynXOtclhXfqWVxBff8+tdMGDOYeZbiKhWRALn3NNt7RY7K4OqqqcS0W1oOq2VCB5R+a3UooxtqSLaDFKpmr3N97Q2PwDDzG+LyMpm/QFEKfCJiCwCsL07yQUA8onoML78Rcev7WLmTS2KsdTZ4PUAitsT5M6owKfRBiNsI0qtaTC1ce9Y/QZtIxgOgE9Eu1qTPxF5FsDhoxRTnS5sGE2nrHwUY74KB6Q6w3UADuL/R6uBoo7kdoe1tpeMLjdo/heEJS8leBivUwAAAABJRU5ErkJggg=='

CSS = open(SRC + '/assets/css/admin-os.css').read()
JS = open(SRC + '/assets/js/admin-os.js').read()
MODULES = json.load(open('/tmp/modules.json'))

# WordPress's own admin chrome, reproduced closely enough to measure against.
WP = """
html,body{margin:0;padding:0}
html.wp-toolbar{padding-top:32px}
body{background:#f0f0f1;color:#1d2327;font:13px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
#wpadminbar{position:fixed;top:0;left:0;right:0;height:var(--bar-h,32px);z-index:99999;background:#1d2327;color:#f0f0f1;
  display:flex;align-items:center;gap:16px;padding:0 12px;flex-wrap:wrap}
#wpadminbar .ab-sp{flex:1}
#adminmenuback{position:fixed;top:32px;left:0;bottom:0;width:160px;background:#1d2327;z-index:9990}
#adminmenuwrap{position:relative;float:left;width:160px;z-index:9991}
#adminmenu{margin:0;padding:8px 0 40px;list-style:none;width:160px}
#adminmenu a{display:flex;align-items:center;gap:8px;padding:7px 12px;color:#f0f0f1;text-decoration:none;font-size:13px}
#adminmenu .dash{width:18px;text-align:center;opacity:.75}
#adminmenu .wp-menu-separator{height:6px;margin:6px 0;border-top:1px solid rgba(255,255,255,.08)}
#adminmenu .wp-submenu{list-style:none;margin:0;padding:0;display:block;background:#101517}
#adminmenu .wp-submenu a{padding:6px 12px 6px 22px;color:#c3c4c7;font-size:13px}
#adminmenu .wp-submenu li.current a{color:#fff;font-weight:600;box-shadow:inset 2px 0 0 #72aee6}
#wpcontent{margin-left:160px}
#wpbody-content{padding:0;float:left;width:100%}
"""

MENU = [
    ("\u25A0", "Dashboard"), ("\u2712", "Posts"), ("\u25BC", "Media"),
    ("\u2261", "Pages"), ("\u2751", "Comments"), ("\u2698", "Appearance"),
    ("\u2699", "Plugins"), ("\u2637", "Users"), ("\u2699", "Tools"),
    ("\u2699", "Settings"),
]
COUNTS = {"listings": 128, "projects": 42, "duplicates": 5, "enquiries": 17,
          "visits": 3, "team": 6, "requests": 2, "bin": 7}


def ico(name, cls=""):
    return f'<svg class="ico {cls}" aria-hidden="true"><use href="#eos-i-{name}"></use></svg>'


# ----------------------------------------------------------------- chrome

def menu_html():
    out = [f'<li><a href="#"><span class="dash">{d}</span>{n}</a></li>' for d, n in MENU[:4]]
    out.append('<li class="wp-menu-separator"></li>')
    out.append('<li class="current"><a href="#"><span class="dash">\u25A4</span>Office</a>')
    out.append('<ul class="wp-submenu">')
    for m in MODULES:
        cur = ' class="current"' if m['slug'] == 'estat-today' else ''
        badge = f' <span class="estat-menu-count">{COUNTS[m["badge"]]}</span>' if m['badge'] and COUNTS.get(m['badge']) else ''
        out.append(f'<li{cur}><a href="#">{m["title"]}{badge}</a></li>')
    out.append('</ul></li>')
    out.append('<li class="wp-menu-separator"></li>')
    out += [f'<li><a href="#"><span class="dash">{d}</span>{n}</a></li>' for d, n in MENU[4:]]
    return "\n".join(out)


def rail_html(active="estat-today"):
    order, groups = [], {}
    for m in MODULES:
        groups.setdefault(m['group'], []) or order.append(m['group']) if m['group'] not in groups else None
        groups[m['group']].append(m)
    out = ['<aside class="rail" id="rail">',
           '<div class="brand brand--logo">'
           f'<span class="brand__mark brand__mark--logo"><img class="estat-logo" src="{MD_LOGO}" alt="" aria-hidden="true"></span>',
           '<div class="brand__txt"><div class="brand__name">Mayfair Properties &amp; Developers</div>',
           '<div class="brand__sub">The office</div></div></div>',
           '<nav class="rail__scroll rail-scroll" id="nav">']
    for g in order:
        out.append(f'<div class="rail__group"><div class="rail__gname">{g}</div>')
        for m in groups[g]:
            cur = " is-active" if m['slug'] == active else ""
            badge = f'<span class="nav__badge">{COUNTS[m["badge"]]}</span>' if m['badge'] and COUNTS.get(m['badge']) else ''
            out.append(f'<a class="nav{cur}" href="#">{ico(m["icon"])}'
                       f'<span class="nav__txt">{m["title"]}</span>{badge}</a>')
        out.append('</div>')
    out.append(f'</nav><div class="rail__foot"><button type="button" class="rail__collapse" '
               f'id="railToggle" aria-pressed="false">{ico("collapse")}'
               f'<span class="nav__txt">Collapse</span></button></div></aside>')
    return "\n".join(out)


def topbar(title):
    return f"""
<header class="top">
  <div class="top__crumb"><h1 class="dsp">{title}</h1></div>
  <div class="search">{ico('search', 'search__ico')}
    <input class="search__in" id="searchIn" type="search" placeholder="Search properties, leads, people…">
    <span class="search__kbd"><kbd>⌘</kbd><kbd>K</kbd></span></div>
  <div class="top__acts">
    <button type="button" class="btn btn--bronze btn--sm">{ico('plus')}Quick Add</button>
    <button type="button" class="iconbtn" id="bellBtn">{ico('bell')}<i class="iconbtn__dot"></i></button>
    <button type="button" class="me" id="meBtn"><span class="me__av">RS</span>
      <span><span class="me__name">Ravi Sharma</span><span class="me__role">Office Owner</span></span></button>
  </div>
</header>"""


def phead(title, sub, eyebrow, action=""):
    act = f'<div class="phead__r">{action}</div>' if action else ''
    return f"""<div class="phead"><div class="phead__l">
      <div class="phead__eyebrow"><span class="lbl">{eyebrow}</span></div>
      <h1>{title}</h1><p class="phead__sub mut">{sub}</p></div>{act}</div>"""


# ---------------------------------------------------------------- screens

PEOPLE = [("Ravi Sharma", "Office Owner", "+91 98111 22334", 42, 9),
          ("Anita Verma", "Senior Agent — Sohna Road", "+91 98111 22335", 27, 14),
          ("Deepak Kumar Yadav", "Field Agent", "", 12, 3),
          ("Meera Krishnan Nair", "Agent", "+91 98111 22337", 8, 5),
          ("Suresh Dey", "Agent", "+91 98111 22338", 19, 6),
          ("Priya Bhatnagar", "Agent", "+91 98111 22339", 4, 1)]


def screen_team():
    cards = ""
    for i, (n, r, ph, homes, leads) in enumerate(PEOPLE):
        av = f' style="background-image:linear-gradient(140deg,#cbb79c,#a89478)"'
        cards += f"""
      <button type="button" class="panel card card--lift b3 anim" style="--d:{i*40}ms" data-drawer="agent" data-id="{i}">
        <span class="tcard__hd">
          <span class="tcard__av"{av}>{''.join(w[0] for w in n.split()[:2])}</span>
          <span class="tcard__id"><b class="tcard__name">{n}</b><span class="tcard__role mut">{r}</span></span>
        </span>
        <span class="tcard__row">{ico('phone')}<span class="num">{ph or 'No number yet'}</span></span>
        <span class="divider"></span>
        <span class="tcard__stats">
          <span><span class="lbl">Properties</span><b class="num">{homes}</b></span>
          <span><span class="lbl">Enquiries</span><b class="num">{leads}</b></span>
        </span>
      </button>"""
    return phead("Team", "Who takes the calls and shows the homes.", "People",
                 f'<button type="button" class="btn btn--bronze">{ico("plus")}Add member</button>') \
        + f'<div class="bento bento--cards" id="teamGrid">{cards}</div>'


PROJECTS = [("M3M Capital Financial Centre", "M3M India", "Ready to move", "₹1.85 Cr", 24, 9),
            ("Arize Tessoro — Sector 69 Gurugram", "Arize Developers", "Under construction", "₹1.20 Cr", 18, 4),
            ("Emaar India Business Centre", "Emaar India", "Ready to move", "On request", 31, 12),
            ("Chintels Corporate Park", "Chintels India", "Under construction", "₹92,000/sq ft", 12, 2),
            ("Magnum Towers", "Magnum Builders", "Ready to move", "₹78 L", 8, 1),
            ("Global Foyer JMD", "JMD Group", "Ready to move", "₹1.40 Cr", 15, 6)]


def screen_projects():
    cards = ""
    for i, (n, dev, stage, price, homes, avail) in enumerate(PROJECTS):
        cards += f"""
      <button type="button" class="panel card card--lift b3 anim" style="--d:{i*40}ms" data-drawer="project" data-id="{i}">
        <span class="pcard__cov" style="background-image:linear-gradient(140deg,#cbb79c,#a89478)">{ico('layers')}</span>
        <b class="pcard__name">{n}</b>
        <span class="pcard__by mut">{dev}</span>
        <span class="pcard__tags"><span class="badge badge--pending">{stage}</span><span class="badge badge--live">Live</span></span>
        <span class="divider"></span>
        <span class="pcard__stats">
          <span><span class="lbl">Homes</span><b class="num">{homes}</b></span>
          <span><span class="lbl">Available</span><b class="num">{avail}</b></span>
          <span class="pcard__from"><span class="lbl">From</span><b>{price}</b></span>
        </span>
        <span class="pcard__cta">{ico('edit')}Edit</span>
      </button>"""
    return phead("Societies & Projects", "The developments you sell inside.", "Inventory",
                 f'<button type="button" class="btn btn--bronze">{ico("plus")}Add project</button>') \
        + f'<div class="bento bento--cards" id="projGrid">{cards}</div>'


def stat_card(icon, value, label, note, i):
    return f"""
      <div class="panel stat b3 anim" style="--d:{i*60}ms">
        <span class="stat__ico">{ico(icon)}</span>
        <span class="stat__v num" data-count="{value}">{value}</span>
        <span class="stat__l">{label}</span>
        <span class="stat__d mut">{note}</span>
      </div>"""


def screen_bin():
    rows = ""
    for i, (n, kind, when, by, was, left) in enumerate([
        ("3 BHK park facing, Sector 57", "Property", "2 hours ago", "Ravi Sharma", "publish", 27),
        ("Arize Tessoro — Unit 1204", "Property", "yesterday", "Anita Verma", "draft", 26),
        ("Supertech Limited Editions Township", "Project", "4 days ago", "Ravi Sharma", "publish", 22),
        ("2 BHK corner unit with a very long descriptive title that refuses to fit", "Property", "1 week ago", "Deepak", "pending", 18),
    ]):
        rows += f"""
        <tr class="hlrow" data-id="{i}">
          <td><label class="cb"><input type="checkbox" class="cb__i" data-row="{i}"><i></i></label></td>
          <td><div class="tcell"><span class="tthumb tthumb--empty">{ico('home')}</span>
            <span class="tcell__b"><span class="tname"><b>{n}</b></span></span></div></td>
          <td><span class="badge">{kind}</span></td>
          <td><span class="mut">{when}</span></td>
          <td><span class="mut">{by}</span></td>
          <td>{was}</td>
          <td><span class="badge">{left} days</span></td>
          <td><div class="rowacts">
            <button type="button" class="btn btn--ghost btn--ico btn--sm">{ico('undo')}</button>
            <button type="button" class="btn btn--ghost btn--ico btn--danger btn--sm">{ico('trash')}</button>
          </div></td>
        </tr>"""
    cards = (stat_card('bin', 7, 'In the bin', 'waiting here', 0)
             + stat_card('clock', 2, 'Removed today', 'in the last few hours', 1)
             + stat_card('chart', 5, 'Removed this week', 'since Monday', 2)
             + stat_card('clock', 22, 'Oldest item', 'days in the bin', 3))
    return (phead("Bin", "Removed properties and projects. Put them back while they are still here.",
                  "Recovery", '<button type="button" class="btn btn--danger">Empty bin</button>')
            + f'<div class="bento bento--stats">{cards}</div>'
            + f"""<div class="notice anim" style="--d:240ms;margin-top:var(--s5)">
                 <span class="notice__k">How long do we keep things?</span>
                 <span class="notice__v">Removed records stay for 30 days, then are destroyed automatically.</span></div>"""
            + f"""<div class="panel" style="margin-top:var(--s5)">
        <div class="panel__h"><div><h3>What is in here</h3><div class="lbl">Put back, or destroy for good</div></div></div>
        <div class="tw"><div class="tw__scroll"><table class="tb"><thead><tr>
          <th style="width:28px"></th><th>Record</th><th>Kind</th><th>Removed</th>
          <th>By</th><th>Was</th><th>Days here</th><th></th>
        </tr></thead><tbody>{rows}</tbody></table></div></div></div>""")



def screen_settings():
    """Settings -> The office, with the logo picker that now lives there."""
    fields = [("Office name", "Mayfair Properties &amp; Developers"),
              ("Tagline", "Developer and channel partner in Gurugram"),
              ("Who people speak to", "Ravi Sharma"),
              ("Phone", "+91 98737 12902"),
              ("WhatsApp", "+91 98737 12902"),
              ("Email", "mayfairpropertiesofficial@gmail.com"),
              ("City", "Gurugram"),
              ("Reference prefix", "MPD-")]
    boxes = "".join(
        f'<div class="field"><label class="field__lbl">{k}</label>'
        f'<input class="in" value="{v}"></div>' for k, v in fields)
    return (phead("Settings", "The office, the website, and how the app behaves.",
                  "System", '<button type="button" class="btn btn--ghost">Change requests</button>')
            + f"""<div class="chipf-row anim" style="--d:80ms;display:flex;gap:8px;flex-wrap:wrap;margin-top:var(--s4)">
                 <a class="chipf is-on" href="#">The office</a>
                 <a class="chipf" href="#">Website</a>
                 <a class="chipf" href="#">Properties</a>
                 <a class="chipf" href="#">Team &amp; access</a>
                 <a class="chipf" href="#">Other programs</a>
               </div>
               <div class="panel anim" style="--d:140ms;margin-top:var(--s5)">
                 <div class="panel__h"><div><h3>The office</h3>
                   <div class="lbl">What the website and the paperwork say about you</div></div></div>
                 <div class="panel__b" style="display:grid;gap:var(--s4);grid-template-columns:1fr 1fr">
                   <div class="field" style="grid-column:1/-1"><label class="field__lbl">Office logo</label>
                     <div class="logopick" id="estatLogoPick">
                       <span class="logopick__well"><img class="logopick__img" src="{MD_LOGO}" alt=""></span>
                       <span class="logopick__acts">
                         <button type="button" class="btn btn--ghost btn--sm" data-logo-choose>Choose a picture</button>
                         <button type="button" class="btn btn--ghost btn--sm" data-logo-clear>Use the default</button>
                       </span>
                       <input type="hidden" name="settings[logo_id]" value="0" data-logo-input></div>
                     <div class="lbl">Shown at the top of the office screen and in the agent's app.
                       Leave it as it is to use the logo this website already has.</div></div>
                   {boxes}
                   <div class="field" style="grid-column:1/-1"><label class="field__lbl">Address</label>
                     <textarea class="in" rows="2">P-106, Sohna-Gurgaon Road, Sector 48, Gurugram</textarea></div>
                 </div>
                 <div class="panel__f" style="display:flex;justify-content:flex-end;padding:var(--s4);border-top:1px solid var(--line)">
                   <button type="button" class="btn btn--bronze">Save</button></div>
               </div>""")


MEDIA = [("Front elevation photograph", "photo", "3 BHK park facing"),
         ("Floor plan — second floor", "floorplan", "Arize Tessoro"),
         ("Brochure 2026 final version", "brochure", "M3M Capital"),
         ("Sale deed scan", "document", "Not linked"),
         ("Kitchen photograph", "photo", "2 BHK corner unit"),
         ("Site layout plan", "floorplan", "Chintels Corporate Park"),
         ("Price list", "document", "Magnum Towers"),
         ("Entrance lobby", "photo", "Global Foyer JMD")]


def screen_gallery():
    tiles = ""
    for i, (title, kind, linked) in enumerate(MEDIA):
        tiles += f"""
      <div class="tile" data-id="{i}" style="animation-delay:{i*25}ms">
        <span class="tile__img" style="background-image:linear-gradient(140deg,#d9d5cb,#b9b4a6)"></span>
        <span class="tile__ov">
          <span class="tile__cb"><i class="cb" role="checkbox" aria-checked="false" tabindex="0"></i></span>
          <span class="tile__ex">{kind.upper()}</span>
        </span>
        <span class="tile__nm"><b>{title}</b><span class="mut">{linked}</span></span>
      </div>"""
    return (phead("Gallery & Media", "Photographs, floor plans, brochures and documents.", "Inventory")
            + f'<div class="masonry" id="galGrid">{tiles}</div>')


def bars_svg():
    rows = [("Website", 46), ("WhatsApp", 31), ("Reference", 22), ("Walk-in", 14), ("Facebook", 9)]
    mx = max(r[1] for r in rows)
    w, h, pad, base = 720, 260, 34, 226
    slot = (w - pad * 2) / len(rows)
    bw = min(54, slot * .56)
    out = [f'<svg class="chart" viewBox="0 0 {w} {h}" role="img">']
    for g in range(5):
        y = base - g * (base - 14) / 4
        out.append(f'<line class="gl" x1="{pad}" x2="{w-pad}" y1="{y:.1f}" y2="{y:.1f}"/>')
    for i, (name, v) in enumerate(rows):
        bh = v / mx * (base - 20)
        x = pad + i * slot + (slot - bw) / 2
        out.append(f'<rect class="bar" x="{x:.1f}" y="{base-bh:.1f}" width="{bw:.1f}" height="{max(2,bh):.1f}" rx="4"/>')
        out.append(f'<text x="{x+bw/2:.1f}" y="{base-bh-7:.1f}" text-anchor="middle" style="font-weight:700;fill:var(--ink-2)">{v}</text>')
        out.append(f'<text x="{x+bw/2:.1f}" y="{h-12}" text-anchor="middle">{name}</text>')
    out.append('</svg>')
    return "".join(out)


def donut_svg():
    rows = [("Apartment", 62, "#725b2f"), ("Floor", 24, "#a68b5b"), ("Plot", 9, "#3f6b4f"), ("Office", 5, "#3c5a7a")]
    total = sum(r[1] for r in rows)
    r, circ = 74, 2 * 3.14159 * 74
    out = [f'<svg class="chart" viewBox="0 0 200 200" role="img" style="max-width:230px;margin:0 auto">',
           f'<circle cx="100" cy="100" r="{r}" fill="none" stroke="var(--inset)" stroke-width="14"/>']
    off = 0
    for _, v, c in rows:
        ln = v / total * circ
        out.append(f'<circle class="ring" cx="100" cy="100" r="{r}" stroke="{c}" '
                   f'stroke-dasharray="{ln:.2f} {circ-ln:.2f}" stroke-dashoffset="{-off:.2f}" '
                   f'style="--len:{circ:.2f}"/>')
        off += ln
    out.append(f'<text x="100" y="96" text-anchor="middle" style="font-size:26px;font-weight:700;fill:var(--ink)">{total}</text>')
    out.append('<text x="100" y="116" text-anchor="middle" style="font-size:10px">properties</text></svg>')
    lgd = "".join(f'<span class="lgd__i"><i class="lgd__sw" style="background:{c}"></i><span>{n}</span></span>'
                  for n, _, c in rows)
    return "".join(out) + f'<div class="lgd" id="donutLgd">{lgd}</div>'


def screen_reports():
    kv = "".join(f'<div class="kv"><span class="kv__k">{k}</span><span class="kv__v">{v}</span></div>'
                 for k, v in [("New enquiries this week", "17"),
                              ("Visits booked this week", "9"),
                              ("Fastest response", "4 minutes"),
                              ("Properties with no photograph", "2"),
                              ("Records marked as duplicates", "5")])
    return (phead("Reports & Analytics", "Where the work comes from and where it goes.", "Overview")
            + f"""<div class="bento">
      <div class="panel b6 anim"><div class="panel__h"><div><h3>Where enquiries come from</h3>
        <div class="lbl">Last 90 days</div></div></div>
        <div class="panel__b chartbox" id="chtBar">{bars_svg()}</div></div>
      <div class="panel b6 anim" style="--d:80ms"><div class="panel__h"><div><h3>What you have</h3>
        <div class="lbl">By property type</div></div></div>
        <div class="panel__b chartbox" id="chtDonut">{donut_svg()}</div></div>
      <div class="panel b6 anim" style="--d:160ms"><div class="panel__h"><div><h3>Who is bringing them in</h3>
        <div class="lbl">Last six weeks</div></div></div>
        <div class="panel__b chartbox" id="chtLine">{bars_svg()}</div></div>
      <div class="panel b6 anim" style="--d:240ms"><div class="panel__h"><div><h3>At a glance</h3>
        <div class="lbl">This week</div></div></div>
        <div class="panel__b">{kv}</div></div>
    </div>""")


PROPS = [("3 BHK apartment with a park view", "Sector 57, Gurugram", "₹1.85 Cr", "publish", 1_750, 92),
         ("2 BHK corner unit, east facing", "Sushant Lok Phase 1", "₹1.20 Cr", "publish", 1_150, 78),
         ("4 BHK penthouse with a terrace garden and a servant quarter", "Golf Course Road", "₹3.40 Cr", "draft", 3_200, 61),
         ("Builder floor, 3 BHK, newly renovated", "Sohna Road", "₹98 L", "pending", 1_600, 44),
         ("Studio apartment near the metro station", "MG Road", "₹42 L", "publish", 520, 88),
         ("Independent house with a large courtyard", "Palam Vihar", "₹2.10 Cr", "publish", 2_400, 70)]


def screen_properties():
    rows = ""
    for i, (n, loc, price, status, area, pct) in enumerate(PROPS):
        cls = {"publish": "badge--live", "draft": "", "pending": "badge--pending"}[status]
        rows += f"""
        <tr class="hlrow" data-id="{i}">
          <td><label class="cb"><input type="checkbox" class="cb__i" data-row="{i}"><i></i></label></td>
          <td><div class="tcell"><span class="tthumb tthumb--empty">{ico('home')}</span>
            <span class="tcell__b"><span class="tname"><b>{n}</b><span>{loc}</span></span></span></div></td>
          <td class="num">{price}</td>
          <td>{loc}</td>
          <td><span class="badge {cls}">{status}</span></td>
          <td>{area} sq ft</td>
          <td><span class="meter"><span class="meter__track"><span class="meter__fill is-hi" style="width:{pct}%"></span></span><b>{pct}%</b></span></td>
          <td><div class="rowacts">
            <button type="button" class="btn btn--quiet btn--sm">Duplicate</button>
            <button type="button" class="btn btn--quiet btn--sm is-danger">Bin</button>
          </div></td>
        </tr>"""
    return (phead("Properties", "Every home the office is selling or renting.", "Inventory",
                  f'<button type="button" class="btn btn--bronze">{ico("plus")}Add a home</button>')
            + f"""<div class="tw"><div class="tw__scroll"><table class="tb">
      <thead><tr><th style="width:36px"></th><th>Property</th><th>Price</th><th>Location</th>
      <th>Status</th><th>Size</th><th style="width:170px">Completeness</th><th style="width:150px"></th></tr></thead>
      <tbody id="propRows">{rows}</tbody></table></div></div>""")


VISITS = [("Anita Rao", "11:00", "Sector 57, Gurugram"), ("Suresh Dey", "1:30", "Sohna Road"),
          ("Meera Kapoor", "4:00", "Golf Course Ext.")]
LISTED = [("3 BHK park facing", "Sector 57", "1.85 Cr"), ("2 BHK corner unit", "Sushant Lok", "1.20 Cr"),
          ("4 BHK penthouse", "Golf Course Rd", "3.40 Cr"), ("Builder floor, 3 BHK", "Sohna Road", "98 L")]


def screen_today():
    wl = "".join(f"""<div class="wl__i" data-id="{i}"><span class="av av--36">{n[0]}</span>
      <div class="wl__b"><div class="wl__n">{n}</div><div class="wl__m mut">{t} · {l}</div></div>
      <span class="badge badge--pending">Today</span></div>""" for i, (n, t, l) in enumerate(VISITS))
    li = "".join(f"""<div class="hlrow" data-id="{i}"><span class="tthumb tthumb--empty">{ico('home')}</span>
      <span class="tcell__b"><span class="tname"><b>{n}</b><span>{l} · ₹{p}</span></span></span>
      <span class="badge badge--live">Live</span></div>""" for i, (n, l, p) in enumerate(LISTED))
    kpis = [("home", "Live properties", 128, "4 added this week"),
            ("inbox", "New enquiries", 17, "Since yesterday"),
            ("calendar", "Today's visits", 3, "First at 11:00"),
            ("shuffle", "Change requests", 2, "Waiting on your yes")]
    k = "".join(f"""<div class="panel metric b3 anim" style="--d:{i*60}ms">
        <div class="metric__top"><div class="metric__ico">{ico(a)}</div>
          <div class="metric__lbl"><div class="lbl">{b}</div></div></div>
        <div class="metric__n num" data-count="{c}">{c}</div>
        <div class="metric__ft"><span class="mut">{d}</span></div></div>""" for i, (a, b, c, d) in enumerate(kpis))
    return (phead("Good morning, Ravi",
                  "Three visits today, four enquiries overnight, and two homes waiting on a photograph.",
                  "Monday, 6 October", f'<button type="button" class="btn btn--bronze">{ico("plus")}Add a home</button>')
            + f'<div class="bento">{k}</div>'
            + f"""<div class="bento" style="margin-top:var(--s5)">
      <div class="panel b4 anim"><div class="panel__h"><div><h3>Today's visits</h3>
        <div class="lbl">In order, earliest first</div></div></div>
        <div class="panel__b"><div class="wl">{wl}</div></div></div>
      <div class="panel b4 anim" style="--d:60ms"><div class="panel__h"><div><h3>Fresh on the market</h3>
        <div class="lbl">Added in the last seven days</div></div></div>
        <div class="panel__b">{li}</div></div>
      <div class="panel b4 anim" style="--d:120ms"><div class="panel__h"><div><h3>How complete the records are</h3>
        <div class="lbl">Out of 100</div></div></div>
        <div class="panel__b">
          <div class="kv"><span class="kv__k">Ready to publish</span><span class="kv__v">82</span></div>
          <div class="kv"><span class="kv__k">Missing a photograph</span><span class="kv__v">2</span></div>
          <div class="kv"><span class="kv__k">Missing a price</span><span class="kv__v">1</span></div>
          <div class="kv"><span class="kv__k">Marked as duplicates</span><span class="kv__v">5</span></div>
        </div></div>
    </div>""")


SCREENS = [
    ("estat-today", "Today", screen_today()),
    ("estat-listings", "Properties", screen_properties()),
    ("estat-projects", "Societies & Projects", screen_projects()),
    ("estat-team", "Team", screen_team()),
    ("estat-gallery", "Gallery & Media", screen_gallery()),
    ("estat-reports", "Reports & Analytics", screen_reports()),
    ("estat-bin", "Bin", screen_bin()),
    ("estat-settings", "Settings", screen_settings()),
]
TITLES = {slug: t for slug, t, _ in SCREENS}

sections = "\n".join(
    f'<section class="screen" data-screen="{slug}" id="scr-{slug}"'
    f' style="display:none">{body}</section>'
    for slug, _, body in SCREENS)

tabs = "".join(
    f'<a class="chipf{" is-on" if i == 0 else ""}" href="#" data-go="{slug}">{t}</a>'
    for i, (slug, t, _) in enumerate(SCREENS))

HTML = f"""<!doctype html>
<html lang="en" class="wp-toolbar"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Estate OS inside wp-admin — preview</title>
<style>{WP}</style>
<style>{CSS}</style>
<style>
  .bar-ctl {{ position:fixed; right:14px; bottom:14px; z-index:99999; background:#1d2327;
    color:#f0f0f1; padding:8px 12px; border-radius:10px; font:12px/1.4 sans-serif;
    display:flex; gap:6px; align-items:center; box-shadow:0 8px 24px rgba(0,0,0,.35) }}
  .bar-ctl button {{ background:#2c2e31; color:#f0f0f1; border:0; border-radius:6px;
    padding:4px 9px; font:inherit; cursor:pointer }}
  .bar-ctl button.is-on {{ background:#a68b5b; color:#16171a; font-weight:700 }}
  .preview-tabs {{ position:sticky; top:0; z-index:5; display:flex; gap:8px; flex-wrap:wrap;
    padding:12px 0 14px; background:linear-gradient(var(--linen) 70%, transparent); }}
</style>
</head>
<body class="wp-admin estat-os-screen admin-bar">

{SPRITE}

<div class="bar-ctl" id="barCtl">
  <span>Toolbar</span>
  <button type="button" data-bar="32" class="is-on">32px</button>
  <button type="button" data-bar="46">46px</button>
  <button type="button" data-bar="64">64px (wrapped)</button>
  <button type="button" data-bar="0">none</button>
</div>
<div id="wpadminbar">
  <span>⛨ mayfairproperties</span><span>+ New</span><span class="ab-sp"></span>
  <span>Howdy, Ravi</span><span>Log out</span>
</div>

<div id="adminmenuback"></div>
<div id="adminmenuwrap"><ul id="adminmenu">
{menu_html()}
</ul></div>

<div id="wpcontent"><div id="wpbody"><div id="wpbody-content">
  <div class="estat-os-page">
    <div class="estat-os">
      <div class="app" id="app">
        {rail_html()}
        <div class="main">
          {topbar("Today")}
          <main class="canvas" id="canvas">
            <div class="preview-tabs">{tabs}</div>
            {sections}
          </main>
        </div>
      </div>
      <div class="scrim" id="scrim" hidden></div>
      <aside class="drawer" id="drawer" role="dialog" aria-modal="true">
        <div class="dw__h"><div class="dw__t">
          <div class="lbl" id="dwKicker">Property</div>
          <h2 id="dwTitle">3 BHK park facing</h2><p id="dwSub"></p></div>
        <button type="button" class="iconbtn" id="dwClose">{ico('x')}</button></div>
        <div class="dw__b" id="dwBody">
          <div class="dr__hero">
            <div class="dr__img" style="background:linear-gradient(150deg,#a68b5b,#5a4522)"></div>
            <div class="dr__hero__b"><h3>3 BHK apartment with a park view</h3>
              <div class="mut">Sector 57, Gurugram</div>
              <div style="margin-top:var(--s3);display:flex;gap:var(--s2);flex-wrap:wrap">
                <span class="badge badge--live">Live</span><span class="badge badge--live">Available</span></div>
            </div></div>
          <div class="dr__b">
            {"".join(f'<div class="kv"><span class="kv__k">{k}</span><span class="kv__v">{v}</span></div>' for k, v in [("Price","₹1.85 Cr"),("Size","1,750 sq ft"),("Bedrooms","3"),("Reference","MP-1042"),("Handled by","Ravi Sharma"),("On the market for","12 days")])}
            <div class="divider"></div>
            <div class="lbl" style="margin-bottom:var(--s2)">How complete the record is</div>
            <div class="meter"><div class="meter__fill is-hi" style="width:88%"></div></div>
            <div class="mut" style="font-size:var(--fs-meta);margin-top:var(--s2)">Nearly there</div>
          </div></div>
        <div class="dw__f" id="dwFoot">
          <a class="btn btn--ghost" href="#">Open and edit</a>
          <a class="btn btn--bronze" href="#">See it on the website</a></div>
      </aside>
      <div class="cmdk" id="cmdk"><div class="cmdk__p">
        <input class="cmdk__in" id="cmdkIn" type="search" placeholder="Search…">
        <div class="cmdk__l" id="cmdkList"></div></div></div>
      <div class="toasts" id="toasts"></div>
      <div class="pop" id="pop"></div>
      <div class="bulkbar" id="bulkbar"><b id="bulkN">0 selected</b>
        <button class="btn btn--sm" data-bulk="restore" style="background:rgba(255,255,255,.1);color:#fff">Restore</button>
        <button class="iconbtn bulkbar__x" id="bulkX">{ico('x')}</button></div>
    </div>
  </div>
</div></div></div>

<script>window.estatOs=__CONFIG__;</script>
<script>{JS}</script>
<script>
(function(){{
  var titles = {json.dumps(TITLES)};
  function show(slug){{
    document.querySelectorAll('.preview-tabs .chipf').forEach(function(a){{
      a.classList.toggle('is-on', a.getAttribute('data-go') === slug);
    }});
    document.querySelectorAll('#canvas > .screen').forEach(function(s){{
      var on = s.getAttribute('data-screen') === slug;
      s.classList.toggle('is-on', on);
      s.style.display = on ? '' : 'none';
      if (on && window.EstatOS) {{ s.style.animation = 'none'; void s.offsetWidth; s.style.animation = ''; }}
    }});
    var h = document.querySelector('.top__crumb h1');
    if (h) {{ h.textContent = titles[slug] || ''; }}
    document.getElementById('canvas').scrollTop = 0;
  }}
  document.querySelectorAll('.preview-tabs .chipf').forEach(function(a){{
    a.addEventListener('click', function(e){{ e.preventDefault(); show(a.getAttribute('data-go')); }});
  }});
  show('estat-today');
  window.__showScreen = show;

  /* Pretend the toolbar is taller (it wraps) or gone, and let the office
     re-measure: that is the whole point of measuring instead of assuming. */
  var ctl = document.getElementById('barCtl');
  ctl.addEventListener('click', function (e) {{
    var b = e.target.closest('button[data-bar]');
    if (!b) {{ return; }}
    var h = parseInt(b.getAttribute('data-bar'), 10);
    document.documentElement.style.setProperty('--bar-h', h + 'px');
    var bar = document.getElementById('wpadminbar');
    bar.style.display = h === 0 ? 'none' : '';
    ctl.querySelectorAll('button').forEach(function (x) {{ x.classList.remove('is-on'); }});
    b.classList.add('is-on');
    window.dispatchEvent(new Event('resize'));
    setTimeout(function () {{ window.dispatchEvent(new Event('resize')); }}, 60);
  }});
}})();
</script>
</body></html>"""

HTML = HTML.replace('__CONFIG__',
                    "{ajax:'#',nonce:'',page:'estat-today',home:'#',i18n:{},modules:[],quick:[],notes:[],palette:[]}")
open('/home/user/preview-admin.html', 'w').write(HTML)
print('written', len(HTML), 'bytes')
