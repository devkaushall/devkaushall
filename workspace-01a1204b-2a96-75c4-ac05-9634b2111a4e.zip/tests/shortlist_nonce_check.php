<?php
/**
 * The send button on a visitor's shortlist only works if two files agree:
 * the page hands the browser a ticket, and the REST route checks that exact
 * ticket. Nothing in the plugin keeps them in step, so this check does.
 *
 * Run: php /home/user/tests/shortlist_nonce_check.php
 */

$root = '/home/user/plugin/estat-os/includes/';
$frontend = file_get_contents( $root . 'Frontend/Frontend.php' );
$rest     = file_get_contents( $root . 'Rest/RestApi.php' );
$js       = file_get_contents( '/home/user/plugin/estat-os/assets/js/public.js' );

$fails = 0;
$say   = function ( $ok, $line ) use ( &$fails ) {
	echo ( $ok ? '  ok   ' : '  FAIL ' ) . $line . "\n";
	if ( ! $ok ) {
		$fails++;
	}
};

// The block that hands the browser its settings: from 'estatPublic' to the
// closing of that wp_localize_script call.
$start = strpos( $frontend, "'estatPublic'" );
$block = '';
if ( false !== $start ) {
	$block = substr( $frontend, $start, 1200 );
}

$say( '' !== $block, 'the website hands the browser an estatPublic block' );
$say(
	(bool) preg_match( "/'shortlistNonce'\s*=>\s*wp_create_nonce\(\s*'estat_shortlist'\s*\)/", $block ),
	'the block carries shortlistNonce, made by wp_create_nonce( estat_shortlist )'
);

$say(
	(bool) preg_match( "/wp_verify_nonce\(\s*\\\$nonce,\s*'estat_shortlist'\s*\)/", $rest ),
	'the REST route verifies that same estat_shortlist ticket'
);

$say(
	false !== strpos( $js, 'settings.shortlistNonce' ),
	'the browser sends what the page gave it'
);

// The one thing that used to be missing: a nonce that is created somewhere
// other than the block the browser reads is a nonce the browser never sees.
preg_match_all( "/wp_create_nonce\(\s*'([a-z_]+)'\s*\)/", $rest . $frontend, $made );
$say(
	in_array( 'estat_shortlist', $made[1], true ),
	'a ticket named estat_shortlist is actually made'
);

echo "\n" . ( $fails ? $fails . " FAILED\n" : "ALL CLEAN\n" );
exit( $fails ? 1 : 0 );
