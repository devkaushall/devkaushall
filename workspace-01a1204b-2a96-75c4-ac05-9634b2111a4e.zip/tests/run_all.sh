#!/usr/bin/env bash
#
# Every standing check, one command.
#
# A green lint has never once proved this plugin works: the four worst faults
# of the last two days — a REST route returning 500, a page drawing its widget
# twice, a form whose handler read a different field name, and a save whose
# nonce did not match — were all invisible to `php -l` and to every rendered
# sweep. Each of them has a check now. This runs them all and says which are
# clean.
#
#   bash /home/user/tests/run_all.sh
#
set -u
cd /home/user || exit 1

pass=0
fail=0
line() { printf '%-26s %s\n' "$1" "$2"; }

run_py() {
	local name="$1" file="$2"
	local out
	out="$(python3 "$file" 2>&1 | tail -1)"
	if [[ "$out" == *"NO FINDINGS"* || "$out" == *"0 FINDINGS"* ]]; then
		line "$name" "clean"
		pass=$((pass + 1))
	else
		line "$name" "$out"
		fail=$((fail + 1))
	fi
}

run_php() {
	local name="$1" file="$2"
	local out
	out="$(php "$file" 2>&1 | tail -1)"
	if [[ "$out" == *"ALL CLEAN"* ]]; then
		line "$name" "clean"
		pass=$((pass + 1))
	else
		line "$name" "$out"
		fail=$((fail + 1))
	fi
}

echo "Estat.OS — standing checks"
echo

run_py  "php static"        tests/php_static_check.py
run_py  "rest callbacks"    tests/callback_arity_check.py
run_py  "forms vs handlers" tests/form_wiring_check.py
run_py  "js contract"       tests/js_contract_check.py
run_py  "data contract"     tests/data_contract_check.py
run_php "rest property"     tests/rest_property_check.php
run_php "shortlist nonce"   tests/shortlist_nonce_check.php
run_php "page tidying"      tests/tidy_pages_check.php
run_php "highlights save"   tests/highlights_save_check.php
run_php "key column repair" tests/key_nullable_check.php
run_php "sitemap seam"      tests/sitemap_seam_check.php

echo
line "checks" "$pass clean, $fail with findings"
exit 0
