#!/usr/bin/env python3
"""Analysis 6 — REST callback arity.

The P1 that broke the live website for weeks was one word:

    'validate_callback' => 'is_numeric',

WordPress calls a route's validation callback with **three** arguments: the
value, the request, and the parameter name. PHP's own internal functions are
checked for arity — `is_numeric()` takes exactly one argument — so PHP 8
answered with `ArgumentCountError`, WordPress showed its "critical error"
page, and every request to `/estat/v1/properties/{id}`, `/estat/v2/properties/{id}`
and `/estat/v1/forms/{id}/submit` returned HTTP 500 before the handler ran.

A *userland* function — anything WordPress defines, anything we define —
simply ignores arguments it did not ask for, which is why
`'sanitize_callback' => 'absint'` never broke.

So the rule this check enforces: no REST argument callback may name a PHP
internal function. Use an array callback to one of our own methods.

Run: python3 /home/user/tests/callback_arity_check.py
"""

import os
import re
import subprocess
import sys

ROOT = '/home/user/plugin/estat-os'

CALLBACK = re.compile(
    r"'((?:validate|sanitize)_callback)'\s*=>\s*'([A-Za-z0-9_\\\\]+)'"
)


def php_internals():
    """Names PHP itself defines; php-cli when present, else a plain list."""
    try:
        out = subprocess.run(
            ['php', '-r', 'echo implode(" ", get_defined_functions()["internal"]);'],
            capture_output=True, text=True, timeout=30, check=True,
        ).stdout
        names = set(out.split())
        if names:
            return names
    except Exception:
        pass
    # Enough of the ones a plugin might reach for that the check still has
    # teeth on a machine without php-cli. `absint` is NOT here: WordPress
    # defines it, and userland functions ignore the extra arguments.
    return {
        'is_numeric', 'is_string', 'is_int', 'is_float', 'is_bool', 'is_array',
        'intval', 'floatval', 'strval', 'boolval', 'abs', 'ceil', 'floor',
        'round', 'number_format', 'strlen', 'trim', 'ltrim', 'rtrim', 'ucfirst',
        'strtolower', 'strtoupper', 'str_replace', 'strpos', 'preg_match',
        'preg_replace', 'json_encode', 'json_decode', 'urlencode', 'urldecode',
        'sanitize_email', 'filter_var', 'count', 'max', 'min',
    }


def files():
    for base, dirs, names in os.walk(ROOT):
        dirs[:] = [d for d in dirs if d not in {'.git', 'node_modules'}]
        for name in names:
            if name.endswith('.php'):
                yield os.path.join(base, name)


internals = php_internals()
findings = []
routes = 0

for path in files():
    text = open(path, encoding='utf-8', errors='replace').read()
    bare = re.sub(r'/\*.*?\*/', ' ', text, flags=re.S)
    bare = re.sub(r'(?m)//.*$', ' ', bare)
    for m in re.finditer(CALLBACK, bare):
        kind, fn = m.group(1), m.group(2).lstrip('\\')
        line = bare[:m.start()].count('\n') + 1
        if fn.lower() in internals:
            findings.append((os.path.relpath(path, ROOT), line, kind, fn))

# How many routes ask one of our own methods, as a sanity figure.
for path in files():
    routes += len(re.findall(r"'(?:validate|sanitize)_callback'\s*=>\s*array\(", 
                             open(path, encoding='utf-8', errors='replace').read()))

print('Analysis 6 — REST argument callbacks (arity)\n')
print('PHP internal functions known: %d' % len(internals))
print('Callbacks handed to one of our own methods: %d\n' % routes)

print('A callback naming a PHP internal — a fatal on every request (%d):'
      % len(findings))
for path, line, kind, fn in findings:
    print('     %s:%d  %s => %s' % (path, line, kind, fn))
if not findings:
    print('     none')
    print('\n     WordPress passes ( $value, $request, $param ). PHP internal')
    print('     functions are arity-checked; userland functions are not.')
    print('     This is why absint was always safe and is_numeric was not.')

print('\n%s' % ('%d FINDINGS' % len(findings) if findings else 'NO FINDINGS'))
sys.exit(0)
