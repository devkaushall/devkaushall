<?php
/**
 * The sitemap filter seam, tested with every shape the SEO plugin may pass.
 *
 * On 7 Oct the live /sitemap_index.xml began returning 500: Rank Math hands
 * `rank_math/sitemap/exclude_empty_terms` an array that contains WP_Taxonomy
 * objects, and the plugin cast every item with strval() — a fatal on the
 * first object. This check walks the fixed callback through every payload
 * shape we have seen or can imagine (names, objects, a mix, junk, hostile)
 * and asserts two things: the right answer, and that not one PHP warning
 * or error escapes. Then it proves the block splitter that used to lean on
 * a lookbehind (which older PCRE refuses to compile — the source of the six
 * preg_split warnings of the same day) returns exactly what it returned
 * before, on the same inputs.
 */

error_reporting( E_ALL );
$notices = array();
set_error_handler(
	function ( $no, $str ) use ( &$notices ) {
		$notices[] = $str;
		return true;
	}
);

define( 'ABSPATH', '/fake/' ); // PublicText does not use it; some WP shims check it.

/* ---- the two WP helpers the tested code needs ---- */
if ( ! class_exists( 'WP_Taxonomy' ) ) {
	class WP_Taxonomy {
		public $name;
		public function __construct( $name ) {
			$this->name = $name;
		}
	}
}
if ( ! function_exists( 'wp_strip_all_tags' ) ) {
	function wp_strip_all_tags( $text, $remove_breaks = false ) {
		$text = preg_replace( '@<(script|style)[^>]*?>.*?</\\1>@si', '', (string) $text );
		$text = strip_tags( $text );
		if ( $remove_breaks ) {
			$text = preg_replace( '/[\r\n\t ]+/', ' ', $text );
		}
		return trim( $text );
	}
}
if ( ! function_exists( 'apply_filters' ) ) {
	function apply_filters( $tag, $value ) {
		return $value;
	}
}
if ( ! function_exists( '__' ) ) {
	function __( $text, $domain = null ) {
		return $text;
	}
}
if ( ! function_exists( '_n' ) ) {
	function _n( $single, $plural, $number, $domain = null ) {
		return 1 === (int) $number ? $single : $plural;
	}
}

require __DIR__ . '/../plugin/estat-os/includes/Support/PublicText.php';
require __DIR__ . '/../plugin/estat-os/includes/Frontend/Seo.php';

use EstatOS\Frontend\Seo;
use EstatOS\Support\PublicText;

$pass = 0;
$fail = 0;
function it( $what, $got, $want ) {
	global $pass, $fail;
	$ok = ( $got === $want );
	if ( $ok ) {
		++$pass;
		echo "  ok   $what\n";
	} else {
		++$fail;
		printf( "  FAIL %s — got %s, want %s\n", $what, var_export( $got, true ), var_export( $want, true ) );
	}
}

echo "== A. rank_math/sitemap/exclude_empty_terms payload shapes\n";
it( 'one object, ours            ', Seo::sitemap_exclude_empty_terms( false, array( new WP_Taxonomy( 'estat_locality' ) ) ), true );
it( 'one object, not ours        ', Seo::sitemap_exclude_empty_terms( false, array( new WP_Taxonomy( 'category' ) ) ), false );
it( 'names only (old shape)      ', Seo::sitemap_exclude_empty_terms( false, array( 'estat_amenity' ) ), true );
it( 'mixed objects and names     ', Seo::sitemap_exclude_empty_terms( false, array( new WP_Taxonomy( 'category' ), 'estat_feature' ) ), true );
it( 'single string               ', Seo::sitemap_exclude_empty_terms( false, 'estat_locality' ), true );
it( 'single object              ', Seo::sitemap_exclude_empty_terms( false, new WP_Taxonomy( 'post_tag' ) ), false );
it( 'empty array keeps the call  ', Seo::sitemap_exclude_empty_terms( true, array() ), true );
it( 'junk skipped, ours kept     ', Seo::sitemap_exclude_empty_terms( false, array( null, 12.5, array( 'x' ), true ) ), false );
it( 'int id among names          ', Seo::sitemap_exclude_empty_terms( false, array( 7, 'estat_locality' ) ), true );

$duck         = new stdClass();
$duck->name   = 'estat_locality';
it( 'object that looks like one  ', Seo::sitemap_exclude_empty_terms( false, array( $duck ) ), true );

$no_name      = new stdClass();
it( 'object without a name       ', Seo::sitemap_exclude_empty_terms( false, array( $no_name ) ), false );

/** Hostile: reading ->name throws — the callback must still answer. */
class Exploding_Tax {
	public function __get( $k ) {
		throw new RuntimeException( 'boom' );
	}
	public function __isset( $k ) {
		throw new RuntimeException( 'boom' );
	}
}
it( 'hostile object, original no ', Seo::sitemap_exclude_empty_terms( false, array( new Exploding_Tax() ) ), false );
it( 'hostile object, original yes', Seo::sitemap_exclude_empty_terms( true, array( new Exploding_Tax() ) ), true );

echo "== B. wp_sitemaps_taxonomies_query_args (core sitemap)\n";
$args = array( 'hide_empty' => false );
$r    = Seo::core_sitemap_term_args( $args, 'estat_locality' );
it( 'string taxonomy, ours       ', $r['hide_empty'], true );
$r = Seo::core_sitemap_term_args( $args, new WP_Taxonomy( 'estat_locality' ) );
it( 'object taxonomy, ours       ', $r['hide_empty'], true );
$r = Seo::core_sitemap_term_args( $args, new WP_Taxonomy( 'category' ) );
it( 'object taxonomy, not ours   ', $r['hide_empty'], false );
$r = Seo::core_sitemap_term_args( $args, null );
it( 'null passed through safely  ', $r['hide_empty'], false );

echo "== C. the block splitter: same answer, no lookbehind\n";
$samples = array(
	'<p>Public line one.</p><p>Office: rate on the office sheet 92,000 per sq ft (unit not confirmed).</p>' ,
	'<div>keep me</div><h2>heading</h2><ul><li>one</li><li>two</li></ul><blockquote>quote</blockquote>',
	"plain paragraph one\n\nplain paragraph two\n\noffice note: verify with the desk",
	'no tags, no blanks, one run of text',
	'',
);
foreach ( $samples as $i => $html ) {
	$out = PublicText::prose( $html );
	// The exact answer must not have changed from the lookbehind version.
	$old_blocks = preg_split( '/(?<=<\/(?:p|div|h[1-6]|li|blockquote)>)/i', $html, -1, PREG_SPLIT_NO_EMPTY );
	$new_blocks = array();
	$parts      = preg_split( '/(<\/(?:p|div|h[1-6]|li|blockquote)>)/i', $html, -1, PREG_SPLIT_DELIM_CAPTURE );
	if ( is_array( $parts ) ) {
		for ( $j = 0, $n = count( $parts ); $j < $n; $j += 2 ) {
			$chunk = $parts[ $j ] . ( isset( $parts[ $j + 1 ] ) ? $parts[ $j + 1 ] : '' );
			if ( '' !== trim( $chunk ) ) {
				$new_blocks[] = $chunk;
			}
		}
	}
	it( 'split #' . ( $i + 1 ) . ' identical to before', $new_blocks ?: array( $html ), ( is_array( $old_blocks ) && $old_blocks ) ? $old_blocks : array( $html ) );
}
$one = PublicText::prose( $samples[0] );
it( 'public paragraph kept       ', strpos( $one, 'Public line one.' ) !== false, true );
it( 'office paragraph dropped    ', strpos( $one, '92,000' ), false );
$two = PublicText::prose( $samples[2] );
it( 'plain text: both kept       ', substr_count( $two, 'plain paragraph' ), 2 );
it( 'plain text: office line out ', strpos( $two, 'verify with the desk' ), false );

echo "== D. warnings that leaked\n";
it( 'no PHP warnings/errors      ', $notices, array() );

printf( "\n%s — %d checks, %d failed\n", $fail ? 'FINDINGS' : 'ALL CLEAN', $pass + $fail, $fail );
exit( $fail ? 1 : 0 );
