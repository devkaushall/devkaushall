<?php
/**
 * The highlights the office types must survive the save.
 *
 * What went wrong on the live site: the Add a home screen asks for highlight
 * lines, the office typed one, and it was gone. Three separate reasons, all
 * here:
 *
 *   1. `Highlights::sanitize()` kept only the codes that exist in the
 *      catalogue ("corner_plot") and deleted every line the office wrote —
 *      on a screen that has no catalogue at all.
 *   2. `Meta::sanitize_value()` forced the list through the 'textarea' type,
 *      which returns a *string*; a string is not a list, so the list was
 *      thrown away.
 *   3. The handler read a fixed set of ten field names that did not include
 *      the one the screen posted.
 *
 * Run: php /home/user/tests/highlights_save_check.php
 */

namespace {
	define( 'ABSPATH', __DIR__ );

	function __( $text, $domain = null ) { return $text; }
	function esc_html__( $text, $domain = null ) { return $text; }
	function esc_html( $text ) { return $text; }
	function esc_attr( $text ) { return $text; }
	function wp_strip_all_tags( $text ) { return strip_tags( (string) $text ); }
	function sanitize_key( $key ) { return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $key ) ); }
	function sanitize_text_field( $text ) { return trim( strip_tags( (string) $text ) ); }
	function apply_filters( $tag, $value ) { return $value; }
	function wp_kses_post( $text ) { return strip_tags( (string) $text, '<p><strong><em>' ); }
	function get_post_meta( $id, $key, $single = false ) { return $GLOBALS['estat_meta'][ $id ][ $key ] ?? ''; }
	function update_post_meta( $id, $key, $value ) { $GLOBALS['estat_meta'][ $id ][ $key ] = $value; return true; }
	function delete_post_meta( $id, $key ) { unset( $GLOBALS['estat_meta'][ $id ][ $key ] ); return true; }
	function wp_unslash( $value ) { return $value; }
	function absint( $value ) { return abs( (int) $value ); }
	function _n( $single, $plural, $number, $domain = null ) {
		return 1 === (int) $number ? $single : $plural;
	}
	function number_format_i18n( $number, $decimals = 0 ) {
		return number_format( (float) $number, (int) $decimals );
	}
	// The stub only stands in when the extension is missing; with mbstring
	// loaded, declaring it again is a fatal error.
	if ( ! function_exists( 'mb_substr' ) ) {
		function mb_substr( $text, $start, $length = null ) {
			return null === $length ? substr( (string) $text, $start ) : substr( (string) $text, $start, $length );
		}
	}
}

namespace {

	$GLOBALS['estat_meta'] = array();

	require '/home/user/plugin/estat-os/includes/Support/Format.php';
	require '/home/user/plugin/estat-os/includes/Support/Sanitize.php';
	require '/home/user/plugin/estat-os/includes/Data/Highlights.php';

	use EstatOS\Data\Highlights;
	use EstatOS\Data\Meta;

	$fails = 0;
	$say   = function ( $ok, $line ) use ( &$fails ) {
		echo ( $ok ? '  ok   ' : '  FAIL ' ) . $line . "\n";
		if ( ! $ok ) {
			$fails++;
		}
	};

	// ---- a line the office typed ---------------------------------------
	echo "a line the office typed\n";
	$typed = Highlights::sanitize( array( 'Park facing corner unit' ) );
	$say( $typed === array( 'Park facing corner unit' ), 'the typed line is kept, not deleted' );

	$mixed = Highlights::sanitize( array( 'Corner plot', 'corner_plot', '' ) );
	$say( $mixed === array( 'corner_plot' ), 'a catalogue label typed out becomes its code, once' );

	$both = Highlights::sanitize( array( 'corner_plot', 'Own terrace' ) );
	$say( $both === array( 'corner_plot', 'Own terrace' ), 'ticks and typed lines live together' );

	$clean = Highlights::sanitize( array( '<script>x</script>Big terrace' ) );
	$say( $clean === array( 'xBig terrace' ) || $clean === array( 'Big terrace' ), 'tags are stripped from a typed line' );

	// ---- the list has to stay a list ------------------------------------
	echo "\nthe list has to stay a list\n";
	$path = '/home/user/plugin/estat-os/includes/Data/Meta.php';
	$src  = file_get_contents( $path );
	preg_match( '/function sanitize_value.*?\n\t\}/s', $src, $m );
	$body = $m[0];
	// The class needs WordPress's Settings::all() at call time only, so a
	// plain require is enough for this one method.
	$drop = array( 'declare( strict_types = 1 );', 'defined( \'ABSPATH\' ) || exit;' );
	$src  = str_replace( $drop, '', $src );
	// The opening tag stays: stripping it turns the file into text the
	// browser prints (a mistake already made once in the pages test).
	$src  = preg_replace( '/^namespace EstatOS\\\\Data;/m', '', $src, 1 );
	file_put_contents( '/tmp/estat-meta-under-test.php', $src );
	require '/tmp/estat-meta-under-test.php';

	$field = array( 'type' => 'free_text', 'label' => 'Highlights' );
	$kept  = \Meta::sanitize_value( array( 'Corner plot', '', 'Own terrace' ), $field );
	$say( is_array( $kept ) && count( $kept ) === 2, 'an array stays an array through the meta sanitiser' );

	$single = \Meta::sanitize_value( 'Just one line', $field );
	$say( $single === array( 'Just one line' ), 'a lone line becomes a list of one' );

	$nothing = \Meta::sanitize_value( array( '' ), $field );
	$say( $nothing === array(), 'an empty entry stays empty, so a cleared list clears' );

	// ---- reading back ---------------------------------------------------
	echo "\nreading back\n";
	$GLOBALS['estat_meta'][7]['_estat_highlights'] = array( 'Own terrace' );
	$say( Highlights::get( 7 ) === array( 'Own terrace' ), 'a stored line is read back' );

	$GLOBALS['estat_meta'][8]['_estat_highlights'] = "Line one\nLine two";
	$say( Highlights::get( 8 ) === array( 'Line one', 'Line two' ), 'an older block of text is read as lines' );

	$GLOBALS['estat_meta'][9]['_estat_highlights'] = 'corner_plot';
	$say( Highlights::get( 9 ) === array( 'corner_plot' ), 'a single stored code is read back' );

	// ---- and the chip builder must not fall over on an unknown line -----
	echo "\nand the chips\n";
	$GLOBALS['estat_meta'][7]['_estat_highlights'] = array( 'Own terrace', 'corner_plot' );
	$GLOBALS['estat_meta'][7]['_estat_bedrooms'] = 3;
	$GLOBALS['estat_meta'][7]['_estat_area_sqft'] = 1500;
	$chips = Highlights::for_card( 7, 3 );
	$labels = array_map( static function ( $c ) { return (string) $c['label']; }, $chips );
	$say( ! empty( $chips ), 'a card still gets its chips (labels: ' . implode( ', ', $labels ) . ')' );

	echo "\n" . ( $fails ? $fails . " FAILED\n" : "ALL CLEAN\n" );
	exit( $fails ? 1 : 0 );
}
