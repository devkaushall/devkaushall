#!/usr/bin/env python3
"""Analysis 2 — the PHP, read as a machine.

Four questions a person reading the code cannot answer reliably at this size:

  1. Every `Foo::bar()` — does class `Foo` exist in this plugin, and does it
     have a `bar()`? A typo here is a white screen, not a wrong colour.
  2. Every `Settings::get( 'key' )` — is `key` one the plugin actually saves?
     A key that is never written returns the default for ever, and the screen
     that reads it looks broken while reporting no error at all.
  3. Every `current_user_can( 'estat_x' )` — is that capability granted
     anywhere? A capability nobody holds is a button that never appears.
  4. Every `wp_verify_nonce( $x, 'action' )` — is that action created
     somewhere? (The visitor shortlist bug of 4.1.5 was exactly this.)

Run: python3 /home/user/tests/php_static_check.py
"""

import os
import re
import sys
from collections import defaultdict

ROOT = '/home/user/plugin/estat-os/includes'
FILES = []
for base, dirs, files in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in {'.git', 'node_modules'}]
    for name in files:
        if name.endswith('.php'):
            FILES.append(os.path.join(base, name))

TEXT = {p: open(p, encoding='utf-8', errors='replace').read() for p in FILES}
ALL = '\n'.join(TEXT.values())


def strip_comments(text):
    text = re.sub(r'/\*.*?\*/', ' ', text, flags=re.S)
    text = re.sub(r'^\s*//.*$', ' ', text, flags=re.M)
    return text


CLEAN = {p: strip_comments(t) for p, t in TEXT.items()}
ALL_CLEAN = '\n'.join(CLEAN.values())

# ---------------------------------------------------------------- 1. calls
CLASS_DEF = re.compile(r'\b(?:final\s+|abstract\s+)?class\s+([A-Za-z_][A-Za-z0-9_]*)')
METHOD_DEF = re.compile(r'\bfunction\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(')

plugin_classes = {}
for path, text in CLEAN.items():
    for m in CLASS_DEF.finditer(text):
        plugin_classes.setdefault(m.group(1), path)

methods = defaultdict(set)
for path, text in CLEAN.items():
    for m in CLASS_DEF.finditer(text):
        name = m.group(1)
        # methods between this class and the next
        start = m.end()
        nxt = [x.start() for x in CLASS_DEF.finditer(text) if x.start() > start]
        chunk = text[start:nxt[0] if nxt else len(text)]
        for fn in METHOD_DEF.finditer(chunk):
            methods[name].add(fn.group(1))

STATIC_CALL = re.compile(r'\b([A-Z][A-Za-z0-9_]*)::([a-z_][A-Za-z0-9_]*)\s*\(')

KNOWN_OTHER = {
    'WP_Error', 'WP_REST_Request', 'WP_REST_Response', 'WP_REST_Server', 'WP_Query',
    'WP_User', 'WP_Query', 'WP_Post', 'WP_List_Table', 'WP_User_Query', 'WP_Filesystem',
    'WP_Error', 'WP_REST_Controller', 'WP_Http', 'WP_CLI', 'WP_Screen', 'WP_Block_Type_Registry',
    'DateTime', 'DateTimeImmutable', 'DateTimeZone', 'Exception', 'RuntimeException', 'ArrayObject',
    'DOMDocument', 'SimpleXMLElement', 'ZipArchive', 'DirectoryIterator', 'RecursiveIteratorIterator',
    'PDO', 'NumberFormatter', 'IntlDateFormatter', 'Collator', 'Normalizer', 'Locale',
    'SplFileObject', 'PhpOffice',
}

bad_calls = []
for path, text in CLEAN.items():
    for m in STATIC_CALL.finditer(text):
        cls, fn = m.group(1), m.group(2)
        if cls in KNOWN_OTHER or cls == 'self' or cls == 'static':
            continue
        if cls in plugin_classes:
            if fn not in methods[cls]:
                # a method may live in a trait or a parent — say so, do not shout
                bad_calls.append((path, cls, fn))
        elif cls in ('WP_Optimize',):
            continue        # an outside plugin, guarded by class_exists
        elif cls.lower().startswith(('estat', 'wp')):
            bad_calls.append((path, cls, fn))

# ---------------------------------------------------------------- 2. settings
defaults_block = re.search(r'function defaults\(\): array \{(.*?)\n\t\}', TEXT.get(
    os.path.join(ROOT, 'Settings', 'Settings.php'), ''), re.S)
default_keys = set(re.findall(r"'([a-z0-9_]+)'\s*=>", defaults_block.group(1))) if defaults_block else set()

read_keys = defaultdict(set)
for path, text in CLEAN.items():
    for m in re.finditer(r"Settings::get\(\s*'([a-z0-9_]+)'", text):
        read_keys[m.group(1)].add(os.path.basename(path))

unknown_settings = {k: v for k, v in read_keys.items() if k not in default_keys}

# ---------------------------------------------------------------- 3. caps
caps_used = defaultdict(set)
for path, text in CLEAN.items():
    for m in re.finditer(r"current_user_can\(\s*'([a-z0-9_]+)'", text):
        caps_used[m.group(1)].add(os.path.basename(path))
    for m in re.finditer(r"has_cap\(\s*'([a-z0-9_]+)'", text):
        caps_used[m.group(1)].add(os.path.basename(path))

caps_defined = set(re.findall(r"'([a-z0-9_]+)'\s*=>\s*true", ALL))
caps_defined |= set(re.findall(r"add_cap\(\s*'([a-z0-9_]+)'", ALL))
# Capability maps are often written as  'estat_x' => array( ... )  too.
caps_defined |= set(re.findall(r"'((?:estat|manage|edit|read|upload|delete|publish)[a-z0-9_]*)'\s*=>", ALL))

# `estat_edit_record` is a virtual capability: it is resolved to a real one
# by Roles::map_meta_cap() with the record's ID, so it is never granted to a
# role and never should be.
META_CAPS = {'estat_edit_record'}
unknown_caps = {c: v for c, v in caps_used.items()
                if c.startswith('estat') and c not in caps_defined and c not in META_CAPS}

# ---------------------------------------------------------------- 4. nonces
# A nonce is created either by wp_create_nonce() or by wp_nonce_field() —
# the second is the usual one on a form, and was being missed.
made = set(re.findall(r"wp_create_nonce\(\s*'([a-z0-9_]+)'", ALL_CLEAN))
made |= set(re.findall(r"wp_nonce_field\(\s*'([a-z0-9_]+)'", ALL_CLEAN))
checked = set(re.findall(r"wp_verify_nonce\(\s*[^,]+,\s*'([a-z0-9_]+)'", ALL_CLEAN))
checked |= set(re.findall(r"check_ajax_referer\(\s*'([a-z0-9_]+)'", ALL_CLEAN))
checked |= set(re.findall(r"check_admin_referer\(\s*'([a-z0-9_]+)'", ALL_CLEAN))
checked |= set(re.findall(r"wp_nonce_field\(\s*'([a-z0-9_]+)'", ALL_CLEAN))

# Nonces WordPress itself creates for a page it renders:
WP_NONCES = {'logged_in'}
# Actions built at runtime, e.g. 'estat_form_submit_' . $form_id:
never_made = sorted(a for a in checked
                    if a not in made and a not in WP_NONCES and not a.endswith('_'))
never_checked = sorted(a for a in made if a not in checked)

# ------------------------------------------- 5. JSON printed into a <script>
#
# A JSON blob echoed inside a <script> element is markup, not data: the first
# `<` in it ends the element. A property titled "2 < 3 BHK" or an imported title
# with a tag still in it was enough to break the page's structured data, and a
# title containing </script><script>alert(1)</script> ran. JSON_HEX_TAG turns
# those characters into \\u003C so every parser reads them back as data.
#
# This rule checks the rule itself as well as the source: a checker that cannot
# fail is worse than no checker.
def json_in_script_faults(text, label):
    out = []
    for m in re.finditer(r'wp_json_encode\s*\(', text):
        call = text[m.start():m.start() + 400]
        window = text[max(0, m.start() - 400):m.start() + 400]
        if '<script' not in window:
            continue
        # The flags may be written inline or held in a variable set a line or
        # two above, so the whole neighbourhood counts, not just the call.
        if 'JSON_HEX_TAG' not in window:
            line = text[:m.start()].count('\n') + 1
            out.append('%s:%d' % (label, line))
    return out


SELF_TEST_BAD = "echo '<script type=\"application/ld+json\">' . wp_json_encode( $data ) . '</script>';"
SELF_TEST_GOOD = "echo '<script type=\"application/ld+json\">' . wp_json_encode( $data, JSON_HEX_TAG ) . '</script>';"
self_ok = (len(json_in_script_faults(SELF_TEST_BAD, 'sample')) == 1
           and json_in_script_faults(SELF_TEST_GOOD, 'sample') == [])

json_faults = []
for path, text in CLEAN.items():
    json_faults += json_in_script_faults(text, os.path.relpath(path, ROOT))

# ----------------------------------- 6. A page title printed straight out
#
# `the_title()` prints whatever is in the database, filters and all — it does
# not escape. A property called "2 < 3 BHK Flats" loses text to the browser, and
# anything with a tag in it runs. Titles arrive by import and by hand, so the
# template escapes; this rule keeps the next template honest too.
#
# Simple on purpose: in a template, `the_title()` on a line without esc_html()
# or esc_attr() is a fault. The rule is tested against a bad and a good line.
def unescaped_title_faults(text, label):
    out = []
    for i, line in enumerate(text.split('\n'), start=1):
        # Only the echoing call is a fault. get_the_title() returns a string
        # that the caller escapes — Components::map() and Qr::svg() do exactly
        # that — and a rule that cannot tell them apart is noise.
        if 'the_title()' not in line or 'get_the_title()' in line:
            continue
        if 'esc_html(' in line or 'esc_attr(' in line:
            continue
        out.append('%s:%d' % (label, i))
    return out


TITLE_BAD = '\t<h1><?php the_title(); ?></h1>'
TITLE_GOOD = '\t<h1><?php echo esc_html( get_the_title() ); ?></h1>'
title_self_ok = (unescaped_title_faults(TITLE_BAD, 's') == ['s:1']
                 and unescaped_title_faults(TITLE_GOOD, 's') == [])

title_faults = []
for path, text in TEXT.items():
    if os.sep + 'templates' + os.sep in path:
        title_faults += unescaped_title_faults(text, os.path.relpath(path, ROOT))

title_faults = sorted(set(title_faults))

# 7. A regex that older PCRE cannot compile: a lookbehind whose alternatives
#    have different lengths ("lookbehind assertion is not fixed length"). This
#    was the source of the six preg_split() warnings of 7 Oct, and it breaks
#    silently on every PHP older than 8.3-ish — the function returns false
#    and the code below it quietly does the wrong thing. Ban lookbehinds
#    outright; a capture-and-glue split needs none.
def lookbehind_faults(text, label):
    out = []
    for n, line in enumerate(strip_comments(text).splitlines(), 1):
        if '(?<=' in line or '(?<!' in line:
            out.append('%s:%d' % (label, n))
    return out


LB_BAD = "$x = preg_split( '/(?<=<\\/(?:p|div)>)/i', $s );"
LB_GOOD = "$x = preg_split( '/(<\\/(?:p|div)>)/i', $s, -1, PREG_SPLIT_DELIM_CAPTURE );"
lb_self_ok = (len(lookbehind_faults(LB_BAD, 's')) == 1 and not lookbehind_faults(LB_GOOD, 's'))

lb_faults = []
for path, text in TEXT.items():
    lb_faults += lookbehind_faults(text, os.path.relpath(path, ROOT))
lb_faults = sorted(set(lb_faults))

# ---------------------------------------------------------------- report
fails = 0
print('Analysis 2 — PHP static\n')

print('1. Static calls to a class or method this plugin does not have (%d):' % len(bad_calls))
for path, cls, fn in sorted(set(bad_calls)):
    print('     %-42s %s::%s' % (os.path.relpath(path, ROOT), cls, fn))
if not bad_calls:
    print('     none')
fails += len(set(bad_calls))

print('\n2. Settings read but never saved — always the default (%d):' % len(unknown_settings))
for k, where in sorted(unknown_settings.items()):
    print('     %-24s read in %s' % (k, ', '.join(sorted(where))))
if not unknown_settings:
    print('     none')
fails += len(unknown_settings)

print('\n3. Capabilities checked but granted nowhere (%d):' % len(unknown_caps))
for c, where in sorted(unknown_caps.items()):
    print('     %-28s used in %s' % (c, ', '.join(sorted(where))))
if not unknown_caps:
    print('     none')
fails += len(unknown_caps)

print('\n4. Nonces checked but never created (%d):' % len(never_made))
for a in never_made:
    print('     %s' % a)
if not never_made:
    print('     none')
fails += len(never_made)

print('\n5. JSON printed inside a <script> without JSON_HEX_TAG (%d):' % len(json_faults))
for f in sorted(json_faults):
    print('     %s' % f)
if not json_faults:
    print('     none')
fails += len(json_faults)

print('     (self-test: the rule catches a bad line: %s, and leaves a good one alone: %s)'
      % ('yes' if len(json_in_script_faults(SELF_TEST_BAD, 's')) == 1 else 'NO',
         'yes' if not json_in_script_faults(SELF_TEST_GOOD, 's') else 'NO'))

print('\n6. A page title printed without escaping (%d):' % len(title_faults))
for f in title_faults:
    print('     %s' % f)
if not title_faults:
    print('     none')
fails += len(title_faults)
if not title_self_ok:
    print('     (self-test FAILED: the rule does not tell a bad line from a good one)')
    fails += 1

print('\n7. A regex with a lookbehind, which older PCRE cannot compile (%d):' % len(lb_faults))
for f in lb_faults:
    print('     %s' % f)
if not lb_faults:
    print('     none')
fails += len(lb_faults)
if not lb_self_ok:
    print('     (self-test FAILED: the rule does not tell a bad line from a good one)')
    fails += 1

print('\n   (informational) nonces created and never checked (%d): %s'
      % (len(never_checked), ', '.join(never_checked) or 'none'))

print('\n%s' % ('%d FINDINGS' % fails if fails else 'NO FINDINGS'))
sys.exit(0)
