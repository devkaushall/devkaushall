#!/usr/bin/env python3
"""Analysis 3 — the browser side, joined to the PHP side.

Three questions, all of them "does the name on one side exist on the other":

  1. Every `document.querySelector('[data-x]')` / `getElementById('y')` in the
     plugin's JavaScript — does the PHP ever write `data-x`, or `id="y"`? A
     hook with no markup is a feature that silently does nothing.
  2. Every `word('key', 'fallback')` — is that key in the array the PHP
     localizes? A missing key prints the English fallback, which is how a
     translated screen turns English one card at a time.
  3. Every `estat/v1/...` path a script fetches — is that route registered?
     (A 404 from a route nobody registered looks exactly like "no results".)

Run: python3 /home/user/tests/js_contract_check.py
"""

import os
import re
import sys
from collections import defaultdict

ROOT = '/home/user/plugin/estat-os'
JS_FILES = []
PHP_FILES = []
for base, dirs, files in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in {'.git', 'node_modules'}]
    for name in files:
        if name.endswith('.js'):
            JS_FILES.append(os.path.join(base, name))
        elif name.endswith('.php'):
            PHP_FILES.append(os.path.join(base, name))


def read(path):
    return open(path, encoding='utf-8', errors='replace').read()


PHP = '\n'.join(read(p) for p in PHP_FILES)
JS = {p: read(p) for p in JS_FILES}
JS_ALL = '\n'.join(JS.values())

fails = 0
print('Analysis 3 — JavaScript ↔ PHP contract\n')

# ---------------------------------------------------------------- 1. hooks
hook_use = defaultdict(set)
for path, text in JS.items():
    for m in re.finditer(r"querySelector(?:All)?\(\s*'\[([a-zA-Z0-9_-]+)(?:[\]\[=])", text):
        name = m.group(1)
        if not name.startswith('data-'):
            continue           # [aria-invalid], [name=…] — not a data hook
        hook_use['data:' + name[len('data-'):]].add(os.path.basename(path))
    for m in re.finditer(r"querySelector(?:All)?\(\s*'\.([a-z][a-z0-9-]*)'", text):
        hook_use['class:' + m.group(1)].add(os.path.basename(path))
    for m in re.finditer(r"getElementById\(\s*'([a-zA-Z0-9_-]+)'", text):
        hook_use['id:' + m.group(1)].add(os.path.basename(path))

missing = {}
for hook, where in hook_use.items():
    kind, name = hook.split(':', 1)
    if kind == 'data':
        written = re.search(r'data-%s(\s*=\s*["\']|\s*>)' % re.escape(name), PHP) is not None
    elif kind == 'id':
        written = re.search(r'id="%s"' % re.escape(name), PHP) is not None
    else:
        written = re.search(r'[="\' ]%s[ "\']' % re.escape(name), PHP) is not None
    if not written:
        missing[hook] = where

# Three families are expected and are not bugs:
#   * estat-lb-*      — the lightbox is built in JavaScript, so its classes
#                       exist only once the dialog is open;
#   * data-estat-*    — hooks for markup the office builds in Elementor;
#   * adminmenuback / adminmenuwrap / wpadminbar — WordPress's own elements.
def expected(hook):
    name = hook.split(':', 1)[1]
    return (name.startswith('estat-lb-') or hook.startswith('data:estat-')
            or name in {'adminmenuback', 'adminmenuwrap', 'wpadminbar'}
            or name.endswith('-') or name.startswith('kcard') or name.startswith('tgl'))

real = {h: v for h, v in missing.items() if not expected(h)}
print('1. A JavaScript hook the PHP never writes (%d real, %d expected):'
      % (len(real), len(missing) - len(real)))
for hook, where in sorted(real.items()):
    print('     %-34s asked for by %s' % (hook, ', '.join(sorted(where))))
if not real:
    print('     none')
for hook, where in sorted(missing.items()):
    if expected(hook):
        print('     (expected) %-28s %s' % (hook, ', '.join(sorted(where))))
fails += len(real)

# ---------------------------------------------------------------- 2. i18n
word_use = defaultdict(set)
for path, text in JS.items():
    for m in re.finditer(r"word\(\s*'([a-zA-Z0-9_]+)'", text):
        word_use[m.group(1)].add(os.path.basename(path))

# The arrays the PHP localizes: 'key' => __( ... )
localized = set(re.findall(r"'([a-zA-Z0-9_]+)'\s*=>\s*(?:__|_x|_n)\(", PHP))
localized |= set(re.findall(r"'([a-zA-Z0-9_]+)'\s*=>\s*\(string\)", PHP))
localized |= set(re.findall(r"'([a-zA-Z0-9_]+)'\s*=>\s*(?:\(bool\)|\(int\)|true|false|\d)", PHP))

unlocalized = {k: v for k, v in word_use.items() if k not in localized}
print('\n2. An interface word asked for by JavaScript and not localized (%d):' % len(unlocalized))
for k, where in sorted(unlocalized.items()):
    print('     %-22s used by %s' % (k, ', '.join(sorted(where))))
if not unlocalized:
    print('     none')

# ---------------------------------------------------------------- 3. routes
registered = set()
for path in PHP_FILES:
    text = read(path)
    for m in re.finditer(r"register_rest_route\(\s*self::NS,\s*'/([a-z0-9_/-]+)'", text):
        registered.add(m.group(1).strip('/'))
    for m in re.finditer(r"register_rest_route\(\s*self::NS,\s*'([a-z0-9_/-]+)'", text):
        registered.add(m.group(1).strip('/'))

called = defaultdict(set)
for path, text in JS.items():
    for m in re.finditer(r"restUrl\s*\+\s*'([a-z0-9_/-]+)'", text):
        called[m.group(1)].add(os.path.basename(path))
    for m in re.finditer(r"'estat/v1/([a-z0-9_/-]+)'", text):
        called[m.group(1)].add(os.path.basename(path))

unknown_routes = {}
for route, where in called.items():
    head = route.split('/')[0]
    if head not in registered and route not in registered:
        unknown_routes[route] = where

print('\n3. A REST path a script calls and the plugin does not register (%d):'
      % len(unknown_routes))
for route, where in sorted(unknown_routes.items()):
    print('     %-24s called by %s' % (route, ', '.join(sorted(where))))
if not unknown_routes:
    print('     none')
print('   (registered: %s)' % ', '.join(sorted(registered))[:220])

# --------------------------------------- 4. database text written as markup
#
# `x.innerHTML = '<b>' + row.title + '</b>'` puts a property title into the page
# as markup. Titles, lead names, photograph names and the messages the office
# builds out of field labels all come from the database, so a title containing
# a tag ran in the office the moment somebody searched for it. The fix is to
# escape (esc / escapeText) or to build a text node; this rule keeps the next
# line honest.
#
# A member expression (row.title, res.data.message, note.msg …) inside an
# innerHTML assignment must be wrapped in one of the escapers. Server-built
# markup (the drawer's own HTML) and fixed icon names are allow-listed by name,
# with the reason written next to them.
SAFE_MARKUP = {
    'data.html',      # built and escaped by the office screen, sent ready to draw
    'data.foot',      # same
}

# Functions that do the escaping themselves, so calling one is as good as
# writing the escaper here. `cell()` is public.js's table cell — it trims,
# replaces an empty answer with a dash and escapes the rest before returning.
SAFE_WRAPPERS = ('esc(', 'escapeText(', 'iconName(', 'cell(', 'encodeURIComponent(', 'JSON.stringify(')

def unescaped_markup_faults(text, label):
    out = []
    lines = text.split('\n')
    for i, line in enumerate(lines):
        if '.innerHTML' not in line:
            continue
        stmt = line
        j = i
        while ';' not in stmt and j + 1 < len(lines) and j < i + 8:
            j += 1
            stmt += ' ' + lines[j]
        rhs = stmt.split('.innerHTML', 1)[1]
        for m in re.finditer(r'\b([a-zA-Z_$][\w$]*\.[a-zA-Z_$][\w$]*)', rhs):
            token = m.group(1)
            after = rhs[m.end():m.end() + 2]
            if after.startswith('('):
                continue                      # a method call: .trim(), .replace(…)
            before = rhs[max(0, m.start() - 32):m.start()]
            if any(w in before for w in SAFE_WRAPPERS):
                continue
            if token in SAFE_MARKUP:
                continue
            if token.startswith('document.') or token.startswith('window.'):
                continue
            out.append('%s:%d (%s)' % (label, i + 1, token))
    return sorted(set(out))


# The rule is tested before it is trusted.
BAD_SAMPLE = "x.innerHTML = '<b>' + row.title + '</b>';"
GOOD_SAMPLE = "x.innerHTML = '<b>' + esc(row.title) + '</b>';"
GOOD_SAMPLE_2 = "td.innerHTML = cell( ( item.facts || {} )[ key ] );"
GOOD_SAMPLE_3 = "box.innerHTML = html.trim();"
self_ok = (unescaped_markup_faults(BAD_SAMPLE, 's') == ['s:1 (row.title)']
           and unescaped_markup_faults(GOOD_SAMPLE, 's') == []
           and unescaped_markup_faults(GOOD_SAMPLE_2, 's') == []
           and unescaped_markup_faults(GOOD_SAMPLE_3, 's') == [])

markup_faults = []
for path, text in JS.items():
    markup_faults += unescaped_markup_faults(text, os.path.basename(path))

print('\n4. Database text written into the page as markup (%d):' % len(markup_faults))
for f in markup_faults:
    print('     %s' % f)
if not markup_faults:
    print('     none')
if not self_ok:
    print('     (self-test FAILED: the rule cannot tell a bad line from a good one)')
fails += len(markup_faults) + (0 if self_ok else 1)

total = len(real) + len(unlocalized) + len(unknown_routes) + len(markup_faults) + (0 if self_ok else 1)
print('\n%s' % ('%d FINDINGS' % total if total else 'NO FINDINGS'))
sys.exit(0)
