<?php
/**
 * Check for the two live defects found on 2026-10-07:
 *
 *   1. REST /properties/{id} answered only for a single home, so a heart on a
 *      society or project card came back 404 and silently left the visitor's
 *      shortlist.
 *   2. The reply carried no `questions` / `facts`, so the visitor's browser
 *      had nothing to draw the side-by-side table from.
 *
 * No WordPress here. The real PostTypes, Status, Comparison and RestApi files
 * are loaded; everything they reach out to (get_post, meta, Format, Listings,
 * Projects, Agents) is stubbed.
 *
 * Run: php /home/user/tests/rest_property_check.php
 */

namespace EstatOS\Data {
	class Listings {
		public static $rows = array();
		public static function to_array( int $id, bool $private = false ): array {
			return self::$rows[ $id ] ?? array();
		}
	}
	class Projects {
		public static $rows = array();
		public static function to_array( int $id ): array {
			return self::$rows[ $id ] ?? array();
		}
	}
	class Agents {
		public static function to_array( int $id ): array {
			return array( 'id' => $id, 'name' => 'Agent' );
		}
	}
	class Taxonomies {
		public const LOCALITY = 'estat_locality';
		public const AMENITY  = 'estat_amenity';
		public const FEATURE  = 'estat_feature';
	}
}

namespace EstatOS\Support {
	class Format {
		public static function money( float $amount, $symbol = null, $style = null ): string {
			return 'Rs ' . number_format( $amount );
		}
		public static function area( float $value, string $unit = 'sqft' ): string {
			return $value . ' ' . $unit;
		}
		public static function price_range( $min, $max, string $offer = 'sale', bool $on_request = false ): string {
			return 'Rs ' . number_format( (float) $min ) . ' - ' . number_format( (float) $max );
		}
	}
}

namespace {
	define( 'ABSPATH', __DIR__ );
	define( 'MINUTE_IN_SECONDS', 60 );

	$GLOBALS['estat_posts'] = array();
	$GLOBALS['estat_meta']  = array();
	$GLOBALS['estat_terms'] = array();

	function get_post( $id ) {
		return $GLOBALS['estat_posts'][ (int) $id ] ?? null;
	}
	function get_posts( $args = array() ) {
		return array();
	}
	function get_post_meta( $id, $key, $single = false ) {
		return $GLOBALS['estat_meta'][ (int) $id ][ $key ] ?? '';
	}
	function get_permalink( $id ) {
		return 'https://example.test/?p=' . (int) $id;
	}
	function get_the_title( $id ) {
		return get_post( $id )->post_title ?? '';
	}
	function __( $text, $domain = null ) {
		return $text;
	}
	function _n( $one, $many, $number, $domain = null ) {
		return 1 === (int) $number ? $one : $many;
	}
	function is_wp_error( $thing ) {
		return false;
	}
	function wp_get_object_terms( $id, $tax, $args = array() ) {
		return $GLOBALS['estat_terms'][ (int) $id ][ $tax ] ?? array();
	}
	function absint( $value ) {
		return abs( (int) $value );
	}
	function sanitize_text_field( $value ) {
		return trim( (string) $value );
	}
	function esc_url_raw( $value ) {
		return (string) $value;
	}
	function esc_html( $value ) {
		return $value;
	}
	function esc_attr( $value ) {
		return $value;
	}
	function wp_salt( $scheme = '' ) {
		return 'salt';
	}
	function wp_hash( $value ) {
		return hash( 'sha256', $value );
	}
	function get_transient( $key ) {
		return 0;
	}
	function set_transient( $key, $value, $ttl = 0 ) {
		return true;
	}
	function add_query_arg( $key, $value, $url ) {
		return $url . '?print=' . $value;
	}
	function wp_unslash( $value ) {
		return $value;
	}
	function wp_json_encode( $value ) {
		return json_encode( $value );
	}
	function apply_filters( $tag, $value ) {
		return $value;
	}
	function do_action() {}
	function current_user_can( $cap ) {
		return false;
	}
	function get_current_user_id() {
		return 0;
	}

	class WP_Error {
		public $code;
		public $message;
		public $data;
		public function __construct( $code = '', $message = '', $data = array() ) {
			$this->code    = $code;
			$this->message = $message;
			$this->data    = $data;
		}
		public function get_error_code() {
			return $this->code;
		}
		public function get_error_data() {
			return $this->data;
		}
	}

	class WP_REST_Request implements ArrayAccess {
		private $params;
		public function __construct( array $params = array() ) {
			$this->params = $params;
		}
		public function get_params() {
			return $this->params;
		}
		#[\ReturnTypeWillChange]
		public function offsetExists( $offset ): bool {
			return isset( $this->params[ $offset ] );
		}
		#[\ReturnTypeWillChange]
		public function offsetGet( $offset ): mixed {
			return $this->params[ $offset ] ?? null;
		}
		#[\ReturnTypeWillChange]
		public function offsetSet( $offset, $value ): void {
			$this->params[ $offset ] = $value;
		}
		#[\ReturnTypeWillChange]
		public function offsetUnset( $offset ): void {}
	}

	class WP_REST_Response {
		public $data;
		public $status;
		public function __construct( $data = null, $status = 200 ) {
			$this->data   = $data;
			$this->status = $status;
		}
	}

	class WP_REST_Server {
		public const READABLE  = 'GET';
		public const CREATABLE = 'POST';
	}

	$root = '/home/user/plugin/estat-os/includes/';
	require_once $root . 'Data/PostTypes.php';
	require_once $root . 'Support/Status.php';
	require_once $root . 'Support/Comparison.php';

	/*
	 * RestApi declares strict_types, which must be the first statement in its
	 * file; loaded through require it is, so it can be used as-is once the
	 * declare line is out of the way of this harness's own dynamic use.
	 */
	$api = file_get_contents( $root . 'Rest/RestApi.php' );
	$api = preg_replace( '/declare\( strict_types = 1 \);/', '', $api, 1 );
	file_put_contents( '/tmp/estat-restapi-under-test.php', $api );
	require '/tmp/estat-restapi-under-test.php';

	// ---- fixtures -------------------------------------------------------
	$GLOBALS['estat_posts'][7]  = (object) array( 'ID' => 7, 'post_type' => 'estat_listing', 'post_status' => 'publish', 'post_title' => 'Sunlit 3BHK on Golf Course Road' );
	$GLOBALS['estat_posts'][9]  = (object) array( 'ID' => 9, 'post_type' => 'estat_project', 'post_status' => 'publish', 'post_title' => 'Arize Tessoro' );
	$GLOBALS['estat_posts'][11] = (object) array( 'ID' => 11, 'post_type' => 'estat_listing', 'post_status' => 'draft', 'post_title' => 'Draft flat' );
	$GLOBALS['estat_posts'][12] = (object) array( 'ID' => 12, 'post_type' => 'estat_listing', 'post_status' => 'publish', 'post_title' => 'Thin listing' );

	$GLOBALS['estat_terms'][7] = array( 'estat_locality' => array( 'Golf Course Road' ) );
	$GLOBALS['estat_terms'][9] = array( 'estat_locality' => array( 'Sector 63A' ) );

	\EstatOS\Data\Listings::$rows[7] = array(
		'id' => 7, 'title' => 'Sunlit 3BHK on Golf Course Road', 'url' => get_permalink( 7 ),
		'price_display' => 'Rs 2,45,00,000', 'area' => 1850, 'area_unit' => 'sqft', 'bedrooms' => 3,
		'bathrooms' => 0, 'floor' => 12, 'furnishing' => 'Semi-furnished', 'parking' => 2,
		'locality' => array( 'Golf Course Road' ), 'availability' => '', 'project_name' => 'M3M Golf Estate',
		'agent_id' => 0, 'project_id' => 9,
	);
	// Only three of the ten are known; the rest must arrive as empty strings.
	\EstatOS\Data\Listings::$rows[12] = array(
		'id' => 12, 'title' => 'Thin listing', 'url' => get_permalink( 12 ),
		'price_display' => '', 'price' => 7500000, 'area' => 0, 'area_unit' => 'sqft', 'bedrooms' => 0,
		'bathrooms' => 0, 'floor' => 0, 'furnishing' => '', 'parking' => 0,
		'locality' => array(), 'availability' => '', 'project_name' => '',
		'agent_id' => 0, 'project_id' => 0,
	);
	\EstatOS\Data\Projects::$rows[9] = array(
		'id' => 9, 'title' => 'Arize Tessoro', 'url' => get_permalink( 9 ),
	);
	$GLOBALS['estat_meta'][9] = array(
		'_estat_price_min' => '24000000', '_estat_price_max' => '42000000',
		'_estat_unit_types' => '3BHK, 4BHK', '_estat_project_type' => 'Group housing',
		'_estat_possession_date' => 'Dec 2027', '_estat_developer' => 'Arize',
	);

	// ---- checks ---------------------------------------------------------
	$fails = 0;
	$say   = function ( $ok, $line ) use ( &$fails ) {
		echo ( $ok ? '  ok   ' : '  FAIL ' ) . $line . "\n";
		if ( ! $ok ) {
			$fails++;
		}
	};

	$home    = \EstatOS\Rest\RestApi::get_property( new WP_REST_Request( array( 'id' => 7 ) ) );
	$society = \EstatOS\Rest\RestApi::get_property( new WP_REST_Request( array( 'id' => 9 ) ) );
	$draft   = \EstatOS\Rest\RestApi::get_property( new WP_REST_Request( array( 'id' => 11 ) ) );
	$missing = \EstatOS\Rest\RestApi::get_property( new WP_REST_Request( array( 'id' => 999 ) ) );
	$thin    = \EstatOS\Rest\RestApi::get_property( new WP_REST_Request( array( 'id' => 12 ) ) );

	echo "single home (/properties/7)\n";
	$say( $home instanceof WP_REST_Response, 'answers with a response' );
	$say( 'Sunlit 3BHK on Golf Course Road' === $home->data['title'], 'carries the title the browser draws' );
	$say( 'https://example.test/?p=7' === $home->data['url'], 'carries the permalink' );
	$say( is_array( $home->data['questions'] ) && 10 === count( $home->data['questions'] ), 'carries all ten questions' );
	$say( array( 'price', 'area', 'bedrooms', 'bathrooms', 'floor', 'furnishing', 'parking', 'locality', 'availability', 'society' ) === array_keys( $home->data['questions'] ), 'in the office order' );
	$say( is_array( $home->data['facts'] ) && 10 === count( $home->data['facts'] ), 'carries ten answers' );
	$say( 'Rs 2,45,00,000' === $home->data['facts']['price'], 'price answered' );
	$say( '1850 sqft' === $home->data['facts']['area'], 'size answered' );
	$say( 'M3M Golf Estate' === $home->data['facts']['society'], 'society answered' );
	$say( '' === $home->data['facts']['bathrooms'], 'a question with no answer is empty, not dropped' );

	echo "\nsociety (/properties/9) — the one that used to 404\n";
	$say( $society instanceof WP_REST_Response, 'a project is answered, not refused' );
	$say( 'Arize Tessoro' === ( $society->data['title'] ?? '' ), 'carries the title' );
	$say( 10 === count( $society->data['facts'] ?? array() ), 'carries ten answers' );
	$say( '3BHK, 4BHK' === ( $society->data['facts']['bedrooms'] ?? '' ), 'unit types land where the question asks' );
	$say( 'Dec 2027' === ( $society->data['facts']['availability'] ?? '' ), 'possession lands on availability' );
	$say( '' === ( $society->data['facts']['bathrooms'] ?? 'x' ), 'a blank stays blank for a society too' );

	echo "\nnot for the public\n";
	$say( $draft instanceof WP_Error, 'a draft reads as not found' );
	$say( 404 === ( $draft->get_error_data()['status'] ?? 0 ), 'with a 404' );
	$say( $missing instanceof WP_Error, 'an id that never existed reads as not found' );

	echo "\na listing with almost nothing filled in (/properties/12)\n";
	$say( 10 === count( $thin->data['facts'] ?? array() ), 'still ten answers' );
	$said  = count( array_filter( (array) $thin->data['facts'], function ( $v ) { return '' !== $v; } ) );
	$say( 1 === $said, 'one said — the price, which falls back to the number' );
	$say( 'Rs 7,500,000' === $thin->data['facts']['price'], 'and it is written as money, not a raw figure' );
	$say( 9 === 10 - $said, 'nine blanks travel as blanks' );

	echo "\n" . ( $fails ? $fails . " FAILED\n" : "ALL CLEAN\n" );
	exit( $fails ? 1 : 0 );
}
