<?php
/**
 * The idempotency-key column repair, tested against a database we control.
 *
 * The live repair asks the database to let a key be NULL, then claims it is
 * finished. Whether that claim is true cannot be tested on a healthy database
 * alone: the interesting case is a database that refuses the change, and a
 * healthy database never does. So this check hands the repair a database that
 * answers exactly as each kind of server does, and reads what it wrote down.
 *
 *   1. a database that allows the change      -> the repair is marked done
 *   2. a database that refuses it             -> NOT marked done (it will try again)
 *   3. allows the change, but the clearing fails -> NOT marked done
 *   4. nothing to clear                       -> marked done
 *   5. already done                           -> no queries at all
 *
 * A false "done" here is how the lost-enquiry bug survived: the update that
 * was supposed to fix the column never ran, and nothing said so.
 */

namespace {

	/** A database that answers on cue. */
	class FakeWpdb {
		public $prefix      = 'wp_';
		public $errors      = false;
		public $log         = array();
		public $alter_ok    = true;    // does ALTER ... MODIFY work?
		public $null_ok     = true;    // does the column report Null=YES?
		public $clear_ok    = true;    // does the clearing UPDATE work?
		public $empties     = array( 'estat_leads' => 0, 'estat_submissions' => 0 );

		public function suppress_errors( $on = true ) { $this->errors = (bool) $on; return true; }

		public function prepare( $q, ...$args ) { return $q; }

		public function query( $q ) {
			$this->log[] = $q;
			if ( false !== stripos( $q, 'ALTER TABLE' ) ) {
				return $this->alter_ok;
			}
			if ( false !== stripos( $q, 'UPDATE' ) ) {
				if ( ! $this->clear_ok ) {
					return false;
				}
				$table = $this->table_of( $q );
				$n     = $this->empties[ $table ] ?? 0;
				$this->empties[ $table ] = 0;
				return $n;
			}
			return 0;
		}

		public function get_row( $q, $mode = null ) {
			$this->log[] = $q;
			return array( 'Field' => 'idempotency_key', 'Null' => $this->null_ok ? 'YES' : 'NO' );
		}

		public function get_var( $q ) {
			$this->log[] = $q;
			if ( false !== stripos( $q, 'COUNT(*)' ) ) {
				return $this->empties[ $this->table_of( $q ) ] ?? 0;
			}
			return null;
		}

		private function table_of( $q ) {
			return false === stripos( $q, 'estat_submissions' ) ? 'estat_leads' : 'estat_submissions';
		}
	}

	defined( 'ABSPATH' ) || define( 'ABSPATH', '/tmp/wp/' );
	defined( 'ARRAY_A' ) || define( 'ARRAY_A', 'ARRAY_A' );

	$GLOBALS['estat_options'] = array();
	$GLOBALS['wpdb']          = new FakeWpdb();

	function get_option( $key, $default = false ) {
		return $GLOBALS['estat_options'][ $key ] ?? $default;
	}
	function update_option( $key, $value, $autoload = null ) {
		$GLOBALS['estat_options'][ $key ] = $value;
		return true;
	}
	function delete_option( $key ) {
		unset( $GLOBALS['estat_options'][ $key ] );
		return true;
	}
	function dbDelta( $sql ) { return array(); }
	function wp_cache_get( $k, $g ) { return false; }
	function wp_cache_set( $k, $v, $g, $t = 0 ) { return true; }
	function wp_cache_delete( $k, $g ) { return true; }
	function current_time( $t ) { return '2026-10-08 00:00:00'; }
	function sanitize_key( $k ) { return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $k ) ); }

	require '/home/user/plugin/estat-os/includes/Install/Schema.php';

	$fails = 0;
	$say   = function ( $ok, $line ) use ( &$fails ) {
		echo ( $ok ? '  PASS  ' : '  FAIL  ' ) . $line . "\n";
		if ( ! $ok ) {
			$fails++;
		}
	};

	$OPTION = 'estat_os_key_nullable';

	/** Run the repair once with the database answering as told. */
	$run = function ( $alter_ok, $null_ok, $clear_ok, $empties ) use ( $OPTION ) {
		$GLOBALS['estat_options'] = array();
		$db = new FakeWpdb();
		$db->alter_ok = $alter_ok;
		$db->null_ok  = $null_ok;
		$db->clear_ok = $clear_ok;
		$db->empties  = $empties;
		$GLOBALS['wpdb'] = $db;

		$m = new ReflectionMethod( 'EstatOS\Install\Schema', 'clear_empty_keys' );
		$m->setAccessible( true );
		$m->invoke( null, 'wp_' );

		return array( get_option( $OPTION ), $db );
	};

	echo "The idempotency-key repair\n\n";

	list( $flag, $db ) = $run( true, true, true, array( 'estat_leads' => 1, 'estat_submissions' => 1 ) );
	$say( '1' === $flag, 'a database that allows the change is written down as done' );
	$say( 0 === $db->empties['estat_leads'] && 0 === $db->empties['estat_submissions'],
		'and the rows that held an empty key were cleared' );

	list( $flag, $db ) = $run( false, false, false, array( 'estat_leads' => 1, 'estat_submissions' => 0 ) );
	$say( false === $flag, 'a database that refuses the change is NOT written down as done (it can try again)' );
	$say( 1 === $db->empties['estat_leads'], 'and the row that still holds an empty key is left visible' );

	list( $flag, $db ) = $run( true, true, false, array( 'estat_leads' => 1, 'estat_submissions' => 0 ) );
	$say( false === $flag, 'a clearing statement that fails is not mistaken for a success' );

	list( $flag, $db ) = $run( true, true, true, array( 'estat_leads' => 0, 'estat_submissions' => 0 ) );
	$say( '1' === $flag, 'a database with nothing to clear is written down as done' );

	// already done: not a single query should be issued
	$GLOBALS['estat_options'] = array( $OPTION => '1' );
	$db = new FakeWpdb();
	$GLOBALS['wpdb'] = $db;
	$m = new ReflectionMethod( 'EstatOS\Install\Schema', 'clear_empty_keys' );
	$m->setAccessible( true );
	$m->invoke( null, 'wp_' );
	$say( array() === $db->log, 'once it is done, the repair touches the database no more' );

	echo "\n" . ( $fails ? "FAILED: $fails" : 'ALL CLEAN' ) . "\n";
	exit( $fails ? 1 : 0 );
}
