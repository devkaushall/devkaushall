#!/usr/bin/env python3
"""Analysis 7 — the form and the handler must agree on names.

This is the fault that cost the office a week, twice. A screen writes a form;
the code that receives it reads a *different* name. Every file is valid, the
page draws, a lint is clean, and the button does nothing — or, worse, answers
"that link has expired".

  * Add a home posted `action=estat_save_listing`; the handler read only
    `estat_action`, so Publish returned before doing anything.
  * Then the routing was fixed and the *nonce* did not match: the screen
    carries `estat_add_home` for a new property while the save checked
    `estat_save_listing_0`, so Publish answered "that link has expired" with
    the property untouched.
  * The save buttons are `name="save" (publish|draft)` and the handler read
    `estat_save_mode`.
  * The highlights are `name="highlights[]"` and the handler kept a fixed
    list of ten field names that did not include them.
  * Export links say `kind=leads`; the reader read `what`.

So the check does three things, for every form in the office screens:
  1. the action key it posts must be routed by Actions::handle();
  2. the nonce it carries must be one the *handler that route reaches* checks
     (a record's own key counts: `estat_save_listing_` + id);
  3. every field it shows must be read somewhere, or belong to the record
     schema, or to the settings allowlist.

Run: python3 /home/user/tests/form_wiring_check.py
"""

import os
import re
import sys

ROOT = os.environ.get('ESTAT_ROOT', '/home/user/plugin/estat-os')
SCREENS = os.path.join(ROOT, 'includes', 'Admin', 'Os', 'Screens')
ACTIONS = os.path.join(ROOT, 'includes', 'Admin', 'Actions.php')

findings = []


def read(path):
    with open(path, encoding='utf-8', errors='replace') as handle:
        return handle.read()


actions_php = read(ACTIONS)

# ---------------------------------------------------------------- the routes
# case 'save_listing': self::save_listing();
switches = re.findall(r"case\s+'([a-z0-9_]+)'\s*:\s*\n\s*self::([a-z0-9_]+)\(", actions_php)
route_of = {}
for key, method in switches:
    route_of.setdefault(key, method)
# A route may be handled inside one shared method (form_action, save_agent …).
caps = set(re.findall(r"'([a-z0-9_]+)'\s*=>\s*'[a-z_]+',", actions_php))

# ------------------------------------------------- the nonces a method checks
def body_of(method):
    """The text of one private/public static method."""
    m = re.search(
        r"(?:private|public|protected)\s+static\s+function\s+%s\s*\([^)]*\)[^{]*\{" % method,
        actions_php)
    if not m:
        return ''
    depth, i = 0, m.end() - 1
    start = i
    while i < len(actions_php):
        if actions_php[i] == '{':
            depth += 1
        elif actions_php[i] == '}':
            depth -= 1
            if depth == 0:
                return actions_php[start:i + 1]
        i += 1
    return actions_php[start:]


def nonces_of(method):
    """Literal nonces (and key prefixes) one method will accept."""
    body = body_of(method)
    if not body:
        return set(), set()
    exact, prefix = set(), set()

    # self::verify( 'literal' ) and self::verify( 'prefix' . $x )
    for m in re.finditer(r"self::verify\(\s*'([a-z0-9_]+)'(?:\s*\.\s*([^,)]+))?", body):
        if m.group(2):
            prefix.add(m.group(1))
        else:
            exact.add(m.group(1))

    # self::verify_any( array( 'a', 'b' . $x ) )
    for m in re.finditer(r"self::verify_any\(\s*array\((.*?)\)", body, re.S):
        for piece in m.group(1).split(','):
            lit = re.match(r"\s*'([a-z0-9_]+)'", piece)
            if not lit:
                continue
            if '.' in piece:
                prefix.add(lit.group(1))
            else:
                exact.add(lit.group(1))

    # One method may call another that does the checking.
    for called in re.findall(r"self::([a-z0-9_]+)\(", body):
        if called in ('verify', 'verify_any', method):
            continue
        more_exact, more_prefix = nonces_of(called)
        exact |= more_exact
        prefix |= more_prefix

    return exact, prefix


# The names the handler reads for itself, and the field names it looks at.
reads_action = {
    'action': bool(re.search(r"\$_(?:REQUEST|GET|POST)\[\s*'action'\s*\]", actions_php)),
    'estat_action': bool(re.search(r"\$_(?:REQUEST|GET|POST)\[\s*'estat_action'\s*\]", actions_php)),
}
read_names = set(re.findall(r"\$_(?:POST|REQUEST)\[\s*'([a-z0-9_]+)'\s*\]", actions_php))
read_names |= set(re.findall(r"self::\w+\(\s*'([a-z0-9_]+)'", actions_php))
read_names |= {'title', 'offer', 'price', 'area'} if 'listing_input' in actions_php else set()
read_names |= {'save'} if re.search(r"'save'\s*,", actions_php) else set()

schema = read(os.path.join(ROOT, 'includes', 'Data', 'Meta.php'))
settings_php = read(os.path.join(ROOT, 'includes', 'Settings', 'Settings.php'))
known = {'tab', 'listing_id', 'project_id', 'estat_nonce', 'action', 'estat_action',
         'agent_id', 'visit_id', 'lead_id', 'form_id', 'job_id', 'id', 'kind',
         'verification', 'settings', 'save'}

# ------------------------------------------------------------------- the forms
FORM = re.compile(r"<form\b(.*?)</form>", re.S)
forms_seen = 0

for name in sorted(os.listdir(SCREENS)):
    if not name.endswith('.php'):
        continue
    text = read(os.path.join(SCREENS, name))
    for m in FORM.finditer(text):
        block = m.group(1)
        line = text[:m.start()].count('\n') + 1
        if 'admin-post.php' not in block and 'estat_action' not in block:
            continue
        forms_seen += 1

        # ---- what the form posts its action under --------------------
        posted = re.findall(
            r"name=\"(action|estat_action)\"\s+value=\"([a-zA-Z0-9_]+)\"", block)
        for key_name, value in posted:
            short = value[len('estat_'):] if value.startswith('estat_') else value
            if not reads_action.get(key_name, False):
                findings.append(
                    '%s:%d  posts its action as %s="%s" and Actions.php never reads '
                    "'%s' — the handler is looking at the other name and returns "
                    'before doing anything' % (name, line, key_name, value, key_name))
                continue
            method = route_of.get(short)
            if not method:
                findings.append(
                    '%s:%d  posts %s=%s and no route in Actions::handle() answers '
                    'to "%s" — the press would return without doing anything'
                    % (name, line, key_name, value, short))
                continue

            # ---- and the nonce it carries must be one that route checks --
            exact, prefix = nonces_of(method)
            if method in ('form_action', 'save_agent', 'record_target'):
                # These fan out by a second field; accept the union of the
                # whole file rather than guessing which branch runs.
                exact, prefix = nonces_of('form_action')[0] | nonces_of('save_agent')[0], \
                                nonces_of('form_action')[1] | nonces_of('save_agent')[1]

            carried = re.findall(r"wp_nonce_field\(\s*'([a-z0-9_]+)'", block)
            # A nonce built for one record: wp_nonce_field( 'estat_save_listing_' . $id )
            carried += re.findall(r"wp_nonce_field\(\s*'([a-z0-9_]+_)'\s*\.", block)
            for nonce in carried:
                if nonce in ('logged_in',):
                    continue
                if nonce in exact or nonce in prefix:
                    continue
                if any(nonce.startswith(p) for p in prefix):
                    continue
                findings.append(
                    '%s:%d  the form carries the nonce "%s" while the handler that '
                    'this action reaches (%s) checks %s — the press answers '
                    '"that link has expired"'
                    % (name, line, nonce, method,
                       ', '.join(sorted(exact | prefix)) or 'nothing at all'))

        # ---- the fields ------------------------------------------------
        for field in sorted(set(re.findall(r"name=\"([a-zA-Z0-9_\[\]]+)\"", block))):
            bare = field[:-2] if field.endswith('[]') else field
            if bare in read_names or bare in known:
                continue
            m2 = re.fullmatch(r'settings\[([a-z0-9_]+)\]', bare)
            if m2:
                if "'%s'" % m2.group(1) in settings_php:
                    continue
                findings.append(
                    '%s:%d  the settings form offers "%s" and Settings::sanitize() '
                    'does not know that key — the box would save as nothing'
                    % (name, line, bare))
                continue
            if "'_estat_%s'" % bare in schema or "'%s'" % bare in schema:
                continue
            findings.append(
                '%s:%d  the form offers the field "%s" and nothing reads it — the '
                'office can fill it in and it is dropped on save'
                % (name, line, field))

print('Analysis 7 — does every form field reach a reader?\n')
print('Routes: %d   forms with an action of their own: %d\n' % (len(route_of), forms_seen))
if findings:
    for f in findings:
        print('     ' + f)
else:
    print('     none')
print('\n%s' % ('%d FINDINGS' % len(findings) if findings else 'NO FINDINGS'))
sys.exit(0)
