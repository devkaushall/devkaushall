#!/usr/bin/env python3
"""Analysis 6 — REST callbacks WordPress will call with three arguments.

The P1 that broke the live website for weeks was one word:

    'validate_callback' => 'is_numeric',

WordPress calls a validation callback with **three** arguments — the value,
the request, the parameter name. PHP's own `is_numeric()` takes exactly one,
so PHP 8 answers with `ArgumentCountError`, WordPress turns that into its
"critical error" page, and every request to `/estat/v1/properties/{id}` — and
`/estat/v2/properties/{id}`, and `/forms/{id}/submit` — returned HTTP 500
before its handler ran a single line.

A *userland* function (any WordPress function, any of ours) simply ignores
arguments it does not declare, so `absint`, `sanitize_text_field` and friends
are all fine. Only PHP's own internal functions are a fatal.

This check reads every `validate_callback` and `sanitize_callback` in the
plugin and reports the ones naming an internal PHP function.

Run: python3 /home/user/tests/rest_callback_check.py
"""

import os
import re
import subprocess
import sys

ROOT = '/home/user/plugin/estat-os'
PHP = []
for base, dirs, files in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in {'.git', 'node_modules'}]
    for name in files:
        if name.endswith('.php'):
            PHP.append(os.path.join(base, name))


def internal_functions():
    """The names PHP itself defines, straight from PHP when it is available."""
    known = os.environ.get('ESTAT_INTERNAL_CACHE', '/tmp/estat-internal-fn.txt')
    try:
        with open(known, encoding='utf-8') as handle:
            return set(handle.read().split())
    except OSError:
        pass
    try:
        out = subprocess.run(
            ['php', '-r', 'echo implode(" ", get_defined_functions()["internal"]);'],
            capture_output=True, text=True, timeout=30, check=True,
        ).stdout
        names = set(out.split())
        try:
            with open(known, 'w', encoding='utf-8') as handle:
                handle.write(' '.join(sorted(names)))
        except OSError:
            pass
        return names
    except Exception:
        # A short list of the ones a plugin might plausibly reach for, so the
        # check still has teeth on a machine without php-cli.
        return {
            'is_numeric', 'intval', 'floatval', 'abs', 'strlen', 'is_string',
            'is_int', 'is_array', 'is_bool', 'is_float', 'is_null', 'trim',
            'ltrim', 'rtrim', 'strpos', 'strtolower', 'strtoupper', 'ucfirst',
            'lcfirst', 'urldecode', 'urlencode', 'number_format', 'round',
            'ceil', 'floor', 'max', 'min', 'count', 'array_keys', 'implode',
            'explode', 'json_encode', 'json_decode', 'preg_match', 'preg_replace',
        }


CALLBACK = re.compile(r"'((?:validate|sanitize)_callback)'\s*=>\s*'([A-Za-z0-9_\\\\]+)'")

internal = internal_functions()
print('Analysis 6 — REST validation and sanitising callbacks\n')
print('PHP internal functions known: %d\n' % len(internal))

findings = []
for path in PHP:
    text = open(path, encoding='utf-8', errors='replace').read()
    text = re.sub(r'/\*.*?\*/', ' ', text, flags=re.S)
    for m in re.finditer(CALLBACK, text):
        kind, fn = m.group(1), m.group(2).lstrip('\\')
        if fn.lower() in internal:
            line = text[:m.start()].count('\n') + 1
            findings.append((os.path.relpath(path, ROOT), line, kind, fn))

print('A callback naming a PHP internal function — fatal on every request (%d):'
      % len(findings))
for path, line, kind, fn in findings:
    print('     %s:%d  %s => %s' % (path, line, kind, fn))
    print('        WordPress calls it with ( $value, $request, $param );')
    print('        PHP internal functions accept exactly one argument.')
if not findings:
    print('     none')

# And the belt to go with the braces: every id route should still validate.
every = '\n'.join(open(p, encoding='utf-8', errors='replace').read() for p in PHP)
print('Routes still checking their id: %d'
      % len(re.findall(r"'validate_callback'\s*=>\s*array\(\s*__CLASS__,\s*'is_id'\s*\)", every)))

print('\n%s' % ('%d FINDINGS' % len(findings) if findings else 'NO FINDINGS'))
sys.exit(0)
