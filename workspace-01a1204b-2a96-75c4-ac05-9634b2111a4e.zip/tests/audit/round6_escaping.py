#!/usr/bin/env python3
"""Round 6 — does anything the office or a visitor typed ever come back as code?

Sanitising on the way in is the first line; the second is escaping on the way
out, and only the second one saves you when the value did not come in through
this plugin at all — an import, an older version, another plugin, a database
somebody edited by hand.

So this round writes hostile text straight into the database, then reads every
rendered surface — the office screens, the public pages, the phone — and looks
for a live tag. Escaped text (`&lt;img`) is correct and passes; a real
`<img onerror=...>` fails.
"""

import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from harness import Site, check, summary , DB  # noqa: E402

PAYLOAD = "<img src=x onerror=alert(1)>"
REFLEX = "<script>alert(9)</script>"

OFFICE_SCREENS = [
    ("estat-add-home", ""),
    ("estat-listings", ""),
    ("estat-enquiries", ""),
    ("estat-duplicates", ""),
    ("estat-forms", ""),
    ("estat-agents", ""),
    ("estat-settings", ""),
]


def live(html):
    """Any unescaped occurrence of the payload, in any of its disguises."""
    hits = []
    for probe in ("<img src=x onerror", "<img src=\"x\" onerror", "<script>alert(", "onerror=alert(1)>"):
        for m in re.finditer(re.escape(probe), html, re.I):
            hits.append(html[max(0, m.start() - 40):m.end() + 20].replace("\n", " "))
    return hits


def escaped(html):
    return "&lt;img" in html or "&amp;lt;img" in html


def main():
    before = Site.log_mark()
    owner = Site().login("owner", "ownerpass")
    anon = Site()

    print("A. Hostile text, written straight into the database")
    import json
    import sqlite3

    con = sqlite3.connect(DB)
    # a property, made the normal way, then given a nasty title and detail by hand
    lid = int(Site.wp(
        '$id = wp_insert_post( array( "post_title" => "Audit hostile home", "post_type" => "estat_listing",'
        ' "post_status" => "publish" ) ); update_post_meta( $id, "estat_price", 12345678 );'
        ' update_post_meta( $id, "estat_locality", "Sector 43" ); echo $id;'
    ).strip().splitlines()[-1])
    check("a listing to spoil exists", lid > 0, lid)
    con.execute("UPDATE wp_posts SET post_title = ? WHERE ID = ?", (PAYLOAD + " home", lid))
    con.execute("UPDATE wp_postmeta SET meta_value = ? WHERE post_id = ?", (PAYLOAD, lid))

    # A row of this round's own, so poisoning it cannot disturb what the other
    # rounds left behind — an older version of this fixture renamed whatever
    # enquiry happened to be newest, and two rounds later found their own
    # record missing under the name they were looking for.
    con.execute(
        "INSERT INTO wp_estat_leads (name, phone, message, status, source, created_at, updated_at) "
        "VALUES (?, ?, ?, 'new', 'office', '', '')",
        ("Round six fixture", "+919800007777", "poison me"),
    )
    fixture_id = con.execute("SELECT MAX(id) FROM wp_estat_leads").fetchone()[0]
    con.execute("UPDATE wp_estat_leads SET name = ?, message = ? WHERE id = ?", (PAYLOAD, PAYLOAD, fixture_id))
    lead = con.execute("SELECT id, name FROM wp_estat_leads WHERE id = ?", (fixture_id,)).fetchone()
    check("an enquiry carrying a tag was stored", PAYLOAD in lead[1], lead)

    row = con.execute("SELECT definition FROM wp_estat_forms WHERE id = 2").fetchone()
    definition = json.loads(row[0]) if row and row[0] else {}
    fields = definition.get("rows", [{}])[0].get("columns", [{}])[0].get("fields", [])
    if fields:
        fields[0]["label"] = PAYLOAD
        con.execute("UPDATE wp_estat_forms SET name = ?, definition = ? WHERE id = 2",
                    (PAYLOAD + " form", json.dumps(definition)))
    con.commit()
    con.close()
    check("a form carrying a tag exists", True, "form 2 re-labelled")

    print("\nB. The office screens")
    for page, query in OFFICE_SCREENS:
        html = owner.screen(page, query)
        hits = live(html)
        check("%s never renders the tag as code" % page, not hits, hits[:1] or "clean")
        if page == "estat-enquiries":
            lead_ok = escaped(html) or "onerror" not in html

    print("\nC. What looking for trouble shows you")
    for probe in (PAYLOAD, REFLEX):
        s, res = owner.ajax(os_action="search", q=probe)
        check("the rail search does not hand the probe back as markup",
              "<img" not in str(res) and "<script" not in str(res), str(res)[:120])

    html = owner.screen("estat-listings", "&s=" + REFLEX)
    check("a search on the properties screen is escaped",
          not live(html) and REFLEX not in html, live(html)[:1] or "clean")

    print("\nD. The public pages")
    for url, label in [("/enquiry/", "the enquiry page"), ("/property/", "the properties list")]:
        code, body = anon.get(url)[0], anon.get(url)[1]
        hits = live(body)
        check("%s stays clean" % label, not hits, hits[:1] or "clean")

    slug = Site.sql("SELECT post_name FROM wp_posts WHERE ID = %d" % lid)
    if slug:
        body = anon.get("/property/%s/" % slug[0][0])[1]
        hits = live(body)
        check("a single property page escapes its own title", not hits, hits[:1] or "clean")
    else:
        check("a single property page escapes its own title", False, "no slug")

    forms = Site.sql("SELECT ID FROM wp_posts WHERE post_name='enquiry'")
    body = anon.get("/enquiry/")[1]
    check("a form label carrying a tag is not drawn as code", not live(body), live(body)[:1] or "clean")

    print("\nE. The phone")
    for who, sess in (("the office", owner), ("an agent", Site().login("siteagent", "agentpass"))):
        for screen in ("today", "enquiries", "properties"):
            body = sess.get("/agent/?screen=" + screen)[1]
            hits = live(body)
            check("%s, %s screen stays clean" % (who, screen), not hits, hits[:1] or "clean")

    print("\nG. PHP notices")
    log = [l for l in Site.log_since(before) if "Fatal" in l or "Warning" in l or "Notice" in l]
    check("no PHP warning or fatal from any of the above", not log, log[:3])

    return summary("round 6 — escaping")


if __name__ == "__main__":
    main()
