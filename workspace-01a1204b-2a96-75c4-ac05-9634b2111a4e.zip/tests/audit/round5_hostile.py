#!/usr/bin/env python3
"""Round 5 — what the desk, the website and the phone do when fed nonsense.

Everything here is something a real visitor, a bored teenager or a broken
client can produce without trying: a missing or forged nonce, a form definition
that is not JSON, a field sent as an array, a 5,000-character message, a script
tag, an id that was never there, `' OR 1=1--` in the search box. None of it may
produce a PHP notice, a 500, or a stored script.
"""

import json
import os
import re
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from harness import Site, check, summary  # noqa: E402


def raw_ajax(sess, payload, nonce="__keep__"):
    """Post to admin-ajax without the harness quietly supplying a good nonce."""
    data = {"action": "estat_os_action"}
    if nonce != "__keep__":
        data["_ajax_nonce"] = nonce
    data.update(payload)
    s, body, _ = sess.post("/wp-admin/admin-ajax.php", data)
    try:
        return s, json.loads(body)
    except Exception:
        return s, body[:200]


def main():
    before = Site.log_mark()
    Site.reset_rate_limit()
    owner = Site().login("owner", "ownerpass")
    agent = Site().login("siteagent", "agentpass")

    print("A. The desk, poked")
    s, res = raw_ajax(owner, {"os_action": "act", "do": "scan"}, nonce="")
    check("an office action with no nonce at all is refused",
          s in (400, 403) and "found" not in str(res), (s, str(res)[:120]))

    s, res = raw_ajax(owner, {"os_action": "act", "do": "scan"}, nonce="deadbeef00")
    check("an office action with a forged nonce is refused",
          s in (400, 403) and "found" not in str(res), (s, str(res)[:120]))

    s, res = raw_ajax(agent, {"os_action": "act", "do": "scan"}, nonce="")
    check("an agent with no nonce is refused too", s in (400, 403), (s, str(res)[:120]))

    s, res = owner.ajax(os_action="act", do="no_such_thing_here")
    check("an office action that does not exist answers 400", s == 400, (s, res))

    s, res = owner.ajax(os_action="act", do="approve", id="not-a-number")
    check("approving \"not-a-number\" is refused cleanly", s in (400, 404, 422), (s, res))

    s, res = owner.ajax(os_action="act", do="restore", id="999999")
    check("restoring a record that never existed is refused", s in (404, 422), (s, res))

    s, res = owner.ajax(os_action="act", do="bin", id="-5")
    check("binning a negative id is refused", s in (400, 404, 422), (s, res))

    print("\nB. The form builder, fed rubbish")
    s, res = owner.ajax(os_action="save", what="form", id="0", definition="{not json at all")
    check("a form definition that is not JSON is refused without a fatal",
          s in (400, 422) and s != 500, (s, str(res)[:120]))

    s, res = owner.ajax(os_action="save", what="form", id="0", definition=json.dumps({"steps": []}))
    check("a form that asks nothing is refused, with a reason a person can act on",
          s == 422 and "box" in str(res).lower(), (s, str(res)[:140]))

    big = {"steps": [{"id": "s1", "title": "Big", "rows": [{"columns": [{"width": "100", "fields": [
        {"id": "f%d" % i, "type": "text", "label": "Box %d" % i, "required": False} for i in range(150)
    ]}]}]}]}
    s, res = owner.ajax(os_action="save", what="form", id="0", definition=json.dumps(big))
    check("a form with 150 boxes is handled, not crashed", s in (200, 400), (s, str(res)[:120]))

    s, res = owner.ajax(os_action="save", what="form", id="0", definition=json.dumps(
        {"steps": [{"id": "s1", "rows": [{"columns": [{"width": "100", "fields": [
            {"id": "weird", "type": "text", "label": "L" * 4000, "required": True}]}]}]}]}))
    check("a 4,000-character box label does not break the save", s in (200, 400), (s, str(res)[:120]))

    print("\nC. The website form, fed rubbish")
    anon = Site()
    page = None
    for pid, slug in Site.sql("SELECT ID, post_name FROM wp_posts WHERE post_type='page' AND post_status='publish'"):
        if "enquiry" in slug or "palette" in slug:
            page = slug
    check("a public page with a form exists", bool(page), page or "looked for enquiry/palette")
    if not page:
        return summary("round 5 — hostile input")

    html = anon.get("/" + page + "/")[1]
    fields = dict(re.findall(r'name="(estat_nonce|estat_ts|estat_sig|idempotency_key)"[^>]*value="([^"]*)"', html))
    endpoint = re.search(r'data-endpoint="([^"]+)"', html).group(1)
    path = endpoint.split("/wp-json/", 1)[-1]

    base = {"estat_nonce": fields.get("estat_nonce", ""), "estat_ts": fields.get("estat_ts", ""),
            "estat_sig": fields.get("estat_sig", ""), "page_url": anon.base + "/" + page + "/"}

    def send(f, key):
        Site.reset_rate_limit()
        time.sleep(1.2)
        return anon.rest(path, dict(base, idempotency_key=key, fields=f))

    st, body = send({"name": "XSS Probe", "phone": "+919800001111",
                     "message": "<script>alert(1)</script> onerror=alert(2)"}, "xss-1")
    check("a script tag in an enquiry does not blow up the endpoint", st in (200, 422), (st, body[:120]))

    stored = Site.sql("SELECT name, message FROM wp_estat_leads WHERE name = 'XSS Probe' ORDER BY id DESC LIMIT 1")
    blob = json.dumps(stored)
    check("no tag survives the journey into the database",
          "<" not in blob, blob[:160])

    st, body = send({"name": "Long Talker", "phone": "+919800001222", "message": "A" * 5000}, "long-1")
    check("a 5,000-character message is accepted or refused, not fatal", st in (200, 422), (st, body[:120]))
    if st == 200:
        n = Site.sql("SELECT MAX(LENGTH(message)) FROM wp_estat_leads")
        check("and what was kept can be read back whole", int(n[0][0] or 0) in (5000, 4000), n)

    st, body = send({"name": "No Phone"}, "nophone-1")
    check("an enquiry with no phone is refused with a message a visitor can act on",
          st == 422 and "phone" in json.dumps(body).lower(), (st, body[:200]))

    st, body = send({"name": {"nested": "object"}, "phone": ["+91", "9800001333"], "message": "arrays"}, "shape-1")
    check("arrays and objects where words belong do not cause a fatal", st in (200, 422), (st, body[:150]))

    st, body = send({"name": "Emoji 🏠 Person", "phone": "+919800001444",
                     "message": "😀 twelve-foot ceilings — dash, ünïcode, 你好"}, "unicode-1")
    check("emoji and non-Latin text are accepted", st == 200, (st, body[:150]))
    # Looked up by phone: the name on a record can legitimately be corrected
    # later from the office, and another round here renames rows on purpose.
    sent = Site.sql("SELECT payload FROM wp_estat_submissions WHERE payload LIKE '%Emoji%' ORDER BY id DESC LIMIT 1")
    kept = Site.sql("SELECT name, message FROM wp_estat_leads WHERE phone = '+919800001444' ORDER BY id DESC LIMIT 1")
    # The submission record keeps the answers as JSON, which escapes non-Latin
    # characters as \\uXXXX — correct, and unreadable to a substring test. So
    # the payload is decoded first, and the promise is checked where a person
    # would see it: the enquiry the office opens.
    decoded = json.loads(sent[0][0]) if sent else {}
    check("the emoji and the non-Latin text come back out of the database the way they went in",
          "🏠" in decoded.get("name", "") and "你好" in decoded.get("message", "")
          and bool(kept) and "🏠" in kept[0][0] and "你好" in kept[0][1],
          (decoded.get("name"), decoded.get("message", "")[:40], kept))

    st, body = anon.rest(path, dict(base, fields={"name": "Get Probe", "phone": "+919800001555"}), method="GET")
    check("a GET where only a submit belongs is refused", st in (404, 405, 422), st)

    print("\nD. Searching for trouble")
    for probe, label in [("' OR 1=1--", "an SQL-style probe"), ("%_%", "wildcards"),
                         ("<script>", "a script tag"), ("🏠", "an emoji")]:
        s, res = owner.ajax(os_action="search", q=probe)
        check("the rail search survives %s" % label, s == 200 and isinstance(res, dict), (s, str(res)[:100]))

    print("\nE. The phone, with nothing in its hands")
    n0 = Site.sql("SELECT COUNT(*) FROM wp_estat_leads")[0][0]
    s, body, _ = agent.post("/agent/", {"estat_pocket_action": "capture-lead",
                                        "quick_enquiry": "Niti 9811122233 wants a 3 BHK"})
    n1 = Site.sql("SELECT COUNT(*) FROM wp_estat_leads")[0][0]
    check("the phone writes nothing at all without its nonce", n0 == n1, (n0, n1, s))

    s, body, _ = agent.post("/agent/", {"estat_pocket_action": "capture-lead",
                                        "_estat_pocket": agent.pocket_nonce(), "quick_enquiry": ""})
    n2 = Site.sql("SELECT COUNT(*) FROM wp_estat_leads")[0][0]
    check("and nothing out of an empty quick enquiry either", n2 == n1, (n1, n2, s))
    blank = Site.sql("SELECT COUNT(*) FROM wp_estat_leads WHERE name = '' AND phone = ''")
    check("and no blank lead exists at all", int(blank[0][0]) == 0, blank)

    asked = Site.sql("SELECT COUNT(*) FROM wp_estat_requests")[0][0]
    answered = Site.sql("SELECT COUNT(*) FROM wp_estat_requests WHERE status <> 'pending'")[0][0]
    s, body, _ = agent.post("/agent/", {"estat_pocket_action": "settle-request",
                                        "_estat_pocket": agent.pocket_nonce(), "request_id": "abc"})
    check("the phone refuses a request id that is not a number, without touching any request",
          Site.sql("SELECT COUNT(*) FROM wp_estat_requests WHERE status <> 'pending'")[0][0] == answered,
          ("answered before", answered, "of", asked, "http", s))

    print("\nF. PHP notices")
    log = Site.log_since(before)
    bad = [l for l in log if "Fatal error" in l or "Warning" in l or "Notice" in l]
    check("nothing above produced a PHP warning, notice or fatal", not bad, bad[:3])

    return summary("round 5 — hostile input")


if __name__ == "__main__":
    main()
