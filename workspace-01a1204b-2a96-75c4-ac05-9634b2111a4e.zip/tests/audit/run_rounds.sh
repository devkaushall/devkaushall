#!/bin/bash
# Every audit round, in order, against the running site.
set -e
cd "$(dirname "$0")"
for r in round1_enquiries.py round2_forms.py round3_properties.py round4_upgrade.py \
         round5_hostile.py round6_escaping.py round7_browser.py round8_flows.py \
         round9_buttons.py round10_integrity.py round11_sitemap_seo.py; do
  echo "=================== $r"
  python3 "$r" | tail -6
done
