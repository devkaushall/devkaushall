#!/usr/bin/env python3
"""
Round 2 — the form the office builds is the form the website can receive.

The one thing a form must never do is ask a visitor for something the page
does not draw, or refuse a visitor for a box they cannot see. This round
builds a form with every kind of box the palette offers, renders the page,
and posts a filled-in enquiry through the same endpoint the browser uses.
"""
import json
import os
import re
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from harness import Site, check, summary  # noqa: E402

PALETTE = [
    ("text", "Any text"),
    ("email", "Email"),
    ("phone", "Phone"),
    ("number", "A number"),
    ("url", "A link"),
    ("date", "A date"),
    ("select", "A list"),
    ("radio", "One of a few"),
    ("checkbox", "A tick box"),
    ("textarea", "A longer answer"),
]

ODD_NAMES = ["tel", "longtext", "dropdown", "choice"]   # aliases a caller might use


def seen_name(Site, fid):
    rows = Site.sql("SELECT name FROM wp_estat_forms WHERE id = %d" % int(fid))
    return rows[0][0] if rows else ""


def main():
    before = Site.log_mark()
    Site.reset_rate_limit()
    owner = Site().login("owner", "ownerpass")

    # ------------------------------------------------------------------ build
    print("A. Build a form with every kind of box")
    fields = []
    for key, label in PALETTE:
        f = {"id": key, "label": label, "type": key, "required": key in ("text", "phone", "email", "select")}
        if key in ("select", "radio"):
            f["options"] = ["One", "Two", "Three"]
        fields.append(f)
    # and the same boxes under the everyday names a caller might use
    for i, odd in enumerate(ODD_NAMES):
        f = {"id": "odd" + str(i), "label": "Odd " + odd, "type": odd, "required": True}
        if odd in ("dropdown", "choice"):
            f["options"] = ["One", "Two"]
        fields.append(f)

    html = owner.screen("estat-forms")
    nonce = None
    m = re.search(r'"nonce":"([a-f0-9]{10})"', html) or re.search(r'var estatOs = (\{.*?\});', html, re.S)
    nonce = json.loads(m.group(1)).get("nonce") if m and m.group(0).startswith("var") else (m.group(1) if m else None)

    definition = {"rows": [{"columns": [{"fields": fields}]}]}
    s, res = owner.ajax(os_action="save", what="form", id="0",
                        definition=json.dumps(definition))
    print("   save ->", s, str(res)[:200])
    check("the form builder accepted the form", isinstance(res, dict) and res.get("success"), str(res)[:200])

    fid = (res.get("data", {}) or {}).get("id") if isinstance(res, dict) and res.get("success") else None
    if not fid:
        # the office screen's save shape differs; fall back to the model directly
        fid = Site.wp('echo \\EstatOS\\Forms\\Forms::save( array( "name" => "Palette form", "definition" => '
                      'json_decode( file_get_contents( "/tmp/formdef.json" ), true ) ), 0 );')
        fid = int(fid.strip().splitlines()[-1]) if fid.strip().isdigit() else None
    check("a form was stored", bool(fid), fid)

    if not fid:
        return summary("round 2 — forms")

    # ------------------------------------------------------------- the page
    print("\nB. Put it on a page and look at what the visitor is given")
    Site.wp('$p = get_page_by_path( "palette" );'
            '$args = array( "post_type" => "page", "post_status" => "publish", "post_title" => "Palette", '
            '"post_name" => "palette", "post_content" => \'[estat_form id="%d"]\' );'
            'if ( $p ) { $args["ID"] = $p->ID; wp_update_post( $args ); } else { wp_insert_post( $args ); } echo "ok";' % fid)
    page = Site().get("/palette/")[1]
    drawn = set(re.findall(r'name="fields\[([^\]]+)\]"', page))
    expected = set(f["id"] for f in fields)
    missing = expected - drawn
    check("every box in the form is drawn on the page", not missing, "missing: " + ", ".join(sorted(missing)))
    check("the odd type names were kept, not thrown away",
          all(("odd" + str(i)) in drawn for i in range(len(ODD_NAMES))),
          "drawn: " + ", ".join(sorted(drawn)))

    # ---------------------------------------------------------- the enquiry
    print("\nC. A visitor fills it in and sends it")
    stamp = dict(re.findall(r'name="(estat_nonce|estat_ts|estat_sig|idempotency_key)"[^>]*value="([^"]*)"', page))
    path = re.search(r'data-endpoint="([^"]+)"', page).group(1).split("/wp-json/", 1)[-1]
    values = {}
    for f in fields:
        if f["type"] == "checkbox":
            values[f["id"]] = "Yes"
        elif f["type"] == "select":
            values[f["id"]] = "Two"
        elif f["type"] == "radio":
            values[f["id"]] = "One"
        elif f["type"] == "date":
            values[f["id"]] = "2026-11-01"
        elif f["type"] == "email":
            values[f["id"]] = "palette@example.com"
        elif f["type"] == "phone":
            values[f["id"]] = "+919800000404"
        elif f["type"] == "number":
            values[f["id"]] = "3"
        elif f["type"] == "url":
            values[f["id"]] = "https://example.com/listing"
        elif f["type"] == "textarea":
            values[f["id"]] = "A longer answer, written out."
        else:
            values[f["id"]] = "Palette visitor"
    values["odd0"], values["odd1"], values["odd2"], values["odd3"] = (
        "+919800000405", "A long answer", "Two", "One")

    payload = {"estat_nonce": stamp["estat_nonce"], "estat_ts": stamp["estat_ts"],
               "estat_sig": stamp["estat_sig"], "idempotency_key": stamp["idempotency_key"],
               "page_url": "http://localhost:8080/palette/", "fields": values}
    time.sleep(1.3)
    st, body = Site().rest(path, payload)
    print("   submit ->", st, body[:200])
    check("the visitor's enquiry is accepted", st == 200 and '"ok":true' in body, body[:200])
    lead = dict((r[1], r) for r in Site.leads()).get("Palette visitor")
    check("it is stored as a real enquiry, not set aside", lead is not None and lead[3] != "spam", lead)

    # ------------------------------------------------- an empty required box
    print("\nD. The same form with the required name left empty")
    Site.reset_rate_limit()
    blank = dict(payload)
    blank["fields"] = dict(values, **{"text": ""})
    blank["idempotency_key"] = "blank-" + stamp["idempotency_key"]
    st2, body2 = Site().rest(path, blank)
    print("   submit ->", st2, body2[:200])
    check("an incomplete form says which box is empty", st2 == 422 and '"text"' in body2, body2[:200])

    notes = Site.log_since(before)
    print("\nE. PHP notices:", notes or "(none)")
    check("no PHP warnings from the form path", not notes, notes[:200])

    return summary("round 2 — forms")


if __name__ == "__main__":
    sys.exit(1 if main() else 0)
