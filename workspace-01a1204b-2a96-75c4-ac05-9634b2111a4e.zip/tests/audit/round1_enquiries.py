#!/usr/bin/env python3
"""
Round 1 — the enquiry family, through the real screens.

The office, the phone and the website all create enquiries, and the first
walk-through found that only one of them could ever be stored. This round
walks all three paths on a running site and reads back what was written.
"""
import os
import re
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from harness import Site, check, summary  # noqa: E402


def main():
    before = Site.log_mark()
    Site.reset_rate_limit()   # this run starts with a clean slate for the visitor test
    site = Site().login("owner", "ownerpass")
    print("signed in as owner")

    # ---------------------------------------------------------------- office
    print("\nA. The office writes an enquiry (the drawer on the Enquiries screen)")
    made = []
    for i, (nm, ph) in enumerate([("Walk-in One", "+919800000101"),
                                  ("Walk-in Two", "+919800000102"),
                                  ("Walk-in Three", "+919800000103")], 1):
        s, res = site.ajax(os_action="save", what="lead", id="0",
                           **{"fields[name]": nm, "fields[phone]": ph,
                              "fields[message]": "came to the office", "fields[source]": "manual"})
        say = res.get("data", {}).get("say") if isinstance(res, dict) else res
        made.append((nm, s, say))
        print("   %-14s HTTP %s  %s" % (nm, s, say))
    rows = dict((r[1], r) for r in Site.leads())
    for nm, s, say in made:
        check("office enquiry stored: " + nm, nm in rows and rows[nm][3] != "spam",
              rows.get(nm, "not in wp_estat_leads at all"))

    # -------------------------------------------------------------- the phone
    print("\nB. The phone writes one (Pocket, /agent/capture-lead)")
    agent = Site().login("siteagent", "agentpass")
    body = agent.get("/agent/capture-lead/")[1]
    nonce = re.search(r'name="_estat_pocket" value="([a-f0-9]{10})"', body)
    check("Pocket capture screen carries its nonce", bool(nonce), body[:120])
    if nonce:
        s, b, url = agent.post("/agent/capture-lead/", {
            "_estat_pocket": nonce.group(1), "estat_pocket_action": "quick_enquiry",
            "name": "Phone Walk-in", "phone": "+919800000201", "intent": "buy",
            "locality": "Sohna Road", "budget_min": "8000000", "budget_max": "11000000",
            "message": "met at the site office",
        })
        print("   post ->", s, url.split("8080")[-1][:70])
        rows = dict((r[1], r) for r in Site.leads())
        check("Pocket enquiry stored: Phone Walk-in", "Phone Walk-in" in rows, rows.get("Phone Walk-in", "missing"))
        # and the same enquiry again, as a careful agent would re-enter it
        s2, b2, url2 = agent.post("/agent/capture-lead/", {
            "_estat_pocket": nonce.group(1), "estat_pocket_action": "quick_enquiry",
            "name": "Phone Walk-in", "phone": "+919800000201", "intent": "buy",
            "locality": "Sohna Road", "budget_min": "8000000", "budget_max": "11000000",
            "message": "met at the site office",
        })
        twice = [r for r in Site.leads() if r[1] == "Phone Walk-in"]
        check("the same Pocket enquiry is not stored twice", len(twice) == 1, twice)

    # ------------------------------------------------------------ the website
    print("\nC. The website writes one (the public form, twice)")
    anon = Site()
    page = None
    for pid, slug in Site.sql("SELECT ID, post_name FROM wp_posts WHERE post_type='page' AND post_status='publish'"):
        if "enquiry" in slug or "contact" in slug:
            page = slug
    check("a public page with the form exists", bool(page), "looked for enquiry/contact page")
    if page:
        html = anon.get("/" + page + "/")[1]
        fields = dict(re.findall(r'name="(estat_nonce|estat_ts|estat_sig|idempotency_key|fields\[[a-z]+\])"[^>]*value="([^"]*)"', html))
        check("form carries a signed stamp", "estat_sig" in fields, sorted(fields))
        # first: an honest visitor who takes their time
        endpoint = re.search(r'data-endpoint="([^"]+)"', html).group(1)
        path = endpoint.split("/wp-json/", 1)[-1]
        # exactly the shape forms.js posts: a fields object inside JSON
        data = {"estat_nonce": fields.get("estat_nonce", ""),
                "estat_ts": fields.get("estat_ts", ""),
                "estat_sig": fields.get("estat_sig", ""),
                "idempotency_key": fields.get("idempotency_key", ""),
                "page_url": site.base + "/" + page + "/",
                "fields": {"name": "Website Visitor", "phone": "+919800000301",
                           "message": "saw the page online"}}
        time.sleep(1.4)
        st, body = anon.rest(path, data)
        print("   submit ->", st, body[:150])
        lead = dict((r[1], r) for r in Site.leads()).get("Website Visitor")
        check("website enquiry stored and not filed as spam",
              lead is not None and lead[3] != "spam", lead or body[:140])
        check("a submission record was kept for it",
              any(r[2] for r in Site.submissions()),
              Site.submissions())

        # and the stamp cannot be faked: an older signed stamp is stale, not fake
        old_ts = str(int(fields.get("estat_ts", "0")) - 4000)
        st2, body2 = anon.rest(path, dict(data, **{"estat_ts": old_ts,
                                                   "idempotency_key": "tampered-" + str(time.time()),
                                                   "fields": {"name": "Tampered Stamp", "phone": "+919800000302"}}))
        print("   tampered stamp ->", st2, body2[:120])
        tampered = dict((r[1], r) for r in Site.leads()).get("Tampered Stamp")
        check("a forward-dated stamp is treated as no stamp at all (saved, not lost)",
              tampered is not None and tampered[3] != "spam", tampered or body2[:120])

    # ------------------------------------------------------------------------
    print("\nD. What the database holds now")
    for r in Site.leads():
        print("   ", r)
    check("every enquiry of this round is in the table", len(Site.leads()) >= 5, Site.leads())

    print("\nE. PHP notices during the round")
    notes = Site.log_since(before)
    print("   ", notes or "(none)")
    check("no PHP warnings from these screens", not notes, notes[:200])

    return summary("round 1 — enquiries")


if __name__ == "__main__":
    sys.exit(1 if main() else 0)
