#!/usr/bin/env python3
"""Screenshots at the two sizes the office actually uses.

1440 x 900 — a desk screen, where the bento dashboard lives.
390 x 844  — a phone, where the pocket and the public site live.

Real data only: the sandbox is seeded with properties, enquiries and visits
before a single picture is taken.
"""

import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from playwright.sync_api import sync_playwright  # noqa: E402

BASE = "http://localhost:8080"
OUT = "/home/user/shots"

DESK = [
    ("office-today", "/wp-admin/admin.php?page=estat-today", True),
    ("office-properties", "/wp-admin/admin.php?page=estat-listings", True),
    ("office-add-home", "/wp-admin/admin.php?page=estat-add-home", True),
    ("office-enquiries", "/wp-admin/admin.php?page=estat-enquiries", True),
    ("office-visits", "/wp-admin/admin.php?page=estat-visits", True),
    ("office-forms", "/wp-admin/admin.php?page=estat-forms", True),
    ("office-duplicates", "/wp-admin/admin.php?page=estat-duplicates", True),
    ("office-settings", "/wp-admin/admin.php?page=estat-settings", True),
    ("office-spreadsheet", "/wp-admin/admin.php?page=estat-spreadsheet", True),
]

# The pocket's five doors live at /agent/<name>; the root is Today.
PHONE = [
    ("phone-today", "/agent/", True),
    ("phone-leads", "/agent/leads", True),
    ("phone-visits", "/agent/visits", True),
    ("phone-more", "/agent/more", True),
    ("phone-approvals", "/agent/approvals", True),
    ("phone-public-home", "/", False),
    ("phone-public-properties", "/properties/", False),
    ("phone-public-enquiry", "/enquiry/", False),
]


def shoot(page, name, path, login_as, width, height):
    page.set_viewport_size({"width": width, "height": height})
    page.goto(BASE + path, wait_until="domcontentloaded")
    time.sleep(1.6)
    page.screenshot(path=os.path.join(OUT, name + ".png"), full_page=False)
    return page


def main():
    os.makedirs(OUT, exist_ok=True)
    with sync_playwright() as p:
        browser = p.chromium.launch()
        ctx = browser.new_context(viewport={"width": 1440, "height": 900}, device_scale_factor=1)
        page = ctx.new_page()
        page.goto(BASE + "/wp-login.php")
        page.fill("#user_login", "owner")
        page.fill("#user_pass", "ownerpass")
        page.click("#wp-submit")
        page.wait_for_load_state("networkidle")
        print("signed in as the owner")

        for name, path, _ in DESK:
            shoot(page, name, path, True, 1440, 900)
            print("  1440", name)

        for name, path, _ in PHONE:
            shoot(page, name, path, True, 390, 844)
            print("  390 ", name)

        ctx.close()
        browser.close()
    print("done ->", OUT)


if __name__ == "__main__":
    main()
