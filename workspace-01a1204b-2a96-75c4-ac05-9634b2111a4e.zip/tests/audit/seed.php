<?php
/**
 * Realistic demo data, written through the plugin's own APIs.
 * Run: wp eval-file /home/user/tests/audit/seed.php --user=owner --path=/tmp/wp
 */

use EstatOS\Data\Agents;
use EstatOS\Data\Listings;
use EstatOS\Data\Projects;
use EstatOS\Forms\Forms;
use EstatOS\Leads\Leads;
use EstatOS\Leads\Visits;

function say( $what, $result ) {
	if ( is_wp_error( $result ) ) {
		echo "FAIL {$what}: " . $result->get_error_message() . "\n";
		return 0;
	}
	echo "ok {$what}: " . ( is_array( $result ) ? wp_json_encode( $result ) : $result ) . "\n";
	return (int) $result;
}

/* ---------------------------------------------------------------- team ---- */
$agents = array();
foreach ( array(
	array( 'name' => 'Rohit Mehra', 'role' => 'Owner', 'phone' => '+919810011001', 'email' => 'rohit@mayfair.test' ),
	array( 'name' => 'Priya Nair', 'role' => 'Site Agent', 'phone' => '+919810011002', 'email' => 'priya@mayfair.test' ),
	array( 'name' => 'Imran Qureshi', 'role' => 'Site Agent', 'phone' => '+919810011003', 'email' => 'imran@mayfair.test' ),
	array( 'name' => 'Kavita Rana', 'role' => 'Office', 'phone' => '+919810011004', 'email' => 'kavita@mayfair.test' ),
) as $p ) {
	$id = say( 'agent ' . $p['name'], Agents::save( $p, 0 ) );
	if ( $id ) {
		$agents[ $p['name'] ] = $id;
	}
}

/* ------------------------------------------------------------ societies ---- */
$societies = array();
$projects  = array(
	array( 'title' => 'Godrej Woodsville', 'address' => 'Sector 43, Golf Course Road', 'developer' => 'Godrej Properties', 'project_status' => 'ready', 'category' => 'residential', 'possession_date' => gmdate( 'Y-m-d' ), 'unit_types' => '2 BHK, 3 BHK, 4 BHK', 'description' => 'A ready society on Golf Course Road with a clubhouse, a swimming pool and a large green park in the middle.' ),
	array( 'title' => 'M3M Golf Estate', 'address' => 'Sector 65, Golf Course Extension', 'developer' => 'M3M India', 'project_status' => 'ready', 'category' => 'residential', 'possession_date' => gmdate( 'Y-m-d' ), 'unit_types' => '3 BHK, 4 BHK', 'description' => 'Golf-facing apartments and villas in Sector 65, with a 9-hole course inside the estate.' ),
	array( 'title' => 'DLF Magnolias', 'address' => 'Sector 42, Golf Course Road', 'developer' => 'DLF', 'project_status' => 'ready', 'category' => 'residential', 'possession_date' => gmdate( 'Y-m-d' ), 'unit_types' => '4 BHK, 5 BHK', 'description' => 'Large four and five bedroom homes beside the Rapid Metro, with a formal lobby and full power backup.' ),
	array( 'title' => 'Sobha City Crest', 'address' => 'Sector 108, Dwarka Expressway', 'developer' => 'Sobha Limited', 'project_status' => 'construction', 'category' => 'residential', 'possession_date' => '2027-12-01', 'unit_types' => '3 BHK, 4 BHK', 'description' => 'Three and four bedroom homes on Dwarka Expressway, possession in December 2027.' ),
	array( 'title' => 'The Camellias Extension', 'address' => 'Sector 42, Golf Course Road', 'developer' => 'DLF', 'project_status' => 'construction', 'category' => 'residential', 'possession_date' => '2028-06-01', 'unit_types' => '3 BHK, 4 BHK', 'description' => 'A new phase beside The Camellias, with a residents-only club and a 6-acre central garden.' ),
);
foreach ( $projects as $p ) {
	$id = say( 'project ' . $p['title'], Projects::save( $p, 0 ) );
	if ( $id ) {
		$societies[ $p['title'] ] = $id;
	}
}

/* ---------------------------------------------------------- properties ---- */
$homes = array(
	array( 'title' => '3 BHK in Godrej Woodsville, Sector 43', 'locality' => 'Sector 43, Golf Course Road', 'project' => 'Godrej Woodsville', 'property_type' => 'apartment', 'offer' => 'sale', 'price' => 32500000, 'area' => 2250, 'bedrooms' => 3, 'bathrooms' => 3, 'balconies' => 2, 'furnishing' => 'semi', 'facing' => 'north_east', 'floor' => 11, 'total_floors' => 22, 'possession_date' => gmdate( 'Y-m-d' ), 'agent' => 'Priya Nair', 'status' => 'publish', 'highlights' => array( 'Corner unit with three open sides', 'Park and pool view from the balcony', 'Two covered car parks', 'Society power backup' ) ),
	array( 'title' => '4 BHK in DLF Magnolias, Sector 42', 'locality' => 'Sector 42, Golf Course Road', 'project' => 'DLF Magnolias', 'property_type' => 'apartment', 'offer' => 'sale', 'price' => 82500000, 'area' => 4200, 'bedrooms' => 4, 'bathrooms' => 5, 'balconies' => 3, 'furnishing' => 'furnished', 'facing' => 'north', 'floor' => 8, 'total_floors' => 12, 'possession_date' => gmdate( 'Y-m-d' ), 'agent' => 'Rohit Mehra', 'status' => 'publish', 'highlights' => array( 'Four bedrooms, all with attached bathrooms', 'Private lift lobby', 'Faces the central lawn', 'Two staff rooms' ) ),
	array( 'title' => '3 BHK in M3M Golf Estate, Sector 65', 'locality' => 'Sector 65, Golf Course Extension', 'project' => 'M3M Golf Estate', 'property_type' => 'apartment', 'offer' => 'rent', 'rent' => 145000, 'area' => 2400, 'bedrooms' => 3, 'bathrooms' => 3, 'balconies' => 2, 'furnishing' => 'furnished', 'facing' => 'east', 'floor' => 6, 'total_floors' => 18, 'agent' => 'Imran Qureshi', 'status' => 'publish', 'highlights' => array( 'Looks on to the golf course', 'Fully furnished, ready to move in', 'Rent includes one car park', 'Society gym and pool' ) ),
	array( 'title' => '2 BHK on Sohna Road, near Subhash Chowk', 'locality' => 'Sohna Road', 'property_type' => 'apartment', 'offer' => 'sale', 'price_type' => 'negotiable', 'price' => 9500000, 'area' => 1180, 'bedrooms' => 2, 'bathrooms' => 2, 'balconies' => 1, 'furnishing' => 'unfurnished', 'facing' => 'south', 'floor' => 3, 'total_floors' => 9, 'agent' => 'Imran Qureshi', 'status' => 'publish', 'highlights' => array( 'Walking distance to Subhash Chowk', 'Two baths, both with windows', 'Bank loan already cleared' ) ),
	array( 'title' => '4 BHK floor in Sector 57, independent', 'locality' => 'Sector 57', 'property_type' => 'builder_floor', 'offer' => 'sale', 'price' => 27500000, 'area' => 3000, 'bedrooms' => 4, 'bathrooms' => 4, 'balconies' => 2, 'furnishing' => 'semi', 'facing' => 'east', 'floor' => 2, 'total_floors' => 3, 'agent' => 'Priya Nair', 'status' => 'publish', 'highlights' => array( 'Full floor with a private terrace', 'Three-side open, good light all day', 'Two car parks in front' ) ),
	array( 'title' => 'Plot on Golf Course Extension, 300 sq yd', 'locality' => 'Golf Course Extension', 'project' => 'Sobha City Crest', 'property_type' => 'plot', 'offer' => 'sale', 'price' => 45000000, 'area' => 2700, 'area_unit' => 'sqyd', 'agent' => 'Rohit Mehra', 'status' => 'publish', 'highlights' => array( 'Corner plot on a 60-foot road', 'Sanctioned for a three-floor house', 'Clear title, one owner' ) ),
	array( 'title' => '3 BHK in Sobha City Crest, Dwarka Expressway', 'locality' => 'Sector 108, Dwarka Expressway', 'project' => 'Sobha City Crest', 'property_type' => 'apartment', 'offer' => 'sale', 'price_type' => 'on_request', 'area' => 2010, 'bedrooms' => 3, 'bathrooms' => 3, 'balconies' => 2, 'furnishing' => 'unfurnished', 'facing' => 'north_east', 'floor' => 14, 'total_floors' => 28, 'agent' => 'Kavita Rana', 'status' => 'publish', 'highlights' => array( 'Corner unit, 14th floor', 'Covered car park included', 'Club membership included in the price' ) ),
	array( 'title' => '1 BHK on Golf Course Road, Sector 43', 'locality' => 'Sector 43, Golf Course Road', 'project' => 'Godrej Woodsville', 'property_type' => 'apartment', 'offer' => 'rent', 'rent' => 42000, 'area' => 720, 'bedrooms' => 1, 'bathrooms' => 1, 'balconies' => 1, 'furnishing' => 'semi', 'facing' => 'west', 'floor' => 4, 'total_floors' => 15, 'agent' => 'Priya Nair', 'status' => 'publish', 'highlights' => array( 'Facing the park', 'Society pool and gym', 'Walk to the Rapid Metro' ) ),
	array( 'title' => '3 BHK in The Camellias, Sector 42', 'locality' => 'Sector 42, Golf Course Road', 'project' => 'The Camellias Extension', 'property_type' => 'apartment', 'offer' => 'sale', 'price' => 95000000, 'area' => 3600, 'bedrooms' => 3, 'bathrooms' => 4, 'balconies' => 2, 'furnishing' => 'furnished', 'facing' => 'north_east', 'floor' => 20, 'total_floors' => 38, 'agent' => 'Rohit Mehra', 'status' => 'publish', 'highlights' => array( 'Twenty-second floor, city view', 'Two staff rooms', 'Four baths, two with a bath tub' ) ),
	array( 'title' => '3 BHK in Godrej Woodsville, corner', 'locality' => 'Sector 43, Golf Course Road', 'project' => 'Godrej Woodsville', 'property_type' => 'apartment', 'offer' => 'sale', 'price' => 32500000, 'area' => 2250, 'bedrooms' => 3, 'bathrooms' => 3, 'furnishing' => 'semi', 'facing' => 'north_east', 'floor' => 12, 'total_floors' => 22, 'agent' => 'Imran Qureshi', 'status' => 'draft', 'highlights' => array( 'Corner unit', 'Park view' ) ),
	array( 'title' => 'Office space on MG Road, ready to move', 'locality' => 'MG Road', 'property_type' => 'office', 'offer' => 'lease', 'rent' => 850000, 'area' => 5000, 'furnishing' => 'furnished', 'floor' => 5, 'total_floors' => 10, 'agent' => 'Kavita Rana', 'status' => 'pending', 'highlights' => array( 'Fully fitted office on the fifth floor', 'Two cabins and thirty-eight seats', 'Two lifts, one service lift' ) ),
	array( 'title' => '3 BHK in M3M Golf Estate, Sector 65, park side', 'locality' => 'Sector 65, Golf Course Extension', 'project' => 'M3M Golf Estate', 'property_type' => 'apartment', 'offer' => 'sale', 'price' => 41500000, 'area' => 2620, 'bedrooms' => 3, 'bathrooms' => 3, 'balconies' => 2, 'furnishing' => 'semi', 'facing' => 'north', 'floor' => 9, 'total_floors' => 18, 'agent' => 'Rohit Mehra', 'status' => 'publish', 'highlights' => array( 'Park-facing, quiet side of the tower', 'Two covered car parks', 'Ready to move in' ) ),
);

$made = array();
foreach ( $homes as $h ) {
	$row = array(
		'title'          => $h['title'],
		'locality'       => $h['locality'],
		'project_id'     => $societies[ $h['project'] ?? '' ] ?? 0,
		'agent_id'       => $agents[ $h['agent'] ?? '' ] ?? 0,
		'property_type'  => $h['property_type'],
		'offer'          => $h['offer'],
		'status'         => $h['status'],
		'price_type'     => $h['price_type'] ?? 'fixed',
		'price'          => $h['price'] ?? '',
		'rent'           => $h['rent'] ?? '',
		'area'           => $h['area'] ?? '',
		'area_unit'      => $h['area_unit'] ?? 'sqft',
		'bedrooms'       => $h['bedrooms'] ?? '',
		'bathrooms'      => $h['bathrooms'] ?? '',
		'balconies'      => $h['balconies'] ?? '',
		'furnishing'     => $h['furnishing'] ?? '',
		'facing'         => $h['facing'] ?? '',
		'floor'          => $h['floor'] ?? '',
		'total_floors'   => $h['total_floors'] ?? '',
		'possession_date' => $h['possession_date'] ?? '',
		'highlights'     => $h['highlights'],
		'description'    => $h['title'] . ' in ' . $h['locality'] . '. Ring the office to arrange a visit on any day between ten and seven.',
		'latitude'       => '28.' . wp_rand( 400000, 499999 ),
		'longitude'      => '77.' . wp_rand( 100000, 199999 ),
	);
	$id = say( 'listing ' . $h['title'], Listings::save( $row, 0 ) );
	if ( $id ) {
		$made[ $h['title'] ] = $id;
	}
}

/* -------------------------------------------------------------- forms ---- */
say(
	'form',
	Forms::save(
		array(
			'name'       => 'Property enquiry',
			'status'     => 'active',
			'definition' => array(
				'rows' => array(
					array(
						'columns' => array(
							array(
								'fields' => array(
									array( 'id' => 'name', 'label' => 'Your name', 'type' => 'text', 'required' => true ),
									array( 'id' => 'phone', 'label' => 'Phone number', 'type' => 'phone', 'required' => true ),
									array( 'id' => 'email', 'label' => 'Email', 'type' => 'email', 'required' => false ),
									array( 'id' => 'message', 'label' => 'What are you looking for?', 'type' => 'textarea', 'required' => false ),
									array( 'id' => 'budget', 'label' => 'Budget', 'type' => 'select', 'required' => false, 'options' => array( 'Under 1 Cr', '1–2 Cr', 'Above 2 Cr' ) ),
									array( 'id' => 'consent', 'label' => 'You may call me about this', 'type' => 'checkbox', 'required' => false ),
								),
							),
						),
					),
				),
			),
			'settings'   => array(
				'success_message' => 'Thank you. We have received your enquiry and will contact you soon.',
				'error_message'   => 'Sorry, we could not send your enquiry. Please check the form and try again.',
				'lead_source'     => 'form',
			),
		),
		0
	)
);

/* ------------------------------------------------------------ enquiries ---- */
$lead_ids = array();
foreach ( array(
	array( 'name' => 'Deepak Sharma', 'phone' => '+919876500011', 'email' => 'deepak.sharma@example.com', 'intent' => 'buy', 'locality' => 'Sector 43, Golf Course Road', 'budget_min' => 25000000, 'budget_max' => 35000000, 'message' => 'Looking for a three bedroom near Golf Course Road for my parents.', 'source' => 'website', 'status' => 'new' ),
	array( 'name' => 'Neha Gupta', 'phone' => '+919876500022', 'email' => 'neha.gupta@example.com', 'intent' => 'rent', 'locality' => 'Sector 65, Golf Course Extension', 'budget_min' => 100000, 'budget_max' => 160000, 'message' => 'Need a furnished three bedroom for a year from next month.', 'source' => 'form', 'status' => 'contacted' ),
	array( 'name' => 'Arjun Reddy', 'phone' => '+919876500033', 'email' => 'arjun.reddy@example.com', 'intent' => 'buy', 'locality' => 'Sohna Road', 'budget_min' => 8000000, 'budget_max' => 11000000, 'message' => 'Two bedroom on Sohna Road, ready to move.', 'source' => 'whatsapp', 'status' => 'scheduled' ),
	array( 'name' => 'Fatima Sheikh', 'phone' => '+919876500044', 'email' => 'fatima.sheikh@example.com', 'intent' => 'buy', 'locality' => 'Sector 57', 'budget_min' => 20000000, 'budget_max' => 30000000, 'message' => 'Wants a full floor, four bedrooms, Sector 57.', 'source' => 'call', 'status' => 'new' ),
) as $l ) {
	$id = say( 'lead ' . $l['name'], Leads::create( $l ) );
	if ( $id ) {
		$lead_ids[ $l['name'] ] = $id;
	}
}

/* --------------------------------------------------------------- visits ---- */
if ( ! empty( $lead_ids['Arjun Reddy'] ) ) {
	say(
		'visit',
		Visits::schedule(
			array(
				'lead_id'      => $lead_ids['Arjun Reddy'],
				'listing_id'   => $made['2 BHK on Sohna Road, near Subhash Chowk'] ?? 0,
				'agent_id'     => $agents['Imran Qureshi'] ?? 0,
				'scheduled_at' => gmdate( 'Y-m-d H:i:s', strtotime( '+2 days 11:00' ) ),
				'notes'        => 'Meet at the society gate. Bring the floor plan.',
			)
		)
	);
}

/* ------------------------------------------------- the page with the form ---- */
$form_id = (int) Site_Forms_id();
function Site_Forms_id() {
	global $wpdb;
	return (int) $wpdb->get_var( "SELECT id FROM wp_estat_forms ORDER BY id DESC LIMIT 1" );
}
$existing = get_page_by_path( 'enquiry' );
if ( ! $existing ) {
	$page_id = wp_insert_post( array(
		'post_type'    => 'page',
		'post_status'  => 'publish',
		'post_title'   => 'Enquiries',
		'post_name'    => 'enquiry',
		'post_content' => '[estat_form id="' . $form_id . '"]',
	) );
	say( 'page /enquiry/', $page_id );
}

echo "---\n";
echo 'listings published: ' . wp_count_posts( 'estat_listing' )->publish . "\n";
echo "done\n";
