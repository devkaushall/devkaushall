#!/usr/bin/env python3
"""Round 7 — the browser, doing what a person does.

Nothing here is a headless request. A real browser signs in, types in the
office's search box, opens the forms screen, clicks through screens at three
sizes, and this script watches the page for:

  * the escape work done in 4.1.11 — a property whose title contains a tag must
    show as text in the search results, not run;
  * overflow — a screen that scrolls sideways on a phone is a screen with a
    button off the edge;
  * console errors — a JavaScript fault is invisible to every PHP check.

The database is poisoned with hostile titles first, so this is the one round
that can actually prove the fix in the place it matters.
"""

import json
import os
import sqlite3
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from harness import Site, check, summary , DB  # noqa: E402
from playwright.sync_api import sync_playwright  # noqa: E402

BASE = "http://localhost:8080"
PAYLOAD = "<img src=x onerror=alert(1)>"

OFFICE = [
    ("estat-today", ""),
    ("estat-listings", ""),
    ("estat-add-home", ""),
    ("estat-enquiries", ""),
    ("estat-visits", ""),
    ("estat-forms", ""),
    ("estat-projects", ""),
    ("estat-duplicates", ""),
    ("estat-team", ""),
    ("estat-gallery", ""),
    ("estat-settings", ""),
    ("estat-reports", ""),
    ("estat-bin", ""),
    ("estat-spreadsheet", ""),
]


def poison():
    con = sqlite3.connect(DB)
    con.execute("UPDATE wp_posts SET post_title = ? WHERE post_title = 'Audit hostile home'",
                (PAYLOAD + " home",))
    con.execute("UPDATE wp_posts SET post_title = ? WHERE post_title LIKE 'Audit hostile home%'",
                (PAYLOAD + " home",))
    con.commit()
    row = con.execute("SELECT ID, post_title FROM wp_posts WHERE post_title LIKE '%onerror%' LIMIT 1").fetchone()
    con.close()
    return row


def main():
    before = Site.log_mark()
    poisoned = poison()
    check("a property with a hostile title is in the database", bool(poisoned), poisoned)

    console = []
    page_errors = []
    fired = []

    with sync_playwright() as p:
        browser = p.chromium.launch()
        ctx = browser.new_context(viewport={"width": 1440, "height": 900})
        page = ctx.new_page()
        page.on("console", lambda m: console.append((m.type, m.text[:200])))
        page.on("pageerror", lambda e: page_errors.append(str(e)[:200]))
        # if any alert fires, the payload executed — record it and dismiss
        page.on("dialog", lambda d: (fired.append(d.message), d.dismiss()))

        print("\nA. The office, in a browser")
        check("the office signs in", Site.browser_login(page), page.url)

        for slug, query in OFFICE:
            page.goto("%s/wp-admin/admin.php?page=%s%s" % (BASE, slug, query),
                      wait_until="domcontentloaded")
            time.sleep(0.5)
            width = page.evaluate("[document.documentElement.scrollWidth, window.innerWidth]")
            side = width[0] - width[1]
            check("%s does not scroll sideways at 1440" % slug, side <= 2, (width, side))

        print("\nB. The search box, with a hostile title in the database")
        page.goto(BASE + "/wp-admin/admin.php?page=estat-today", wait_until="networkidle")
        page.click("#searchIn")                     # the field opens the palette
        time.sleep(0.8)
        page.fill("#cmdkIn", "onerror")
        time.sleep(1.8)                             # let the office answer
        drawn = page.evaluate("""() => {
            const box = document.getElementById('cmdkList');
            return box ? box.innerHTML : '(no list)';
        }""")
        print("     the palette drew:", drawn[:200].replace("\n", " "))
        check("typing in the search box really reaches the records",
              "onerror" in drawn, drawn[:200])
        # Escaped text still reads "onerror=alert" — only the characters that
        # change the meaning of markup are replaced. So the test is a live tag,
        # and the escaped form must be there to prove it was the escaping that
        # saved it.
        check("the record is drawn as text, not as markup",
              "<img" not in drawn and "&lt;img" in drawn, drawn[:200])

        rows = page.evaluate("""() => {
            const out = [];
            document.querySelectorAll('#cmdkList .cmdk__i').forEach(function (el) {
                out.push({ text: el.textContent.trim(), html: el.innerHTML.slice(0, 120),
                           href: el.getAttribute('href'),
                           group: (el.previousElementSibling && el.previousElementSibling.className.indexOf('cmdk__g') > -1)
                                  ? el.previousElementSibling.textContent.trim() : '' });
            });
            return out;
        }""")
        hit = [r for r in rows if "onerror" in r["text"]]
        check("the property with the hostile title is one of the results", bool(hit), rows[:2])
        if hit:
            check("and its row links to the property's own page",
                  "estat-add-home" in (hit[0]["href"] or "") or "edit=" in (hit[0]["href"] or ""),
                  hit[0]["href"])
            check("and its words are literally the property's name, not a picture",
                  "<img" not in hit[0]["html"], hit[0]["html"])

        print("\nC. The same search, opened with the keyboard shortcut")
        page.keyboard.press("Escape")
        time.sleep(0.4)
        page.keyboard.press("Control+k")
        time.sleep(0.6)
        page.fill("#cmdkIn", "Sector 43")
        time.sleep(1.8)
        drawn2 = page.evaluate("() => (document.getElementById('cmdkList') || {}).textContent || ''")
        check("a search for a locality lists properties from the office",
              "Sector 43" in drawn2, drawn2[:160].replace("\n", " "))

        print("\nD. The phone, at 390")
        page.set_viewport_size({"width": 390, "height": 844})
        for path in ("/agent/", "/agent/leads", "/agent/visits", "/agent/more", "/agent/approvals"):
            page.goto(BASE + path, wait_until="domcontentloaded")
            time.sleep(0.6)
            w = page.evaluate("[document.documentElement.scrollWidth, window.innerWidth]")
            check("%s does not scroll sideways at 390" % path, w[0] - w[1] <= 2, (w, w[0] - w[1]))
            tabs = page.eval_on_selector_all(".estat-pocket-tabs a, .estat-pocket-tabbar a, nav a",
                                             "els => els.length")
            check("%s keeps its doors on the phone" % path, tabs >= 4, tabs)

        print("\nE. The public pages, at 390")
        for path in ("/", "/properties/", "/enquiry/"):
            page.goto(BASE + path, wait_until="domcontentloaded")
            time.sleep(0.7)
            w = page.evaluate("[document.documentElement.scrollWidth, window.innerWidth]")
            check("%s does not scroll sideways at 390" % path, w[0] - w[1] <= 2, (w, w[0] - w[1]))
            hits = page.evaluate("() => document.body.innerHTML.includes('<img src=x')")
            check("%s never renders the payload as an element" % path, not hits, hits)

        ctx.close()
        browser.close()

    print("\nF. What the browser complained about")
    check("no alert ever ran", not fired, fired[:2])
    hard = [e for e in page_errors if e]
    check("no JavaScript error on any screen", not hard, hard[:3])
    errs = [c for c in console if c[0] == "error"]
    check("no console errors worth reading", len(errs) <= 2, errs[:3])

    print("\nG. PHP notices")
    log = [l for l in Site.log_since(before) if "Fatal" in l or "Warning" in l or "Notice" in l]
    check("no PHP warning while the browser worked", not log, log[:3])

    return summary("round 7 — in a real browser")


if __name__ == "__main__":
    main()
