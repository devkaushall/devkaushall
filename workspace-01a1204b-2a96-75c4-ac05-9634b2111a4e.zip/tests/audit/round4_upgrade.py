#!/usr/bin/env python3
"""Round 4 — the update path.

A plugin is not only what it does on a fresh install: it is what it does to a
site that already holds the old version's data. This round puts the leads table
back into the old, broken shape (idempotency_key NOT NULL, one row holding an
empty string), tells WordPress it is running 4.1.9, and lets the usual update
routine run — the same thing that happens when the office clicks "Update".

What has to be true afterwards:
  * an enquiry still saves, whatever the database allows, and
  * the plugin says "done" only when the column really is fixed.
"""

import os
import re
import sqlite3
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from harness import Site, check, summary  # noqa: E402

from harness import DB  # the real SQLite file, wherever the driver points
KEEP = "idempotency_key"          # the column under test


def rows():
    con = sqlite3.connect(DB)
    col = [r for r in con.execute("PRAGMA table_info(wp_estat_leads)") if r[1] == KEEP][0]
    empties = con.execute("SELECT COUNT(*) FROM wp_estat_leads WHERE idempotency_key=''").fetchone()[0]
    last = con.execute("SELECT COALESCE(MAX(id),0) FROM wp_estat_leads").fetchone()[0]
    con.close()
    return col[3] == 0, empties, last            # nullable?, empty rows, highest id


def rebuild(mode):
    """Rebuild the leads table with idempotency_key either strict or nullable."""
    con = sqlite3.connect(DB)
    con.execute("DROP TABLE IF EXISTS wp_estat_leads_old")
    sql = con.execute("SELECT sql FROM sqlite_master WHERE name='wp_estat_leads'").fetchone()[0]
    new = sql.replace('CREATE TABLE "wp_estat_leads"', 'CREATE TABLE "wp_estat_leads_old"', 1)
    if new == sql:
        new = sql.replace("CREATE TABLE `wp_estat_leads`", "CREATE TABLE `wp_estat_leads_old`", 1)
    line = [l for l in new.splitlines() if KEEP in l][0]
    if mode == "strict":
        new = new.replace(line, line.split(",")[0].rstrip() + " NOT NULL DEFAULT ''", 1)
    else:
        new = new.replace(line, line.split(",")[0].rstrip(), 1)   # no NOT NULL: may hold NULL
    con.execute("PRAGMA foreign_keys=off")
    con.execute(new)
    cols = [r[1] for r in con.execute("PRAGMA table_info(wp_estat_leads)")]
    sel = ", ".join("COALESCE(`%s`, '')" % c if c == KEEP else "`%s`" % c for c in cols)
    con.execute("INSERT INTO wp_estat_leads_old (%s) SELECT %s FROM wp_estat_leads"
                % (", ".join("`%s`" % c for c in cols), sel))
    # an old installation: one row holds the empty key, the rest hold their own
    con.execute("UPDATE wp_estat_leads_old SET idempotency_key = 'auto|legacy|' || id WHERE id > 1")
    con.execute("UPDATE wp_estat_leads_old SET idempotency_key='' WHERE id=1")
    con.execute("DROP TABLE wp_estat_leads")
    con.execute("ALTER TABLE wp_estat_leads_old RENAME TO wp_estat_leads")
    con.commit()
    con.close()


def refresh_metadata():
    """Make the sandbox's own column report agree with the table (MySQL: free)."""
    Site.wp('global $wpdb; $wpdb->suppress_errors( true );'
            '$wpdb->query( "ALTER TABLE {$wpdb->prefix}estat_leads MODIFY idempotency_key CHAR(64) NULL DEFAULT NULL" );'
            '$wpdb->suppress_errors( false ); echo "ok";')


def update():
    Site.wp('update_option("estat_version","4.1.9",false); delete_option("estat_os_key_nullable");')
    out = Site.wp('\\EstatOS\\Install\\Migrator::maybe_upgrade(); echo get_option("estat_version");')
    # leave the fixtures tidy: an installation that has been through an update
    # never ends with two rows sharing a key
    Site.wp('global $wpdb; $t = $wpdb->prefix . "estat_leads";'
            '$wpdb->query( "UPDATE {$t} SET idempotency_key = CONCAT( \'auto|legacy|\', id ) '
            'WHERE idempotency_key IS NULL OR idempotency_key = \'\' OR idempotency_key = \'auto|old\'" ); echo "ok";')
    return out


def flag():
    return Site.wp('echo var_export( get_option( "estat_os_key_nullable" ), true );').strip()


def main():
    print("A. A site still running the old build")
    rebuild("strict")
    nullable, empties, last = rows()
    check("the old shape is back — a column that refuses NULL, one row holding an empty key",
          not nullable and empties == 1, (nullable, empties))

    print("\nB. The update runs")
    out = update()
    with open("/home/user/plugin/estat-os/estat-os.php") as f:
        want = re.search(r"Version:\s*([0-9.]+)", f.read()).group(1)
    check("the site reports the new version", want in out, out.strip()[-120:])

    nullable, empties, last = rows()
    fixed = nullable and empties == 0
    print("     (this database: nullable=%s, empty rows=%s)" % (nullable, empties))
    check("the plugin only says \"fixed\" when the column really is fixed",
          (flag() == "'1'") == fixed, ("flag", flag(), "nullable", nullable, "empties", empties))

    print("\nC. Enquiries keep working either way")
    saved = Site.wp(
        '$ok = 0; for ( $i = 0; $i < 3; $i++ ) {'
        ' $r = \\EstatOS\\Leads\\Leads::create( array( "name" => "Round Four " . $i,'
        ' "phone" => "+9198000090" . $i, "message" => "x" ) );'
        ' $ok += is_wp_error( $r ) ? 0 : 1; } echo $ok;'
    ).strip()
    check("three enquiries in a row are all saved", saved.splitlines()[-1] == "3", saved)
    # A key-less enquiry is stored with no key at all on a healthy install —
    # the column is UNIQUE and NULL may repeat, which is exactly what makes a
    # second walk-in enquiry possible. What must never happen is an *empty
    # string* (one only, ever) or two rows sharing one key.
    fresh = Site.sql("SELECT COUNT(*) FROM wp_estat_leads WHERE id > %d AND idempotency_key = ''" % last)
    check("no enquiry written since the update holds an empty-string key", int(fresh[0][0]) == 0, fresh)
    shared = Site.sql("SELECT idempotency_key, COUNT(*) c FROM wp_estat_leads "
                      "WHERE idempotency_key IS NOT NULL GROUP BY idempotency_key HAVING c > 1")
    check("and no two enquiries share a key", not shared, shared)

    print("\nD. What the sandbox can and cannot show")
    note = Site.wp('global $wpdb; $wpdb->suppress_errors( true );'
                   '$r = $wpdb->query( "ALTER TABLE {$wpdb->prefix}estat_leads MODIFY idempotency_key CHAR(64) NULL" );'
                   '$wpdb->suppress_errors( false ); echo var_export( false !== $r, true );').strip()
    if note.endswith("false"):
        print("     (this sandbox's SQLite driver refuses ALTER MODIFY, so the repair's")
        print("      \"all clear\" branch is proved in tests/key_nullable_check.php instead)")
        check("a database that refuses the change leaves the repair un-written",
              flag() == "false", flag())
    else:
        nullable, empties, _ = rows()
        check("a database that allows the change is written down as done",
              flag() == "'1'", ("flag", flag(), "nullable", nullable, "empties", empties))

    print("\nE. PHP notices")
    log = Site.log_since(Site.log_mark())
    check("no PHP warnings while updating", not log, log)

    return summary()


if __name__ == "__main__":
    main()
