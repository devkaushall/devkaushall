#!/usr/bin/env python3
"""Round 8 — the three journeys the office actually takes, in a browser.

A request-level test can prove an endpoint answers. It cannot prove that a
person pressing the buttons gets the right result. These three journeys are the
ones that broke before, each traced from the first click to the stored record:

  1. Add a home and publish it — the journey behind the "that link has expired"
     page, and behind the office landing nowhere after a save;
  2. Build a form, save it, and find it still there after a reload — the journey
     behind the builder that stored an empty layout;
  3. Open an enquiry, move it along, and reload — the journey behind the
     statuses that never moved.
"""

import json
import os
import sqlite3
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from harness import Site, check, summary , DB  # noqa: E402
from playwright.sync_api import sync_playwright  # noqa: E402

BASE = "http://localhost:8080"


def db():
    return sqlite3.connect(DB)


def main():
    before = Site.log_mark()
    errors = []

    with sync_playwright() as p:
        browser = p.chromium.launch()
        ctx = browser.new_context(viewport={"width": 1440, "height": 900})
        page = ctx.new_page()
        page.on("pageerror", lambda e: errors.append(str(e)[:160]))
        # Several of the office's buttons ask before they act. A browser with
        # nobody sitting in it has to answer that question the way a person
        # would, or the test measures its own silence.
        dialogs = []
        page.on("dialog", lambda d: (dialogs.append(d.message[:80]), d.accept()))

        check("the office signs in", Site.browser_login(page), page.url)
        # ------------------------------------------------- 1. publish a home
        print("A. Add a home, and publish it")
        page.goto(BASE + "/wp-admin/admin.php?page=estat-add-home", wait_until="domcontentloaded")
        time.sleep(1.2)
        headline = "Browser journey flat %d" % int(time.time())
        page.fill("#ahTitle", headline)
        page.fill("#ahPrice", "21500000")
        loc = page.query_selector('input[name="locality"]')
        if loc:
            loc.fill("Sector 57")
        for _ in range(3):
            page.click("#ahAddHl")
            time.sleep(0.2)
        rows = page.query_selector_all("#ahHl input")
        for i, inp in enumerate(rows[:3]):
            inp.fill(["Three-side open balcony", "Two covered car parks", "Corner unit"][i])
        time.sleep(0.4)
        page.click("#ahPublish")
        page.wait_for_load_state("domcontentloaded")
        time.sleep(1.6)

        note = page.evaluate("() => { const n = document.querySelector('.estat-note, .notice, #ahNotice'); return n ? n.textContent.trim() : ''; }")
        print("     after publishing:", (note or page.url)[:120])
        saved = Site.sql("SELECT ID, post_title, post_status FROM wp_posts WHERE post_title = '%s' LIMIT 1" % headline)
        check("the property was stored", bool(saved), saved)
        check("and it was not left as a draft", bool(saved) and saved[0][2] in ("publish", "pending"), saved)
        price = Site.sql("SELECT meta_value FROM wp_postmeta WHERE post_id = %d AND meta_key = '_estat_price'" % (saved[0][0] if saved else 0))
        check("with its price", bool(price) and str(price[0][0]).startswith("21500000"), price)
        banner = page.evaluate("""() => {
            const n = document.querySelector('.estat-note, .notice, .dr__b');
            return n ? n.textContent.trim().slice(0, 120) : '';
        }""")
        check("no \"link has expired\" page was shown",
              "purana ho gaya" not in page.content().lower() and "expired" not in banner.lower(),
              (banner, page.url))
        check("and the office was taken to the property it just saved, not a blank list",
              ("edit=" in page.url) or ("estat-add-home" in page.url), page.url)

        # ------------------------------------------------- 2. build a form
        print("\nB. Build a form, save it, reload")
        page.goto(BASE + "/wp-admin/admin.php?page=estat-forms", wait_until="domcontentloaded")
        time.sleep(1.6)
        fid = int(page.evaluate("() => (document.getElementById('fbFormId') || {}).value || 0"))
        before_boxes = page.eval_on_selector_all("#fbCanvas .fbfield", "els => els.length")
        before_labels = page.eval_on_selector_all("#fbCanvas .fbfield b", "els => els.map(e => e.textContent.trim())")
        check("the form opens with the boxes it already had", before_boxes >= 1, (fid, before_boxes))

        page.click('#fbTools [data-tool="text"]')
        time.sleep(0.5)
        page.fill("#fbSetLabel", "Which floor do you want")
        time.sleep(0.2)
        page.click("#fbSetReq")                        # the page's own tick
        time.sleep(0.4)
        ticked = page.evaluate("() => document.querySelector('#fbCanvas .fbfield[data-req=\"1\"]') ? 'yes' : 'no'")
        check("the panel that renames a box and marks it required exists and works",
              ticked == "yes", ticked)

        page.click("#fbSave")
        time.sleep(2.6)
        toast = page.evaluate("() => { const t = document.getElementById('toasts'); return t ? t.textContent.trim() : ''; }")
        print("     the office said:", toast[:60])
        page.reload(wait_until="domcontentloaded")
        time.sleep(1.6)
        after_boxes = page.eval_on_selector_all("#fbCanvas .fbfield", "els => els.length")
        after_labels = page.eval_on_selector_all("#fbCanvas .fbfield b", "els => els.map(e => e.textContent.trim())")
        check("every box that was already there survived the save",
              after_boxes == before_boxes + 1, (before_boxes, after_boxes))
        check("and the ones that were there kept their own labels", after_labels[:len(before_labels)] == before_labels,
              (before_labels, after_labels))
        check("the new box kept the label that was typed into it",
              "Which floor do you want" in after_labels, after_labels)

        stored = Site.sql("SELECT definition FROM wp_estat_forms WHERE id = %d" % fid)
        boxes, required, labels = 0, 0, []

        def boxes_of(definition):
            """The boxes of a form, wherever the writer put them.

            A definition may carry its rows at the top, or one level down
            inside a step — the builder writes the second shape, an import the
            first. Counting only one shape is how a stored form looked empty
            when it was full.
            """
            found = []
            for row in definition.get("rows", []) or []:
                for col in row.get("columns", []) or []:
                    found += list(col.get("fields", []) or [])
            for step in definition.get("steps", []) or []:
                found += boxes_of(step)
            return found

        if stored and stored[0][0]:
            found = boxes_of(json.loads(stored[0][0]))
            boxes = len(found)
            labels = [str(f.get("label", "")) for f in found]
            required = len([f for f in found if f.get("required")])
        check("the stored form has every box, not just the new one", boxes == after_boxes, (boxes, after_boxes))
        check("and the required tick was stored, not quietly dropped", required >= 1, (required, labels))

        # the same form, drawn for a visitor, and filled in
        Site.reset_rate_limit()
        slug = Site.sql("SELECT post_name FROM wp_posts WHERE post_name IN ('palette','enquiry') AND post_status='publish' ORDER BY (post_name='enquiry') DESC LIMIT 1")
        page.goto(BASE + "/" + slug[0][0] + "/", wait_until="domcontentloaded")
        time.sleep(1.0)
        drawn = page.eval_on_selector_all("form[data-endpoint] .field__lbl, form[data-endpoint] label",
                                          "els => els.map(e => e.textContent.trim())")
        check("the page a visitor opens draws the form the office just saved",
              any("Which floor" in d for d in drawn) or len(drawn) >= 3, drawn[:6])

        # ------------------------------------------------- 3. an enquiry moves
        print("\nC. Open an enquiry and move it along")
        page.goto(BASE + "/wp-admin/admin.php?page=estat-enquiries", wait_until="domcontentloaded")
        time.sleep(1.2)
        lead = Site.sql("SELECT id, status FROM wp_estat_leads ORDER BY id DESC LIMIT 1")[0]
        opened = page.evaluate("""(id) => {
            const b = document.querySelector('#enqRows [data-drawer="enquiry"][data-id="' + id + '"]')
                   || document.querySelector('[data-drawer="enquiry"][data-id="' + id + '"]');
            if (!b) { return false; }
            b.click();
            return true;
        }""", int(lead[0]))
        check("the enquiry has an Open button on the list", opened, opened)
        time.sleep(2.2)
        drawer = page.evaluate("() => ((document.getElementById('dwBody') || {}).textContent || '').replace(/\\s+/g, ' ').trim()")
        title = page.evaluate("() => (document.getElementById('dwTitle') || {}).textContent || ''")
        check("clicking it opens the enquiry in the drawer", bool(drawer) and bool(title.strip()), (title[:40], drawer[:80]))

        page.click('#dwFoot [data-act="lead-advance"]')
        time.sleep(2.6)
        now = Site.sql("SELECT status FROM wp_estat_leads WHERE id = %d" % int(lead[0]))[0][0]
        check("moving it on a stage really moves the stored enquiry",
              now != lead[1], (lead[1], now, dialogs[:1]))

        # and the drawer, opened again, says so
        page.goto(BASE + "/wp-admin/admin.php?page=estat-enquiries", wait_until="domcontentloaded")
        time.sleep(1.6)
        page.evaluate("""(id) => {
            const b = document.querySelector('#enqRows [data-drawer="enquiry"][data-id="' + id + '"]');
            if (b) { b.click(); }
        }""", int(lead[0]))
        time.sleep(2.2)
        again = page.evaluate("() => ((document.getElementById('dwBody') || {}).textContent || '').replace(/\\s+/g, ' ')")
        stage_word = {"new": "new", "contacted": "contacted", "visit": "scheduled", "negotiation": "negotiation",
                      "won": "won", "lost": "lost"}.get(now, now)
        check("and the drawer, opened again, shows the new stage", stage_word.lower() in again.lower(),
              (now, again[:140]))

        ctx.close()
        browser.close()

    print("\nD. The browser's own complaints")
    check("no JavaScript error during the journeys", not errors, errors[:2])
    log = [l for l in Site.log_since(before) if "Fatal" in l or "Warning" in l or "Notice" in l]
    check("no PHP warning during the journeys", not log, log[:3])

    return summary("round 8 — the office's own journeys")


if __name__ == "__main__":
    main()
