#!/usr/bin/env python3
"""Round 11 — the sitemap seams that took the live site down on 7 Oct.

Two failures, one afternoon:

  * /sitemap_index.xml returned HTTP 500 for every request — Rank Math hands
    the exclude_empty_terms filter an array of WP_Taxonomy objects and the
    plugin cast each item with strval(). A cast is not a check; on an object
    it is a fatal.
  * the content firewall's block splitter used a lookbehind whose alternatives
    have different lengths — older PCRE refuses to compile it, warns on every
    render and silently degrades the split.

This round runs both seams the way the real plugins run them: through the
WordPress filter system with the exact payload shapes Rank Math passes (the
sandbox may or may not have Rank Math installed; the filter and the payload
are reproducible either way). If Rank Math is installed it also brings it up,
serves the real sitemap index and every child, then takes it down again so
the other rounds find the site as they left it.
"""

import os
import re
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from harness import Site, WPCLI, check, summary  # noqa: E402

RM_DIR = "/tmp/wp/wp-content/plugins/seo-by-rank-math"


def wp_cli(*args):
    r = subprocess.run(WPCLI + list(args), capture_output=True, text=True)
    return ((r.stdout or "") + (r.stderr or "")).strip()


def main():
    before = Site.log_mark()
    s = Site()

    print("A. The Rank Math seam — objects, names, mixed, junk, hostile")
    out = Site.wp("$o = array_map('get_taxonomy', array('category','estat_locality')); "
                  "echo apply_filters('rank_math/sitemap/exclude_empty_terms', false, $o) ? 'true' : 'false';")
    check("object list incl. ours -> excludes, no fatal", out.endswith("true") and "Fatal" not in out, out)
    out = Site.wp("$o = array_map('get_taxonomy', array('category','post_tag')); "
                  "echo apply_filters('rank_math/sitemap/exclude_empty_terms', false, $o) ? 'true' : 'false';")
    check("object list without ours -> answer kept", out.endswith("false"), out)
    out = Site.wp("echo apply_filters('rank_math/sitemap/exclude_empty_terms', false, array('category')) ? 'true' : 'false';")
    check("names-only list (old shape) still works", out.endswith("false"), out)
    out = Site.wp("echo apply_filters('rank_math/sitemap/exclude_empty_terms', true, 'estat_feature') ? 'true' : 'false';")
    check("single string still works", out.endswith("true"), out)
    out = Site.wp("echo apply_filters('rank_math/sitemap/exclude_empty_terms', true, null) ? 'true' : 'false';")
    check("null keeps the plugin's own answer", out.endswith("true"), out)
    out = Site.wp("echo apply_filters('rank_math/sitemap/exclude_empty_terms', false, "
                  "array(null, array('x'), 12.5, new stdClass(), get_taxonomy('estat_amenity'))) ? 'true' : 'false';")
    check("junk skipped, the good item still counts", out.endswith("true"), out)

    print("\nB. The core-sitemap seam")
    out = Site.wp("$r = apply_filters('wp_sitemaps_taxonomies_query_args', array('hide_empty'=>false), get_taxonomy('estat_locality')); "
                  "echo $r['hide_empty'] ? 'true' : 'false';")
    check("core: object arg hides empty terms for ours", out.endswith("true"), out)
    out = Site.wp("$r = apply_filters('wp_sitemaps_taxonomies_query_args', array('hide_empty'=>false), 'category'); "
                  "echo $r['hide_empty'] ? 'true' : 'false';")
    check("core: somebody else's taxonomy untouched", out.endswith("false"), out)
    code, body, _ = s.get("/wp-sitemap.xml")
    check("core sitemap serves 200", code == 200, code)

    print("\nC. The block splitter — old PCRE's complaint must not exist here")
    out = Site.wp("echo strpos(\\EstatOS\\Support\\PublicText::prose('<p>Keep this sentence about the flat.</p>"
                  "<p>Office: rate on the source sheet, not confirmed.</p>'), 'source sheet') === false ? 'ok' : 'bad';")
    check("prose() filters on a page render, no warning", out.endswith("ok"), out)
    src = subprocess.run(["grep", "-rn", "(?<=\\|(?<!", "/home/user/plugin/estat-os/includes/",
                          "--include=*.php"], capture_output=True, text=True)
    check("no lookbehind regex anywhere in the plugin", src.stdout.strip() == "", src.stdout[:200])

    print("\nD. The real stack, if Rank Math is installed")
    have_rm = os.path.isdir(RM_DIR)
    if not have_rm:
        check("Rank Math not installed here — seam proven via A instead", True, "skipped")
    else:
        wp_cli("plugin", "activate", "seo-by-rank-math")
        Site.wp("update_option('rank_math_modules', array('general-settings','sitemap','link-counter','redirections')); "
                "update_option('rank_math_registration_skip', true); "
                "$o = (array) get_option('rank-math-options-sitemap', array()); "
                "foreach (array('estat_locality','estat_amenity','estat_feature') as $t) { $o['tax_' . $t . '_sitemap'] = true; } "
                "update_option('rank-math-options-sitemap', $o); "
                "global $wp_rewrite; $wp_rewrite->flush_rules(); echo 'set';")
        code, body, _ = s.get("/sitemap_index.xml")
        check("index serves 200 with objects flying through the filter", code == 200, code)
        check("index is XML, built by Rank Math", "<?xml" in body[:120] and "Rank Math" in body, body[:120])
        kids = re.findall(r"<loc>([^<]+)</loc>", body)
        check("index lists every child", len(kids) >= 4, kids)
        bad = []
        for u in kids:
            c2, b2, _ = s.get(u)
            if c2 != 200 or "<urlset" not in b2:
                bad.append((u, c2))
        check("every child sitemap serves 200", not bad, bad)
        empties = Site.wp("$t = get_terms(array('taxonomy'=>'estat_locality','hide_empty'=>false,"
                           "'fields'=>'ids')); $z = array(); foreach ($t as $id) { $x = get_term($id); if (0 == $x->count) $z[] = $x->slug; } "
                           "echo implode(',', $z) ?: 'none';")
        loc_child = [u for u in kids if "estat_locality" in u]
        if loc_child and empties not in ("none", ""):
            c3, b3, _ = s.get(loc_child[0])
            leaked = [slug for slug in empties.split(",") if slug in b3]
            check("empty localities are out of the term sitemap", not leaked, leaked or empties)
        else:
            check("empty localities are out of the term sitemap", True, "no empty terms right now (%s)" % empties)
        # take the visitor back to the site the other rounds expect
        wp_cli("plugin", "deactivate", "seo-by-rank-math")
        Site.wp("global $wp_rewrite; $wp_rewrite->flush_rules(); echo 'down';")

    print("\nE. Nothing new went wrong while doing any of this")
    log = Site.log_since(before)
    check("no estat-os fatal or warning in the log",
          not re.search(r"Fatal|Uncaught", log) or "estat-os" not in log, log[-400:])
    check("no lookbehind compilation warning", "lookbehind" not in log.lower(), log[-200:])
    check("no preg_split warning from the plugin", "preg_split" not in log, log[-200:])

    summary("round 11 — the sitemap seams")


if __name__ == "__main__":
    main()
