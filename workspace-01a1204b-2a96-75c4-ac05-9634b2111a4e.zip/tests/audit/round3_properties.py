#!/usr/bin/env python3
"""
Round 3 — properties, duplicates, the bin, approvals and who may do what.

Every check here works the office screen the way the office does: a real form
post, a real AJAX button press, and a read-back from the database.
"""
import os
import re
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from harness import Site, check, summary  # noqa: E402


def status_of(pid):
    rows = Site.sql("SELECT post_status FROM wp_posts WHERE ID = %d" % int(pid))
    return rows[0][0] if rows else None


def meta(pid, key):
    rows = Site.sql("SELECT meta_value FROM wp_postmeta WHERE post_id = %d AND meta_key = '%s'" % (int(pid), key))
    return rows[0][0] if rows else None


def main():
    before = Site.log_mark()
    # this round makes its own records; clear yesterday's so the counts mean something
    Site.wp('global $wpdb; $ids = $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_title LIKE \'Audit %\'" );'
            'foreach ( $ids as $id ) { wp_delete_post( (int) $id, true ); } echo count( $ids );')
    owner = Site().login("owner", "ownerpass")

    # ------------------------------------------------------------------ publish
    print("A. Publish a property from the office screen")
    fields = owner.office_form("estat-add-home")
    fields.update({"action": "estat_add_home", "listing_id": "0",
                   "title": "Audit 3 BHK in Sector 43", "locality": "Sector 43, Golf Course Road",
                   "offer": "sale", "property_type": "apartment", "price": "31000000",
                   "area": "2100", "bedrooms": "3", "save": "publish"})
    s, body, url = owner.post("/wp-admin/admin-post.php", fields, follow=True)
    print("   landed:", url.split("8080")[-1][:80])
    rows = Site.sql("SELECT ID, post_title, post_status FROM wp_posts WHERE post_title = 'Audit 3 BHK in Sector 43'")
    check("the property was saved", bool(rows), rows)
    check("Publish really put it on the website",
          bool(rows) and rows[0][2] == "publish", rows[0][2] if rows else None)
    pid = int(rows[0][0]) if rows else 0
    check("the price was stored", meta(pid, "_estat_price") not in (None, "", "0"),
          meta(pid, "_estat_price"))

    # ------------------------------------------------------------- the duplicate
    print("\nB. A near-identical second record, then the Duplicates screen")
    twin = owner.office_form("estat-add-home")
    twin.update({"action": "estat_add_home", "listing_id": "0",
                 "title": "Audit 3 BHK in Sector 43, corner unit", "locality": "Sector 43, Golf Course Road",
                 "offer": "sale", "property_type": "apartment", "price": "31200000",
                 "area": "2110", "bedrooms": "3", "save": "publish"})
    owner.post("/wp-admin/admin-post.php", twin, follow=True)
    twins = Site.sql("SELECT ID FROM wp_posts WHERE post_title LIKE 'Audit 3 BHK in Sector 43%' AND post_status = 'publish'")
    check("both records are in the office", len(twins) == 2, twins)

    s, res = owner.ajax(os_action="act", do="scan", kind="listings")
    say = (res.get("data") or {}).get("say") if isinstance(res, dict) else res
    print("   Check now ->", s, say)
    check("Check now answers instead of 'that action is not known'", s == 200 and bool((res or {}).get("success")), res)
    found = (res.get("data") or {}).get("found") if isinstance(res, dict) else 0
    check("the scan found the pair", bool(found), found)

    screen = owner.screen("estat-duplicates")
    check("the Duplicates screen lists the pair it just found",
          "Audit 3 BHK in Sector 43" in screen, "neither title is on the screen")

    # ------------------------------------------------------------------- bin
    print("\nC. The bin: an honest refusal, then a real restore")
    s, res = owner.ajax(os_action="act", do="restore", id=str(pid))
    msg = (res.get("data") or {}).get("message") if isinstance(res, dict) else res
    trashed = status_of(pid) == "trash"
    check("restoring a record that is not in the bin is refused, not pretended",
          s == 422 and not trashed, (s, msg))
    check("...and the record is untouched", status_of(pid) == "publish", status_of(pid))

    s, res = owner.ajax(os_action="act", do="bin", id=str(pid))
    check("moving it to the bin works", s == 200 and status_of(pid) == "trash", status_of(pid))
    s, res = owner.ajax(os_action="act", do="restore", id=str(pid))
    check("restoring it from the bin works", s == 200 and status_of(pid) == "publish", status_of(pid))

    # ------------------------------------------------------------- approvals
    print("\nD. Approving a change request, as the office owner")
    # an agent proposes a new price, then the desk answers it
    ask = Site.wp('$r = \EstatOS\Field\Requests::create( array( "record_id" => %d, "changes" => array( "price" => 33000000, "note" => "Owner wants a little more" ) ) );'
                  'echo is_wp_error( $r ) ? "ERR " . $r->get_error_message() : $r;' % pid)
    rid = ask.strip().splitlines()[-1]
    check("an agent's change request was filed", rid.isdigit(), rid)
    if rid.isdigit():
        s, res = owner.ajax(os_action="act", do="approve", id=rid)
        price = meta(pid, "_estat_price")
        check("the desk's Approve really applies the change",
              s == 200 and str(price).startswith("33000000"), (s, price, res))
        check("an already-answered request is refused, not silently re-done",
              owner.ajax(os_action="act", do="approve", id=rid)[0] == 422,
              owner.ajax(os_action="act", do="approve", id=rid))
        s, res = owner.ajax(os_action="act", do="approve", id="999999")
        check("a request id that does not exist is refused", s == 422, (s, res))

    # ------------------------------------------------------------ permissions
    print("\nE. What the phone's role may not do")
    agent = Site().login("siteagent", "agentpass")
    s, res = agent.ajax(os_action="act", do="purge", id=str(pid))
    check("an agent may not destroy a record", s == 403, (s, res))
    s, res = agent.ajax(os_action="save", what="form", id="1", definition='{"rows":[]}')
    check("an agent may not change the website's forms", s == 403, (s, res))
    s, res = agent.ajax(os_action="act", do="approve", id=rid)
    check("an agent may not approve", s in (403, 404), (s, res))

    # ----------------------------------------------------------------- search
    print("\nF. The search box on the office rail")
    s, res = owner.ajax(os_action="search", q="sector 43")
    items = (res.get("data") or {}).get("items") if isinstance(res, dict) else None
    check("a search by locality finds the properties", bool(items), res if not items else items[:2])
    s, res = owner.ajax(os_action="search", q="priya")
    items = (res.get("data") or {}).get("items") if isinstance(res, dict) else None
    kinds = set((i.get("kind") for i in (items or [])))
    check("a search for a person finds the person", "agent" in kinds, items[:3] if items else res)

    notes = Site.log_since(before)
    print("\nG. PHP notices:", notes or "(none)")
    check("no PHP warnings during this round", not notes, notes[:200])

    return summary("round 3 — properties")


if __name__ == "__main__":
    sys.exit(1 if main() else 0)
