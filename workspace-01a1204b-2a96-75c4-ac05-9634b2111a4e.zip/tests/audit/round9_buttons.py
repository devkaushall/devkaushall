#!/usr/bin/env python3
"""Round 9 — every button on every office screen, pressed.

A screen full of buttons that look alive and do nothing is the worst kind of
broken: nothing says "no". This walks the office's screens, presses each button
that carries an instruction (`data-act`), and asks what changed — a message, a
new page, or a redrawn panel. Silence is the finding.

Buttons that destroy records (purge, empty the bin, remove a photograph) are
left alone here; they have their own rounds.
"""

import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from harness import Site, check, summary  # noqa: E402
from playwright.sync_api import sync_playwright  # noqa: E402

BASE = "http://localhost:8080"

SKIP = {"purge", "empty-bin", "delete-media", "detach-media", "tokens-reset"}

SCREENS = [
    ("estat-today", ""),
    ("estat-listings", ""),
    ("estat-enquiries", ""),
    ("estat-visits", ""),
    ("estat-projects", ""),
    ("estat-team", ""),
    ("estat-gallery", ""),
    ("estat-duplicates", ""),
    ("estat-bin", ""),
    ("estat-forms", ""),
    ("estat-settings", ""),
    ("estat-reports", ""),
]


def fingerprint(page):
    return page.evaluate("""() => {
        const toast = document.getElementById('toasts');
        const body = document.getElementById('canvas') || document.body;
        return (toast ? toast.textContent.trim() : '') + '|' + (body.innerHTML || '').length + '|' + location.href;
    }""")


def main():
    before = Site.log_mark()
    sil = []

    with sync_playwright() as p:
        browser = p.chromium.launch()
        ctx = browser.new_context(viewport={"width": 1440, "height": 900})
        page = ctx.new_page()
        page.on("dialog", lambda d: d.accept())
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)[:140]) if "ViewTransition" not in str(e) else None)

        check("the office signs in", Site.browser_login(page), page.url)
        print("A. Pressing every instruction button")
        total = 0
        for slug, _ in SCREENS:
            url = "%s/wp-admin/admin.php?page=%s" % (BASE, slug)
            listing = []
            page.goto(url, wait_until="domcontentloaded")
            time.sleep(1.2)
            acts = page.evaluate("""() => Array.from(document.querySelectorAll('[data-act]'))
                .map((b, i) => ({ act: b.getAttribute('data-act'), sel: '[data-act="' + b.getAttribute('data-act') + '"]', i: i }))""")
            seen = {}
            for a in acts:
                seen.setdefault(a["act"], a)
            for act, info in sorted(seen.items()):
                if act in SKIP:
                    continue
                page.goto(url, wait_until="domcontentloaded")
                time.sleep(1.1)
                was = fingerprint(page)
                try:
                    page.click(info["sel"], timeout=4000)
                except Exception as e:
                    listing.append("%s: not clickable (%s)" % (act, str(e)[:40]))
                    continue
                time.sleep(1.8)
                now = fingerprint(page)
                total += 1
                if now == was:
                    listing.append("%s: nothing happened" % act)
            if listing:
                sil += [(slug, x) for x in listing]
                print("  %-20s %s" % (slug, "; ".join(listing)))
            else:
                print("  %-20s every button did something" % slug)

        print("\nB. Opening a drawer from each list that has one")
        for slug, kind in (("estat-listings", "listing"), ("estat-enquiries", "enquiry"),
                           ("estat-visits", "visit"), ("estat-projects", "project")):
            page.goto("%s/wp-admin/admin.php?page=%s" % (BASE, slug), wait_until="domcontentloaded")
            time.sleep(1.3)
            opened = page.evaluate("""(kind) => {
                const b = document.querySelector('[data-drawer="' + kind + '"][data-id]:not([data-id="0"])');
                if (b) { b.click(); return 'button'; }
                // the properties table opens the record by clicking its row
                const row = document.querySelector('#propRows tr[data-id], tr[data-id]');
                if (row) { row.querySelector('td').click(); return 'row'; }
                return false;
            }""", kind)
            time.sleep(2.4)
            body = page.evaluate("() => ((document.getElementById('dwBody') || {}).textContent || '').trim()")
            check("the %s list opens its own drawer" % kind, bool(opened) and len(body) > 20,
                  (opened, body[:60]))

        print("\nB2. The three answers a visit can be given")
        vid = Site.sql("SELECT id FROM wp_estat_visits ORDER BY id LIMIT 1")
        if vid:
            rid = int(vid[0][0])
            for act, want in (("visit-done", "done"), ("visit-no_show", "no_show"), ("visit-cancelled", "cancelled")):
                Site.wp('global $wpdb; $wpdb->query( "UPDATE {$wpdb->prefix}estat_visits SET outcome = \'pending\' WHERE id = %d" );' % rid)
                page.goto("%s/wp-admin/admin.php?page=estat-visits" % BASE, wait_until="domcontentloaded")
                time.sleep(1.3)
                clicked = page.evaluate("""(sel) => {
                    const b = document.querySelector(sel);
                    if (!b) { return false; }
                    b.click();
                    return true;
                }""", '[data-act="%s"][data-id="%d"]' % (act, rid))
                time.sleep(2.0)
                got = Site.sql("SELECT outcome FROM wp_estat_visits WHERE id = %d" % rid)
                check("pressing \"%s\" really records it" % act, clicked and got and got[0][0] == want,
                      (clicked, got, want))
        else:
            check("a visit exists to answer", False, "none seeded")

        ctx.close()
        browser.close()

    print("\nC. The verdict")
    check("no button on any office screen is silent", not sil, sil[:6])
    check("no JavaScript error while pressing them", not errors, errors[:3])
    log = [l for l in Site.log_since(before) if "Fatal" in l or "Warning" in l or "Notice" in l]
    check("no PHP warning while pressing them", not log, log[:3])
    print("     (%d buttons pressed)" % total)

    return summary("round 9 — every button")


if __name__ == "__main__":
    main()
