#!/bin/bash
# Rebuild the live WordPress audit sandbox from nothing.
#
# /tmp is wiped whenever the sandbox restarts, so this script brings the whole
# test site back in one command:
#
#   bash tests/audit/rebuild_sandbox.sh [build]
#
# "build" is either `released` (the 4.1.10 zip as shipped) or `working` (the
# tree in plugin/estat-os). The site is then at http://localhost:8080 with
# owner / ownerpass, and the log at /tmp/wp/debug.log.
set -euo pipefail

WP=/tmp/wp
SETUP=/tmp/wpsetup
BUILD="${1:-working}"
WPCLI="php $SETUP/wp-cli.phar --path=$WP --allow-root"

echo "== 1. PHP"
if ! command -v php >/dev/null; then
  sudo apt-get update -qq
  sudo apt-get install -y -qq php-cli php-sqlite3 php-mbstring php-curl php-xml php-zip php-intl >/dev/null
fi
php -v | head -1

echo "== 2. downloads"
mkdir -p "$SETUP" "$WP"
if [ ! -f "$SETUP/wp-cli.phar" ]; then
  curl -sSL -o "$SETUP/wp-cli.phar" https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar
fi
if [ ! -f "$SETUP/latest.zip" ]; then
  curl -sSL -o "$SETUP/latest.zip" https://wordpress.org/latest.zip
fi
if [ ! -f "$SETUP/sqlite.zip" ]; then
  curl -sSL -o "$SETUP/sqlite.zip" https://downloads.wordpress.org/plugin/sqlite-database-integration.zip
fi

echo "== 3. WordPress core"
if [ ! -f "$WP/wp-load.php" ]; then
  rm -rf "$SETUP/core"; mkdir -p "$SETUP/core"
  unzip -q -o "$SETUP/latest.zip" -d "$SETUP/core"
  cp -r "$SETUP/core/wordpress/." "$WP/"
fi

echo "== 4. SQLite in place of MySQL"
rm -rf "$SETUP/plug"; mkdir -p "$SETUP/plug"
unzip -q -o "$SETUP/sqlite.zip" -d "$SETUP/plug"
cp -r "$SETUP/plug/sqlite-database-integration" "$WP/wp-content/plugins/"
if [ ! -f "$WP/wp-content/db.php" ]; then
  sed -e "s#{SQLITE_IMPLEMENTATION_FOLDER_PATH}#$WP/wp-content/plugins/sqlite-database-integration#" \
      -e "s#{SQLITE_PLUGIN}#sqlite-database-integration/load.php#" \
      "$WP/wp-content/plugins/sqlite-database-integration/db.copy" > "$WP/wp-content/db.php"
fi

echo "== 5. wp-config.php"
cp "$WP/wp-config-sample.php" "$WP/wp-config.php"
cat > /tmp/wp/router.php <<'ROUTER'
<?php
/** Router for `php -S`, so pretty permalinks reach WordPress. */
$root = __DIR__;
$path = parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH );
$file = realpath( $root . $path );
if ( $file && is_file( $file ) && 0 === strpos( $file, $root ) ) {
	if ( substr( $file, -4 ) === '.php' ) {
		require $file;
		return true;
	}
	return false;
}
$_SERVER['SCRIPT_NAME']     = '/index.php';
$_SERVER['SCRIPT_FILENAME'] = $root . '/index.php';
$_SERVER['PHP_SELF']        = '/index.php';
require $root . '/index.php';
return true;
ROUTER
python3 - "$WP/wp-config.php" <<'PY'
import re, sys
p = sys.argv[1]
s = open(p).read()
s = re.sub(r"define\(\s*'DB_NAME'.*?\n", "define( 'DB_NAME', 'wordpress' );\ndefine( 'DB_USER', 'root' ); define( 'DB_PASSWORD', '' ); define( 'DB_HOST', 'localhost' );\n", s, count=1)
s = s.replace("define( 'WP_DEBUG', false );", "")
if True:
    s = s.replace("/* That's all, stop editing!", """define( 'WP_DEBUG', true );
define( 'WP_DEBUG_LOG', '/tmp/wp/debug.log' );
define( 'WP_DEBUG_DISPLAY', false );
define( 'WP_HOME', 'http://localhost:8080' );
define( 'WP_SITEURL', 'http://localhost:8080' );

/* That's all, stop editing!""")
open(p, 'w').write(s)
PY

echo "== 6. clean database + install"
rm -f "$WP/wp-content/database/.ht.sqlite" "$WP/debug.log"
$WPCLI core install --url=http://localhost:8080 --title="Mayfair Properties" \
  --admin_user=owner --admin_password=ownerpass --admin_email=owner@mayfair.test --skip-email >/dev/null
$WPCLI option update permalink_structure '/%postname%/' >/dev/null
$WPCLI option update timezone_string 'Asia/Kolkata' >/dev/null
$WPCLI rewrite structure '/%postname%/' --hard >/dev/null 2>&1 || true

echo "== 7. plugin ($BUILD)"
rm -rf "$WP/wp-content/plugins/estat-os"
if [ "$BUILD" = "released" ]; then
  rm -rf /tmp/base410; mkdir -p /tmp/base410
  python3 -c "
import zipfile, glob
zipfile.ZipFile(sorted(glob.glob('/home/user/Estate_OS-*.zip'))[0]).extractall('/tmp/base410')
"
  cp -r /tmp/base410/estat-os "$WP/wp-content/plugins/"
else
  cp -r /home/user/plugin/estat-os "$WP/wp-content/plugins/"
fi
$WPCLI plugin activate estat-os >/dev/null

echo "== 8. the site agent's own login"
$WPCLI user create siteagent agent@mayfair.test --role=estat_office_agent --user_pass=agentpass >/dev/null 2>&1 || true

echo "== 9. demo data"
$WPCLI eval-file /home/user/tests/audit/seed.php --user=owner 2>&1 | tail -12

echo "== 10. server"
pkill -f "php -d error_reporting" 2>/dev/null || true
sleep 1
cd "$WP" && (setsid php -d error_reporting=E_ALL -d display_errors=0 -S 0.0.0.0:8080 /tmp/wp/router.php >/tmp/wp/server.log 2>&1 &)
sleep 2
curl -s -o /dev/null -w "site: HTTP %{http_code}\n" http://localhost:8080/wp-admin/
echo "ready — owner/ownerpass, $BUILD build, http://localhost:8080"
