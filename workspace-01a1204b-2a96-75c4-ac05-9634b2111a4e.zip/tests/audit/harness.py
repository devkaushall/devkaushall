#!/usr/bin/env python3
"""
The audit harness: a real browser-shaped client for the office and the phone.

Nothing here is a mock — every call is an HTTP request to the running site, and
every answer is read back from the database it actually wrote.

    from harness import Site
    site = Site().login("owner", "ownerpass")
    site.leads()                      # rows straight out of wp_estat_leads
    site.ajax(os_action="save", ...)  # what the office screens post
"""
import http.cookiejar
import json
import os
import re
import sqlite3
import subprocess
import urllib.parse
import urllib.request as U

BASE = "http://localhost:8080"
WP = "/tmp/wp"


def _db_path():
    """Where the SQLite file actually is.

    Newer sqlite-database-integration keeps the database in a hashed sibling
    folder and points at it from db-path.php; a plain open of .ht.sqlite then
    finds an empty file and every table 'disappears'. Follow the pointer."""
    plain = WP + "/wp-content/database/.ht.sqlite"
    try:
        hint = open(WP + "/wp-content/database/db-path.php").read()
        m = re.search(r"return __DIR__ \. '([^']+)'", hint)
        if m:
            cand = os.path.normpath(WP + "/wp-content/database" + m.group(1))
            if os.path.isfile(cand) and os.path.getsize(cand) > 0:
                return cand
    except OSError:
        pass
    return plain


DB = _db_path()
WPCLI = ["php", "/tmp/wpsetup/wp-cli.phar", "--path=" + WP, "--allow-root"]


class NoRedirect(U.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


class Site:
    def __init__(self, base=BASE):
        self.base = base
        self.cj = http.cookiejar.CookieJar()
        self.op = U.build_opener(U.HTTPCookieProcessor(self.cj))
        self.op.addheaders = [("User-Agent", "estat-audit/2.0")]
        self.noredir = U.build_opener(U.HTTPCookieProcessor(self.cj), NoRedirect)
        self.who = "?"

    # ------------------------------------------------------------------ http
    def get(self, path, follow=True):
        url = path if path.startswith("http") else self.base + path
        op = self.op if follow else self.noredir
        try:
            with op.open(url, timeout=60) as r:
                return r.status, r.read().decode("utf-8", "replace"), r.geturl()
        except U.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace"), url

    def post(self, path, data, follow=True):
        url = path if path.startswith("http") else self.base + path
        body = urllib.parse.urlencode(data, doseq=True).encode() if isinstance(data, dict) else data
        op = self.op if follow else self.noredir
        try:
            with op.open(U.Request(url, data=body, method="POST"), timeout=60) as r:
                return r.status, r.read().decode("utf-8", "replace"), r.geturl()
        except U.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace"), url

    def login(self, user="owner", pw="ownerpass"):
        self.get("/wp-login.php")
        s, b, url = self.post("/wp-login.php", {
            "log": user, "pwd": pw, "wp-submit": "Log In",
            "redirect_to": self.base + "/wp-admin/", "testcookie": "1"})
        self.who = user if "wp-admin" in url or "wpadminbar" in b else "?"
        return self

    # --------------------------------------------------------------- screens
    def screen(self, page, query=""):
        return self.get("/wp-admin/admin.php?page=%s%s" % (page, query))[1]

    def ajax_nonce(self):
        body = self.screen("estat-today")
        m = re.search(r'var estatOs = (\{.*?\});', body, re.S)
        return json.loads(m.group(1))["nonce"] if m else None

    def ajax(self, **payload):
        data = {"action": "estat_os_action", "_ajax_nonce": self.ajax_nonce()}
        data.update(payload)
        s, b, _ = self.post("/wp-admin/admin-ajax.php", data)
        try:
            return s, json.loads(b)
        except Exception:
            return s, b[:300]

    def office_form(self, page, action=None):
        """Fields of the single admin-post form on a screen, ready to submit."""
        html = self.screen(page)
        m = re.search(r"<form\b[^>]*>.*?</form>", html, re.S)
        if not m:
            return None
        tag = m.group(0)
        fields = {}
        for f in re.finditer(r"<(input|select|textarea)\b([^>]*)>", tag, re.I):
            a = f.group(2)
            n = re.search(r'name="([^"]*)"', a)
            if not n:
                continue
            t = (re.search(r'type="([^"]*)"', a) or ["", "text"])[1].lower() if re.search(r'type="([^"]*)"', a) else f.group(1).lower()
            if t in ("submit", "button", "file", "image"):
                continue
            v = re.search(r'value="([^"]*)"', a)
            fields[n.group(1)] = v.group(1) if v else ""
        return fields

    def admin_post(self, fields):
        return self.post("/wp-admin/admin-post.php", fields)

    # ------------------------------------------------------------ pocket/eth
    def pocket(self, uri, data=None):
        if data is None:
            return self.get(uri)
        return self.post(uri, data)

    def pocket_nonce(self, uri="/agent/new"):
        body = self.get(uri)[1]
        m = re.search(r'name="estat_nonce" value="([a-f0-9]{10})"', body)
        return m.group(1) if m else None

    def rest(self, path, data=None, nonce=None, method=None):
        url = self.base + "/wp-json/" + path.lstrip("/")
        hdr = {"Content-Type": "application/json"}
        if nonce:
            hdr["X-WP-Nonce"] = nonce
        body = json.dumps(data).encode() if data is not None else None
        req = U.Request(url, data=body, headers=hdr, method=method or ("POST" if body else "GET"))
        try:
            with self.op.open(req, timeout=60) as r:
                return r.status, r.read().decode("utf-8", "replace")
        except U.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace")

    # ------------------------------------------------------------- browser
    @staticmethod
    def browser_login(page, user="owner", pw="ownerpass"):
        """Sign a browser in, and prove it happened.

        Clicking WordPress's own "Log In" button sometimes leaves Chromium on
        an intermediate error document in this sandbox, and a test that trusts
        the click then measures a login page for the rest of its run — which is
        how a round reports "nothing happened" for every button on the site.
        So: click, ask for a real screen, check the menu is there, and if it is
        not, do it again.
        """
        import time
        base = "http://localhost:8080"
        for _ in range(3):
            page.goto(base + "/wp-login.php", wait_until="domcontentloaded")
            page.fill("#user_login", user)
            page.fill("#user_pass", pw)
            try:
                page.click("#wp-submit", timeout=8000)
            except Exception:
                pass
            time.sleep(0.6)
            try:
                page.goto(base + "/wp-admin/admin.php?page=estat-today", wait_until="domcontentloaded", timeout=20000)
            except Exception:
                pass
            time.sleep(0.8)
            signed = page.evaluate("() => !!document.getElementById('adminmenu')")
            if signed:
                return True
        return False

    # ----------------------------------------------------------------- data
    @staticmethod
    def sql(q, fetch=True):
        con = sqlite3.connect(DB)
        try:
            cur = con.execute(q)
            return cur.fetchall() if fetch else None
        finally:
            con.commit()
            con.close()

    @staticmethod
    def reset_rate_limit():
        """Forget this address's submissions, so a test starts from zero."""
        Site.sql("DELETE FROM wp_options WHERE option_name LIKE '%estat_rl_%'", fetch=False)
        Site.sql("DELETE FROM wp_options WHERE option_name LIKE '_transient%estat_rl_%'", fetch=False)

    @staticmethod
    def leads():
        return Site.sql("SELECT id,name,phone,status,source,idempotency_key FROM wp_estat_leads ORDER BY id")

    @staticmethod
    def submissions():
        return Site.sql("SELECT id,form_id,lead_id,idempotency_key FROM wp_estat_submissions ORDER BY id")

    @staticmethod
    def visits():
        return Site.sql("SELECT id,lead_id,listing_id,outcome,dedupe_hash FROM wp_estat_visits ORDER BY id")

    @staticmethod
    def posts(type_="estat_listing"):
        return Site.sql(
            "SELECT p.ID, p.post_title, p.post_status FROM wp_posts p "
            "WHERE p.post_type='%s' AND p.post_status NOT IN ('trash','auto-draft') ORDER BY p.ID" % type_)

    @staticmethod
    def wp(code):
        r = subprocess.run(WPCLI + ["eval", code], capture_output=True, text=True)
        out = (r.stdout or r.stderr or "").strip().splitlines()
        return "\n".join(out[-6:]) if out else ""

    @staticmethod
    def log_mark():
        try:
            return len(open(WP + "/debug.log", "rb").read())
        except FileNotFoundError:
            return 0

    @staticmethod
    def log_since(mark):
        try:
            data = open(WP + "/debug.log", "rb").read()[mark:].decode("utf-8", "replace")
        except FileNotFoundError:
            return ""
        bad = [l for l in data.splitlines()
               if ("Fatal" in l or "Warning" in l or "Deprecated" in l or "Notice" in l) and "wp-cli" not in l]
        return "\n".join(bad[:10])

    # ------------------------------------------------------------------ misc
    @staticmethod
    def notices(body):
        """The office's own messages at the top of a screen."""
        return [re.sub(r"<[^>]+>", "", m).strip() for m in
                re.findall(r'class="notice[^"]*"[^>]*>(.*?)</div>', body, re.S)][:4]


RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append((bool(ok), name, detail))
    print(("  PASS  " if ok else "  FAIL  ") + name + ((" — " + str(detail)[:220]) if detail else ""))
    return ok


def summary(title="round"):
    ok = sum(1 for r in RESULTS if r[0])
    bad = len(RESULTS) - ok
    print("\n== %s: %d checks, %d failed" % (title, len(RESULTS), bad))
    for good, name, detail in RESULTS:
        if not good:
            print("   FAILED:", name, "|", str(detail)[:200])
    return bad
