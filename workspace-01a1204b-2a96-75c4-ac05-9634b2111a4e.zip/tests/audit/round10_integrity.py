#!/usr/bin/env python3
"""Round 10 — the data, after everything the other rounds did to it.

The other rounds press buttons, post forms and feed nonsense. This one reads
what is left in the database and asks the questions the product promises the
answers to: every enquiry can be saved (so no key is empty), every submission
points at an enquiry that exists, every stored state is a word the office
knows, and nothing hostile is sitting in a field that gets drawn.

It is a different method from the others on purpose: they check behaviour,
this checks the state behaviour left behind. A silent loss — a record written
half-way, a link to something deleted, a value outside the vocabulary — shows
up here and nowhere else.
"""

import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from harness import Site, check, summary  # noqa: E402


def main():
    before = Site.log_mark()

    print("A. Every record can be identified")
    # NULL is the honest value for an enquiry nobody gave a key to, and the
    # UNIQUE index allows many of them. An empty string is the value that can
    # exist only once — that is the shape the lost-enquiry bug had.
    empty_keys = Site.sql("SELECT COUNT(*) FROM wp_estat_leads WHERE idempotency_key = ''")
    check("no enquiry holds an empty-string key", int(empty_keys[0][0]) == 0, empty_keys)
    dupes = Site.sql("SELECT idempotency_key, COUNT(*) c FROM wp_estat_leads "
                     "WHERE idempotency_key IS NOT NULL GROUP BY idempotency_key HAVING c > 1")
    check("no two enquiries share a key", not dupes, dupes)
    dup_visits = Site.sql("SELECT dedupe_hash, COUNT(*) c FROM wp_estat_visits GROUP BY dedupe_hash HAVING c > 1")
    check("no two visits share a dedupe stamp", not dup_visits, dup_visits)

    print("\nB. Nothing points at something that is gone")
    orphans = Site.sql(
        "SELECT COUNT(*) FROM wp_estat_submissions s "
        "WHERE s.lead_id > 0 AND NOT EXISTS ( SELECT 1 FROM wp_estat_leads l WHERE l.id = s.lead_id )")
    check("every submission points at an enquiry that exists", int(orphans[0][0]) == 0, orphans)
    ghost_events = Site.sql(
        "SELECT COUNT(*) FROM wp_estat_lead_events e "
        "WHERE NOT EXISTS ( SELECT 1 FROM wp_estat_leads l WHERE l.id = e.lead_id )")
    check("every history entry points at an enquiry that exists", int(ghost_events[0][0]) == 0, ghost_events)
    ghost_visits = Site.sql(
        "SELECT COUNT(*) FROM wp_estat_visits v "
        "WHERE v.lead_id > 0 AND NOT EXISTS ( SELECT 1 FROM wp_estat_leads l WHERE l.id = v.lead_id )")
    check("every visit points at an enquiry that exists", int(ghost_visits[0][0]) == 0, ghost_visits)

    print("\nC. Every stored state is a word the office knows")
    words = Site.wp('echo implode(",", array_keys( \\EstatOS\\Support\\Vocabulary::visit_outcomes() ));').strip().splitlines()[-1]
    ids = Site.sql("SELECT DISTINCT outcome FROM wp_estat_visits")
    bad = [r[0] for r in ids if r[0] not in words.split(",")]
    check("every visit carries one of the office's outcomes", not bad, (bad, words))

    request_words = Site.wp('echo implode(",", array_keys( \\EstatOS\\Support\\Vocabulary::request_states() ));').strip().splitlines()[-1]
    states = Site.sql("SELECT DISTINCT status FROM wp_estat_requests")
    bad = [r[0] for r in states if r[0] not in request_words.split(",")]
    check("every change request carries one of its own states", not bad, (bad, request_words))

    lead_words = Site.wp('echo implode(",", array_keys( \\EstatOS\\Support\\Vocabulary::lead_statuses() ));').strip().splitlines()[-1]
    statuses = Site.sql("SELECT DISTINCT status FROM wp_estat_leads")
    bad = [r[0] for r in statuses if r[0] not in lead_words.split(",")]
    check("every enquiry carries one of the office's stages", not bad, (bad, lead_words))

    print("\nD. What the product itself stores")
    # The screens are proved to escape a hostile value in round 6. What belongs
    # here is the other half: a value that arrives through the product's own
    # door must be stored as text, not as markup with its own opinions.
    import json as _json
    import time as _time

    Site.reset_rate_limit()
    anon = Site()
    page = None
    for _pid, slug in Site.sql("SELECT ID, post_name FROM wp_posts WHERE post_type='page' AND post_status='publish'"):
        if "enquiry" in slug or "palette" in slug:
            page = slug
    if page:
        import re as _re
        html = anon.get("/" + page + "/")[1]
        fields = dict(_re.findall(r'name="(estat_nonce|estat_ts|estat_sig|idempotency_key)"[^>]*value="([^"]*)"', html))
        endpoint = _re.search(r'data-endpoint="([^"]+)"', html).group(1).split("/wp-json/", 1)[-1]
        _time.sleep(1.2)
        anon.rest(endpoint, dict(fields, page_url=anon.base + "/" + page + "/",
                                 fields={"name": "Integrity Probe", "phone": "+919800009999",
                                         "message": "<b>bold</b> and <img src=x onerror=alert(1)>"}))
        stored = Site.sql("SELECT name, message FROM wp_estat_leads WHERE phone = '+919800009999' ORDER BY id DESC LIMIT 1")
        sent = Site.sql("SELECT payload FROM wp_estat_submissions WHERE payload LIKE '%Integrity Probe%' ORDER BY id DESC LIMIT 1")
        blob = _json.dumps(stored) + _json.dumps(sent)
        check("an enquiry that arrives with a tag is stored without one",
              bool(stored) and bool(sent) and "<" not in blob, blob[:160])

    print("\nE. The forms the office saves are usable")
    forms_before = Site.sql("SELECT COUNT(*) FROM wp_estat_forms WHERE definition LIKE '%\"fields\":[]%' OR definition LIKE '%steps\":[]%'")
    owner = Site().login("owner", "ownerpass")
    s2, res2 = owner.ajax(os_action="save", what="form", id="0", definition='{"steps": []}')
    after = Site.sql("SELECT COUNT(*) FROM wp_estat_forms WHERE definition LIKE '%\"fields\":[]%' OR definition LIKE '%steps\":[]%'")
    check("the office cannot save a form that asks nothing",
          s2 == 422 and int(after[0][0]) == int(forms_before[0][0]), (s2, str(res2)[:120], forms_before, after))

    print("\nF. PHP notices")
    log = [l for l in Site.log_since(before) if "Fatal" in l or "Warning" in l or "Notice" in l]
    check("reading all of this raised nothing", not log, log[:3])

    return summary("round 10 — what the data says")


if __name__ == "__main__":
    main()
