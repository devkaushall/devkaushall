#!/usr/bin/env python3
"""Analysis 5 — the data contract.

A plugin this size keeps its promises in names: option keys, post meta keys,
AJAX actions. Every one of them is written in one file and read in another, and
nothing in PHP complains when the two disagree — the read simply returns
nothing, for ever, and the screen that shows it looks empty rather than broken.

Three lists, each a door that only opens one way:

  1. Post meta written by the plugin and read by nobody (dead weight), and —
     the damaging direction — **read and never written** (a screen that can
     never show anything).
  2. Settings keys: the same question for the settings array.
  3. AJAX actions: registered in PHP but never called by any script, and
     called by a script but not registered. (A silent `0` reply from
     admin-ajax is the classic "nothing happens when I press it".)

Run: python3 /home/user/tests/data_contract_check.py
"""

import os
import re
import sys
from collections import defaultdict

ROOT = '/home/user/plugin/estat-os'
PHP, JS = [], []
for base, dirs, files in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in {'.git', 'node_modules'}]
    for name in files:
        path = os.path.join(base, name)
        if name.endswith('.php'):
            PHP.append(path)
        elif name.endswith('.js'):
            JS.append(path)

php_text = '\n'.join(open(p, encoding='utf-8', errors='replace').read() for p in PHP)
js_text = '\n'.join(open(p, encoding='utf-8', errors='replace').read() for p in JS)


def strip_comments(text):
    text = re.sub(r'/\*.*?\*/', ' ', text, flags=re.S)
    return re.sub(r'^\s*//.*$', ' ', text, flags=re.M)


php_code = strip_comments(php_text)
js_code = strip_comments(js_text)

print('Analysis 5 — the data contract\n')

# ------------------------------------------------------------- 1. post meta
written = defaultdict(set)
read = defaultdict(set)
for path in PHP:
    text = strip_comments(open(path, encoding='utf-8', errors='replace').read())
    name = os.path.basename(path)
    for m in re.finditer(r"(?:update|add)_post_meta\(\s*[^,]+,\s*'(_estat_[a-z0-9_]+|estat_[a-z0-9_]+)'", text):
        written[m.group(1)].add(name)
    for m in re.finditer(r"get_post_meta\(\s*[^,]+,\s*'(_estat_[a-z0-9_]+|estat_[a-z0-9_]+)'", text):
        read[m.group(1)].add(name)
    for m in re.finditer(r"Meta::(?:set|save|write)\(\s*[^,]+,\s*'([a-z0-9_]+)'", text):
        written['_estat_' + m.group(1)].add(name)
    for m in re.finditer(r"Meta::(?:get|read)\(\s*[^,]+,\s*'([a-z0-9_]+)'", text):
        read['_estat_' + m.group(1)].add(name)

never_written = {k: v for k, v in read.items() if k not in written}
never_read = {k: v for k, v in written.items() if k not in read}

# Informational, not findings: most of these are written through a helper
# (`update_post_meta( $id, $key, $value )` with the key in a variable), which
# this pass cannot follow. They are listed so a person can spot-check, not as
# a list of bugs.
print('1a. Post meta read but not written by a literal key — needs a human eye (%d):'
      % len(never_written))
for k, where in sorted(never_written.items()):
    print('     %-30s read in %s' % (k, ', '.join(sorted(where))))
if not never_written:
    print('     none')

print('\n1b. Post meta written and never read — collected and never shown (%d):'
      % len(never_read))
for k, where in sorted(never_read.items()):
    print('     %-30s written in %s' % (k, ', '.join(sorted(where))))
if not never_read:
    print('     none')

# ------------------------------------------------------------- 2. settings
defaults = re.search(r'function defaults\(\): array \{(.*?)\n\t\}',
                     open(os.path.join(ROOT, 'includes/Settings/Settings.php'),
                          encoding='utf-8').read(), re.S)
keys = set(re.findall(r"'([a-z0-9_]+)'\s*=>", defaults.group(1))) if defaults else set()

get_keys, set_keys = defaultdict(set), defaultdict(set)
for path in PHP:
    text = strip_comments(open(path, encoding='utf-8', errors='replace').read())
    name = os.path.basename(path)
    for m in re.finditer(r"Settings::get\(\s*'([a-z0-9_]+)'", text):
        get_keys[m.group(1)].add(name)
    for m in re.finditer(r"Settings::update\(\s*array\(\s*'([a-z0-9_]+)'", text):
        set_keys[m.group(1)].add(name)
    for m in re.finditer(r"\$out\['([a-z0-9_]+)'\]", text):
        set_keys[m.group(1)].add(name)
    for m in re.finditer(r"update_option\(\s*'estat_([a-z0-9_]+)'", text):
        set_keys[m.group(1)].add(name)

settings_never_saved = {k: v for k, v in get_keys.items() if k not in keys and k not in set_keys}
print('\n2a. Settings read but in neither defaults nor any save — always empty (%d):'
      % len(settings_never_saved))
for k, where in sorted(settings_never_saved.items()):
    print('     %-28s read in %s' % (k, ', '.join(sorted(where))))
if not settings_never_saved:
    print('     none')

settings_never_read = {k: v for k, v in set_keys.items() if k not in get_keys and k not in keys}
print('\n2b. Settings saved but never read anywhere (%d):' % len(settings_never_read))
for k, where in sorted(settings_never_read.items()):
    print('     %-28s saved in %s' % (k, ', '.join(sorted(where))))
if not settings_never_read:
    print('     none')

# ------------------------------------------------------------- 3. ajax
registered = set()
for path in PHP:
    text = strip_comments(open(path, encoding='utf-8', errors='replace').read())
    registered |= set(re.findall(r"add_action\(\s*'wp_ajax(?:_nopriv)?_([a-z0-9_]+)'", text))
    registered |= set(re.findall(r"'(estat_os_[a-z]+)'\s*=>\s*'[a-z]+',", text))

called = set()
for path in JS:
    text = strip_comments(open(path, encoding='utf-8', errors='replace').read())
    called |= set(re.findall(r"action['\"]?\s*[:=]\s*['\"]([a-z0-9_]+)['\"]", text))
    called |= set(re.findall(r"body\.append\(\s*'action',\s*'([a-z0-9_]+)'", text))
    called |= set(re.findall(r"'(estat_os_[a-z]+)'", text))

dead_handlers = sorted(a for a in registered if a not in called and a.startswith('estat'))
orphan_calls = sorted(a for a in called if a.startswith('estat') and a not in registered)

print('\n3a. An AJAX action registered in PHP and called by no script (%d):' % len(dead_handlers))
for a in dead_handlers:
    print('     %s' % a)
if not dead_handlers:
    print('     none')

print('\n3b. An AJAX action a script calls that PHP does not register (%d):' % len(orphan_calls))
for a in orphan_calls:
    print('     %s' % a)
if not orphan_calls:
    print('     none')

total = (len(settings_never_saved) + len(orphan_calls))
print('\n%s' % ('%d FINDINGS (the other lists are information)' % total if total else 'NO FINDINGS'))
sys.exit(0)
