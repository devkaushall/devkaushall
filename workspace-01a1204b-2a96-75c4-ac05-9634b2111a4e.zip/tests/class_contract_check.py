#!/usr/bin/env python3
"""Analysis 1 — the class contract.

The bug that reached the live site on 2026-10-07 was not a wrong value in a
stylesheet. It was a **name**: the PHP wrote `is-quick`, the CSS asked for
`estat-pocket-block--quick`, and nothing joined the two. The page looked
finished to every test we had, because the tests measured a preview file whose
class names were written by hand — and the hand matched the CSS instead of the
PHP.

So this check joins them mechanically, in both directions:

  * every class the CSS targets must be written somewhere in PHP or JS;
  * every class the PHP writes must be either targeted by the CSS or known to
    be a hook (data-* style) that nothing styles.

It reads the real files. A class that is only in the preview is reported
separately, because the preview existing only for the preview is how the
fiction started.

Run: python3 /home/user/tests/class_contract_check.py
"""

import os
import re
import sys
from collections import defaultdict

ROOT = '/home/user/plugin/estat-os'
PREVIEWS = ['/home/user/preview-pocket.html', '/home/user/preview-admin.html']

# Classes that legitimately carry no CSS in this plugin.
IGNORE_CLASSES = {
    # WordPress's own screen classes, drawn by wp-admin.
    'wp-admin', 'admin-bar', 'wp-toolbar', 'wp-core-ui',
    # Accessibility helpers that exist to be ignored.
    'screen-reader-text',
    # Everything the preview builder puts on the page itself.
    'pkscreen', 'pktoasts', 'pktoast', 'pk-dark', 'chip', 'chips', 'bar-ctl',
    'preview-tabs', 'wp-preview',
}


def read(path):
    try:
        with open(path, encoding='utf-8', errors='replace') as handle:
            return handle.read()
    except OSError:
        return ''


def walk(exts):
    for base, dirs, files in os.walk(ROOT):
        dirs[:] = [d for d in dirs if d not in {'.git', 'node_modules'}]
        for name in files:
            if name.endswith(exts):
                yield os.path.join(base, name)


CLASS_TOKEN = re.compile(r'\.(-?[_a-zA-Z][_a-zA-Z0-9-]*)')

PHP_CLASS_ATTR = re.compile(r'class\s*=\s*"([^"]*)"|class\s*=\s*\'([^\']*)\'')
# A class written as a bare string, or as the head of a concatenation:
# 'estat-icon ' . $class, "estat-pocket-block is-quick", 'estat-menu-count%3$s'
QUOTED_WORDS = re.compile(r"['\"]([^'\"\n]{2,80})['\"]")


def _tokens(chunk):
    """Class names out of a fragment that may hold PHP, formats and spaces."""
    chunk = re.sub(r'<\?php.*?\?>', ' ', chunk, flags=re.S)   # inline PHP
    chunk = re.sub(r'<\?=.*?\?>', ' ', chunk, flags=re.S)
    chunk = re.sub(r'%[0-9]*\$?[a-zA-Z]', ' ', chunk)          # printf placeholders
    chunk = re.sub(r'\{[^}]*\}', ' ', chunk)                   # {curly}
    chunk = re.sub(r'[$,;:+()|\[\]]', ' ', chunk)
    chunk = chunk.replace("'", ' ').replace('"', ' ').replace('\\n', ' ')
    out = set()
    for token in chunk.split():
        token = token.strip('.')
        if not token or len(token) > 60:
            continue
        # A class name: at least one letter, no spaces, no dots inside.
        if not re.fullmatch(r'[a-zA-Z][a-zA-Z0-9_-]*', token):
            continue
        if '-' not in token and token not in ('anim', 'hidden', 'is-on', 'clearfix'):
            continue
        out.add(token)
    return out


# Ways JavaScript writes a class: className="x", class="x",
# classList.add('x'), setAttribute('class', 'x').
JS_CLASS_WRITE = re.compile(
    r'''class(?:Name)?\s*=\s*[\'"]([^\'"]+)[\'"]'''
    r'''|classList\s*\.\s*(?:add|remove|toggle)\s*\(([^)]*)\)'''
    r'''|setAttribute\s*\(\s*[\'"]class[\'"]\s*,\s*[\'"]([^\'"]+)[\'"]'''
)


def classes_in_html(text):
    out = set()
    # A class written from JavaScript inside a PHP string:
    #   . 'var main=document.createElement("div");main.className="estat-q-main";'
    # The quote-pair scan further down cannot see this one — the PHP string's
    # own single quote pairs with the first double quote and swallows the
    # class name — which is how four live rules came to look like dead code.
    # So class writes are read directly.
    for m in JS_CLASS_WRITE.finditer(text):
        chunk = m.group(1) or m.group(2) or m.group(3) or ''
        chunk = re.sub(r"['\"]", ' ', chunk)
        out |= _tokens(chunk)
    # An id is not a class: asked for by name elsewhere, chosen by the browser.
    for attr in ('id', 'for', 'name', 'href', 'action', 'value'):
        text = re.sub(r'\b%s\s*=\s*"[^"]*"' % attr, ' ', text)
        text = re.sub(r"\b%s\s*=\s*'[^']*'" % attr, ' ', text)
    for m in PHP_CLASS_ATTR.finditer(text):
        out |= _tokens(m.group(1) or m.group(2) or '')
    # Classes handed to a helper: Icon::render('roof', 'estat-icon big')
    for m in QUOTED_WORDS.finditer(text):
        word = m.group(1).strip()
        if ' ' in word or '-' in word:
            out |= _tokens(word)
    return out


def classes_in_css(text):
    """Every class a selector targets, with the file's own comments stripped."""
    text = re.sub(r'/\*.*?\*/', ' ', text, flags=re.S)
    out = set()
    # Only look at selector text, not declaration bodies.
    for block in re.finditer(r'([^{}]+)\{[^{}]*\}', text):
        selector = block.group(1)
        if selector.strip().startswith('@'):
            continue
        for token in CLASS_TOKEN.findall(selector):
            out.add(token)
    return out


def main():
    php_text, js_text = [], []
    for path in walk(('.php',)):
        php_text.append(read(path))
    for path in walk(('.js',)):
        js_text.append(read(path))
    php_all = '\n'.join(php_text)
    js_all = '\n'.join(js_text)
    anywhere = php_all + '\n' + js_all

    php_classes = classes_in_html(php_all)

    css_classes = defaultdict(set)
    for path in walk(('.css',)):
        for token in classes_in_css(read(path)):
            css_classes[token].add(os.path.basename(path))

    js_classes = classes_in_html(js_all)

    preview_classes = set()
    for path in PREVIEWS:
        preview_classes |= classes_in_html(read(path))

    written = php_classes | js_classes

    dead = sorted(c for c in css_classes
                  if c not in written and c not in IGNORE_CLASSES
                  and (c.startswith('estat-') or c.endswith(('is-on', 'is-wide', 'has-logo'))))

    preview_only = sorted(c for c in preview_classes
                          if c.startswith('estat-') and c not in written)

    # Classes the PHP hangs layout on but the CSS never mentions: the shape of
    # today's bug, caught from the other side.
    unstyled = sorted(c for c in php_classes
                      if c.startswith('estat-') and c not in css_classes
                      and c not in IGNORE_CLASSES)

    # The app's own screens: every class written there SHOULD be styled by the
    # app's own stylesheet, and every class styled there SHOULD be written.
    app_written = set()
    for base, dirs, files in os.walk(ROOT):
        if not (base.endswith('/includes/Pocket') or base.endswith('/includes/Admin/Os')
                or base.endswith('/includes/Admin/Os/Screens')):
            continue
        for name in files:
            if name.endswith('.php'):
                app_written |= classes_in_html(read(os.path.join(base, name)))

    app_css = {}
    for name in ('pocket.css', 'admin-os.css'):
        for token in classes_in_css(read(os.path.join(ROOT, 'assets/css', name))):
            app_css.setdefault(token, set()).add(name)

    print('PHP/JS classes: %d   CSS classes: %d   preview-only: %d\n'
          % (len(written), len(css_classes), len(preview_only)))

    print('0a. a class the APP writes that its own stylesheet never styles (%d):'
          % len([c for c in app_written if c.startswith('estat-') and c not in app_css]))
    for c in sorted(c for c in app_written if c.startswith('estat-') and c not in app_css):
        print('     %s' % c)

    print('\n0b. a class the APP stylesheets target that nothing anywhere writes (%d):'
          % len([c for c in app_css if c.startswith('estat-') and c not in written]))
    for c in sorted(c for c in app_css if c.startswith('estat-') and c not in written):
        print('     .%-40s %s' % (c, ','.join(sorted(app_css[c]))))
    print()

    ours = [c for c in dead if not css_classes[c] <= {'public.css', 'forms.css'}]
    theirs = [c for c in dead if css_classes[c] <= {'public.css', 'forms.css'}]
    print('1a. CSS for OUR screens that targets a class nothing writes (%d)'
          ' — a rule that never runs:' % len(ours))
    for c in ours:
        print('     .%-42s %s' % (c, ', '.join(sorted(css_classes[c]))))
    if not ours:
        print('     none')
    print('\n1b. CSS for the public site with no plugin markup (%d) — expected:'
          ' these are for templates the office builds in Elementor.' % len(theirs))
    for c in theirs[:8]:
        print('     .%s' % c)
    if len(theirs) > 8:
        print('     … and %d more' % (len(theirs) - 8))

    print('\n2. The preview invents a class the plugin never writes (%d):' % len(preview_only))
    for c in preview_only:
        print('     %s' % c)
    if not preview_only:
        print('     none')

    print('\n3. The plugin writes a class nothing styles (%d) — the shape of the'
          ' bento bug:' % len(unstyled))
    for c in unstyled:
        print('     %s' % c)
    if not unstyled:
        print('     none')

    return 1 if (dead or preview_only) else 0


if __name__ == '__main__':
    sys.exit(main())
