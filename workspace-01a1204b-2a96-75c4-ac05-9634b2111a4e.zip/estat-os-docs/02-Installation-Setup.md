# 02 — Installation, Setup & First-Run Configuration

## Simple meaning (Hinglish)

Plugin install karna 5 minute ka kaam hai: Plugins → Add New → Upload → ZIP chuno → Install → Activate. Activate hote hi plugin apni tables bana leta hai aur aapko **Setup** screen le jaata hai. Wahin par office ka naam, phone, shehar aur website ke pages set karne hote hain. Ye sab ho jaaye to property add karna shuru kar sakte hain.

---

## 1. Before you start

| Check | How to check | If it fails |
|---|---|---|
| PHP ≥ 7.4 | WordPress → Tools → Site Health → Info → Server | Ask the host to upgrade |
| WordPress ≥ 6.0 | Dashboard → Updates | Update WordPress |
| InnoDB with utf8mb4 | Site Health → Database | Ask the host |
| Uploads directory writable | Settings → Media shows a path | Fix file permissions |
| A working mail sender | Settings → General, or an SMTP plugin | Enquiry emails will silently fail |
| Permalinks not "Plain" | Settings → Permalinks | Property pages will 404 |

**Nothing is required beyond this.** No Elementor, no ACF, no Composer, no external API key.

---

## 2. Install

### From a ZIP file (the normal way)

1. WordPress admin → **Plugins → Add New → Upload Plugin**.
2. Choose `Estate_OS-3.6.6.zip`.
3. Press **Install Now**.
4. Press **Activate Plugin**.

### From the WordPress.org directory

Plugins → Add New → search **Estat.OS** → Install → Activate.

### From the filesystem

```
wp-content/plugins/estat-os/
```

Contents must be the plugin root: `estat-os.php` directly inside `estat-os/`, **not** inside a second nested folder.

---

## 3. What activation actually does

`Install\Activator::activate()` runs, in this exact order:

1. `Schema::install()` — `dbDelta()` over all **14** tables. Idempotent: safe on every activation.
2. `Roles::install()` — creates `estat_office_owner` and `estat_office_agent`, grants the full capability set to `administrator`. Idempotent.
3. Registers post types and taxonomies so rewrite rules exist when flushed.
4. **Does not** seed taxonomy terms (deliberate — see note below).
5. Adds the `estat_settings` option **only if it is missing** — an existing office's configuration is never overwritten by an upgrade.
6. `Forms::seed()` — creates the starter enquiry form if none exists.
7. `Scheduler::schedule()` — registers the three cron jobs.
8. **Does not** publish pages. Pages are created as **drafts** and published by you (see §5).
9. Purges every known page cache.
10. On a genuinely fresh install (no `estat_installed_at` option) sets `estat_show_setup = 1`, which is what lands you on the welcome screen.
11. Writes `estat_db_version` (12) and `estat_version` (3.6.6).
12. `flush_rewrite_rules()`.

> **Why no auto-seeding and no auto-publishing?** An upgrade must never surprise a running office. Terms you did not ask for and pages suddenly appearing on a live site are two of the most common "the plugin broke my website" complaints. Both are now manual, and both live behind one button.

### After activation, verify

```
/wp-json/estat/v1/health
```

Expected: `{"ok":true,"version":"3.6.6"}`. This endpoint is public on purpose — it is the single fastest way to confirm the plugin is alive after any deployment.

---

## 4. The Setup screen

`Admin\Screens\SetupScreen`, reached automatically on a fresh install or from **Estat.OS → Finish setup**.

It runs (`Admin\Actions::run_setup()`) as one guided pass:

1. **Office identity** — office name, tagline, contact person, phone, WhatsApp, email, address, office hours, logo.
2. **Where you work** — city (or cities), the currency and price format.
3. **Your team** — add at least one team member, because every enquiry can be assigned to somebody.
4. **Website pages** — review the 14 pages the plugin can create and press one button.
5. **First property** — optional; adding one now means the website is not empty.

Skipping is allowed (`skip_setup()`); the setup notice can be dismissed and the screen re-opened any time.

---

## 5. Creating the website pages

`Frontend\Pages` defines **14** public pages. Two paths create them:

| Path | Where | Result |
|---|---|---|
| **Settings → Pages → Create pages** | Office Settings | Creates the pages as **drafts** |
| **Setup screen** | Finish setup | Same, with explanations |

They are **drafts first** so that nothing appears on a live site without review. Review each draft, then publish the ones you want.

| Slug | Title | Contains |
|---|---|---|
| `properties` | Properties | `[estat_search][estat_properties]` |
| `search` | Search Properties | `[estat_search]` |
| `projects` | Projects | `[estat_projects]` |
| `projects-by-stage` | Projects by Stage | `[estat_projects_by_stage]` |
| `team` | Our team | `[estat_team]` |
| `localities` | Localities | `[estat_email]`/locality listing |
| `locality-map` | Locality Map | `[estat_locality_map]` |
| `amenities` | Amenities | `[estat_amenities]` |
| `features` | Features | `[estat_features]` |
| `favorites` | Saved Properties | `[estat_favorites]` |
| `compare` | Compare Properties | `[estat_compare]` |
| `emi` | EMI Calculator | `[estat_emi]` |
| `alerts` | Search Alerts | `[estat_alerts]` |
| `contact` | Contact us | `[estat_form]` |

`Install\Pages::existing()` re-checks stored IDs on every read and **silently drops** any page you have deleted, so a stale ID can never send a visitor to a 404.

If a page is missing later: **Office Settings → Advanced → Recreate pages**, or run **Repair data**.

---

## 6. Post-install checklist

Work through this once; it takes about twenty minutes.

- [ ] `/wp-json/estat/v1/health` returns `ok`.
- [ ] **Settings → General** — office name, phone, WhatsApp, email, address, logo, city, currency.
- [ ] **Settings → Listings & workflow** — verification mode, expiry days, completeness threshold.
- [ ] **Settings → Leads & enquiries** — notification email, from-name, from-address, consent text.
- [ ] **Settings → Integrations** — Google Maps key (optional), webhook (optional).
- [ ] **Settings → Pages** — create pages, then publish the ones you want.
- [ ] **Team** — add every agent; give each one a WordPress user so Pocket login works.
- [ ] **Societies / Projects** — add the projects you sell.
- [ ] **Properties** — add one property by hand and check it on the website before importing hundreds.
- [ ] **Website forms** — open the seeded form, confirm it looks right, submit a test enquiry.
- [ ] Confirm the test enquiry arrived **and** the notification email arrived.
- [ ] **Settings → Permalinks → Save** once, to flush rewrite rules.

---

## 7. Elementor users only

1. Install and activate Elementor (free or Pro).
2. `Integrations\Elementor\Bridge` detects it and registers a widget category **Estat.OS** plus **19 widgets**.
3. Build your Properties page in Elementor and drop in **Property Search** + **Property Directory**.
4. Leave **Settings → Integrations → "Elementor forms to enquiries"** on if you want Elementor's native form submissions to flow into Enquiries.
5. If you build an Elementor **Theme Builder** single template for listings, the plugin detects it (`Bridge::has_template('single')`) and steps back so your design wins.

The plugin ships a defensive guard for a known Elementor Pro crash: `Taxonomies::guard_get_the_terms()` intercepts `get_the_terms` and returns `[]` instead of a `WP_Error`, because Elementor Pro calls `wp_kses_post( WP_Error )` and fatals. Taxonomies also register twice — on `init` priority **0** and on `elementor/init` — so they always exist before Elementor asks.

---

## 8. Multisite

- **Network-activate is supported.** Each site keeps its own `estat_settings`, its own 14 tables (prefixed per site) and its own content.
- Roles and capabilities are installed **per site** on activation of that site.
- `uninstall.php` loops over every site on the network when erasure is opted in.
- There is **no** global network settings screen by design; each office configures its own site.

---

## 9. Deactivation and uninstall

| Action | What is kept |
|---|---|
| **Deactivate** | Everything. Cron is unscheduled (`Scheduler::unschedule()`), nothing is deleted. |
| **Delete** (default) | Everything. `uninstall.php` returns immediately unless you opted in. |
| **Delete** with *"erase my data"* ticked | All 14 tables dropped, all 6 post types and their meta deleted, all 5 taxonomies' terms deleted, both roles removed, all options removed. |

The switch lives in **Office Settings → Advanced → Delete all data on uninstall** (`delete_data_on_uninstall`, default `false`).

> Before deleting, always **Import & export → Export** your listings and leads. There is no undo.

---

## 10. Troubleshooting installation

| Symptom | Cause | Fix |
|---|---|---|
| "needs PHP 7.4 or newer" notice | Host too old | Upgrade PHP, then activate again |
| White screen right after activate | PHP fatal in a must-use plugin or theme | Check `wp-content/debug.log` |
| `/wp-json/estat/v1/health` 404 | Permalinks are "Plain" | Settings → Permalinks → Save |
| Property page 404s | Rewrite rules stale | Settings → Permalinks → Save |
| Setup screen never appears | `estat_installed_at` already set | Go to Estat.OS → Finish setup manually |
| Pages created but blank | Drafts not published | Pages → publish them |
| Tables missing after a host migration | `dbDelta` blocked or partial | Deactivate, activate, then check **Advanced → Repair data** |
| Enquiry email never arrives | No mail sender on the server | Install an SMTP plugin; test with **Settings → Send test email** |
