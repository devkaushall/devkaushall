# 07 — Listings, Projects, Team, Gallery & Insights Workflows

## Simple meaning (Hinglish)

Is chapter mein chaar screens hain: **Properties**, **Societies/Projects**, **Team**, aur **Gallery**. Kaunsi cheez kahan milti hai aur uske saath roz kya karna hai — yahi likha hai.

---

## 1. Properties screen

`Admin\Screens\ListingsNew`

### Layout
- **Three metric tiles** — how many properties, how many live, how many need attention.
- **Toolbar** — search, filter by status / type / locality / agent, bulk-select.
- **Table** — cover thumbnail, headline, reference, locality, type, price, status, days listed, completeness.
- **Pagination** — horizontal, with counts.

### The status column (fixed words)
| Stored | Shown as |
|---|---|
| `draft` | Draft |
| `pending` | Waiting for approval |
| `publish` | Live |
| `private` | Paused |
| `future` | Scheduled |
| `trash` | In bin |

### Row actions
`Partials::record_actions()` — Edit, Duplicate check, Move to bin, plus status moves. `Partials::move_to_bin_button()` carries a confirmation panel; `Partials::bin_row_actions()` handles the two bin-only actions.

### Bulk operations
`Admin\Actions::bulk_operations()` publishes the legal set:
- Move to bin · Restore · Delete permanently
- Publish · Pause · Draft
- Mark verified · Unmark verified
- Mark featured · Unmark
- Mark available · Under offer · Sold · Rented
- Assign to agent · Change locality
- Rebuild index · Export selected

Every bulk action writes an undo token (`Data\Bin::remember_undo()`), so the whole batch is reversible from the banner that appears afterwards.

### The advanced editor
`ListingsScreen::editor()` organises ~40 fields into **three chapters**:
1. **The basics** — identity, location, what it is.
2. **The numbers** — price, rent, area, rooms, floor.
3. **The rest** — media, highlights, SEO, ownership, advanced.

Extras sit behind a collapsible panel (`Partials::extras_open()`), which stays open if any field inside it has content (`Partials::has_content()`) — so you never lose a filled-in field behind a closed panel.

### Completeness
`Data\Listings::completeness()` returns a percentage and a list of what is missing. `Data\Health::of()` adds rule-level findings:

| Level | Rule |
|---|---|
| high | No sale/rent chosen · no property type · no locality · no price · size empty · no bedroom count · name disagrees with bedroom count · not one photo |
| medium | Description very short · availability not filled in |
| low | Everything else worth a nudge |

Below the threshold the property appears in **attention** but is **not blocked** from publishing.

---

## 2. Societies & Projects screen

`Admin\Screens\ProjectsScreen`

### Layout
Full width · three metric tiles · an **18-field form in 7 two-column groups** · a **6-column table** · horizontal pagination.

### The 18 fields
| Group | Fields |
|---|---|
| Identity | Name, Slug, Builder/Developer |
| Where | Locality, Address, City |
| What | Category, Unit types |
| Stage | Project status, Possession date |
| Money | Price min, Price max, Price unit, Currency |
| Units | Total units, Available units |
| Compliance | Registration number |

### Categories (fixed)
`residential`, `commercial`, `affordable`, `mixed`, `other`

### Stages (fixed)
`ready`, `construction`, `new_launch`, `completed`

### How projects and properties connect
A property holds `project_id`. `Data\Projects::listing_counts()` batches the count for many projects in **one** query, so the table stays fast. Deleting a project unlinks its properties — it never deletes them.

### Day to day
Add the project once. Then, when adding a property, choose it from the dropdown. The property:
- appears on the project's public page,
- inherits the locality if you leave locality empty,
- contributes to the project's unit counts.

---

## 3. Team screen

`Admin\Screens\TeamNew`

### What a team member record holds
Full name · Role in the office · Phone · WhatsApp · Email · Short bio · Photo · linked WordPress user.

### How it connects
- `Data\Agents::for_user( $user_id )` — WordPress user ⇒ agent record (drives Pocket).
- `Data\Agents::listing_count( $agent_id )` — how many properties they own.
- `Data\Agents::on_delete()` — reassigns or unlinks; never strands a property or enquiry.

### Setting an agent up properly
1. **Team → Add** → name, phone, WhatsApp, email, photo, role.
2. **Users → Add New** → username, email, role **Office Agent**.
3. Make the **phone number identical** on both records.
4. Send them `/pocket/`.

### Day to day
- Assign every enquiry to somebody (`estat_assign_leads`).
- Check the **Reports → agent table** weekly.
- When someone leaves: reassign first, delete second.

---

## 4. Gallery & Media

`Admin\Screens\GalleryScreen`

### Why it exists
The raw WordPress media library shows every file on the site, uses language an estate office does not need, and loads a heavy uploader. Gallery shows **only office files**, grouped by kind.

### Kinds
| Kind | Typical files |
|---|---|
| Photo | JPG, PNG, WebP |
| Brochure | PDF |
| Floor plan | PDF, JPG |
| Document | Sale deed, NOC, registry |

### How it works
`Data\Media::kinds()`, `::mimes_for()`, `::query()`, `::set_kind()`, `::link()`, `::cleanup_for_record()`, `::used_elsewhere()`, `::counts()`.

Files remain in the standard WordPress library — the plugin adds a *kind* and a *link* to a record. That means every backup plugin, CDN and optimisation plugin keeps working.

### Day to day
- Upload per property, or into the gallery and link later.
- Use the **linked / unlinked** filter to find orphans.
- Deleting a linked file warns you if it is used elsewhere.

---

## 5. Insights (Blog / Articles / Market Insights)

`Admin\Screens\InsightsScreen`

Three tabs, one screen — because to an office they are the same job: put something useful on the website.

| Kind | Taxonomy term |
|---|---|
| Blog | `estat_insight_kind = blog` |
| Article | `article` |
| Market Insight | `insight` |

Subject categories live in `estat_insight_topic` (for example "Market Trends", "Home Loan", "Legal").

### Day to day
Write → pick the kind and topic → publish. Archive and single templates ship with the plugin, and the Elementor **Insights** widget lists them anywhere.

---

## 6. Cross-record rules worth knowing

| Situation | What really happens |
|---|---|
| Delete a project | Its properties are unlinked, never deleted |
| Delete an agent | Their properties and enquiries are reassigned or unlinked |
| Delete a media file | Blocked if `used_elsewhere()` is true |
| Change a locality term | Search index re-indexes (`SearchIndex::on_terms_changed()`) |
| Unpublish a property | Index row updates (`SearchIndex::on_status_change()`) |
| Import with a known `external_id` | Updates in place instead of creating a duplicate |
| Bin a property | Reversible; permanent delete needs a typed word |

---

## 7. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Property not on the website | Status not `publish`, or cached | Check status; purge cache |
| Property page 404 | Permalinks | Settings → Permalinks → Save |
| Project counts wrong | Index drift | Advanced → Rebuild search index |
| Photos not showing | Wrong kind, or file not linked | Gallery → check kind and link |
| Agent cannot log in to Pocket | No WP user or phone mismatch | See `06` §2 |
| Bulk bar does nothing | JavaScript error from another plugin | Console; try with other plugins off |
| Completeness stuck below 100 | A rule you consider irrelevant | Fill it or lower the threshold |
