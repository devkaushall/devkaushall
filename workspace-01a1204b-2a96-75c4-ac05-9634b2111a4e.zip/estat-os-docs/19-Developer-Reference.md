# 19 — Developer Reference

Conventions: the root namespace is `EstatOS\`. `Data\Listings::save()` means `EstatOS\Data\Listings::save()` in `includes/Data/Listings.php`.

---

## 1. Constants

| Constant | Value | Meaning |
|---|---|---|
| `ESTAT_VERSION` | `3.6.6` | Code version |
| `ESTAT_DB_VERSION` | `12` | Schema version |
| `ESTAT_FILE` | path | Plugin main file |
| `ESTAT_DIR` | path | Plugin directory with trailing slash |
| `ESTAT_URL` | URL | Plugin URL with trailing slash |
| `ESTAT_BASENAME` | string | `estat-os/estat-os.php` |
| `ESTAT_MIN_PHP` | `7.4` | Floor |
| `ESTAT_MIN_WP` | `6.0` | Floor |
| `Settings::OPTION` | `estat_settings` | The one settings array |
| `Rest\RestApi::NS` | `estat/v1` | API namespace (v2 is literal `'estat/v2'`) |
| `Schema::HEALTH_KEY` | `estat_schema_healthy` | Schema health memo |
| `Scheduler::DAILY` | `estat_daily_maintenance` | Cron hook |
| `Scheduler::SUMMARY` | `estat_daily_summary` | Cron hook |
| `Scheduler::WEEKLY` | `estat_weekly_report` | Cron hook |
| `Webhooks::RETRY_HOOK` | `estat_webhook_retry` | Cron hook |
| `Roles::OWNER` | `estat_office_owner` | Role |
| `Roles::AGENT` | `estat_office_agent` | Role |

---

## 2. Hooks

### Actions

| Hook | When | Arguments |
|---|---|---|
| `estat_loaded` | After all modules register | `$plugin` |
| `estat_daily_maintenance` | Daily cron | — |
| `estat_daily_summary` | Daily 8 am | — |
| `estat_weekly_report` | Monday 8 am | — |
| `estat_webhook_retry` | Failed delivery retry | — |
| `estat_hourly_maintenance` | Hourly | — |

### Filters

| Filter | Signature | Purpose |
|---|---|---|
| `estat_modules` | `apply_filters( 'estat_modules', array $classes )` | Add or replace a module before boot |
| `estat_form_field_types` | `apply_filters( 'estat_form_field_types', array $types )` | Add a form field type |

### WordPress hooks the plugin consumes (not exhaustive)
`init` (0 for CPTs and taxonomies, 1 for the migrator), `plugins_loaded` (1), `after_setup_theme` (999), `wp_loaded` (999), `elementor/init`, `get_the_terms`, `wp_privacy_personal_data_exporters`, `wp_privacy_personal_data_erasers`, `wp_robots`, `rank_math/frontend/*`, `wpseo_robots`, `template_include`, `rest_api_init`.

### AJAX actions (admin)
`estat_upload`, `estat_move_pipeline`, `estat_test_mail`, `estat_test_webhook`, `estat_lead_timeline`.

---

## 3. Accessing a module

```php
$plugin  = \EstatOS\Plugin::instance();
$module  = $plugin->module( 'listings' );   // null if not registered
```

Adding your own module:

```php
add_filter( 'estat_modules', function ( array $classes ): array {
    $classes['my_thing'] = \My\Thing::class;   // must have register()
    return $classes;
} );
```

---

## 4. Core class API

### `Data\Listings`
```php
save( array $input, int $post_id = 0 )                 // create/update
validate( array $input, int $post_id = 0 ): array      // [ok, errors, warnings]
set_cover( int $listing_id, int $attachment_id ): void
refresh_derived( int $listing_id ): void
completeness( int $listing_id ): array                 // [percent, missing[]]
days_listed( int $listing_id ): int
to_array( int $listing_id, bool $private = false ): array
find_by_external_id( string $external_id ): int
```

### `Data\Projects`
```php
save( array $input, int $post_id = 0 )
to_array( int $project_id ): array
stats( int $project_id ): array
listing_counts( array $project_ids ): array            // batched — one query
find_by_external_id( string $external_id ): int
```

### `Data\Agents`
```php
save( array $input, int $post_id = 0 )
listing_count( int $agent_id ): int
for_user( int $user_id ): int                           // WP user ⇒ agent id
to_array( int $agent_id ): array
```

### `Leads\Leads`
```php
normalize_phone( string $phone ): string
validate( array $data ): array
create( array $input )                                  // dedupes, assigns, notifies
get( int $lead_id ): ?array
query( array $args = array() ): array
update( int $lead_id, array $input )
assign( int $lead_id, int $agent_id, bool $log = true ): bool
append_note( int $lead_id, string $note ): void
erase( int $lead_id ): bool
counts(): array
apply_retention( int $days ): int
export_csv( array $filters = array(), bool $consent_only = false ): string
```

### `Leads\Visits`
```php
schedule( array $input )
update( int $visit_id, array $input )
get( int $visit_id ): ?array
query( array $args = array() ): array
counts(): array
ics( int $visit_id ): ?string
```

### `Leads\LeadEvents`
```php
add( int $lead_id, string $type, array $payload = array(), int $actor_id = 0 ): int
for_lead( int $lead_id ): array
count( int $lead_id ): int
```

### `Data\Duplicate`
```php
bands(): array
reason_words(): array
band( int $score ): string                              // 'same' | 'near' | 'maybe' | ''
stops( string $band ): bool
fingerprint( array $record ): array
from_post( string $kind, int $post_id ): array
from_input( string $kind, array $input ): array
name_score( string $a, string $b ): float
meaning_score( string $a, string $b ): float
metres( float $lat1, float $lng1, float $lat2, float $lng2 ): float
score( array $a, array $b ): array
candidates( string $kind, array $fp, int $exclude_id = 0, int $limit = 80, bool $narrow = false ): array
check( string $kind, array $input, int $exclude_id = 0, int $limit = 5, bool $narrow = false ): array
check_saved( string $kind, int $post_id, int $limit = 3 ): array
scan( string $kind, int $max_records = 500, float $seconds = 18.0 ): array
remember( string $kind, int $post_id ): array
stored( int $post_id ): array
keep_both( int $post_id, int $other_id, string $kind = 'listing' ): void
forget( int $post_id ): void
forget_cache(): void
```

### `Data\Health`
```php
rules(): array
of( int $listing_id ): array
level( array $keys ): string
attention( int $limit = 50 ): array
summary(): array
suspect_terms( string $taxonomy ): array
name_looks_wrong( string $name ): string
term_listing_count( int $term_id, string $taxonomy ): int
csv( array $rows ): string
city(): string
```

### `Data\Bin`
```php
move( int $record_id, string $why = '', string $batch = '' )
restore( int $record_id )
delete_forever( int $record_id )
batch( string $operation, array $ids, string $why = '' ): array
summary( array $result, string $verb, array $names = array() ): string
query( array $filters = array() ): array
row( int $record_id ): array
count(): int
remember_undo( array $ids ): string
undo_ids( string $token ): ?array
undo( string $token ): array
summary_counts(): array
previous_state_label( int $record_id ): string
sees_everything(): bool
```

### `Data\Undo`
```php
fields(): array
capture( int $post_id ): void
history( int $post_id ): array
available( int $post_id ): bool
restore( int $post_id ): bool
last_change( int $post_id ): int
```

### `Search\SearchIndex`
```php
index_listing( int $listing_id ): void
remove( int $listing_id ): void
rebuild_batch( int $batch = 100, int $offset = 0 ): int
status(): array
on_terms_changed( $object_id, $terms, $tt_ids, $taxonomy ): void
on_status_change( $new_status, $old_status, $post ): void
```

### `Search\Query`
```php
normalize( array $raw ): array      // 31 keys, see 13 §2
// returns [ ids, total, page, per_page, pages ]
```

### `Csv\Spreadsheet`
```php
columns( string $kind ): array
bridge_mappings( string $system = '' ): array
bridge_systems(): array
preview( string $path, int $sample_rows = 5 ): array|WP_Error
guess_mapping( array $headers, string $kind, string $bridge = '' ): array
guess_bridge( array $headers, string $kind = 'listings' ): string
column_plan( array $headers, array $mapping, string $kind ): array
translate_row( string $kind, array $mapped ): array
```

### `Support\Status`
```php
label( string $family, string $value ): string
labels( string $family ): array
tone( string $family, string $value ): string          // good|warn|danger|quiet|''
transitions( string $family, string $from ): array
can( string $family, string $from, string $to ): bool
next( string $family, string $from ): string
actor_is_office(): bool
publication_note( string $value ): string
```
Families: `publication`, `availability`, `verification`, `construction`, `lead`, `visit`, `request`.

### `Support\Vocabulary`
```php
property_types()  offers()  availability()  freshness()
construction()    verification()  publication()  request_states()
lead_statuses()   visit_outcomes()  furnishing()  facing()
price_types()     project_categories()  sources()
all_filters()     share_channels()
```

### `Support\Sanitize`
Typed helpers used everywhere: `text()`, `int( $v, $min, $max )`, `money()`, `bool()`, `date()`, `slug()`, `html()`, `url()`, `email()`, `phone()`, `lines()`, `csv_list()`.

### `Settings\Settings`
```php
get( string $key, $default = null )
update( array $pairs )
defaults(): array
sanitize( $input ): array
```

### `Audit\AuditLog`
```php
record( string $action, string $object_type = '', int $object_id = 0, array $context = array() ): void
query( array $args = array() ): array
purge_older_than( int $days ): int
describe( string $action ): string
```

### `Webhooks\Webhooks`
```php
events(): array
deliver( string $event, array $payload, int $attempt = 1 ): void
sign( string $message, string $secret ): string
verify( string $message, string $secret, string $signature ): bool
test(): array
recent( int $limit = 20 ): array
```

### `Frontend\Seo` (pure, testable)
```php
plan(): array
decide( array $context ): array        // index, canonical, title, description, why
query_params(): array
noindex_ids(): array
has_own_title(): bool
has_own_description(): bool
fit( string $text, int $limit ): string
```

### `Pocket\Pocket`
```php
can_use(): bool
is_office(): bool
agent_id(): int
owns( int $record_id ): bool
can_see( $post ): bool
url( string $view = '', int $id = 0 ): string
redirect( string $view, int $id = 0, string $ok = '' ): void
flash(): string
my_records( string $search = '', string $kind = '' ): array
binned_records( string $kind = '' ): array
status_of( $post ): array
icon( string $name, int $size = 20 ): string
```

---

## 5. REST API

### `estat/v1`

| Method | Path | Permission |
|---|---|---|
| GET | `/health` | public |
| GET | `/properties` | public |
| GET | `/properties/{id}` | public |
| GET | `/projects/{id}/stats` | public |
| GET | `/agents` | public |
| POST | `/forms/{id}/submit` | public |
| GET | `/leads` | `estat_manage_leads` |
| POST | `/leads` | `estat_manage_leads` |
| POST | `/leads/{id}` | `estat_manage_leads` |
| GET | `/visits` | `estat_manage_visits` |
| POST | `/visits` | `estat_manage_visits` |
| POST | `/visits/{id}` | `estat_manage_visits` |
| GET | `/alerts` | `estat_manage_leads` |
| POST | `/alerts` | public |
| POST | `/share` | public |
| POST | `/maintenance` | `estat_run_maintenance` |

### `estat/v2`

| Method | Path | Permission |
|---|---|---|
| GET | `/properties` | public, full `search_args()` |
| GET | `/properties/{id}` | public |
| GET | `/projects` | public |
| GET | `/projects/{id}` | public |
| GET | `/projects/stages` | public |
| GET | `/agents` | public |
| GET | `/localities` | public |

### Authentication for writes
Application Passwords over HTTPS, or a logged-in cookie + `X-WP-Nonce`.

```bash
curl -u user:app-password \
  https://site.com/wp-json/estat/v1/leads?per_page=20
```

---

## 6. Stored value reference

| Family | Values |
|---|---|
| `publication` | `draft`, `pending`, `publish`, `private`, `future`, `trash` |
| `availability` | `available`, `on_hold`, `rented`, `sold` |
| `verification` | `unverified`, `self_verified`, `office_verified` |
| `construction` | `ready`, `construction`, `new_launch` |
| `freshness` | `just_listed`, `ready_to_move` |
| `lead` | `new`, `contacted`, `scheduled`, `won`, `lost` |
| `visit` outcome | `pending`, `done`, `no_show`, `cancelled` |
| `request` | `pending`, `approved`, `declined` |
| `offer` | `sale`, `rent`, `lease` |
| `price_type` | `fixed`, `negotiable`, `starting_from`, `on_request` |
| `property_type` | `apartment`, `builder_floor`, `villa`, `plot`, `commercial_shop`, `office`, `warehouse`, `farm_house`, `other` |
| `project category` | `residential`, `commercial`, `affordable`, `mixed`, `other` |
| `project status` | `ready`, `construction`, `new_launch`, `completed` |
| `furnishing` | ``, `unfurnished`, `semi`, `furnished` |
| `facing` | ``, `north`, `south`, `east`, `west`, `north_east`, `north_west`, `south_east`, `south_west` |
| `area_unit` | `sqft`, `sqyd`, `sqm` |
| `area_type` | `carpet`, `builtup`, `super`, `plot` |

**Legacy lead aliases** folded automatically: `qualified`→`contacted`, `visit_scheduled`→`scheduled`, `converted`→`won`, `spam`→deleted.

---

## 7. Adding things safely

### A new settings field
Add a default in `Settings::defaults()`, a rule in `Settings::sanitize()`, and a control in `Admin\Screens\SettingsNew`.

### A new form field type
```php
add_filter( 'estat_form_field_types', function ( array $types ): array {
    $types['pan'] = array(
        'label'   => 'PAN number',
        'input'   => 'text',
        'options' => false,
    );
    return $types;
} );
```
Then handle rendering in `Forms\Renderer::field()` and validation in `Forms\Submissions::validate_fields()`.

### A new status
1. Add the key to `Support\Vocabulary`.
2. Add the label and tone in `Support\Status`.
3. Add the legal moves in `Support\Status::transitions()`.
4. Add the column to `estat_index` if it must be searchable.
5. Add a migration step if existing data needs rewriting.

**Never** add a status by only adding a label. The transition graph is the source of truth.

### A new admin screen
1. Screen class in `includes/Admin/Screens/` with a static `render()`.
2. Add an entry to `Admin::pages()` with `title`, `cap`, `menu`, `design`, `class`.
3. Any action: add a case in `Admin\Actions::handle()` with capability → nonce → work → redirect.

### A new Elementor widget
Add a class extending `Integrations\Elementor\BaseWidget` and register it in `Widgets::classes()`. Guard with `Bridge::active()`.

---

## 8. Coding standards

- `declare( strict_types = 1 );` in every file.
- `defined( 'ABSPATH' ) || exit;` in every file that can be reached directly.
- One class per file, `final` wherever inheritance is not intended.
- Doc blocks on every method with `@param` / `@return`.
- PHP 7.4 syntax only — no arrow-function-only idioms in hot paths, no PHP 8 attributes.
- Escape at output, sanitise at input, prepare every query.
- No business logic in a screen class.
- Every user-visible string goes through `__()` with the `estat-os` domain.

---

## 9. Building a release

```bash
cd wp-content/plugins
zip -r Estate_OS-3.6.6.zip estat-os -x '*.git*' '*.DS_Store' '*/node_modules/*'
```

Rules:
- Root folder inside the zip must be `estat-os/`.
- Bump `ESTAT_VERSION` in `estat-os.php`.
- Bump `ESTAT_DB_VERSION` **only** when the schema changed.
- Add a `Migrator` step when the schema changed.
- Regenerate `languages/estat-os.pot` if strings changed.
- Keep **exactly one** `Estate_OS-*.zip` in the release folder.
