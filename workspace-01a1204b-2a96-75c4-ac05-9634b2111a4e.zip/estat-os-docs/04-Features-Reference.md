# 04 — Feature Reference

Every feature: **what it does, how it works inside, how to configure it, how to operate it.**

---

## F1 · Listings (Properties)

### Simple meaning
Property = ek ghar/dukaan jo aap bech ya kiraye par dete hain. Isme photos, price, size, rooms, address aur khaas baatein (highlights) hoti hain.

### What it does
Stores every property with price, size, rooms, floor, facing, furnishing, availability, construction stage, photos, documents, map position, highlights and a **readiness score**.

### How it works internally
| Concern | Code |
|---|---|
| Save / update | `Data\Listings::save( $input, $post_id )` |
| Validation | `Data\Listings::validate()` — returns `[ok, errors, warnings]` |
| Meta write | `Data\Listings::save_meta()` |
| Terms write | `Data\Listings::save_terms()` |
| Cover photo | `Data\Listings::set_cover()` |
| Derived fields | `Data\Listings::refresh_derived()` — ref, slug, search text |
| Readiness | `Data\Listings::completeness()` + `Data\Health::of()` |
| Serialise for API | `Data\Listings::to_array( $id, $private )` |
| Index sync | `Search\SearchIndex::index_listing()` |
| Undo snapshot | `Data\Undo::capture()` before a bulk change |

### Configuration
Group 3 — verification mode, expiry, completeness threshold, per-page, filters.

### Day to day
**Add a home** → four groups (basics, price, photo, highlights) → **Save**. The screen warns you *while you type* if the property looks like one you already have.

### Watch out for
- Completeness below `completeness_threshold` (default 70) means the listing appears in the attention list and is still fine to publish — it is a nudge, not a block.
- `external_id` is your own reference. Re-importing a file with the same `external_id` **updates** instead of creating a duplicate.

---

## F2 · Societies & Projects

### Simple meaning
Society/project = wo building ya township jisme kai properties hain. Ek baar project banao, phir usme properties jodo. Project page par sabhi available properties apne-aap dikhte hain.

### What it does
Holds one record per building/township: builder, locality, category, stage, price range, unit types, total and available units, possession date, registration number, highlights, and a live count of listings belonging to it.

### How it works internally
`Data\Projects::save()`, `::to_array()`, `::stats()`, `::listing_counts()` (batched — one query for many projects, never N+1), `::on_delete()` (unlinks listings, never orphans them).

The screen (`Admin\Screens\ProjectsScreen`) is drawn in the same shapes as Properties: three metric tiles, an 18-field form in 7 two-column groups, a 6-column table.

### Day to day
Add the project once → while adding a property, pick it from the **Society / Project** dropdown → the property now appears on the project page and inherits the locality.

---

## F3 · Team (Agents)

### Simple meaning
Team = aapke agents. Har agent ka naam, phone, photo aur uski properties. Enquiry kisi ek agent ko assign hoti hai.

### How it works internally
`Data\Agents::save()`, `::listing_count()`, `::for_user()` (maps a WordPress user to an agent record — this is how Pocket knows who is logged in), `::on_delete()` (reassigns or unlinks, never strands a listing).

### Day to day
Add each agent. **Give each one a WordPress user account with the `estat_office_agent` role** — without it they cannot log in to Pocket.

---

## F4 · Enquiries (Leads)

### Simple meaning
Enquiry = kisi visitor ka phone/email/message. Website form, Pocket, ya import — sab ek hi inbox mein aate hain. Har enquiry ko aage badhana hota hai: New → Contacted → Scheduled → Won/Lost.

### How it works internally
| Concern | Code |
|---|---|
| Create | `Leads\Leads::create()` — validates, dedupes, assigns, logs an event, fires notifications and webhooks |
| Phone normalisation | `Leads\Leads::normalize_phone()` — Indian 10-digit handling, `+91`, leading-zero stripping |
| Duplicate guard | `dedupe_hash` (phone + listing + time window) with a `UNIQUE KEY` |
| Idempotency | `idempotency_key` `UNIQUE KEY` — a double-submitted form cannot create two leads |
| Timeline | `Leads\LeadEvents::add()` → `estat_lead_events` |
| Assignment | `Leads\Leads::assign()`, with `auto_agent()` rules |
| Erasure | `Leads\Leads::erase()` — blanks personal fields, keeps the row for reporting |
| Retention | `Leads\Leads::apply_retention( $days )` — cron-driven |
| Export | `Leads\Leads::export_csv( $filters, $consent_only )` |

### Legal moves (`Support\Status`)
```
new       → contacted, lost
contacted → scheduled, lost
scheduled → won, lost
won/lost  → contacted, won, lost   (a closed enquiry may be reopened)
```
Legacy aliases are folded: `qualified`→contacted, `visit_scheduled`→scheduled, `converted`→won, `spam`→deleted.

### Day to day
Enquiries screen → open a card → add a note, set a follow-up date, move the status, assign an agent, schedule a visit, download the visit `.ics`.

---

## F5 · Site Visits

### Simple meaning
Visit = agent aur client ka milna. Date-time set karo, baad mein likho ki kya hua — Completed / No-show / Cancelled.

### How it works internally
`Leads\Visits::schedule()`, `::update()`, `::query()`, `::counts()`, `::ics()`. A `UNIQUE KEY` on `dedupe_hash` prevents double-booking the same person at the same time. `reminder_sent` is flagged by cron. The `.ics` download is a real calendar file (RFC 5545, with `ics_escape()` applied to every text field).

### Day to day
From an enquiry → **Schedule a visit** → date, time, agent, property → save → **Download .ics** to put it in your phone's calendar. After the visit, mark the outcome.

---

## F6 · Pipeline

### Simple meaning
Pipeline = enquiry ka board. Chaar column: New, Contacted, Scheduled, Won/Lost. Card ek column se doosre mein kheecho.

### How it works internally
`Admin\Screens\PipelineScreen` renders a Kanban; `Admin::ajax_move_pipeline()` handles the drag. Every move goes through `Support\Status::can()` on the server — the browser cannot invent a move that the law forbids.

---

## F7 · Forms (visual builder)

### Simple meaning
Form = website par wala "Contact us" box. Aap khud decide karte hain ki kaunse sawal poochhe jaayein.

### How it works internally
| Concern | Code |
|---|---|
| Definition | JSON rows → columns → fields, `Forms\Forms::sanitize_definition()` re-validates from scratch on the server |
| Field types | 27 in `Forms\FieldTypes::all()` |
| Style | `Forms\Style::sanitize()` + `::to_css()` |
| Render | `Forms\Renderer::render()` — server-rendered, progressive enhancement only |
| Intake | `Forms\Submissions::handle()` — validate, idempotency, create lead, fire `form.submitted` |
| Steps | `Forms\Forms::get_steps()` — multi-step support |

### Day to day
Website forms → New form → drag fields → set colours → **Save** → copy `[estat_form id="3"]` into any page.

---

## F8 · Import & Export (Spreadsheet)

### Simple meaning
Excel/CSV file se hazaaron properties ek baar mein daalo. Pehle plugin dikhata hai ki kaunsa column kisme jayega, phir aap confirm karte hain, phir import hota hai — aur **undo** bhi ho sakta hai.

### How it works internally
`Csv\Spreadsheet`: `preview()` → `guess_bridge()` → `guess_mapping()` → `column_plan()` → `translate_row()` → `import()` → `undo_import()`.

The importer:
1. Opens the file **inside the uploads directory only** (realpath check — a path outside is refused).
2. Auto-detects the delimiter and encoding (BOM-aware).
3. Scores all nine bridge systems and picks one only if it reads **two more columns** than the plain reading.
4. Shows a **column plan**: every column in your file and what will happen to it. Silence about a column is how "where did my RERA number go?" bugs are born.
5. Imports in chunks, storing `estat_import_jobs` with `created_ids` and `undo_data`.
6. Offers **Undo this import** as a real button.

### The "Where did this file come from?" dropdown
| Choose | When |
|---|---|
| **Generic CSV** | Your headers are already the plugin's own names, or unknown. **Safest — starts here.** |
| 99acres / MagicBricks / Housing / NoBroker / Makaan / CommonFloor export | The file is literally downloaded from that portal |
| Developer / builder master sheet | A builder's own sheet: `project_name`, `builder`, `micro_market`, `bhk_config`, `price_cr`, `rera`… |
| Old Estat-OS / custom | Exported from an older Estat.OS |

> Matching runs **direct first**: a header that already equals a plugin column name is matched before any bridge is consulted. If your file uses the plugin's own headers, all nine options produce an identical 100% mapping.

### CSV column contract
| Kind | Columns |
|---|---|
| **projects** (24) | `external_id, title, slug, description, locality, developer, project_type, category, address, city, highlights, notes, project_status, possession_date, price_min, price_max, price_unit, currency, total_units, available_units, unit_types, regulatory_id, latitude, longitude` |
| **listings** (38) | `external_id, title, description, offer, property_type, price, price_type, rent, deposit, maintenance, area, area_unit, area_type, bedrooms, bathrooms, balconies, parking, floor, total_floors, age, facing, furnishing, address, locality, amenities, latitude, longitude, availability, freshness, construction, possession_date, project_ref, agent_ref, developer, regulatory_id, featured, investment, status` |
| **agents** (7) | `external_id, title, role, phone, whatsapp, email, bio` |
| **leads** (7) | `name, phone, email, message, source, listing_ref, status` |
| **visits** (8) | `scheduled_at, name, phone, listing_ref, listing_name, agent, outcome, notes` |

Multi-value columns (`locality`, `amenities`, `highlights`) are **newline-separated** inside a quoted field.

---

## F9 · Duplicates

### Simple meaning
Agar ek property do baar dali jaaye to plugin khud pakadta hai. Naam, area, size, rooms, price, description — sab mila kar score nikalta hai.

### How it works internally
`Data\Duplicate` — one engine, two places it is shown.

1. **Fingerprint** (`fingerprint()`): normalised text, sector extraction, token set, trigrams, digit set.
2. **Blocking** (`candidates()`): only plausible pairs are compared, so 10,000 records do not mean 50 million comparisons.
3. **Scoring** (`score()`): name (Dice coefficient on trigrams), meaning, area, rooms, money, kind, details, builder, units, possession date, and map distance in metres.
4. **Bands:** `same` → stops you. `near` → stops you. `maybe` → tells you and steps out of the way.
5. **Reasons** are human: "The names are almost the same", "The map pins are within a few steps of each other".
6. **Outcome:** `keep_both()` records that you deliberately kept both, so it stops asking.

### Configuration
The rules live in code (`bands()`, `reason_words()`), by design — one REEP logic, not a dial in two places.

---

## F10 · Bin & Undo

### Simple meaning
Bin = recycle bin. Kuch delete karo to pehle bin mein jaata hai, wahan se wapas aa sakta hai. Permanent delete ek alag, jaan-bujhkar kiya jaane wala kaam hai.

### How it works internally
`Data\Bin` — `move()`, `restore()`, `delete_forever()`, `batch()`, `summary()`, `undo()`. Every batch action records a token in `remember_undo()` so the whole batch can be reversed. Deleting forever requires typing a confirmation word. `Data\Undo` snapshots a fixed field list per post type before edit-level changes.

### Day to day
Properties → select rows → **Move to bin**. Bin → **Restore** or **Delete forever**. After any bulk action, an **Undo** banner appears with a countdown.

---

## F11 · Gallery & Media

### Simple meaning
Saari photos, brochures aur documents ek hi jagah. WordPress ki media library se alag — sirf wahi files jo office ki hain.

### How it works internally
`Data\Media`: `kinds()` (photo / brochure / document / floor plan), `mimes_for()`, `query()`, `link()`, `cleanup_for_record()`, `used_elsewhere()`, `counts()`. Files stay in the standard WordPress media library; the plugin adds a *kind* and a *link* to a record. Deleting a linked file checks `used_elsewhere()` first.

---

## F12 · Insights (Blog / Articles / Market Insights)

### Simple meaning
Website par likhne ke liye teen tarah ka content: Blog, Article, aur Market Insight. Sab ek screen par.

### How it works internally
`Data\Insights::save()`, `::query()`, `::count()`, `::to_array()`. Kind is the `estat_insight_kind` taxonomy; subject is `estat_insight_topic`. Public archive and single templates ship with the plugin.

---

## F13 · Reports

### Simple meaning
Reports batate hain ki kitni enquiries aayin, kaunse agent ne kitna kaam kiya, kaunsa area chal raha hai, aur enquiry kahan se aayi.

### How it works internally
`Admin\Screens\Reports` builds from `estat_index` and the lead tables — never from raw `WP_Query` over meta — so it stays fast at 10,000 listings. Sections: enquiry summary, pipeline, agent table, inventory, localities, sources.

---

## F14 · Search Alerts

### Simple meaning
Visitor ne search kiya aur bola "naya property aaye to batao". Plugin usko email bhejta hai jab koi matching property live hoti hai.

### How it works internally
`Search\Alerts`: `create()`, `handle_confirm()` (double opt-in token), `handle_unsubscribe()`, `on_listing_published()` (matches the new listing against every active alert), `process_queue()` (cron), `delete()`. Two tables exist: `estat_search_alerts` (original) and `estat_alerts` (per-spec, with `frequency` and `token`).

---

## F15 · Pocket (Field Agent OS)

### Simple meaning
Pocket = agent ke phone ka chhota app. Agent site se photo kheench ke property daal sakta hai, enquiry dekh sakta hai, visit update kar sakta hai. Internet na ho to data queue mein ruk jaata hai.

### How it works internally
`Pocket\Pocket` — `add_rewrites()` creates `/pocket/...`, `phone_auth()` lets an agent log in with a phone number, `agent_id()` resolves the WP user to an agent, `owns()` enforces per-record ownership, `can_see()` filters the working list. `Pocket\Steps` holds the guided capture flow; `Pocket\Actions` mirrors the admin action-handler pattern exactly.

Twenty-two views: today, login, listings, new, listing, change, inbox, enquiry, approvals, you, leads, visits, visit, more, capture, capture-lead, capture-want, capture-visit, capture-owner, search, queue.

> **Old links keep working.** Every older address is preserved verbatim — a link shared last year still opens.

---

## F16 · Office Dashboard (front-end)

### Simple meaning
Ek chhota dashboard jo website par hi chalta hai (`/office/`) — bina WordPress admin mein ghuse. Today, Listings, Approvals.

### How it works internally
`Office\Dashboard` — `add_rewrites()`, `query_vars()`, `serving()`, `gate()` (capability check), `handle()`/`post()`. `Office\Screens::render()` draws a shell with navigation.

---

## F17 · Change Requests

### Simple meaning
Agent ne kisi property mein badlaav kiya jo uski apni nahi hai → wo seedha nahi hota. Pehle office ko request jaati hai, office approve ya decline karta hai.

### How it works internally
`Field\Requests`: `create()` (with `clean_changes()` typed per field), `current_values()`, `describe()`, `query()`, `pending_count()`, `approve()`, `decline()`, `mark()`, `append_note()`. `may_edit_directly()` decides whether the user bypasses the whole workflow (office) or goes through it (agent).

`pocket_agents_edit_live = false` is what routes field edits into this queue.

---

## F18 · Notifications & Webhooks

See **14-Notifications-Integrations.md**.

---

## F19 · Practice Mode

See §9 of **03-Configuration-Settings.md**.

---

## F20 · Design Tokens & Page Blocks

| Screen | Class | What it controls |
|---|---|---|
| Colours & fonts | `Admin\Screens\DesignTokensScreen` | Overrides `assets/css/tokens.css` without editing code; live preview, export CSS, reset |
| Page blocks | `Admin\Screens\TemplatesScreen` | Drag-order of listing/project page blocks |

`Data\Templates::default_blocks('listing')` ships 17 blocks (header, signals, cover, share, facts, costs, emi, description, gallery, video, documents, map, agent, enquiry, locality…). `default_blocks('project')` ships 11. Turning a block off removes it from the rendered page everywhere at once.

## The office logo (4.1.6)

**Settings → The office → Office logo.** One picture, picked from the media
library, shown at the top of the office screen and in the agent's app. *Use
the default* puts it back to whatever the website already uses.

The order the app tries, in `Support/Logo.php`:

1. the picture chosen here (`logo_id`);
2. the logo WordPress is set to use (Appearance → Customize → Site Identity);
3. the mark that ships inside the plugin.

Never a broken image: if all three are missing, the drawn roof glyph the app
used before is shown instead. A fourth answer is available to a developer
through the `estat_logo_url` filter.
