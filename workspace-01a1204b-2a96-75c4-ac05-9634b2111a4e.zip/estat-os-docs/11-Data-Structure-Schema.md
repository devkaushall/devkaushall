# 11 — Data Structure, Storage & Schema

## Simple meaning (Hinglish)

Data do jagah rehta hai. **WordPress posts** mein property/project/team (dheere badalne wali cheezein). Plugin ki **14 apni tables** mein enquiry/visit/form/search (tezi se badalne wali cheezein). Isse website tez chalti hai.

Poora backup lene ke liye dono chahiye — posts **aur** tables.

---

## 1. Custom post types (6)

Registered by `Data\PostTypes::register_post_types()` on `init` priority **0**.

| Constant | Key | Holds |
|---|---|---|
| `PostTypes::LISTING` | `estat_listing` | Properties |
| `PostTypes::PROJECT` | `estat_project` | Societies and projects |
| `PostTypes::AGENT` | `estat_agent` | Team members |
| `PostTypes::AGENCY` | `estat_agency` | Agencies (multi-agency mode) |
| `PostTypes::DOCUMENT` | `estat_document` | Documents |
| `PostTypes::INSIGHT` | `estat_insight` | Blogs, articles, market insights |

Each uses `simple_caps()` so capabilities map to the plugin's own verb set (see `12-Permissions-Roles.md`).

---

## 2. Taxonomies (5)

Registered by `Data\Taxonomies::register_taxonomies()`.

| Constant | Key | Attached to |
|---|---|---|
| `LOCALITY` | `estat_locality` | listings, projects |
| `FEATURE` | `estat_feature` | listings |
| `AMENITY` | `estat_amenity` | listings, projects |
| `INSIGHT_KIND` | `estat_insight_kind` | insights (blog / article / insight) |
| `INSIGHT_TOPIC` | `estat_insight_topic` | insights (Market Trends, Home Loan, …) |

`Taxonomies::seed()` exists but is **never run automatically** — seeding terms you did not ask for is how offices end up with junk filters. Run it from Tools if you want starter terms.

---

## 3. Meta schema

`Data\Meta` registers and sanitises every field.

| Schema function | Covers |
|---|---|
| `Meta::listing_schema()` | All listing meta (price, rent, area, bedrooms, floor, facing, furnishing, availability, freshness, construction, possession, agent, project, address, coordinates, featured, investment, external id, regulatory id, video, tour …) |
| `Meta::project_schema()` | developer, project status, price min/max, total units, available units, unit types, highlights |
| `Meta::agent_schema()` | role, phone, whatsapp, email, bio, linked user |
| `Meta::schema_for( $post_type )` | Dispatcher |
| `Meta::sanitize_value( $value, $field )` | Typed sanitiser per field |

All listing meta keys are prefixed `_estat_` (for example `_estat_price`, `_estat_bedrooms`, `_estat_offer`). Registered meta means WordPress REST, `register_meta` validation and the block editor all understand them.

---

## 4. The fourteen custom tables

Created by `Schema::install()` with `dbDelta()`; listed in `Schema::tables()`. Names are **base** names — the WordPress prefix is added by `Schema::table()`.

| # | Base name | Holds |
|---|---|---|
| 1 | `estat_leads` | Enquiries |
| 2 | `estat_lead_events` | Enquiry timeline |
| 3 | `estat_visits` | Site visits |
| 4 | `estat_forms` | Form definitions |
| 5 | `estat_submissions` | Form submissions |
| 6 | `estat_index` | Flat search index, one row per listing |
| 7 | `estat_audit` | Activity history |
| 8 | `estat_webhook_log` | Webhook delivery attempts |
| 9 | `estat_import_jobs` | Import jobs, with undo data |
| 10 | `estat_requests` | Change requests |
| 11 | `estat_search_alerts` | Saved-search alerts (original) |
| 12 | `estat_alerts` | Saved-search alerts (spec version) |
| 13 | `estat_templates` | Page block order |
| 14 | `estat_share_log` | Share analytics |

### 4.1 `estat_leads` (enquiries)

```sql
id BIGINT UNSIGNED AUTO_INCREMENT
created_at, updated_at DATETIME
name VARCHAR(191), phone VARCHAR(32), email VARCHAR(191)
message TEXT
intent VARCHAR(20), locality VARCHAR(191)
budget_min DECIMAL(18,2), budget_max DECIMAL(18,2)
source VARCHAR(64) DEFAULT 'website'
source_url VARCHAR(255), submission_source VARCHAR(191)
utm_source, utm_medium, utm_campaign VARCHAR(100)
listing_id, project_id, agent_id, assigned_agent_id, form_id BIGINT UNSIGNED
status VARCHAR(32) DEFAULT 'new'
lost_reason VARCHAR(32), notes LONGTEXT
followup_at DATETIME NULL
consent TINYINT(1), consent_text_version VARCHAR(20)
ip_hash CHAR(64), user_agent VARCHAR(255)
practice TINYINT(1), erased TINYINT(1)
dedupe_hash CHAR(64), idempotency_key CHAR(64)

PRIMARY KEY (id)
UNIQUE KEY idempotency_key (idempotency_key)
KEY dedupe_hash, status_created(status,created_at), agent_id,
    assigned_agent_id, listing_id, phone, created_at, followup_at
```

### 4.2 `estat_lead_events`
`id, lead_id, created_at, actor_id, type VARCHAR(32) DEFAULT 'created', payload LONGTEXT`
Keys: `lead_id`, `type`, `created_at`.

### 4.3 `estat_visits`
`id, created_at, updated_at, lead_id, listing_id, agent_id, scheduled_at DATETIME, outcome VARCHAR(32) DEFAULT 'pending', notes TEXT, reminder_sent TINYINT(1), practice TINYINT(1), dedupe_hash CHAR(64)`
**`UNIQUE KEY dedupe_hash`** — this is what prevents a double booking.
Keys: `scheduled_at`, `lead_id`, `agent_id`, `outcome`.

### 4.4 `estat_forms`
`id, created_at, updated_at, name, slug, status VARCHAR(20) DEFAULT 'active', definition LONGTEXT, settings LONGTEXT`
**`UNIQUE KEY slug`**, `KEY status`.

### 4.5 `estat_submissions`
`id, created_at, form_id, lead_id, payload LONGTEXT, page_url VARCHAR(255), ip_hash CHAR(64), idempotency_key CHAR(64), practice TINYINT(1)`
**`UNIQUE KEY idempotency_key`** — a double submit cannot create a duplicate.

### 4.6 `estat_index` (the important one)

One row per listing. Every public search, filter, sort, map and report reads this table — never postmeta.

```sql
listing_id BIGINT UNSIGNED (PRIMARY KEY)
post_status VARCHAR(20) DEFAULT 'draft'
title VARCHAR(255), search_text TEXT
offer, property_type, availability, construction, furnishing, facing VARCHAR(20/32)
price DECIMAL(18,2), rent DECIMAL(18,2), price_sort DECIMAL(18,2)
area_sqft DECIMAL(14,2)
bedrooms, bathrooms SMALLINT; floor, total_floors, parking, balconies, age SMALLINT
locality_ids, amenities_ids, features_ids VARCHAR(191)
project_id, agent_id BIGINT UNSIGNED
featured, investment, verified, practice TINYINT(1)
completeness SMALLINT UNSIGNED
latitude DECIMAL(10,7), longitude DECIMAL(10,7)
possession_date DATE NULL
published_at DATETIME NULL, updated_at DATETIME

KEY status_offer(post_status, offer)
KEY price_sort, area_sqft, bedrooms, property_type,
    project_id, agent_id, featured, verified, facing, published_at
```

`price_sort` exists because sale and rent live in different columns; sorting needs one number.

### 4.7 `estat_audit`
`id, created_at, user_id, action VARCHAR(64), object_type VARCHAR(32), object_id BIGINT, context LONGTEXT`
Keys: `action_created(action, created_at)`, `object(object_type, object_id)`, `created_at`.

### 4.8 `estat_webhook_log`
`id, created_at, event VARCHAR(64), object_id BIGINT, status_code SMALLINT, success TINYINT(1), attempt SMALLINT, error VARCHAR(255)`
Key: `event_created`.

### 4.9 `estat_import_jobs`
`id, created_at, updated_at, user_id, kind VARCHAR(32), file_path VARCHAR(255), mapping LONGTEXT, state VARCHAR(20), total_rows, processed_rows, created_count, updated_count, skipped_count, errors LONGTEXT, file_hash CHAR(64), created_ids LONGTEXT, undo_data LONGTEXT, bridge_type VARCHAR(32), duplicate_mode VARCHAR(20)`
Keys: `state`, `file_hash`.

### 4.10 `estat_requests`
`id, created_at, updated_at, record_id, record_type, requested_by, reviewed_by, status VARCHAR(20) DEFAULT 'pending', changes LONGTEXT, message TEXT, reason TEXT`
Keys: `status`, `record_id`, `requested_by`.

### 4.11–4.12 `estat_search_alerts` and `estat_alerts`

`estat_search_alerts`: `id, created_at, updated_at, email, name, filters LONGTEXT, filters_hash CHAR(64), active, confirmed, confirm_token, last_sent_at, last_listing_id, send_count, source_url`

`estat_alerts` (spec version): `id, email, phone, query LONGTEXT, frequency VARCHAR(20) DEFAULT 'instant', confirmed, token VARCHAR(64), created_at, last_sent_at, unsubscribed_at`

Two tables exist for backward compatibility. Both are written; reads prefer the newer one.

### 4.13 `estat_templates`
`id, created_at, updated_at, name, slug, type VARCHAR(32) DEFAULT 'listing', blocks LONGTEXT, settings LONGTEXT, is_default TINYINT(1)`
**`UNIQUE KEY slug`**, `KEY type`.

### 4.14 `estat_share_log`
`id, created_at, listing_id, channel VARCHAR(32), ip_hash CHAR(64)`
Keys: `listing_id`, `channel`, `created_at`.

---

## 5. Options

| Option | Holds |
|---|---|
| `estat_settings` | The single settings array |
| `estat_db_version` | Schema version (currently 12) |
| `estat_version` | Code version |
| `estat_installed_at` | First-install timestamp |
| `estat_show_setup` | Show the setup screen |
| `estat_schema_healthy` | Memo of table health (`Schema::HEALTH_KEY`) |
| `estat_index_repair_offset` | Resumable index-repair cursor |

---

## 6. Why the search index exists

A `WP_Query` with six meta filters across 10,000 listings joins `postmeta` six times and cannot use a useful index. The plugin therefore keeps a **denormalised, indexed row per listing**.

Maintenance of the index:

| Trigger | Handler |
|---|---|
| Listing saved | `SearchIndex::index_listing()` |
| Listing deleted | `SearchIndex::remove()` |
| Post status changed | `SearchIndex::on_status_change()` |
| Terms changed | `SearchIndex::on_terms_changed()` |
| Daily cron | `Scheduler::repair_index()` — rebuilds in batches of 200, resumable |
| Manual | **Advanced → Rebuild search index** |

`SearchIndex::status()` reports how many rows exist and how many are stale.

---

## 7. Undo snapshots

`Data\Undo::fields()` declares which meta keys are snapshotted per post type before a change.

**Listing:** price, rent, deposit, maintenance, price_type, area, area_unit, bedrooms, bathrooms, balconies, parking, floor, total_floors, offer, availability, freshness, construction, property_type, agent_id, project_id, address, furnishing …

**Project:** developer, project_status, price_min, price_max, total_units, available_units …

`Undo::capture()` before, `Undo::restore()` after, `Undo::history()` to read, `Undo::available()` to know whether there is anything to restore.

---

## 8. Data integrity rules

| Rule | Enforced by |
|---|---|
| A project is never orphaned by a deleted listing | `Projects::on_delete()` unlinks |
| A listing is never orphaned by a deleted project | `Projects::on_delete()` unlinks |
| An agent deletion never strands records | `Agents::on_delete()` reassigns |
| A media file in use is never silently deleted | `Media::used_elsewhere()` |
| A double form submit never creates two leads | `UNIQUE KEY idempotency_key` |
| The same visit is never booked twice | `UNIQUE KEY dedupe_hash` |
| A form slug is never duplicated | `UNIQUE KEY slug` |
| An IP address is never stored raw | `ip_hash CHAR(64)` |

---

## 9. Backup and restore

**A complete backup needs both halves.**

1. **WordPress database** — posts, postmeta, terms, options, **and the 14 `estat_*` tables**. Most backup plugins include all tables by default; verify, because a few only back up tables with the site prefix and these do have it.
2. **`wp-content/uploads/`** — all photos, brochures and documents.

### Restore
1. Restore files and database together.
2. Check `estat_db_version` — if the restored data is older than the code, `Migrator::maybe_upgrade()` runs automatically on the next request (`init`, priority 1).
3. Verify with `/wp-json/estat/v1/health`.
4. Run **Advanced → Rebuild search index** and **Repair data**.
5. Purge caches.

### Migrating to a new host
- Take a full backup (database + uploads).
- Restore on the new host.
- **Settings → Permalinks → Save** (rewrites).
- Purge caches.
- Verify `/wp-json/estat/v1/health` and one property page.

---

## 10. Migration history

`Install\Migrator::maybe_upgrade()` compares stored `estat_db_version` with `ESTAT_DB_VERSION` (12) and runs pending steps: `step_2 … step_12`. Steps are idempotent and run inside `init` priority 1 so no request can happen against an unmigrated schema.

`Install\RepairData::run()` is the manual repair: `repair_localities()` re-links locality terms, `repair_pages()` recreates missing pages.
