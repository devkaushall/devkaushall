# 03 — Configuration & Settings Reference

## Simple meaning (Hinglish)

Sab kuch ek hi jagah set hota hai: **Estat.OS → Settings**. Isme 6 group hain — Office, General, Listings, Leads, Integrations, Advanced. Har setting ka matlab neeche likha hai. Jo chhod doge wo default value le lega, plugin chalta rahega.

---

## 1. How settings are stored

- **One option, one array:** `estat_settings` (`Settings\Settings::OPTION`).
- Defaults live in `Settings\Settings::defaults()` and are merged on read, so a missing key can never cause a PHP notice.
- Saving goes through `Settings\Settings::sanitize()`, which validates **every** key with a typed rule. Unknown keys are dropped.
- Any change fires `AuditLog::on_settings_changed()` — who changed what is recorded.
- The screen is `Admin\Screens\SettingsNew`, with six groups declared in `SettingsNew::groups()`.

**Developer note:** read with `Settings::get( 'key', $default )`; write with `Settings::update( [ 'key' => $value ] )`. Never `get_option('estat_settings')` directly — you will miss the default merge.

---

## 2. Group 1 — Office overview

Who you are. This is what appears on the website, in emails, and on printed sheets.

| Setting | Key | Default | Notes |
|---|---|---|---|
| Office name | `office_name` | `Mayfair Properties & Developers` | Site title fallback, email signature |
| Tagline | `tagline` | `Developer and channel partner in Gurugram` | Shown under the name |
| Contact person | `contact_person` | — | Named on the website |
| Reference prefix | `ref_prefix` | — | Prepended to generated reference numbers |
| Phone | `phone` | `+91 98737 12902` | Click-to-call |
| WhatsApp | `whatsapp` | `+91 98737 12902` | Used by the WhatsApp CTA |
| Email | `email` | — | Shown publicly; **not** the mail sender |
| Address | `address` | — | Printed sheets, contact blocks |
| Office hours | `office_hours` | `Mon to Sun, 10 am to 6 pm` | |
| Logo | `logo_id` | 0 | Attachment ID |
| QR / Pocket link | — | derived | A QR code to the Pocket app is drawn on this screen |

**Day to day:** set this once. It rarely changes except phone numbers and the logo.

---

## 3. Group 2 — General

| Setting | Key | Default | What it changes |
|---|---|---|---|
| Country | `country` | `IN` | Phone formatting |
| Currency | `currency` | `INR` | Stored with prices |
| Currency symbol | `currency_symbol` | `₹` | Display only |
| Price format | `price_format` | `indian` | `indian` = lakh/cr grouping; `western` = thousand/million |
| Default area unit | `default_area_unit` | `sqft` | New listings default |
| Cities | `cities` | `['Gurugram']` | Multiple cities supported |
| Default city | `city` | `Gurugram` | Appended to addresses |
| Map provider | `map_provider` | `osm` | `osm` works with **no key at all** |
| Google Maps key | `google_maps_key` | — | Only needed if you switch provider |
| Map default lat / lng / zoom | `map_default_lat`, `map_default_lng`, `map_default_zoom` | — / — / 11 | Fallback centre |
| Regulatory label | `regulatory_label` | `RERA` | Rename to MahaRERA, RERA Karnataka, etc. |
| Show regulatory number | `show_regulatory` | `true` | Hide if you do not want it public |
| Office language | `language` | `auto` | Language of the admin screens |
| Website language | `frontend_language` | `auto` | Language of the public site |
| Visitor may switch language | `allow_visitor_lang` | `true` | Shows `[estat_language]` switcher |
| Admin theme | `admin_theme` | `light` | `light` / `dark` |

**Important:** the office language and the website language are **independent**. A Hinglish-speaking office can run an English website.

---

## 4. Group 3 — Listings & workflow

| Setting | Key | Default | What it changes |
|---|---|---|---|
| Verification mode | `verification_mode` | `optional` | `optional` / `required` / `off`. `required` means a listing cannot go live until verified |
| Listing expiry days | `listing_expiry_days` | `0` | `0` = never expire. Otherwise the daily cron moves stale listings to draft |
| Completeness threshold | `completeness_threshold` | `70` | Percentage below which a listing is "incomplete" and appears in attention |
| Just-listed days | `just_listed_days` | `7` | How long the "Just listed" badge lasts |
| Listings per page | `listings_per_page` | `12` | Public directory page size |
| Favourites enabled | `enable_favorites` | `true` | Visitor shortlist |
| Compare enabled | `enable_compare` | `true` | Side-by-side compare |
| Schema.org enabled | `enable_schema` | `true` | JSON-LD output |
| Practice mode | `practice_mode` | `false` | Adds demo data with a banner; see §9 |
| Multi-agency | `multi_agency` | `false` | Enables the agency layer |
| Enabled filters | `enabled_filters` | all 22 | Which search filters show |
| Filter order | `filter_order` | all 22 | Order they show in |
| Page renderer | `page_renderer` | `theme` | `theme` / `plugin` — who draws single pages |

### Search filters (22, in four groups)

**Basic:** locality, property type, offer, bedrooms, bathrooms, price, area
**Details:** furnishing, facing, floor, total floors, construction stage, availability, possession date, age
**Amenities:** parking, balconies, amenities, features
**Trust:** verified only, featured, investment

Turning a filter off removes it from the public search form but does **not** remove it from the query engine — a hand-built URL still works, which is what SEO landing pages rely on.

---

## 5. Group 4 — Leads & enquiries

| Setting | Key | Default | Notes |
|---|---|---|---|
| Notification email | `notify_email` | — | Where new-enquiry alerts go |
| From name | `email_from_name` | office name | |
| From address | `email_from_address` | — | Should be on your own domain |
| Email footer text | `email_footer_text` | — | Appended to every mail |
| Notify: new enquiry | `notify_new_lead` | `true` | |
| Notify: listing needs approval | `notify_listing_approval` | `true` | |
| Notify: daily summary | `notify_daily_summary` | `true` | 8 am daily |
| Notify: weekly report | `notify_weekly_report` | `true` | Monday 8 am |
| Lead retention days | `retention_days` | `0` | `0` = keep forever. Otherwise the daily cron erases older personal data |
| Lead assignment rules | `lead_assign_rules` | `[]` | Round-robin or per-locality rules |
| Consent text | `consent_text` | `I agree to be contacted about this enquiry.` | Versioned and stored with each lead |
| Privacy policy URL | `privacy_url` | — | Linked under every form |
| Price-on-request label | `price_on_request_label` | `Price on request` | |
| WhatsApp CTA enabled | `whatsapp_cta_enabled` | `true` | |
| WhatsApp CTA text | `whatsapp_cta_text` | — | |
| EMI default rate | `emi_default_rate` | `8.5` | Percent |
| EMI default years | `emi_default_years` | `20` | |
| Locality pages | `locality_pages` | `true` | |
| Share enabled | `share_enabled` | `true` | WhatsApp / copy link |
| Print enabled | `print_enabled` | `true` | Print sheet |
| Search alerts enabled | `search_alerts_enabled` | `false` | Off by default — needs confirmed mail |
| Pocket: show enquiries | `pocket_show_enquiries` | `true` | |
| Pocket: agents may edit live records | `pocket_agents_edit_live` | `false` | `false` routes changes through approval |

---

## 6. Group 5 — Integrations

| Setting | Key | Default | Notes |
|---|---|---|---|
| Webhooks enabled | `webhook_enabled` | `false` | |
| Webhook URL | `webhook_url` | — | Primary endpoint |
| Webhook URL 2 | `webhook_url_2` | — | Secondary (CRM + sheet, for example) |
| Webhook secret | `webhook_secret` | — | HMAC-SHA256 signing key |
| Webhook version | `webhook_version` | `v2` | Payload shape |
| Webhook retry | `webhook_retry` | `true` | Three attempts, exponential backoff |
| Webhook events | `webhook_events` | `lead.created`, `lead.updated`, `visit.scheduled` | Tick from the 12 available |
| Elementor forms → enquiries | `elementor_forms_to_enquiries` | `true` | |
| Inbound secret | `inbound_secret` | — | Shared secret for inbound REST writes |
| Test mail last sent | `test_mail_last_sent` | — | Diagnostic |

Two tool buttons sit on this screen: **Send test email** and **Send test webhook**. Use them after any change — they are the fastest way to prove the plumbing before real enquiries depend on it.

---

## 7. Group 6 — Advanced

| Setting | Key | Default | Notes |
|---|---|---|---|
| Pages | `pages` | `[]` | slug ⇒ post ID map |
| Setup done | `setup_done` | `false` | |
| Design tokens | `design_tokens` | `[]` | Colour/font overrides |
| Delete data on uninstall | `delete_data_on_uninstall` | `false` | **Dangerous.** See §9 of `02` |

### Tools on this screen

| Tool | What it does |
|---|---|
| **Repair data** | `Install\RepairData::run()` — re-links localities, recreates missing pages |
| **Rebuild search index** | `SearchIndex::rebuild_batch()` in loops until done |
| **Rescan duplicates** | `Duplicate::scan()` across the whole inventory |
| **Purge caches** | `Support\Cache::purge_all()` |
| **Export settings** | Download the settings array as JSON |
| **Run maintenance now** | Fires `Scheduler::run_daily()` immediately |

---

## 8. Recommended configuration by office size

### One-person office
- Verification mode: `optional`
- Listing expiry: `0`
- Pocket agents edit live: `true`
- Search alerts: `off`
- Webhooks: `off`

### 2–10 agents
- Verification mode: `required`
- Listing expiry: `90`
- Pocket agents edit live: `false` (changes go to Change Requests)
- Lead assignment: round-robin
- Search alerts: `on`

### 10+ agents / multi-city
- Everything above, plus:
- Multi-agency: `on`
- Retention: `365` days
- Webhooks: `on` with a CRM endpoint
- Assign rules per locality

---

## 9. Practice mode

`Support\PracticeMode` (`practice_mode`, default `false`).

When on, `PracticeMode::seed()` creates three demo properties with bundled photos and a visible **PRACTICE** badge on every screen. `PracticeMode::clear()` removes them and nothing else.

Use it to learn the system or to train a new agent. Practice records are tagged `practice = 1` in the database and are excluded from exports, reports and search results unless `include_practice` is explicitly requested.

---

## 10. Configuration that is *not* a setting

| Behaviour | Where it really lives |
|---|---|
| Status words | `Support\Vocabulary` — code, not settings |
| Duplicate strictness bands | `Data\Duplicate::bands()` — code |
| Which fields are undoable | `Data\Undo::fields()` — code |
| Form field types | `Forms\FieldTypes::all()` — code |
| Page block order | **Page blocks** screen (`Data\Templates`) |
| Colours and fonts | **Colours & fonts** screen (`Support\DesignTokens`) |

---

## 11. Troubleshooting settings

| Symptom | Cause | Fix |
|---|---|---|
| Change saves but nothing changes | Page cache | Settings → Advanced → Purge caches |
| Notification email not arriving | No SMTP, or `notify_email` empty | SMTP plugin; use Send test email |
| Prices show wrong symbol | `currency_symbol` | Group 2 |
| Search filters not showing | Filter turned off, or `enabled_filters` stale | Group 3 → re-save the filter list |
| Website still English after choosing Hinglish | Office vs website language are different settings | Set **Website language**, not office language |
| Setting reverts after upgrade | Object cache holding stale option | Purge object cache |
