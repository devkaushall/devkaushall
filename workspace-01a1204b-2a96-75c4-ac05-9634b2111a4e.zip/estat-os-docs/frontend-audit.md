# Estat.OS public frontend audit — 3.6.6

Internal working document. It exists to decide what to change, not to be read
as a deliverable. Source of truth: `/home/user/plugin/estat-os/`.
Live reference: `https://mayfairpropertiesdevelopers.com/project/shf-nivasa-ddjay/`
and `/projects/`.

---

## A. What currently works

* Token layer is real and complete. `assets/css/tokens.css` defines the whole
  palette (#F9F7F2 / #1A1A1A / #725B2F), the type scale, the spacing scale and
  the radii. `Frontend::register_assets()` correctly registers `estat-tokens`
  **before** `estat-public`, so the website does consume the token layer.
* `public.css` already contains a designed component set: `.estat-card`,
  `.estat-card-media`, `.estat-facts`, `.estat-section`, `.estat-prose`,
  `.estat-chips`, `.estat-btn`, `.estat-crumbs`, `.estat-gallery-*`,
  `.estat-empty`, `.estat-pagination`, `.estat-panel`, `.estat-pill`,
  `.estat-detail`, `.estat-aside`. Nothing here needs reinventing.
* `single-listing.php` is the one page that actually uses that component set,
  and it is genuinely good: breadcrumb → head → price → gallery → facts →
  description → features → amenities → documents → map → agent → enquiry.
  It is the reference the other pages should be pulled up to.
* Template fallback in `Frontend::choose_template()` is defensive and correct:
  theme template wins, Elementor template wins unless `page_renderer = plugin`,
  plugin fallback last, whole thing in a `try/catch`.
* `Seo.php` is thorough (canonical, robots, Rank Math/Yoast bridges, sitemap
  exclusion, `plan()`/`decide()`), and `Schema.php` prints conservative JSON-LD
  for listings and agents.
* `Templates::default_blocks( 'project' )` already defines the intended project
  page block order (header, cover, facts, description, gallery, floor_plans,
  amenities, location, units, share, enquiry) and the admin Page-blocks screen
  already edits it.

## B. What is visually weak

1. **Project detail page is a database row.** `single-project.php` is 169 lines:
   H1, one subtitle line, a bare `the_post_thumbnail()`, a flat 10-cell facts
   grid, a WhatsApp button, a `<ul>` of highlights, then `the_content()`.
   No hero, no cover treatment, no gallery, no map, no enquiry form, no
   related content. It stops where a finished page starts.
2. **Projects archive is a title list.** `archive-project.php` prints
   thumbnail + title + "developer · locality · price" in one joined string.
   No header copy, no filters, no status/type signal, no empty state design.
3. **`[estat_projects]` shortcode is off-brand.** Inline `style=` attributes,
   `border-radius:10px`, `border-radius:999px` pills and a progress bar —
   against an explicit design rule of 2px radius and squared tags.
4. **Long descriptions are one dense paragraph.** The SHF Nivasa page prints a
   ~200-word wall of text. Readable, but with no structure, no sub-headings and
   no measure control.

## C. What is structurally weak

5. **Two competing class-name families.** `public.css` designs
   `.estat-page-head`, `.estat-detail-head`, `.estat-section-head`,
   `.estat-btn`, `.estat-crumbs`. The templates emit `.estat-page-header`,
   `.estat-single-header`, `.estat-single-title`, `.estat-article`,
   `.estat-ui-btn-primary`, `.estat-project-highlights`, `.estat-agent-role`,
   `.estat-result-count`, `.estat-sort`, `.estat-insight-card`,
   `.estat-search-field`, `.estat-directory-meta`, `.estat-archive-header`.
   **Every one of those has zero CSS rules.** That is the single biggest cause
   of the "raw" look: the designed stylesheet exists, the templates don't use
   its names.
6. **Card markup is copy-pasted five times.** `archive-listing.php`,
   `archive-project.php`, `taxonomy-estat_locality.php`,
   `taxonomy-estat_amenity.php`, `taxonomy-estat_feature.php` each hand-roll
   `<article class="estat-card">`. Meanwhile `Components::card()` builds a far
   richer card (badges, price, chips, favourite, compare) that only listings
   ever get. The five copies cannot be fixed in one place.
7. **Project page-block architecture is defined but never honoured.**
   `Templates::get_blocks( 'project' )` returns an ordered, admin-editable
   block list and nothing on the public side reads it.
8. **Project media is stored but unreachable.** The project schema holds
   `_estat_gallery`, `_estat_floor_plans`, `_estat_brochures`,
   `_estat_latitude`, `_estat_longitude` — but `Projects::to_array()` returns
   none of them except lat/lng, so no template can render them.
9. **Inline styles scattered through PHP.** 57 in `Components.php` alone, plus
   `Shortcodes::projects()`, `Shortcodes::projects_by_stage()` and
   `single-listing.php`. Bypasses the token layer by construction.

## D. What is technically risky

10. **Internal language leaks to the public site.** Confirmed live:
    "Rate on the office sheet: 92,000 per sq ft (unit not confirmed in the
    source sheet)" is printed under **What stands out** on a public project
    page. `_estat_highlights` is a single textarea the office and the importer
    both write into, with no public/internal split.
    **This is the only data-integrity defect that is live right now.**
11. **No project structured data.** `Schema::output()` handles listing, agent
    and front page only. Project pages emit nothing.
12. **Project archive has no query control.** `Frontend::archive_query()` sets
    `posts_per_page` for listings and taxonomies but not for
    `PostTypes::PROJECT`, so archive paging depends on the global reading
    setting.
13. **No breadcrumbs on project / archive / taxonomy pages.** `single-listing`
    has them, nothing else does.
14. `archive-agent.php` renders `<main class="estat-archive">` with an `<h1>`
    and **no `.estat-container`**, so it is full-bleed while every sibling page
    is contained.

## E. What should be changed

| # | Change | Where |
|---|--------|-------|
| 1 | Public/internal text firewall; every public string passes through it | **new** `Support/PublicText.php` |
| 2 | Return gallery / floor plans / brochures / labels / listing count | `Data/Projects.php` |
| 3 | Shared `project_card()`, `project_grid()`, `project_filters()`, `projects_directory()`, `breadcrumbs()`, `gallery()`, `documents()`, `checkgrid()`, `empty_state()` | `Frontend/Components.php` |
| 4 | Project page renders `Templates::get_blocks('project')` in order | **new** `Frontend/ProjectPage.php` |
| 5 | Rewrite project detail | `templates/single-project.php` |
| 6 | Rewrite projects archive: header + filters + grid + pagination + empty state | `templates/archive-project.php` |
| 7 | Project + breadcrumb structured data | `Frontend/Schema.php` |
| 8 | Project archive query control (page size + filters) | `Frontend/Frontend.php` |
| 9 | Alias layer mapping unstyled legacy class names onto designed components; new project components; 480/768/1024/1440 rules | `assets/css/public.css` |
| 10 | Remove inline styles from `Components::directory()`, `Components::search_form()`, `Shortcodes::projects()`, `Shortcodes::projects_by_stage()`, `single-listing.php` | those files |
| 11 | Route listing archive + the three taxonomy templates through `Components::card()` | those templates |
| 12 | Fix `archive-agent.php` container | that template |

## F. What should NOT be changed

* The token layer's *values* — only additive new tokens.
* `Frontend::choose_template()` resolution order (theme → Elementor → plugin).
* `Seo::plan()` / `decide()` / canonical / robots behaviour.
* Existing URLs, slugs, rewrite rules, shortcode names and their attributes.
* The existing listing card's information content — only its CSS home changes.
* Any admin screen. (Page blocks already stores project blocks; no admin work
  is required to read them.)
* Elementor templates or the live `/projects/` page content itself — the fix
  lands in the plugin and reaches that page through `[estat_projects]`.

## G. Files responsible

| File | Line count | Role |
|------|-----------:|------|
| `includes/Frontend/templates/single-project.php` | 169 | the page to rebuild |
| `includes/Frontend/templates/archive-project.php` | 62 | the directory to rebuild |
| `includes/Frontend/Components.php` | 1066 | card, directory, search form, gallery, map, agents |
| `includes/Frontend/Shortcodes.php` | ~480 | `estat_projects`, `estat_projects_by_stage` |
| `includes/Frontend/templates/archive-listing.php` | 66 | duplicate card |
| `includes/Frontend/templates/taxonomy-*.php` | 38/39/76 | duplicate cards |
| `includes/Frontend/templates/archive-agent.php` | 23 | missing container |
| `includes/Frontend/Schema.php` | 196 | no project schema |
| `includes/Frontend/Frontend.php` | 254 | archive query, asset order |
| `includes/Data/Projects.php` | ~330 | `to_array()` gaps |
| `includes/Data/Templates.php` | ~130 | project block definitions (unused) |
| `assets/css/public.css` | 502 | designed set + missing aliases |
| `assets/css/tokens.css` | 340 | token layer (additive only) |
| `assets/js/public.js` | 350 | gallery + favourite/compare |

---

## Verification notes

* Live project page confirmed leaking: `…/project/shf-nivasa-ddjay/`
  → "What stands out" → *"Rate on the office sheet: 92,000 per sq ft
  (unit not confirmed in the source sheet)"*.
* Live `/projects/` is drawn by Elementor (numbered cards, name + "View
  project" only — no locality, developer, status or price). It is fed by the
  `[estat_projects]` shortcode, so fixing that shortcode fixes the page without
  touching Elementor.
* Unstyled class list verified by grep against `public.css`, `tokens.css` and
  `forms.css` — zero matches each: `estat-search-field`,
  `estat-ui-btn-primary`, `estat-ui-quiet-list`, `estat-directory-meta`,
  `estat-archive-header`, `estat-project-highlights`, `estat-single-header`,
  `estat-page-header`, `estat-article`, `estat-agent-role`,
  `estat-single-description`, `estat-whatsapp-inline`, `estat-section-title-sm`,
  `estat-result-count`, `estat-sort`, `estat-insight-card`,
  `estat-project-listings`.

---

## What was actually done (3.7.0)

### New files

| File | Why |
|------|-----|
| `includes/Support/PublicText.php` | The public/internal firewall. `clean()`, `prose()`, `lines()`, `list_items()`, `is_internal()`, plus a guarded `the_content` filter on single projects. Two filter hooks: `estat_public_internal_markers`, `estat_public_aside_patterns`. |
| `includes/Frontend/ProjectPage.php` | Reads `Templates::get_blocks( 'project' )` and renders each block. Two filter hooks: `estat_project_block_html`, `estat_project_block_html_{$id}`. |

### Changed

| File | Change |
|------|--------|
| `Data/Projects.php` | `to_array()` now returns `gallery`, `floor_plans`, `brochures`, `stage_label`, `category_label`, `unit_type_list`, `highlight_lines`, `locality_terms`. New `ids()` and `listing_count()` helpers. |
| `Data/PostTypes.php` | `has_archive` for projects is now `(bool) apply_filters( 'estat_project_has_archive', false )` — see below. |
| `Frontend/Components.php` | New: `project_card()`, `project_grid()`, `project_filters()`, `project_filters_from_request()`, `projects_directory()`, `project_query()`, `project_price_bands()`, `breadcrumbs()`, `gallery()`, `documents()`, `checkgrid()`, `section_head()`, `empty_state()`. 57 inline styles reduced to 1 (a data-driven progress width). |
| `Frontend/Shortcodes.php` | `estat_projects` and `estat_projects_by_stage` rebuilt on the shared components; shortcode attributes unchanged, `filters="1"` added. |
| `Frontend/Schema.php` | New `project()` (Residence) and `breadcrumbs()` (BreadcrumbList), emitted as an `@graph`. Filter hooks `estat_schema_project`, `estat_schema_breadcrumbs`. |
| `Frontend/Frontend.php` | `archive_query()` now sizes the project archive too. |
| `Frontend/WhatsApp.php` | Project-aware message and button label; reads `_estat_price_min`/`_estat_price_max`. |
| `Frontend/Share.php` | `render_row()` reads whichever record it is given; Print only offered where Print works. |
| `Frontend/Pages.php` | The `projects` page-block shortcode now includes `filters="1"`. |
| `templates/single-project.php` | Thin shell over `ProjectPage`. |
| `templates/archive-project.php` | Directory: header, filters, grid, pagination, empty state. |
| `templates/archive-listing.php` | Uses `Components::card()`; count comes from the main query instead of a second full search. |
| `templates/taxonomy-estat_locality.php` | Properties + projects in this locality, both as real cards. |
| `templates/taxonomy-estat_amenity.php`, `taxonomy-estat_feature.php` | Now identical, built on `Components::card()`. |
| `templates/archive-agent.php` | Wrapped in `.estat-container` with a proper header. |
| `templates/single-listing.php` | 15 inline styles moved to the stylesheet. |
| `assets/css/public.css` | 502 → 1228 lines. Alias layer, project components, EMI, timeline, locality cards, breadcrumb list, and designed rules at 1440 / 1280 / 1024 / 768 / 480. The one unscoped `hr{}` rule is now `.estat-public hr{}`. |

### The archive question — decided, not guessed

`estat_project` has had `has_archive => false` since it was written, so
`archive-project.php` has never been reachable through WordPress, and
`/projects/` on the live site is a WordPress **Page** built in Elementor that
draws `[estat_projects]`. Turning the post type archive on would register
`/project/` — and on a site that already has a page there, it would fight it
for the same URL.

So the archive stays off by default and the directory reaches the live site
through the shortcode, which is the delivery path the site already uses. The
archive template is fully built for sites that want it, and
`estat_project_has_archive` switches it on. No live URL changes.

## Validation (WordPress 7.1.2, PHP 8.4, WP_DEBUG on)

* `php -l` clean on every touched file.
* Zero PHP warnings, notices or deprecations originating in the plugin across
  11 page loads (project archive, 3 project singles, property single, 2
  locality, team single, 2 shortcode pages, home).
* Internal-language leak check on the seeded SHF Nivasa page: **0** matches for
  "source sheet", "office sheet", "not confirmed", "unconfirmed", "unverified",
  "TBC", "RERA number not found", "internal note", "to be verified" — down from
  a live leak of the first of those.
* Project schema emitted as `@graph` with `Residence` + `BreadcrumbList`;
  `offers` and `geo` present only because the record holds them, absent on
  records that do not.
* Empty-data project: only 4 of 11 blocks render (header, cover plate, share,
  enquiry). No empty facts grid, no empty gallery, no empty amenities heading,
  no map.
* Directory filters: each dropdown populated only from values at least one
  published project actually holds; a filter with no matches produces the
  designed empty state, not an empty grid.
* 14 plugin tables created — confirms the figure already documented.

## Not changed, on purpose

* Token values — additions only, and in fact no new tokens were needed.
* `Frontend::choose_template()` resolution order.
* `Seo::plan()`/`decide()`, canonical, robots, sitemap behaviour.
* Every existing URL, slug, rewrite rule, shortcode name and attribute.
* Any admin screen.
* The live `/projects/` page itself.

---

# 3.8.0 — "Explore this project"

The single-project page moved from *static* to *interactive*, and the same
principles were carried onto the property page, the properties directory and
the rest of the public surface. Recorded here because the audit file is the
running record of the frontend work.

## Shape of the change

One new script (`assets/js/ui.js`, handle `estat-ui`) and one new CSS block in
`assets/css/public.css`. Behaviour travels through `data-estat-*` attributes
that a PHP component writes, which buys three things:

1. **Nothing loads or runs where it is not used.** Every module looks for its
   own root element and returns at once when it is not there. `wp_enqueue_script(
   'estat-ui' )` is called from `Components::interact()`, which is called only
   by a component that was actually drawn — never globally.
2. **The page is complete before any script runs.** Real anchors, real buttons
   with real `href`s, every word present in the document. A slow, blocked or
   switched-off script degrades the page, it does not break it.
3. **Reusable.** The gallery, the folded writing, the facts with notes, the
   filter row, the highlight grid, the media cards and the phone bar are the
   same components on a project page and a property page.

`window.estatUi.refresh()` re-runs everything; each element remembers that it
has been wired, so a re-run only ever touches new markup and never double-binds
a control.

## New components (`includes/Frontend/Components.php`)

`gallery()` (rebuilt), `hero_media()`, `section_nav()`, `progress()`,
`read_more()`, `filter_bar()`, `share_actions()`, `media_cards()`,
`fact_grid()`, `highlight_grid()`, `amenity_groups()`, `mobile_actions()`,
plus the private `interact()` (enqueues `estat-ui`) and `icon_for()`.

## Data integrity, enforced in the components

* `section_nav()` returns `''` with fewer than two sections — one section is a
  heading, not a navigation.
* `filter_bar()` returns `''` with fewer than two groups, and **never counts at
  runtime**; every count is written on the server from the real data.
* `read_more()` keeps the whole text in the DOM; only the visible height is
  limited.
* `highlight_grid()` splits only on a dash already present in the office's own
  text and adds no wording.
* `amenity_groups()` derives groups from the amenity term names via the
  `estat_amenity_group_map` filter; empty groups are never offered and `other`
  is always last. On the project page the filter is dropped when there is only
  one group — "All 3 / Security 3" is not a choice.
* `gallery()`/`hero_media()` list surplus photographs as URL-only hidden spans
  (no `<img>`, no request) and fall back to an editorial plate, never a broken
  frame.
* Project map is drawn **only from the project's own coordinates**. The office
  coordinates fallback that is right for a property would pin an office marker
  on a development that is somewhere else entirely.
* Project units filter offers only availability values the office actually
  recorded; a property with the field blank is under "All" and is not given a
  state on the strength of a guess.

## Two leaks closed

1. **`PublicText::prose()` judged the whole block, not the paragraph.** A
   description with no block tags (typed straight into the editor box) was one
   block, so one office sentence anywhere in it removed every public sentence
   with it. It now splits on blank lines first and works paragraph by
   paragraph.
2. **The schema description was the raw text.** `Schema::listing()` published
   `get_the_excerpt()` unfiltered, so an office note removed from the screen
   was still printed in the JSON-LD for every crawler. It now goes through
   `PublicText::prose()` the same way the visible description does.
   Listing highlights were also printed unfiltered in single-listing.php;
   they now go through `PublicText::clean()`.

## Verified

* 13 URLs rendered on WP 7.1.2 / PHP 8.4: zero PHP notices, warnings or
  fatals; zero internal-note leaks.
* `assets/js/ui.js` syntax-checked with `node --check`.
* Headless DOM harness (jsdom) across every page: lightbox opens, steps,
  closes on Escape/veil, counter reads `n / m`; media cards open a frame;
  read-more toggles `aria-expanded`; every filter button's server-written
  count equals the number of items actually shown, for every button on every
  filter bar; accordions open and close; every jump-list link points at a
  section that really exists; zero runtime errors.
* Enquiry: success sets `is-sent` and shows the acknowledgement; "send
  another" restores a form that still holds what was typed; error shakes the
  block and leaves the form in place. Exactly one form on the page.
* `estatUi.refresh()` called three times — controls still respond once.

## Still open

* Project meta has no `_estat_video_url` / `_estat_tour_url` fields in the
  admin screen yet. `Projects::to_array()` now reads them and
  `media_cards()` draws them, but nothing writes them, so in practice a
  project shows the brochure and the floor plans only.

---

## 3.9.0 — the five things that were never earning their place

Basis: 3.8.0. Rule for this release: **delete completely, leave no trace.** Not
switched off, not hidden — taken out of the code, the menus, the templates, the
language files, the stylesheet and the database.

### What went

| # | Removed | Where it lived |
|---|---------|----------------|
| 1 | Insights | `Data/Insights.php`, `Admin/Screens/InsightsScreen.php`, `Data/PostTypes::INSIGHT`, `Data/Taxonomies::INSIGHT_KIND` / `INSIGHT_TOPIC`, 2 public templates, `InsightsWidget`, `estat-insights` menu page, `estat_manage_insights` capability, `save_insight` action, help text in Partials / Settings / Team |
| 2 | `estat_document` post type | `Data/PostTypes::DOCUMENT` + capability + redirect map entry |
| 3 | Dead half of the property screen | `ListingsScreen::render()`, `::attention_card()`, `::listing_table()` — 928 → 648 lines. `::editor()` and the propose/change-request block stay |
| 4 | The PC dashboard at `/dashboard/` | `includes/Office/` (Dashboard.php + Screens.php), `Plugin.php` registration, Settings QR code + overview link |
| 5 | `[estat_office]`, `[estat_public_pages]` | `Shortcodes::office_page()`, `Shortcodes::public_pages()` and both registrations |

### The migration (`Migrator::step_13`, DB version 12 → 13)

Deleting the code is not enough: a site that ran 3.8.0 still holds the rows.
Step 13 runs once on update and is safe to repeat.

1. Force-deletes every `estat_insight` and `estat_document` post (with its meta).
2. Removes `estat_insight_kind` and `estat_insight_topic` fully — the pairing
   with a record, the pairing itself, the term row, its meta and its cache.
   WordPress cannot do this alone: once a taxonomy is unregistered,
   `wp_delete_term()` stops early and leaves the name behind, so every part is
   removed by hand.
3. Strips `[estat_office]` / `[estat_public_pages]` out of any page content.
   Unknown shortcodes print as literal square brackets, so the page is cleaned
   rather than left showing them. Everything else on the page is untouched.
4. Deletes the `estat_office_flush` option and flushes the rewrite rules so the
   `/dashboard/` address no longer resolves.

`uninstall.php` carries the same list (it runs without the plugin loaded), minus
the two removed names.

### Aftermath checks that must keep passing

* `PostTypes::all()` → listing, project, agent, agency. `Taxonomies::all()` →
  locality, feature, amenity.
* 20 admin pages; no `estat-insights`. Visiting it returns 403.
* 18 Elementor widgets (was 19).
* 17 shortcodes (was 19).
* 11 public templates (was 13).
* Language catalogs regenerated (`make-pot` → `msgmerge` → `msgfmt`), no
  obsolete entries left behind.
* No `insight` string anywhere in `assets/`; `--lh-article` kept, its comment
  now names the property and project descriptions it actually styles.
