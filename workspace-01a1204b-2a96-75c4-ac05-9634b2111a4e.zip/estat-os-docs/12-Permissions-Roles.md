# 12 — Permissions, Roles & Access Control

## Simple meaning (Hinglish)

Do role hain: **Office Owner** (sab kuch) aur **Office Agent** (apna kaam). Har kaam ke liye alag permission hai — jaise property delete karne ki permission sirf owner ke paas hai. Isse galti se kuch permanently delete nahi hota.

---

## 1. Roles

`Security\Roles` installs two roles plus administrator compatibility.

| Constant | Key | Label |
|---|---|---|
| `Roles::OWNER` | `estat_office_owner` | Office Owner |
| `Roles::AGENT` | `estat_office_agent` | Office Agent |

Installation (`Roles::install()`) is **idempotent** — safe on every activation. The full capability set is also granted to `administrator` so an admin can always reach everything.

---

## 2. The 24 capabilities

| Capability | What it allows |
|---|---|
| `estat_manage_settings` | Change office settings |
| `estat_manage_listings` | Add and edit listings |
| `estat_publish_listings` | Publish listings to the website |
| `estat_bin_listings` | Move properties to the bin |
| `estat_restore_listings` | Bring properties back from the bin |
| `estat_empty_bin` | Empty the bin and delete permanently |
| `estat_delete_listings` | Delete permanently — **the manager's key** |
| `estat_verify_listings` | Mark listings as office verified |
| `estat_manage_projects` | Manage societies and projects |
| `estat_manage_team` | Manage the team |
| `estat_manage_insights` | Write blogs, articles and insights |
| `estat_manage_leads` | Work with enquiries |
| `estat_assign_leads` | Assign enquiries to team members |
| `estat_erase_leads` | Erase personal information |
| `estat_manage_visits` | Manage site visits |
| `estat_manage_forms` | Build and edit forms |
| `estat_view_submissions` | See form submissions |
| `estat_import_inventory` | Import spreadsheets |
| `estat_export_inventory` | Export spreadsheets |
| `estat_view_reports` | See reports |
| `estat_manage_integrations` | Manage connections and outside programs |
| `estat_view_audit` | See the activity history |
| `estat_run_maintenance` | Run maintenance tools |
| `estat_request_listings` | Ask the office to change someone else's property |
| `estat_review_listings` | Approve or turn down changes proposed from the field |

---

## 3. What each role gets

### Office Owner — everything above, plus
- Empty the bin
- Delete permanently
- Approve / decline change requests
- See the audit log
- Run maintenance

### Office Agent — a working subset
```
estat_manage_listings
estat_bin_listings
estat_restore_listings
estat_request_listings
estat_manage_leads
estat_manage_visits
estat_manage_insights
estat_view_submissions
estat_export_inventory
```

Note what is **absent**, deliberately:
- `estat_delete_listings` — an agent can bin, never destroy.
- `estat_manage_settings` — configuration is the owner's job.
- `estat_view_reports` — numbers are the owner's job.
- `estat_manage_projects` / `estat_manage_team` — structure is the owner's job.
- `estat_manage_forms` — forms change the website for everyone.

---

## 4. Per-record ownership

Capabilities decide *what kind of action* is allowed. Ownership decides *which records*.

| Check | Where | Meaning |
|---|---|---|
| `Pocket::owns( $record_id )` | Pocket | Is this my record? |
| `Pocket::can_see( $post )` | Pocket | May I see it at all? |
| `Pocket::sees_everything()` | Pocket | Office override |
| `Screens::may_see_enquiries()` | Pocket | Are enquiries visible to me? |
| `Screens::lead_is_mine( $lead )` | Pocket | Is this enquiry mine? |
| `Field\Requests::may_edit_directly()` | Everywhere | Do I bypass the approval queue? |

**Server-side, always.** Hiding a button is cosmetic; the check that matters runs before the write.

---

## 5. The enforcement pattern

Every write in the plugin follows the same three steps, in this order:

```php
// 1. Capability
if ( ! current_user_can( 'estat_delete_listings' ) ) {
    wp_die( ... );
}

// 2. Nonce
check_admin_referer( 'estat_delete_record_' . $id );

// 3. Work
Data\Bin::delete_forever( $id );
```

`Admin\Actions::handle()` applies this to all ~60 admin actions. `Pocket\Actions` and `Office\Dashboard::post()` apply the same shape to their own surfaces.

REST endpoints use `permission_callback`:

```php
'permission_callback' => static fn() => current_user_can( 'estat_manage_leads' ),
```

Public read endpoints use `'__return_true'` — properties are meant to be public. Write and private-read endpoints always check.

---

## 6. Where each screen checks

| Screen | Capability required |
|---|---|
| Today | `estat_manage_listings` |
| Add a home | `estat_manage_listings` |
| Properties | `estat_manage_listings` |
| Bin | `estat_bin_listings` |
| Duplicates | `estat_manage_listings` |
| Enquiries | `estat_manage_leads` |
| Societies / Projects | `estat_manage_projects` |
| Team | `estat_manage_team` |
| Import & export | `estat_import_inventory` |
| Settings | `estat_manage_settings` |
| Pipeline | `estat_manage_leads` |
| Site Visits | `estat_manage_visits` |
| Change Requests | `estat_request_listings` |
| Website forms | `estat_manage_forms` |
| Search Alerts | `estat_manage_leads` |
| Reports | `estat_view_reports` |
| Gallery & Media | `estat_manage_listings` |
| Insights | `estat_manage_insights` |
| Page blocks | `estat_manage_settings` |
| Colours & fonts | `estat_manage_settings` |
| Finish setup | `estat_manage_settings` |

Screens a user cannot open are simply absent from the menu — but the server re-checks on render anyway.

---

## 7. REST API permission matrix

| Endpoint | Who |
|---|---|
| `GET /estat/v1/health` | Public |
| `GET /estat/v1/properties` | Public |
| `GET /estat/v1/properties/{id}` | Public |
| `GET /estat/v1/projects/{id}/stats` | Public |
| `GET /estat/v1/agents` | Public |
| `GET/POST /estat/v1/leads` | `estat_manage_leads` |
| `POST /estat/v1/leads/{id}` | `estat_manage_leads` |
| `GET/POST /estat/v1/visits` | `estat_manage_visits` |
| `POST /estat/v1/visits/{id}` | `estat_manage_visits` |
| `GET /estat/v1/alerts` | `estat_manage_leads` |
| `POST /estat/v1/alerts` | Public (a visitor creates their own alert) |
| `POST /estat/v1/share` | Public |
| `POST /estat/v1/maintenance` | `estat_run_maintenance` |
| `GET /estat/v2/*` | Public read |

Full details in `19-Developer-Reference.md`.

---

## 8. Recommended setups

### Sole trader
- You: `administrator` (gets everything).
- Nobody else.

### Small office (2–5)
- Owner: `estat_office_owner`
- Agents: `estat_office_agent`
- Consider `pocket_agents_edit_live = true` for speed.

### Growing office (5–20)
- Owner: `estat_office_owner`
- Senior agents: `estat_office_agent` + `estat_verify_listings` + `estat_assign_leads` (grant via a role editor)
- Agents: `estat_office_agent`
- `pocket_agents_edit_live = false` — all field changes become requests.

---

## 9. Front-end office dashboard access

`/office/` is gated by `Office\Dashboard::gate()`. A user who is not logged in, or lacks the capability, is shown a door screen rather than an error. There is no way to reach office data through that URL without permission.

---

## 10. Audit

`Audit\AuditLog::record( $action, $object_type, $object_id, $context )` writes to `estat_audit` with the user ID and time.

Recorded by default: settings changes, bin moves, restores, permanent deletes, imports and undos, bulk operations, cron runs, webhook deliveries, lead status moves, verification changes.

`AuditLog::purge_older_than( $days )` keeps the table small; wire it to a schedule if you run a very busy office.

---

## 11. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Menu item missing | Missing capability | Check the role |
| "You are not allowed" on save | Capability or nonce | Reload the page (stale nonce) |
| Agent can delete permanently | They have an owner/admin role | Change to `estat_office_agent` |
| REST returns 401 | Not logged in, or wrong capability | Use an application password or a logged-in cookie |
| Audit log empty | No one has done an audited action yet, or purged | Check `estat_audit` |
| Owner cannot see Reports | Role lost its capability | Deactivate/activate to re-run `Roles::install()` |
