# 20 — Implementation Guide (build it from scratch)

This chapter is for a developer who must **reproduce** Estat.OS 3.6.6, or extend it substantially. It gives the file-by-file order, the reason for each piece, and the acceptance test that tells you it works.

---

## 1. Ground rules before writing a line

1. **PHP 7.4 syntax only.** No PHP 8 attributes, no enums, no `readonly`.
2. **`declare( strict_types = 1 );`** at the top of every file.
3. **Namespace `EstatOS\`**; one class per file; file name = class name.
4. **No Composer, no build step, no framework.** Plain PHP, plain WordPress APIs.
5. **No jQuery on the public site.**
6. **Elementor is optional** — every Elementor path is guarded.
7. **Sanitise in, escape out, prepare every query.**
8. **Statuses come from `Support\Vocabulary` + `Support\Status`.** Never a hard-coded word in a template.
9. **One duplicate engine, one status law, one audit trail.**

---

## 2. Build order

### Stage 0 — the skeleton

| File | Do | Acceptance |
|---|---|---|
| `estat-os.php` | Plugin header, version guard, constants, activation hooks, boot | With PHP 7.3 you see one notice and no fatal; with 7.4+ it boots |
| `includes/Autoloader.php` | Map `EstatOS\A\B` → `includes/A/B.php` | `new \EstatOS\Data\Listings()` autoloads |
| `includes/Plugin.php` | Singleton, `boot()`, the 40-module map, `estat_modules` filter, `estat_loaded` action | `estat_loaded` fires; a test module can be injected |
| `includes/functions.php` | Shared helpers used before classes exist | — |

> Get the language loading right here, not later: `plugins_loaded` (1) → `after_setup_theme` (999) → `wp_loaded` (999). One load is not enough.

### Stage 1 — storage

| File | Do | Acceptance |
|---|---|---|
| `Install/Schema.php` | 14 tables with `dbDelta()`; `tables()`, `table()`, `healthy()`, `flush_health()` | Re-running install changes nothing; all 14 exist |
| `Install/Activator.php` | Schema → roles → register CPTs/taxonomies → settings → `Forms::seed()` → cron → cache purge → setup flag → version → flush | Fresh install lands on setup; re-activate is a no-op |
| `Install/Deactivator.php` | Unschedule cron only | Deactivating deletes nothing |
| `Install/Migrator.php` | `maybe_upgrade()` on `init` 1, idempotent steps | Old database upgrades without data loss |
| `Install/RepairData.php` | `repair_localities()`, `repair_pages()` | Broken links heal |
| `uninstall.php` | Erase **only** when opted in | Unticked delete keeps everything |
| `Data/PostTypes.php` | 6 CPTs on `init` **0** | `/properties/` resolves |
| `Data/Taxonomies.php` | 5 taxonomies on `init` **0** and `elementor/init`; the `get_the_terms` guard | No Elementor `wp_kses_post` fatal |
| `Data/Meta.php` | `register_meta` + `sanitize_value` per field | REST shows typed meta |

### Stage 2 — the domain

Build in this order, because each depends on the previous:

```
Settings\Settings        (everything reads settings)
Security\Roles           (everything checks capabilities)
Support\Sanitize         (everything sanitises)
Support\Vocabulary       (every fixed list)
Support\Status           (every legal move)
        │
Data\Listings  Data\Projects  Data\Agents
        │
Search\SearchIndex  Search\Query
        │
Data\Duplicate  Data\Health  Data\Highlights  Data\Media
        │
Leads\Leads  Leads\LeadEvents  Leads\Visits
        │
Forms\Forms  Forms\FieldTypes  Forms\Renderer  Forms\Style  Forms\Submissions
        │
Field\Requests  Data\Bin  Data\Undo  Data\Worklist  Data\Templates
Audit\AuditLog  Webhooks\Webhooks  Notifications\Notifier
Cron\Scheduler  Privacy\Privacy
```

| File | The one thing to get right | Acceptance |
|---|---|---|
| `Data/Listings.php` | `validate()` returns `[ok, errors, warnings]` — three buckets, not a boolean | A short description warns; a missing title errors |
| `Data/Projects.php` | `listing_counts()` is **batched** | 50 projects = 1 query, not 51 |
| `Search/SearchIndex.php` | One flat row per listing, re-indexed on save/status/term | After a direct DB edit, rebuild fixes it |
| `Search/Query.php` | Build `WHERE` from a **column whitelist** only | A crafted key cannot reach SQL |
| `Data/Duplicate.php` | Blocking before comparison; three bands; human reasons | 2,000 records scan inside the time budget |
| `Leads/Leads.php` | `dedupe_hash` + `idempotency_key` unique keys | Double submit = one lead |
| `Forms/Submissions.php` | Re-read the definition from the DB; never trust the browser | A tampered POST is rejected |
| `Data/Bin.php` | Every batch writes an undo token | Bulk 20 → one Undo restores all 20 |
| `Field/Requests.php` | `clean_changes()` typed per field | A request cannot write an illegal value |
| `Cron/Scheduler.php` | Resumable repair via `estat_index_repair_offset` | Interrupted repair continues |

### Stage 3 — the office

| File | Do | Acceptance |
|---|---|---|
| `Admin/Admin.php` | Menu, assets only on plugin screens, routing, 5 AJAX handlers | No plugin CSS on the Posts screen |
| `Admin/Actions.php` | One handler; capability → nonce → work → redirect | Refresh never repeats an action |
| `Admin/Screens/*.php` | 20 screens, render only | No SQL in any screen |
| `Admin/Screens/Partials.php` | Shared header, card, stat, field, bulk bar, pagination, confirm panel | Escaping is automatic for screen authors |
| `Office/Dashboard.php` + `Office/Screens.php` | `/office/` with a capability gate | Anonymous gets a door, not data |
| `Pocket/Pocket.php` + `Screens` + `Steps` + `Actions` | `/pocket/`, phone auth, ownership, offline queue | Old links still resolve |

### Stage 4 — the website

| File | Do | Acceptance |
|---|---|---|
| `Frontend/Frontend.php` | Enqueue, only where needed | No assets on unrelated pages |
| `Frontend/Components.php` | `card()`, `directory()`, `search_form()`, `pagination()`, `emi()`, `map()` | Reused by shortcodes, widgets and templates |
| `Frontend/Shortcodes.php` | 18 shortcodes | Each renders in a Shortcode block |
| `Frontend/templates/*.php` | 13 templates | A theme without support still renders |
| `Frontend/Pages.php` | 14 pages, drafts first | Nothing publishes itself |
| `Frontend/Seo.php` | `decide()` as a **pure function** | Testable with no WordPress |
| `Frontend/Schema.php` | JSON-LD for listing, agent, organization | Passes Google's Rich Results Test |
| `Integrations/Elementor/*` | Bridge + 19 widgets + `form_record()` | Works with Elementor off and on |

### Stage 5 — cross-cutting

`I18n/Language` · `Support/Cache` · `Support/DesignTokens` · `Support/PracticeMode` · `Support/Format` · `Support/Icon` · `Support/Qr` · `Csv/Spreadsheet` · `Rest/RestApi` · `Install/Pages`.

---

## 3. The five pieces most likely to be built wrong

### 3.1 Translation loading
**Symptom:** Hinglish never appears, or appears then reverts to English.
**Cause:** WordPress and the theme re-load the locale during boot.
**Fix:** `I18n\Language` registers the `plugin_locale` filter on `plugins_loaded` **priority 1**; the text domain is loaded on `after_setup_theme` **999** and again on `wp_loaded` **999**; `unload_textdomain()` runs before `load_textdomain()` so a just-in-time English load cannot win.

### 3.2 The Elementor `wp_kses_post` fatal
**Symptom:** `TypeError` in `kses.php` when editing with Elementor Pro.
**Cause:** `get_the_terms()` returns `WP_Error` before taxonomies register; Elementor Pro passes it to `wp_kses_post()`.
**Fix:** register taxonomies on `init` **0** and on `elementor/init`; plus `Taxonomies::guard_get_the_terms()` returning `[]` for any `WP_Error`.

### 3.3 CSV price contamination
**Symptom:** a plot project shows a price of `40`.
**Cause:** free text like "40 – 100 Cr" in `notes` is parsed as a price.
**Fix:** prices live only in `price_min` / `price_max` / `price_unit`; free-text rates are written with the symbol removed and the word "Rate"; research and verification notes are routed to a **markdown notes file**, never into a CSV text cell.

### 3.4 Notes leaking into public highlights
**Symptom:** an internal note appears on the public property page.
**Cause:** the importer promotes leftover `notes` text into a highlight when it looks like a selling point.
**Fix:** keep verification notes in a **separate** store (`sources` in the research file, or a notes export), never in the `notes` column that feeds the importer.

### 3.5 Number formatting
**Symptom:** 38.6 lakh renders as 3.9 million.
**Cause:** rounding to two decimals in crore.
**Fix:** round to **four** decimals in the formatter (`%.4f`), never two, when converting to crore.

---

## 4. Reference implementations (the shape to copy)

### An action handler
```php
case 'estat_verify_listing':
    if ( ! current_user_can( 'estat_verify_listings' ) ) {
        wp_die( esc_html__( 'You are not allowed to do that.', 'estat-os' ) );
    }
    check_admin_referer( 'estat_verify_listing_' . (int) $_POST['id'] );
    self::verify_listing();
    wp_safe_redirect( self::safe_back() );
    exit;
```

### A domain validate()
```php
public static function validate( array $input, int $post_id = 0 ): array {
    $errors = array();
    $warns  = array();

    if ( '' === trim( (string) ( $input['title'] ?? '' ) ) ) {
        $errors['title'] = __( 'Give the property a headline.', 'estat-os' );
    }
    $offer = (string) ( $input['offer'] ?? '' );
    if ( ! array_key_exists( $offer, Vocabulary::offers() ) ) {
        $errors['offer'] = __( 'Say whether this is for sale or for rent.', 'estat-os' );
    }
    if ( '' === (string) ( $input['locality'] ?? '' ) ) {
        $warns['locality'] = __( 'No area yet, so it will be harder to find.', 'estat-os' );
    }

    return array(
        'ok'       => empty( $errors ),
        'errors'   => $errors,
        'warnings' => $warns,
    );
}
```

### A batched count (avoid N+1)
```php
public static function listing_counts( array $project_ids ): array {
    global $wpdb;
    $ids = array_filter( array_map( 'intval', $project_ids ) );
    if ( empty( $ids ) ) { return array(); }
    $in  = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
    $sql = "SELECT project_id, COUNT(*) AS n FROM " . Schema::table( 'estat_index' ) .
           " WHERE project_id IN ($in) AND post_status = 'publish' GROUP BY project_id";
    return $wpdb->get_results( $wpdb->prepare( $sql, $ids ), OBJECT_K ); // phpcs:ignore
}
```

### A pure SEO decision (testable with no WordPress)
```php
$plan = Seo::decide( array(
    'kind'   => 'taxonomy',
    'term'   => $term,
    'params' => array( 'bedrooms_min' => 3 ),
    'url'    => 'https://site.com/properties/?bedrooms_min=3',
) );
// index === false, canonical === 'https://site.com/properties/'
```

---

## 5. Definition of done

A rebuild is complete when **all** of these pass:

- [ ] 14 tables created and healthy
- [ ] 6 post types and 5 taxonomies registered on `init` 0
- [ ] 2 roles and 24 capabilities installed
- [ ] 20 admin screens reachable and gated
- [ ] 18 shortcodes render
- [ ] 19 Elementor widgets register when Elementor is on; nothing breaks when it is off
- [ ] 22 Pocket views resolve; old links still work
- [ ] `estat/v1` and `estat/v2` respond
- [ ] 3 cron hooks scheduled and runnable
- [ ] 12 webhook events fire, sign, log and retry
- [ ] 4 emails send, and a test mail works
- [ ] Import → preview → column plan → import → undo works
- [ ] Export round-trips
- [ ] Duplicate: `same`, `near`, `maybe` all demo-able
- [ ] Bin → restore → delete forever, and bulk undo
- [ ] Search index self-heals and can be rebuilt
- [ ] SEO: noindex on filter URLs, canonical correct, sitemap clean, JSON-LD valid
- [ ] Privacy exporter and eraser registered
- [ ] Hinglish loads and survives a full page request
- [ ] `/wp-json/estat/v1/health` returns the right version
- [ ] A fresh ZIP installs via Plugins → Add New → Upload
- [ ] Deactivate changes nothing; delete changes nothing unless opted in
