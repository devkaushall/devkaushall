# 09 — Forms, Import & Export

## Simple meaning (Hinglish)

Teen kaam is chapter mein:
1. **Forms** — website ka contact box khud banao.
2. **Import** — Excel/CSV se hazaaron properties ek baar mein daalo.
3. **Export** — sab kuch CSV mein nikaalo, kabhi bhi.

---

## Part A — The form builder

### What it does
A visual builder: rows → columns → fields, with responsive widths. You design the form; the plugin renders it, validates it, stores it, and turns every submission into an enquiry.

### How it works internally
| Layer | Class |
|---|---|
| Structure | `Forms\Forms::sanitize_definition()` — server re-validates the posted JSON from scratch |
| Field types | `Forms\FieldTypes::all()` — 27 types |
| Appearance | `Forms\Style::sanitize()` / `::to_css()` |
| Front-end render | `Forms\Renderer::render()` |
| Intake | `Forms\Submissions::handle()` |
| Storage | `estat_forms` (definition) + `estat_submissions` (each send) |
| Steps | `Forms\Forms::get_steps()` — multi-step |

### The 27 field types

**Everyday:** text, textarea, email, phone, number, select, radio, checkbox, checklist, date, time, datetime, file, hidden, consent, url

**Estate-specific:** name, address, message, property type¹, locality¹, budget, property¹, project¹, agent¹

**Layout:** heading, paragraph, submit

¹ Options are filled from live data (your localities, projects, agents, property types) — no maintenance.

### Configuration
Website forms → open a form → three stages (`FormsScreen::stages()`):
1. **Build** — drag fields.
2. **Design** — colours, widths, fonts, button.
3. **Submissions** — see what came in.

### Day to day
1. Create a form.
2. Copy the shortcode: `[estat_form id="3"]`.
3. Paste into any page, or drop the **Estat.OS Form** widget in Elementor.
4. Submit a test enquiry and confirm it lands in **Enquiries**.

### What happens on submit
`Forms\Submissions::handle()`:
1. Re-read the definition from the database (never trust the browser).
2. `validate_fields()` — required, type, format, consent.
3. Build an `idempotency_key`; if it already exists, return the earlier result instead of duplicating.
4. Create or attach the lead.
5. Store the raw payload in `estat_submissions` with hashed IP and page URL.
6. Fire `form.submitted` webhook.
7. Notify.

### Consent
If a `consent` field exists, its exact text and version are stored with the lead (`consent`, `consent_text_version`), so you can prove what the person agreed to. The privacy link comes from `privacy_url`.

---

## Part B — Import

### The five-step flow

**1. Upload**
`Csv\Spreadsheet::preview()` opens the file and reads headers plus sample rows.
- Files must live **inside the uploads directory** — `Spreadsheet::open()` realpath-checks and refuses anything outside.
- Delimiter and encoding are auto-detected (UTF-8 BOM aware).

**2. Choose the kind**
`listings` (38 columns) · `projects` (24) · `agents` (7) · `leads` (7) · `visits` (8)

**3. Say where the file came from**
Nine bridge systems. `Spreadsheet::guess_bridge()` scores all of them and only picks a named one if it reads **at least two more columns** than the plain reading — one extra match is a coincidence, two is a pattern.

| Option | Use when |
|---|---|
| **Generic CSV** | Headers already match the plugin, or unknown. **Start here.** |
| 99acres / MagicBricks / Housing.com / NoBroker / Makaan / CommonFloor export | The file came from that portal |
| Developer / builder master sheet | A builder's own sheet (`project_name`, `builder`, `micro_market`, `bhk_config`, `price_cr`, `rera` …) |
| Old Estat-OS / custom | Exported from an older version |

> **Why "Generic CSV" is nearly always right.** `guess_mapping()` tries a **direct match** against the plugin's own column names *first* and only then consults the bridge. If your headers are already `external_id`, `title`, `developer` … every one of the nine options produces an identical, complete mapping.

**4. Read the column plan**
`Spreadsheet::column_plan()` shows every column in your file and says what will happen to it — which plugin field it lands in, or that it is being left alone. **Read this screen.** Silence about a column is exactly how "where did my RERA number go?" bugs happen.

**5. Confirm and import**
`Admin\Actions::confirm_import()` runs in chunks, writing `estat_import_jobs` with `total_rows`, `processed_rows`, `created_count`, `updated_count`, `skipped_count`, `created_ids` and `undo_data`.

### Duplicate handling during import
Three modes (`duplicate_mode`):
| Mode | Behaviour |
|---|---|
| `skip` (default) | Rows whose `external_id` already exist are skipped |
| `update` | Existing rows are updated |
| `create` | Always create a new record |

### Undo
After **every** import an **Undo this import** button appears. `Admin\Actions::undo_import()` reverses exactly that batch — nothing else.

### CSV writing rules
- One row per record.
- Multi-value fields (`locality`, `amenities`, `highlights`) are **newline-separated inside one quoted cell**.
- Dates are `YYYY-MM-DD`.
- Booleans are `yes` / `no`.
- Numbers are digits only — **no commas, no currency symbols**.
- Leave a cell empty when the fact is unknown. An empty cell is honest; a guess becomes a published lie.
- UTF-8 encoding.

### Sample file
**Import & export → Download sample CSV** (`Admin\Actions::sample_csv()`) writes a template with the correct headers for the chosen kind.

---

## Part C — Export

| Export | Where | Function |
|---|---|---|
| Listings | Import & export → Export | `Admin\Actions::export_csv()` |
| Projects | same | `export_csv()` with kind |
| Agents | same | `export_csv()` |
| Leads | Enquiries → Export | `Leads\Leads::export_csv( $filters, $consent_only )` |
| Visits | Site Visits → Export | `Actions::export_leads_csv()` family |
| Health report | Properties → attention | `Data\Health::csv()` |
| Search index repair | Advanced | — |

Every export is UTF-8 with a BOM so Excel opens it correctly, and **every export excludes practice-mode records** unless you ask for them.

`consent_only = true` exports only leads that gave consent — useful for lawful marketing lists.

---

## Part D — Real-world import playbook

### First import (do this once, carefully)
1. **Download the sample CSV** and open it in Excel or Google Sheets.
2. Copy **ten rows** of your real data into it.
3. Import that ten-row file.
4. Check all ten on the website.
5. Only then import the full file.

Ten minutes of checking saves an afternoon of undo.

### Ongoing imports
- Keep one column as a stable `external_id`. It is what makes re-importing safe.
- Import `projects` **before** `listings`, so listings can attach.
- Import `agents` before listings if you assign by reference.
- After a big import, run **Advanced → Rebuild search index** and **Purge caches**.

### Cleaning data before import
| Problem | Fix |
|---|---|
| Prices written as "1.2 Cr" | Split into `price` (12000000) and `price_unit` |
| "2 BHK, 3 BHK" in one cell | Put in `unit_types`, newline-separated for multi-value |
| Locality and city in one cell | Split into `locality` and `city` |
| Mixed rent and sale | Separate rows, or use the `offer` column |
| Blank everywhere | Leave blank — do not invent |

---

## Part E — Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| "Cannot open file" | File outside uploads, or wrong permissions | Upload through the screen |
| All columns unmapped | Header row not row 1 | Remove title rows above the header |
| Prices come out wrong | Commas or ₹ in the number cells | Digits only |
| Multi-value field shows as one blob | Wrong separator | Newline inside a quoted cell |
| Everything created as draft | `status` column empty | Add `status = publish` |
| Import half-finished | PHP timeout | Raise `max_execution_time`; import in smaller files |
| Duplicates after import | No `external_id` | Add stable IDs and re-import in `update` mode |
| Excel shows garbage characters | Encoding | Re-save as UTF-8, or open with the BOM-aware importer |
| Form submits but no enquiry | Form not saved, or intake blocked | Check the form's **Submissions** tab |
