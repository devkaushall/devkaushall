# 17 — Production Deployment

## Simple meaning (Hinglish)

Live site par plugin chadhane ka sahi tareeka: pehle **staging** par test karo, phir **backup** lo, phir live par update karo, phir **smoke test** karo. Agar kuch gadbad ho to wapas purane version par jaane ka raasta pehle se tayyar rakho.

---

## 1. Pre-deployment checklist

| # | Item | Why |
|---|---|---|
| 1 | Full backup (database **including the 14 tables** + `uploads/`) | Rollback depends on it |
| 2 | Restore tested at least once | An untested backup is not a backup |
| 3 | PHP ≥ 7.4, WP ≥ 6.0 on the target | Hard floor |
| 4 | Staging site exists | Never test on live |
| 5 | Maintenance window agreed | Imports and rebuilds are heavy |
| 6 | Rollback artefact ready (previous ZIP) | Minutes matter |
| 7 | SMTP verified | Enquiry mail is business-critical |
| 8 | Cron verified | Daily jobs depend on it |

---

## 2. The deployment sequence

```
1. Backup          ──► database + uploads
2. Staging         ──► upload new ZIP, activate, run smoke test
3. Verify          ──► /health, one property, one enquiry end-to-end
4. Maintenance mode on the live site
5. Upload new ZIP via Plugins → Add New → Upload
6. Activate / let the upgrade run
7. Settings → Permalinks → Save
8. Purge every cache
9. Run smoke test (§1 of 16-Testing-Verification.md)
10. Maintenance mode off
11. Watch error logs for one hour
```

### Timing
- **Fresh install:** 5 minutes.
- **Upgrade:** 2 minutes plus the migration run. `Migrator::maybe_upgrade()` fires on `init` priority 1; on a large database the first request after the upgrade may take a few seconds. Do not interrupt it.
- **After a big import:** run **Advanced → Rebuild search index** and **Purge caches** inside the maintenance window.

---

## 3. First production install

1. Install and activate.
2. Complete the **Setup** screen.
3. **Settings → Pages → Create pages**, then publish the ones you want.
4. Configure the six settings groups (see `03`).
5. Add the team, giving each agent a WordPress user.
6. Add projects, then import or add properties.
7. Publish one property and verify it on the website **before** importing hundreds.
8. Submit a test enquiry and confirm the email.
9. Send `/pocket/` to the agents.
10. Set up backups and cron.

---

## 4. Upgrades

### Safe by design
- `Schema::install()` uses `dbDelta()` — additive and idempotent.
- `Migrator` runs pending steps only, and each is idempotent.
- The `estat_settings` option is created **only if missing** — your configuration is never overwritten.
- Nothing is auto-published and no terms are auto-seeded.
- Deactivating changes nothing at all.

### Before upgrading
- [ ] Backup
- [ ] Note the current version and `estat_db_version`
- [ ] Read the changelog for breaking changes
- [ ] Have the previous ZIP to hand

### After upgrading
- [ ] `/wp-json/estat/v1/health` shows the new version
- [ ] Permalinks saved
- [ ] Caches purged
- [ ] Smoke test passed
- [ ] One property, one project, one enquiry verified
- [ ] Cron hooks still scheduled

### Downgrade
Downgrades are **not** supported: the schema may have moved forward. To go back, restore the backup (database + uploads) rather than installing the old ZIP over new data.

---

## 5. Rollback procedure

1. Put the site in maintenance mode.
2. **Restore the database** from the pre-deployment backup.
3. **Restore `uploads/`** if anything changed there.
4. If the plugin files changed, replace the `estat-os` folder with the previous version's folder.
5. Permalinks → Save.
6. Purge caches.
7. Run the smoke test.
8. Maintenance mode off.
9. Write down what went wrong before you retry.

> The most common rollback cause is a **failed backup**, not a failed plugin. Verify step 1 of §1 every time.

---

## 6. Production configuration

### `wp-config.php` recommendations

```php
define( 'WP_DEBUG',         false );
define( 'WP_DEBUG_LOG',     true );   // log, but never display
define( 'WP_DEBUG_DISPLAY', false );

// Real cron instead of WP-Cron (set a system cron to wp-cron.php)
define( 'DISABLE_WP_CRON', true );

define( 'DISALLOW_FILE_EDIT', true );

// Raised limits for imports and photo uploads
ini_set( 'memory_limit',        '256M' );
ini_set( 'max_execution_time',  '300'  );
ini_set( 'upload_max_filesize', '32M'  );
ini_set( 'post_max_size',       '64M'  );
```

### Server

| Setting | Minimum for 1,000 listings | For 10,000+ |
|---|---|---|
| PHP memory | 256M | 512M |
| `max_execution_time` | 120 | 300 |
| PHP version | 8.1 recommended | 8.1+ |
| Object cache | optional | **Redis or Memcached** |
| Page cache | recommended | required |
| Cron | system cron | system cron |

### Must-haves in production
- **HTTPS** (consent + webhook security depend on it).
- **SMTP** plugin — enquiry email is business-critical.
- **Backups** including the `estat_*` tables.
- **A page cache** that `Support\Cache::purge_all()` understands (WP Rocket, LiteSpeed, W3TC, SiteGround, Autoptimize, WP Engine are all handled).

---

## 7. Migration to a new host

1. Full backup on the old host (database + uploads).
2. Restore on the new host.
3. Confirm `estat_db_version` — the `Migrator` will run any pending steps on first request.
4. **Settings → Permalinks → Save.**
5. Purge caches.
6. Verify `/wp-json/estat/v1/health`.
7. Verify one property, one project, one enquiry.
8. Re-point DNS.
9. Re-check cron scheduling after the move.
10. Keep the old host live (read-only) for 48 hours.

---

## 8. Multisite deployment

- Network-activate, or activate per site — both work.
- Each site keeps its own settings, tables (per-site prefix) and content.
- Roles install per site at activation.
- `uninstall.php` loops every site when erasure is opted in.
- Plan maintenance windows per site; migrations run per site on first request.

---

## 9. Monitoring

| What to watch | Where | Alert when |
|---|---|---|
| PHP fatals | `wp-content/debug.log`, host logs | Any new entry |
| `/wp-json/estat/v1/health` | Uptime monitor | Not 200 or wrong version |
| Enquiry volume | Reports | Drops to zero for a day |
| Webhook failures | `estat_webhook_log` | Any sustained failure |
| Cron | WP Crontrol / host | Hooks disappear |
| Disk | Host panel | `uploads/` growing fast |
| DB size | Host panel | `estat_audit` / log tables growing |

### Log hygiene
- `estat_audit`, `estat_webhook_log` and `estat_share_log` grow forever unless trimmed.
- `AuditLog::purge_older_than( $days )` is available; schedule it if you run a busy office.

---

## 10. Deployment runbook (copy/paste)

```
PRE
[ ] Backup database + uploads
[ ] Backup restore-tested
[ ] Staging smoke test green
[ ] Previous ZIP to hand
[ ] Maintenance window agreed

DEPLOY
[ ] Maintenance mode ON
[ ] Upload ZIP / activate
[ ] Permalinks → Save
[ ] Purge all caches
[ ] Smoke test (7 checks)
[ ] Maintenance mode OFF

POST (first hour)
[ ] error_log clean
[ ] /health correct version
[ ] One enquiry end-to-end
[ ] Cron hooks present
[ ] Reports load

POST (first day)
[ ] Backup again (post-deploy state)
[ ] Remove the pre-deploy backup? NO — keep 7 days
```

---

## 11. Common deployment failures

| Failure | Cause | Fix |
|---|---|---|
| White screen after upload | PHP fatal, or `memory_limit` | Check logs; raise memory |
| `/health` 404 | Permalinks | Settings → Permalinks → Save |
| Upgrade half-done | Interrupted during migration | Do not interrupt; re-run; if stuck, restore |
| Property pages 404 | Rewrite rules | Permalinks → Save |
| Old data on the website | Page cache | Purge caches |
| Enquiry email stops | SMTP / from-address | SMTP plugin; test mail |
| Cron stops | `DISABLE_WP_CRON` with no system cron | Add the system cron |
| Tables missing after host move | Partial database export | Re-export including all tables |
| Photos missing | `uploads/` not migrated | Copy the directory |
