# 10 — Website & Elementor Integration

## Simple meaning (Hinglish)

Website par properties dikhane ke do tareeke hain:
1. **Shortcode** — kisi bhi page mein `[estat_properties]` likh do.
2. **Elementor** — widget ghaseeto aur chhod do.

Dono ek hi cheez dikhate hain. Elementor zaroori nahi hai — band kar do to bhi sab chalta hai.

---

## 1. The public surface

| Layer | Class | Job |
|---|---|---|
| Assets | `Frontend\Frontend` | Enqueues `public.css` and `public.js` (vanilla, no jQuery) |
| Templates | `Frontend\Pages::template_fallback()` | Chooses the right template for each view |
| Building blocks | `Frontend\Components` | `card()`, `directory()`, `search_form()`, `pagination()`, `emi()`, `map()`, `compare()`, … |
| Shortcodes | `Frontend\Shortcodes` | 18 shortcodes |
| Elementor | `Integrations\Elementor\Bridge` + `Widgets` | 19 widgets, optional |
| SEO | `Frontend\Seo`, `Frontend\Schema` | Head output and JSON-LD |

Templates shipped in `includes/Frontend/templates/`:

`archive-listing` · `single-listing` · `archive-project` · `single-project` · `archive-agent` · `single-agent` · `archive-estat_insight` · `single-estat_insight` · `taxonomy-estat_locality` · `taxonomy-estat_amenity` · `taxonomy-estat_feature` · `page-public` · `print-listing`

---

## 2. Shortcodes (18)

| Shortcode | What it shows |
|---|---|
| `[estat_properties]` | The property directory, with sorting and pagination |
| `[estat_search]` | The search/filter form |
| `[estat_form id="3"]` | A form you built |
| `[estat_team]` | Team directory |
| `[estat_compare]` | Side-by-side comparison |
| `[estat_favorites]` | The visitor's saved properties |
| `[estat_language]` | Language switcher |
| `[estat_alerts]` | "Tell me when something matching comes up" |
| `[estat_share]` | Share buttons |
| `[estat_localities]` | Locality directory with counts |
| `[estat_amenities]` | Amenity directory |
| `[estat_features]` | Feature directory |
| `[estat_projects]` | Project directory |
| `[estat_projects_by_stage]` | Projects grouped by stage |
| `[estat_locality_map]` | Map of localities |
| `[estat_emi]` | EMI calculator |
| `[estat_public_pages]` | Index of the built pages |
| `[estat_office]` | The front-end office dashboard link |

### Common attributes for `[estat_properties]`
`per_page`, `columns`, `orderby` (`recent`, `price_asc`, `price_desc`, `area_desc`), `offer`, `property_type`, `locality`, `bedrooms`, `featured`, `verified`, `project_id`, `agent_id`.

---

## 3. Elementor widgets (19)

Registered by `Bridge::register_widgets()` into a category named **Estat.OS**.

| Widget | Draws |
|---|---|
| `estat_property_search` | Search and filter form |
| `estat_property_directory` | Property grid/list |
| `estat_property_card` | One property card |
| `estat_property_single` | A single property's detail view |
| `estat_project_directory` | Project grid |
| `estat_project_single` | One project's detail view |
| `estat_agent_directory` | Team grid |
| `estat_agent_single` | One team member |
| `estat_form` | A form you built |
| `estat_lead_cta` | Call-to-action block |
| `estat_map` | Map |
| `estat_gallery` | Photo gallery |
| `estat_compare` | Comparison |
| `estat_favorites` | Saved properties |
| `estat_insights` | Blog / article / insight list |
| `estat_documents` | Documents and brochures |
| `estat_visit_scheduler` | Book a visit |
| `estat_whatsapp` | WhatsApp button |
| `estat_emi` | EMI calculator |

All widgets extend `Integrations\Elementor\BaseWidget`, which supplies the category, icon, style and script dependencies, and keywords.

---

## 4. How the Elementor bridge works

`Integrations\Elementor\Bridge`:

| Method | Job |
|---|---|
| `active()` | Is Elementor actually running? |
| `add_category()` | Registers the **Estat.OS** widget category |
| `register_widgets()` | Registers all 19 |
| `form_record()` | Turns Elementor's native form submissions into enquiries |
| `has_template()` | Detects an Elementor Theme Builder template for `single`/`archive` |
| `is_edit_mode()` | Are we inside the editor? |
| `forget_templates()` | Drops cached template answers |

### Elementor forms → enquiries
With `elementor_forms_to_enquiries = true`, `form_record()` maps Elementor's fields onto the lead schema by **field id or label** (`name`, `phone`, `email`, `message`). Unknown fields go into the notes rather than being lost.

### Theme Builder
If you build a single-listing template in Elementor Theme Builder, `has_template('single')` detects it and the plugin steps back so your design wins. If you do not, the plugin's own template is used.

### A crash the plugin defends against
Elementor Pro calls `wp_kses_post()` on the result of `get_the_terms()`. Before our taxonomies are registered, that returns a `WP_Error`, and `wp_kses_post( WP_Error )` is a fatal `TypeError`.

Two defences:
1. Taxonomies register on `init` priority **0** *and* on `elementor/init`.
2. `Taxonomies::guard_get_the_terms()` intercepts `get_the_terms` and returns `[]` instead of any `WP_Error`.

---

## 5. Page blocks (Templates)

`Admin\Screens\TemplatesScreen` + `Data\Templates` — drag to reorder, toggle to hide.

**Listing blocks (17):** header, signals, cover, share, facts, costs, emi, description, gallery, video, documents, map, agent, enquiry, locality …

**Project blocks (11):** header, cover, facts, description, gallery, floor plans, amenities, location, units, share, enquiry.

Turning a block off removes it **everywhere at once** — shortcode, Elementor widget, and the plugin's own template. This is the fastest way to change the shape of every property page on the site.

---

## 6. Colours & fonts (Design Tokens)

`Admin\Screens\DesignTokensScreen` + `Support\DesignTokens`.

- Every colour, spacing and font lives as a CSS variable in `assets/css/tokens.css`.
- The screen overrides them **without editing code**: live preview, custom tokens, export CSS, reset.
- `DesignTokens::inline_css()` / `print_inline()` emit the overrides into `<head>`.

No child theme, no CSS file edits, no redeploy.

---

## 7. Building a property website: two recipes

### Recipe A — no page builder (ten minutes)
1. Create the pages (Settings → Pages).
2. Publish **Properties**, **Projects**, **Our team**, **Contact us**.
3. Set **Settings → Reading** or your menu so Properties is reachable.
4. Done. The shortcodes do the rest.

### Recipe B — Elementor (thirty minutes)
1. Create an empty page called **Properties**.
2. Edit with Elementor.
3. Drop **Property Search** at the top.
4. Drop **Property Directory** beneath it.
5. Set columns and per-page in the widget controls.
6. Build a single-listing template in Theme Builder if you want full control; otherwise the plugin's own template is used.
7. Repeat for Projects and Team.

---

## 8. WhatsApp

`Frontend\WhatsApp` — `enqueue()`, `enabled()`, `number()`, `message()`, `button()`, `shortcode()`, `tap()`.

- The button appears on property pages when `whatsapp_cta_enabled` is on.
- The pre-filled message names the property and links to it.
- `tap()` records the click as a share event (`share.logged` webhook).
- Number comes from the `whatsapp` setting; it can differ from the office phone.

---

## 9. Front-end behaviour worth knowing

| Behaviour | Detail |
|---|---|
| Favourites | Stored in `localStorage`, so no login is required |
| Compare | Up to four properties, also `localStorage` |
| Print | `/print-listing/` template, ink-friendly |
| EMI | Client-side; defaults from `emi_default_rate` / `emi_default_years` |
| Maps | OpenStreetMap by default, **no API key needed** |
| Language switch | `I18n\Language::selector()`, cookies the choice |
| Pagination | Real paged URLs, not infinite scroll — better for SEO and for sharing |
| Lazy loading | Images use native `loading="lazy"` |

---

## 10. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Shortcode prints as text | Inserted in a widget that does not run shortcodes | Use a Shortcode block |
| Widgets missing in Elementor | Elementor not active, or category filter | Check Elementor is on; clear the search box |
| Elementor fatal about `wp_kses_post` | Outdated Elementor Pro | Update Elementor; the guard is already in place |
| Design changes not visible | Page cache | Purge caches |
| Page 404 | Permalinks | Settings → Permalinks → Save |
| Map blank | Blocked tile server, or no coordinates | Check the property's lat/lng |
| WhatsApp button missing | `whatsapp_cta_enabled` off, or number empty | Settings → Leads |
| Theme Builder template ignored | Cached template answer | Elementor → clear cache; `forget_templates()` |
| Listing page looks like the theme's | `page_renderer` = `theme` | Switch to `plugin`, or build a Theme Builder template |

---

## The visitor's shortlist and comparison (4.1.4)

Nothing here is new to the website's architecture: two shortcodes and two
Elementor widgets already existed, and the choices have always been kept in the
visitor's own browser. What was missing was the middle of it — the questions
were a second, shorter list written only in JavaScript, and there was no way to
hand the shortlist to the office.

**On a property card** there are two buttons: a heart (**`estat-fav`**) and
**Compare** (**`estat-compare`**). Neither asks for an account. Nothing is sent
anywhere. The choices sit in `localStorage` under `estat_favorites` and
`estat_compare` — up to four in the comparison.

**`[estat_favorites]`** (Elementor: *Saved properties*) draws the cards again
with their photographs, each with Compare and Remove.

**`[estat_compare]`** (Elementor: *Property Comparison*) draws the table plus
the handoff form. The rows come from the server: `GET /wp-json/estat/v1/
properties/{id}` returns `questions` and `facts`, both from
`Support/Comparison.php` — **the same ten questions the office and the pocket
ask.** A question with no answer prints "Not said"; it is never dropped, because
a missing row reads as a missing fact only when the gap is visible.

**Two repairs (4.1.5).** The reply above was promised in this chapter before
the code kept it: `/properties/{id}` now answers for a **society or project**
as well as for a single home — a heart on a project card used to arrive as
"not found" and drop silently out of the list the visitor had built — and the
page hands the browser its ticket (`shortlistNonce`) in `estatPublic`, without
which *Send this list on WhatsApp* could only ever come back as "this page has
been open a while".

**Sending the list.** The visitor leaves a name and a number and presses
*Send this list on WhatsApp*. That posts to `POST /wp-json/estat/v1/shortlist`,
which:

1. checks a nonce, an empty honeypot field and a limit of five sends per
   address per ten minutes;
2. builds the message from the same `Comparison::facts()` — title, price, link
   per property;
3. creates an **ordinary enquiry** through `Leads::create()` with
   `source = comparison`, so it lands in the office list, is assigned and is
   chased exactly like one from the contact form. Every action is in the audit
   log;
4. answers with a `wa.me` link carrying the same text, which the browser opens.

**Two switches** in Settings turn the heart and the comparison off site-wide
(`enable_favorites`, `enable_compare`). Both are on by default; the shortcodes
return nothing at all when switched off.

**What was deliberately not done:** no visitor accounts, no stored personal
data beyond the enquiry itself, no third-party script, and no change to any
existing public CSS rule — everything added is a new class under `.estat-public`.
