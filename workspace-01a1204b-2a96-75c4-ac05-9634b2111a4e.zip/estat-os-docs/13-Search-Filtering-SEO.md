# 13 — Search, Filtering, SEO & Website-Facing Behaviour

## Simple meaning (Hinglish)

Website par visitor search karta hai — area, budget, rooms. Ye sab plugin ki **search index** table se aata hai, isliye hazaaron properties hone par bhi tez chalta hai.

SEO ka kaam plugin khud karta hai: har property ka sahi title, description, Google ke liye structured data, aur duplicate pages ko `noindex`.

---

## 1. Search architecture

```
Listing saved ──► SearchIndex::index_listing() ──► estat_index (one flat row)
                                                        │
Visitor search ──► Search\Query::normalize() ──► one indexed SQL query ──► IDs
                                                        │
                                          posts fetched by ID (fast)
```

**Why:** a `WP_Query` with six meta filters joins `postmeta` six times. `estat_index` has a purpose-built key for every common filter and returns IDs in one pass.

### Index maintenance
| Trigger | Handler |
|---|---|
| Save | `SearchIndex::index_listing()` |
| Delete | `SearchIndex::remove()` |
| Status change | `SearchIndex::on_status_change()` |
| Term change | `SearchIndex::on_terms_changed()` |
| Daily cron | `Scheduler::repair_index()` — 200-row batches, resumable |
| Manual | Advanced → Rebuild search index |

`SearchIndex::status()` reports row count and staleness.

---

## 2. The filter set

`Search\Query::normalize()` accepts **31 arguments**; `Support\Vocabulary::all_filters()` exposes **22** of them as UI filters.

| Group | Filters |
|---|---|
| Keyword | `keyword` (searches title + `search_text`) |
| Location | `locality` (slugs **or** IDs), `project_id` |
| Basic | `offer`, `property_type`, `bedrooms_min/max`, `bathrooms_min`, `price_min/max`, `area_min/max` |
| Details | `furnishing`, `facing`, `construction`, `availability`, `floor_min/max`, `total_floors_min`, `age_max`, `possession` |
| Amenities | `parking_min`, `balconies_min`, `amenities[]`, `features[]` |
| Trust | `verified`, `featured`, `investment` |
| People | `agent_id` |
| Ordering | `orderby` (`recent`, `price_asc`, `price_desc`, `area_desc`), `page`, `per_page` |
| Internal | `include_practice` |

`locality` accepts slugs or IDs and resolves to term IDs before querying (`B11` behaviour) — so a hand-written URL and a form submission both work.

`per_page` defaults to `listings_per_page` (12).

---

## 3. Filter configuration

**Settings → Listings & workflow:**
- **Enabled filters** (`enabled_filters`) — which appear in the search form.
- **Filter order** (`filter_order`) — the order they appear.

> Turning a filter **off** removes it from the form only. The query engine still honours it, so a hand-built URL keeps working — which is exactly what SEO landing pages rely on (`/properties/?locality=sector-82&bedrooms_min=3`).

---

## 4. SEO: the contract

`Frontend\Seo` is deliberately built as a **pure function you can test**:

```php
Seo::plan();                  // decide for the current request
Seo::decide( $context );      // decide from a plain description — testable
```

The plan returns five things:

```php
[
  'index'       => bool,   // may this page be indexed?
  'canonical'   => string, // the one true URL
  'title'       => string,
  'description' => string,
  'why'         => string, // a human sentence explaining the decision
]
```

### Indexing rules

| Page | Index? |
|---|---|
| A single **published** listing | Yes |
| A draft, pending, private or trashed listing | **No** |
| A taxonomy page **with listings** | Yes |
| A taxonomy page **with zero listings** | **No** — thin page |
| A public page with inventory | Yes |
| A public page with no inventory | **No** |
| Any URL carrying filter parameters | **No** — with a canonical to the clean URL |

That last rule is the important one. Filter combinations generate unlimited near-duplicate URLs; they are all canonicalised to the clean page.

### The filter parameters that trigger it
`Seo::FILTER_PARAMS` — `keyword`, `offer`, `property_type`, `locality`, `bedrooms_min`, `bedrooms_max`, `bathrooms_min`, `price_min`, `price_max`, `area_min`, `area_max`, `furnishing`, and the rest of the filter keys.

`Seo::query_params()` reads `$_GET`, keeps only known keys, and normalises arrays to comma-joined strings.

---

## 5. Titles and descriptions

Written per record type:

| Function | Generates |
|---|---|
| `title_listing()` / `describe_listing()` | e.g. *"3 BHK Apartment for Sale in Sector 82, Gurugram — 1,850 sqft"* |
| `title_project()` / `describe_project()` | Builder, stage, price range, units |
| `title_term()` / `describe_term()` | Locality/amenity name plus live count and price range |
| `title_page()` / `describe_page()` | Per public page |
| `fit( $text, $limit )` | Trims to a sane length without cutting a word mid-way |

Counts come from `Seo::listing_counts()` and `Seo::page_inventory()` — cached per request, never N+1.

---

## 6. Sitemaps

| Integration | Hook |
|---|---|
| WordPress core sitemap | `Seo::core_sitemap_args()` — excludes noindex IDs |
| Any sitemap that asks for excluded IDs | `Seo::sitemap_exclude()` |

`Seo::noindex_ids()` computes the exclusion set once per request: drafts, pending, private, trash, and empty taxonomy terms.

**Result: your sitemap contains only pages Google should actually crawl.**

---

## 7. Robots and canonical

| Target | Hook |
|---|---|
| WordPress core robots | `Seo::core_robots()` |
| Rank Math | `Seo::rank_math_robots()`, `rank_math_canonical()`, `rank_math_title()`, `rank_math_description()` |
| Yoast | `Seo::yoast_robots()` |

`Seo::has_own_title()` / `has_own_description()` check whether your SEO plugin is managing the field. **If it is, Estat.OS steps back** — it never fights an SEO plugin for control.

`Seo::clean_url( $url, $params )` strips tracking and filter parameters from canonicals.

---

## 8. Structured data (JSON-LD)

`Frontend\Schema::output()` prints one JSON-LD block:

| Type | Function | Where |
|---|---|---|
| `Residence` / `Apartment` / `House` / `CommercialBuilding` | `Schema::listing()` | Single listing |
| `Person` (with `RealEstateAgent`) | `Schema::agent()` | Single agent |
| `RealEstateAgent` organization | `Schema::organization()` | Site-wide |

Output includes name, description, image, address, geo coordinates, floor size, number of rooms, and offer with price and currency. Controlled by `enable_schema` (default on).

---

## 9. Head output mechanics

`Frontend\Seo` captures the theme's `<head>`:

1. `head_start()` — opens an output buffer, remembering the level.
2. `head_end()` — reads the buffer.
3. `head_extras( $head, $plan )` — injects or rewrites robots, canonical, OG and Twitter tags as required.

This keeps the plugin working with **any** theme, including ones that print no SEO tags at all, while never double-printing when an SEO plugin is present.

---

## 10. Pagination and crawlability

- Pagination uses real paged URLs (`/properties/page/2/`), not JavaScript infinite scroll.
- Every page carries a self-referencing canonical.
- Filter combinations are `noindex, follow` and canonicalised to the clean URL.
- The public print sheet (`print-listing`) is `noindex`.

---

## 11. Search alerts (visitor side)

`Search\Alerts` — a visitor saves a search and gets email when a match goes live.

```
Visitor saves search ──► row created, unconfirmed
        │
   confirmation email ──► handle_confirm() ──► active
        │
New listing published ──► Alerts::on_listing_published() ──► match?
        │
        └──► queue ──► process_queue() (cron) ──► email
```

`handle_unsubscribe()` honours one-click unsubscribe, and the token is in every email. Off by default (`search_alerts_enabled = false`) because it needs working outbound mail.

---

## 12. Performance characteristics

| Operation | Shape |
|---|---|
| Filtered directory page | 1 indexed query on `estat_index` + 1 `get_posts()` by ID |
| Locality counts | Pre-computed via `Seo::listing_counts()` |
| Project listing counts | One batched query via `Projects::listing_counts()` |
| Reports | Read `estat_index`, never postmeta |
| Map | Coordinates come from index rows |
| Autocomplete | Index-backed |

Nothing in the public path runs a meta query.

---

## 13. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| New property missing from search | Index stale | Advanced → Rebuild search index |
| Old property still in search | Index row not removed | Same |
| Filter URL shows no results | Wrong key names | Use the exact keys in §2 |
| Locality filter ignores my value | Not a slug or ID | Use the term slug |
| Google indexing filter URLs | Canonical missing | Check the head; confirm no plugin strips it |
| Sitemap contains drafts | Sitemap cached | Purge caches, re-check |
| Titles not changing | SEO plugin owns titles | Expected — `has_own_title()` steps back |
| JSON-LD missing | `enable_schema` off, or theme strips it | Turn on; check the source |
| Search slow | Index empty or stale | Rebuild; check `estat_index` row count |
