#!/usr/bin/env python3
"""Build one self-contained HTML book from the markdown chapters.

No network, no CDN, no external fonts — everything is inline so the file
renders inside a sandboxed iframe and offline.
"""
import io, os, re, html, datetime
import markdown

HERE = os.path.dirname(os.path.abspath(__file__))
OUT  = os.path.join(HERE, 'Estat-OS-Documentation.html')

# Chapter order = file order, with human titles.
CHAPTERS = [
    ('00-START-HERE.md',                    'Start here'),
    ('01-Architecture.md',                  'Architecture'),
    ('02-Installation-Setup.md',            'Install & setup'),
    ('03-Configuration-Settings.md',        'Settings'),
    ('04-Features-Reference.md',            'Features'),
    ('05-Office-Day-To-Day.md',             'Office day to day'),
    ('06-Pocket-Field-Agent.md',            'Pocket (field agent)'),
    ('07-Listings-Projects-Team.md',        'Listings, projects, team'),
    ('08-Enquiries-Visits-Pipeline.md',     'Enquiries & visits'),
    ('09-Forms-Import-Export.md',           'Forms & spreadsheets'),
    ('10-Website-Elementor-Integration.md', 'Website & Elementor'),
    ('11-Data-Structure-Schema.md',         'Data & schema'),
    ('12-Permissions-Roles.md',             'Roles & permissions'),
    ('13-Search-Filtering-SEO.md',          'Search & SEO'),
    ('14-Notifications-Integrations.md',    'Notifications & API'),
    ('15-Security-Validation-Performance.md','Security & performance'),
    ('16-Testing-Verification.md',           'Testing'),
    ('17-Deployment-Production.md',          'Deployment'),
    ('18-Troubleshooting-Maintenance.md',    'Troubleshooting'),
    ('19-Developer-Reference.md',            'Developer reference'),
    ('20-Implementation-Guide.md',           'Implementation guide'),
]

PARTS = {
    '00-START-HERE.md':                      'Orientation',
    '01-Architecture.md':                    'Part A — Architecture & implementation',
    '11-Data-Structure-Schema.md':           'Part A — Architecture & implementation',
    '19-Developer-Reference.md':             'Part A — Architecture & implementation',
    '20-Implementation-Guide.md':            'Part A — Architecture & implementation',
    '05-Office-Day-To-Day.md':               'Part B — Running the office',
    '06-Pocket-Field-Agent.md':              'Part B — Running the office',
    '07-Listings-Projects-Team.md':          'Part B — Running the office',
    '08-Enquiries-Visits-Pipeline.md':       'Part B — Running the office',
    '09-Forms-Import-Export.md':             'Part B — Running the office',
    '02-Installation-Setup.md':              'Part C — Website, data & integrations',
    '03-Configuration-Settings.md':          'Part C — Website, data & integrations',
    '04-Features-Reference.md':              'Part C — Website, data & integrations',
    '10-Website-Elementor-Integration.md':   'Part C — Website, data & integrations',
    '12-Permissions-Roles.md':               'Part C — Website, data & integrations',
    '13-Search-Filtering-SEO.md':            'Part C — Website, data & integrations',
    '14-Notifications-Integrations.md':      'Part C — Website, data & integrations',
    '15-Security-Validation-Performance.md': 'Part D — Quality, deployment, operations',
    '16-Testing-Verification.md':            'Part D — Quality, deployment, operations',
    '17-Deployment-Production.md':           'Part D — Quality, deployment, operations',
    '18-Troubleshooting-Maintenance.md':     'Part D — Quality, deployment, operations',
}


def slugify(text: str) -> str:
    s = re.sub(r'[^a-z0-9]+', '-', text.lower()).strip('-')
    return s or 'section'


md = markdown.Markdown(extensions=['tables', 'fenced_code', 'toc', 'attr_list', 'sane_lists'])

bodies, seen_slugs = [], {}
nav_parts = []

for fname, title in CHAPTERS:
    path = os.path.join(HERE, fname)
    raw = io.open(path, encoding='utf-8').read()

    # First H1 becomes the chapter heading; strip it, we render our own.
    raw = re.sub(r'^#\s+.*?\n', '', raw, count=1)

    md.reset()
    body = md.convert(raw)

    # Unique anchors across the whole book.
    def uniq(m):
        base = m.group(2)
        n = seen_slugs.get(base, 0)
        seen_slugs[base] = n + 1
        return '<h%s id="%s">' % (m.group(1), base if n == 0 else '%s-%d' % (base, n))

    body = re.sub(r'<h([23456]) id="([^"]+)">', uniq, body)

    # Demote every heading one level so the chapter title can be the h2.
    for lvl in (5, 4, 3, 2):
        body = re.sub(r'<h%d id="([^"]+)">' % lvl, '<h%d id="\\1">' % (lvl + 1), body)
        body = body.replace('</h%d>' % lvl, '</h%d>' % (lvl + 1))

    anchor = slugify(fname.replace('.md', ''))
    part = PARTS.get(fname, '')
    num = fname.split('-')[0]
    head = ('<h2 id="%s-top"><span class="cnum">%s</span>%s</h2>\n'
            '<div class="cpart">%s</div>\n') % (
        anchor, num, html.escape(title), html.escape(part))
    bodies.append('<section class="chapter" id="%s">\n%s%s\n</section>' % (anchor, head, body))

    part = PARTS.get(fname)
    if part:
        nav_parts.append((part, anchor, title))

nav_html, last_part = [], None
for part, anchor, title in nav_parts:
    if part != last_part:
        if last_part is not None:
            nav_html.append('</div>')
        nav_html.append('<div class="navgroup"><div class="navpart">%s</div>' % html.escape(part))
        last_part = part
    nav_html.append('<a class="navlink" href="#%s">%s</a>' % (anchor, html.escape(title)))
if nav_html:
    nav_html.append('</div>')
nav_html = '\n'.join(nav_html)

CSS = """
:root{
  --ink:#16191d; --muted:#5f6873; --line:#e3e7ec; --bg:#ffffff; --soft:#f7f9fb;
  --accent:#1f6feb; --accent-soft:#eaf2fe; --warn:#b45309; --code:#0f1720;
  --ok:#15803d;
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;
  font-size:16px;line-height:1.65;color:var(--ink);background:var(--bg);-webkit-font-smoothing:antialiased}
.layout{display:flex;min-height:100vh;align-items:flex-start}

/* sidebar */
.sidebar{width:288px;flex:0 0 288px;border-right:1px solid var(--line);background:var(--soft);
  padding:22px 0 60px;position:sticky;top:0;height:100vh;overflow-y:auto}
.brand{padding:0 20px 16px;border-bottom:1px solid var(--line);margin-bottom:14px}
.brand .name{font-weight:700;font-size:16px;letter-spacing:.2px}
.brand .meta{font-size:12px;color:var(--muted);margin-top:3px}
.navgroup{margin:0 0 14px}
.navpart{font-size:11px;font-weight:700;letter-spacing:.09em;text-transform:uppercase;
  color:#8b95a1;padding:8px 20px 5px}
.navlink{display:block;padding:6px 20px;color:#374151;text-decoration:none;font-size:14px;
  border-left:2px solid transparent}
.navlink:hover{background:#eef2f7;color:var(--ink)}
.navlink.active{background:var(--accent-soft);color:var(--accent);border-left-color:var(--accent);font-weight:600}

/* content */
.content{flex:1 1 auto;min-width:0;padding:40px 44px 120px;max-width:1080px}
.chapter{margin:0 0 76px;padding-top:16px}
.chapter:first-child{padding-top:0}
.chapter>h2{font-size:28px;line-height:1.25;margin:0 0 4px;padding-bottom:10px;
  border-bottom:2px solid var(--ink);letter-spacing:-.2px}
.chapter>h2 .cnum{display:inline-block;min-width:42px;color:#9aa4b0;font-weight:600;font-variant-numeric:tabular-nums}
.cpart{font-size:11px;font-weight:700;letter-spacing:.09em;text-transform:uppercase;
  color:#8b95a1;margin:8px 0 22px}
.chapter h3{font-size:21px;margin:34px 0 10px;padding-top:6px}
.chapter h3{font-size:20px;margin:34px 0 10px;letter-spacing:-.1px}
.chapter h4{font-size:16.5px;margin:26px 0 8px;color:#1f2937}
.chapter h5{font-size:14.5px;margin:20px 0 6px;color:#374151;text-transform:uppercase;letter-spacing:.05em}
p{margin:12px 0}
ul,ol{margin:12px 0;padding-left:24px}
li{margin:5px 0}
a{color:var(--accent)}
a:hover{text-decoration:none}
strong{font-weight:650}

/* tables */
table{border-collapse:collapse;width:100%;margin:18px 0;font-size:14.5px;display:block;overflow-x:auto}
th,td{border:1px solid var(--line);padding:9px 12px;text-align:left;vertical-align:top}
th{background:var(--soft);font-weight:650;font-size:13.5px}
tbody tr:nth-child(even){background:#fcfdfe}

/* code */
code{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,"Liberation Mono",monospace;
  font-size:13px;background:#f1f4f8;border:1px solid #e6eaf0;border-radius:4px;padding:1px 5px;color:#b3235a}
pre{background:var(--code);color:#e6edf3;border-radius:8px;padding:16px 18px;overflow-x:auto;
  margin:18px 0;font-size:13px;line-height:1.6}
pre code{background:none;border:0;padding:0;color:inherit;font-size:13px}

blockquote{margin:18px 0;padding:12px 18px;background:var(--accent-soft);
  border-left:4px solid var(--accent);border-radius:0 6px 6px 0;color:#123}
blockquote p{margin:6px 0}
hr{border:0;border-top:1px solid var(--line);margin:38px 0}

.hinglish{background:#fff8e6;border:1px solid #f3e2b6;border-left:4px solid #d99b1c;
  border-radius:0 6px 6px 0;padding:12px 18px;margin:16px 0}
.hinglish p{margin:6px 0}

.toc{display:none}
@media (max-width:900px){
  .layout{display:block}
  .sidebar{position:static;width:auto;height:auto;flex:none;border-right:0;border-bottom:1px solid var(--line)}
  .content{padding:26px 20px 90px;max-width:none}
  .chapter h2{font-size:23px}
  body{font-size:15.5px}
}
@media print{
  .sidebar{display:none}
  .content{padding:0;max-width:none}
  .chapter{page-break-before:always}
  .chapter:first-child{page-break-before:avoid}
  pre,table{page-break-inside:avoid}
  a{color:var(--ink);text-decoration:none}
}
"""

JS = """
(function(){
  var links=[].slice.call(document.querySelectorAll('.navlink'));
  var secs=links.map(function(a){return document.getElementById(a.getAttribute('href').slice(1));});
  function onScroll(){
    var y=window.scrollY+120, idx=0;
    for(var i=0;i<secs.length;i++){ if(secs[i] && secs[i].offsetTop<=y){ idx=i; } }
    links.forEach(function(a,i){ a.classList.toggle('active', i===idx); });
  }
  window.addEventListener('scroll', onScroll, {passive:true});
  onScroll();
})();
"""

today = datetime.date.today().strftime('%d %B %Y')

page = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Estat.OS — Complete Implementation &amp; Documentation</title>
<style>%s</style>
</head>
<body>
<div class="layout">
  <nav class="sidebar">
    <div class="brand">
      <div class="name">Estat.OS Documentation</div>
      <div class="meta">v3.6.6 · DB v12 · %s</div>
    </div>
%s
  </nav>
  <main class="content">
%s
  </main>
</div>
<script>%s</script>
</body>
</html>
""" % (CSS, today, nav_html, '\n'.join(bodies), JS)

io.open(OUT, 'w', encoding='utf-8').write(page)
print('wrote', OUT, os.path.getsize(OUT), 'bytes,', len(bodies), 'chapters')
