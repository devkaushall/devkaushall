# 16 — Testing & Verification

## Simple meaning (Hinglish)

Ye chapter batata hai ki plugin sahi chal raha hai ya nahi — check karne ka tareeka. Poora test karne mein 45 minute lagte hain. Har release se pehle ye chalana chahiye.

---

## 1. The smoke test (five minutes)

Run this after **every** install, upgrade, migration or deploy.

| # | Check | Expected |
|---|---|---|
| 1 | `/wp-json/estat/v1/health` | `{"ok":true,"version":"3.6.6"}` |
| 2 | WP admin → Estat.OS menu | 11 menu items visible |
| 3 | `/properties/` | Loads, no PHP warnings |
| 4 | One single property page | Title, price, gallery, map, enquiry form |
| 5 | Submit a test enquiry | Appears in **Enquiries** + email arrives |
| 6 | `/pocket/` | Loads, or shows the login screen |
| 7 | Search with a filter | Results narrow correctly |

If all seven pass, the deployment is good.

---

## 2. Install & activation

| Test | Steps | Pass criteria |
|---|---|---|
| Fresh install | Activate on a clean site | Setup screen appears; no fatal |
| Table creation | Inspect the database | All **14** `estat_*` tables exist |
| Roles | Users → roles | `estat_office_owner`, `estat_office_agent` exist |
| Idempotent re-activate | Deactivate → activate | Same state; settings preserved |
| Upgrade | Restore an old backup, then activate | `Migrator` runs; no data loss; no fatal |
| Old PHP/WP | PHP 7.3 | One admin notice; site still works |
| Uninstall (keep) | Delete plugin | Data intact |
| Uninstall (erase) | Tick the box, delete | Tables, posts, terms, roles gone |

---

## 3. Listings

| Test | Pass criteria |
|---|---|
| Add a property | Saved; appears in the list and on the website |
| Add with no photo | Saves; completeness flags the missing photo |
| Price on request | Shows the `price_on_request_label`, not "0" |
| Duplicate warning | Adding a near-identical property warns and names the other one |
| Keep both | Warning stops appearing for that pair |
| Move to bin | Disappears from the website; visible in Bin |
| Restore | Comes back exactly as it was |
| Delete forever | Requires typing the word; gone afterwards |
| Bulk 20 rows | All 20 move; Undo banner appears; Undo restores all 20 |
| Undo an edit | Reverts the snapshotted fields only |
| Verification required mode | Cannot publish until verified |

---

## 4. Projects

| Test | Pass criteria |
|---|---|
| Add a project | Saved; appears on `/projects/` |
| Attach 3 properties | Project page lists all 3 |
| Delete the project | The 3 properties survive, unlinked |
| Price range, units | Render correctly |
| Stage change | Fires `project.stage_changed` webhook |

---

## 5. Enquiries & visits

| Test | Pass criteria |
|---|---|
| Submit the website form | Lead created; email sent; event logged |
| Submit **twice** (double click) | **One** lead, not two |
| Same phone, different format | Deduped to the same person |
| Assign to an agent | Agent appears; event logged |
| Illegal status move | Refused with a plain-language reason |
| Schedule a visit | Created; `.ics` downloads and opens |
| Double-book the same slot | Refused (unique `dedupe_hash`) |
| Mark outcome | Lead status follows |
| Erase a lead | Personal fields blanked; row retained |
| Retention job | Old leads erased after `retention_days` |
| Privacy export | WordPress exporter returns the lead |
| Privacy erase | WordPress eraser blanks it |

---

## 6. Forms

| Test | Pass criteria |
|---|---|
| Build a form with all 27 types | Saves without error |
| Required field empty | Blocked with a per-field message |
| Consent not ticked | Blocked |
| Submit | Lead created from the mapped fields |
| Submissions tab | Shows the payload |
| Elementor form (if Elementor on) | Becomes an enquiry when the setting is on |
| Malicious field value | Stripped / rejected |

---

## 7. Import & export

| Test | Pass criteria |
|---|---|
| Sample CSV | Downloads with correct headers |
| Import 10 rows | All 10 correct on the website |
| Import with unknown headers | Column plan explains each; nothing silently lost |
| Import with `Generic CSV` | Mapping complete when headers match plugin names |
| Import with a portal bridge | Extra headers map correctly |
| Re-import same `external_id`, mode `skip` | No duplicates |
| Re-import, mode `update` | Rows updated, not duplicated |
| Undo import | Everything from that batch removed |
| Multi-value cell (newline) | Becomes several values |
| Prices with commas/₹ | Parsed or clearly rejected, never silently wrong |
| Export listings | Opens in Excel; UTF-8 correct |

---

## 8. Duplicates

| Test | Pass criteria |
|---|---|
| Identical record | Band `same` |
| Same name, different sector | Band `maybe` at most |
| Same sector, size and rooms | Band `near` or `same` |
| Rescan | Completes within its time budget |
| `keep_both` | Stops asking for that pair |
| Large inventory (1,000+) | Scan completes without timing out |

---

## 9. Search & SEO

| Test | Pass criteria |
|---|---|
| Each of the 22 filters | Narrows results |
| Two filters together | Both applied |
| Sort by price | Correct order (sale and rent) |
| Paginated page | Loads, self-canonical |
| View the head of a filter URL | `noindex, follow` + canonical to the clean URL |
| Sitemap | Contains only published listings and non-empty terms |
| Single listing source | JSON-LD present and valid |
| Rank Math / Yoast active | No duplicated title tags; Estat.OS yields |
| New property after a direct DB edit | Rebuild index → appears |

---

## 10. Permissions

| Test | Pass criteria |
|---|---|
| Agent opens Settings | Menu item absent; direct URL refused |
| Agent deletes permanently | Refused |
| Agent edits someone else's record | Becomes a change request |
| Owner approves the request | Applied + logged |
| REST write without capability | 401 / 403 |
| REST read | 200, public data only |
| Pocket: not logged in | Login screen, no data |

---

## 11. Notifications & webhooks

| Test | Pass criteria |
|---|---|
| Send test email | Arrives |
| Send test webhook | 200 at the receiver; logged |
| Webhook receiver down | Logged; retried up to 3 times |
| Signature verification | `verify()` returns true for a genuine payload |
| Unknown signature | `verify()` false |
| Daily summary | Arrives at 8 am (or after firing cron manually) |
| Weekly report | Monday 8 am |

---

## 12. Performance

| Test | Method | Target |
|---|---|---|
| Directory page, 1,000 listings | Query Monitor | 1 index query + 1 fetch |
| Directory page, 10,000 | Query Monitor | Under 1 s server time with object cache |
| Reports | Query Monitor | No meta queries |
| Duplicate scan, 2,000 | Stopwatch | Completes within the budget |
| Import 5,000 rows | Stopwatch | Completes or chunks cleanly |

---

## 13. Automated testing

The plugin ships without a test suite, but its architecture makes one straightforward, because the hard parts are **pure functions**:

| Pure function | Test directly |
|---|---|
| `Support\Status::can( $family, $from, $to )` | Every legal and illegal move |
| `Support\Status::transitions()` | Graph completeness |
| `Support\Vocabulary::*` | Every list returns the expected keys |
| `Data\Duplicate::score( $a, $b )` | Known pairs land in known bands |
| `Data\Duplicate::band( $score )` | Boundaries |
| `Frontend\Seo::decide( $context )` | **No WordPress needed** — feed a context array, assert `index`/`canonical` |
| `Support\Sanitize::*` | Type boundaries |
| `Csv\Spreadsheet::translate_row()` | Field-by-field |
| `Csv\Spreadsheet::guess_mapping()` | Headers ⇒ mapping |
| `Leads\Leads::normalize_phone()` | Indian formats |

### Suggested setup
```
tests/
├── bootstrap.php         loads WP test suite
├── test-status.php
├── test-duplicate.php
├── test-seo.php
├── test-sanitize.php
├── test-spreadsheet.php
└── test-phone.php
```
Run with PHPUnit and `wp-cli scaffold plugin-tests`, or `Seo::decide()` and the sanitisation/duplicate helpers can be tested with **plain PHPUnit and no WordPress at all**.

---

## 14. Release acceptance checklist

Before any version ships:

- [ ] Smoke test (§1) passes on a clean site
- [ ] Upgrade test from the previous version passes
- [ ] All 14 tables present and healthy (`Schema::healthy()`)
- [ ] No PHP notices with `WP_DEBUG` on
- [ ] No PHP notices with `WP_DEBUG` on **and** Elementor active
- [ ] All seven smoke URLs return 200
- [ ] Import → website → enquiry round trip works end to end
- [ ] Bulk action + undo works
- [ ] Bin → restore → delete forever works
- [ ] `/health` reports the right version
- [ ] Zip installs cleanly via Plugins → Add New → Upload
- [ ] Only one `Estate_OS-*.zip` remains in the release folder

---

## 15. Regression hot spots

These have broken before; test them every time.

| Area | Why it is fragile |
|---|---|
| Translation loading | WordPress reloads the locale during boot (see `01` §1) |
| Elementor + `wp_kses_post( WP_Error )` | Elementor Pro fatal (see `10` §4) |
| CSV price parsing | Free text can look like a price |
| `notes` → highlight promotion | Leftover notes text can become a public highlight |
| Status transition graph | Adding a status requires updating `transitions()` **and** `Vocabulary` |
| Search index drift | Direct database edits bypass the hooks |
| Bulk + undo tokens | A batch must be reversible as a batch |
