# Estat.OS — Complete Implementation & Documentation

**Version documented:** 4.1.6 · **Database version:** 12 · **License:** GPL-2.0-or-later
**Plugin name:** Estat.OS — Real Estate Operating System · **Text domain:** `estat-os`

---

## Simple meaning (Hinglish)

Ye poora document set ek hi cheez ke baare mein hai: **Estat.OS**, wo WordPress plugin jo aapki property office chalata hai. Isme likha hai ki plugin andar se kaise bana hai, kaise install hoga, kaise set karna hai, roz ka kaam kaise hota hai, aur koi problem aaye to kya karna hai.

Aapko sab padhne ki zarurat nahi. Aap sirf **Part B (Office)** ke chapters padho:
`05`, `06`, `07`, `08`, `09`. Baaki developer ke liye hai.

---

## Who should read what

| Reader | Read these files |
|---|---|
| **Office owner / non-technical user** | `00`, `05`, `06`, `07`, `08`, `09`, `18` |
| **Web designer / Elementor user** | `00`, `02`, `10`, `13` |
| **PHP developer** | all of them, starting `01`, `11`, `19`, `20` |
| **Server / DevOps engineer** | `02`, `15`, `17`, `18` |
| **QA / tester** | `16` |

---

## The plugin in one page

Estat.OS turns a plain WordPress site into the operating system of a real-estate office.

It stores **six kinds of records** (`estat_listing`, `estat_project`, `estat_agent`, `estat_agency`, `estat_document`, `estat_insight`), organises them with **five taxonomies**, keeps **fourteen purpose-built database tables** for the fast-moving operational data (enquiries, visits, form submissions, search index, audit, webhooks), and exposes the whole thing through **twenty admin screens**, **eighteen shortcodes**, **nineteen Elementor widgets**, **two REST API versions**, and a **mobile "Pocket" app** served from the same WordPress install.

Everything is plain PHP with **no Composer, no build step, no external service, and no required page builder.**

### Hard requirements

| Requirement | Value | Where enforced |
|---|---|---|
| PHP | 7.4 or newer | `estat-os.php`, version guard |
| WordPress | 6.0 or newer | `estat-os.php`, version guard |
| MySQL / MariaDB | 5.6+ / 10.1+ (InnoDB, utf8mb4) | `Schema::install()` |
| Elementor | **optional** | `Integrations\Elementor\Bridge::active()` |
| HTTPS | strongly recommended | consent + webhook security |

If PHP or WordPress is too old, the plugin **does not crash the site** — it prints one admin notice and refuses to boot.

---

## Chapter index

### Part A — Architecture and implementation

| # | File | What it covers |
|---|---|---|
| 01 | `01-Architecture.md` | Boot sequence, module map, namespaces, autoloader, design rules |
| 11 | `11-Data-Structure-Schema.md` | Post types, taxonomies, meta keys, all 14 DB tables |
| 19 | `19-Developer-Reference.md` | Hooks, filters, class API, REST endpoints, constants |
| 20 | `20-Implementation-Guide.md` | How to build the plugin file-by-file from scratch |

### Part B — Running the office

| # | File | What it covers |
|---|---|---|
| 05 | `05-Office-Day-To-Day.md` | Morning routine, the Today screen, the worklist |
| 06 | `06-Pocket-Field-Agent.md` | Pocket (Field Agent OS): login, capture, visits, queue |
| 07 | `07-Listings-Projects-Team.md` | Properties, societies/projects, team, gallery, insights |
| 08 | `08-Enquiries-Visits-Pipeline.md` | Leads, dedupe, visits, pipeline, requests, reports |
| 09 | `09-Forms-Import-Export.md` | Form builder, spreadsheet import/export, CSV contract |

### Part C — Website, data and integrations

| # | File | What it covers |
|---|---|---|
| 02 | `02-Installation-Setup.md` | Install, activate, setup wizard, pages, first-run checks |
| 03 | `03-Configuration-Settings.md` | Every setting, every group, what each one changes |
| 04 | `04-Features-Reference.md` | Feature-by-feature: what it does, how it works inside |
| 10 | `10-Website-Elementor-Integration.md` | Shortcodes, Elementor widgets, templates, page blocks |
| 12 | `12-Permissions-Roles.md` | Roles, 24 capabilities, who may do what |
| 13 | `13-Search-Filtering-SEO.md` | Search index, 30 filters, SEO, canonical, sitemaps, schema |
| 14 | `14-Notifications-Integrations.md` | Email, webhooks, WhatsApp, alerts, cron |

### Part D — Quality, deployment, operations

| # | File | What it covers |
|---|---|---|
| 15 | `15-Security-Validation-Performance.md` | Sanitisation, nonces, capabilities, caching, query shape |
| 16 | `16-Testing-Verification.md` | Manual and automated tests, acceptance checklist |
| 17 | `17-Deployment-Production.md` | Production rollout, backups, upgrades, rollback |
| 18 | `18-Troubleshooting-Maintenance.md` | Common faults, diagnostics, repair tools |

---

## Three rules the whole codebase obeys

These are not stylistic preferences. They are load-bearing: break one and a documented behaviour somewhere in this manual stops being true.

**1. One REEP logic.** Every duplicate decision, every status move, every bin action goes through one function. There is never a second implementation of "are these the same?" or "may this record move?". `Data\Duplicate::score()` decides sameness everywhere; `Support\Status::can()` decides legal moves everywhere. Two places may *show* the answer (a warning box while adding, and the Duplicates screen), but only one place *computes* it.

**2. Fixed words.** Statuses, availability, outcomes and stages are fixed vocabularies in `Support\Vocabulary`. The stored value (`publish`, `on_hold`, `office_verified`) and the word shown to a human ("Live", "Under offer", "Verified by office") are separated, so the database never depends on the language. Changing a label is safe; changing a stored key is a migration.

**3. Everything is auditable.** `Audit\AuditLog` records who did what to which record, with context. Bin moves, restores, permanent deletes, imports, settings changes and cron runs are all written. The audit log is also where "why did this disappear?" questions get answered.

---

## The shipped file inventory

| Group | Count | Notes |
|---|---|---|
| PHP files | 121 | ~53,200 lines, namespace `EstatOS\` |
| Admin screens | 20 | `includes/Admin/Screens/*.php` |
| Frontend templates | 12 | `includes/Frontend/templates/*.php` |
| CSS files | 7 | tokens, admin, admin-new, dashboard, fields, forms, pocket, public |
| JavaScript files | 6 | admin, bulk, form-builder, forms, public, share, whatsapp |
| Elementor widgets | 19 | one file, `Widgets.php`, nineteen classes |
| Shortcodes | 18 | `Frontend\Shortcodes` |
| Database tables | 14 | `Schema::tables()` |
| Translations | 3 | `en_US`, `en_IN_hinglish`, `.pot` template |
| SVG backgrounds | 8 | used by the design-token system |

---

## How to read a chapter

Every chapter has the same shape:

- **Simple meaning (Hinglish)** — two or three lines, no jargon.
- **What it does** — the behaviour, from the user's side.
- **How it works internally** — the real classes, methods, tables and hooks.
- **How to configure it** — the exact screen and setting.
- **Day-to-day use** — what the office actually clicks.
- **Troubleshooting** — the faults that actually happen.

Code references are written as `Class::method()` and resolve against the namespace `EstatOS\`, so `Data\Listings::save()` means `EstatOS\Data\Listings::save()` found in `includes/Data/Listings.php`.

---

## Interface, version 4.1.3 (the current one)

The office and the pocket were rebuilt against an approved visual design. What
that means in practice, in one page:

**The office** keeps three layers: WordPress's own menu on the left, the
plugin's module rail inside the content area beside it, and the screen itself.
Societies & Projects are edited from the office screen with an Edit chip and a
save form. The Properties screen has a **Compare** button: tick two to four
homes and they open side by side in the drawer, ten questions asked of each.

**The pocket** (`/agent/`) is the field agent's phone app:

| | Computer | Tablet | Phone |
|---|---|---|---|
| Navigation | dark rail, 252px, on the left | five doors along the bottom | five doors along the bottom |
| Bottom bar | **none** | Today · Leads · **Add** · Properties · Visits | the same five |
| Columns | two | two | one |
| Top bar | name · search · the person | same | search drops to its own line |

The five doors are always: **Today · Leads · ＋ Add · Properties · Visits**, and
Add is the dark one in the middle. Numbers on Today are count-ups, and every
card is a door to the list behind it.

New in 4.1.3: **a shortlist and a comparison**. Every property row carries a
star. The starred homes gather under *My shortlist*, and two to four of them
can be read side by side on ten questions — price, size, bedrooms, bathrooms,
floor, furnishing, parking, where, availability, society. A question with no
answer says "not said" rather than disappearing, because a gap that is visible
is a gap somebody can fill.

### Visitors can shortlist too (4.1.4)

The same idea reaches the public website, without an account: a heart and a
Compare button on every property card, the visitor's own list kept in their
browser, and a **"Send this list on WhatsApp"** button that turns their shortlist
into an ordinary enquiry in the office — source *comparison*, in the audit log,
chased like any other — and opens WhatsApp with the same list written out. The
comparison asks the same ten questions as the office and the agent's phone,
because the list is written down once in `Support/Comparison.php`.

### A full desktop (4.1.5)

Both the office screen and the pocket used to live inside a 1400px column left
over from the first version of the shell. On a 1920px screen that is 260px of
empty page on either side, and the pocket had a second cap (1280px) on top of
it. Measured, then removed: the shell now fills the window, and the pocket's
Today card is a **bento** on a wide screen — numbers across the top, the work
on the left with what is coming beside it, the task list across the foot.
Tablet and phone are unchanged, because a phone has no room to fill.

### The office's own logo, and a rail that holds together (4.1.6)

Every mark in the app was a coloured square with a letter in it — the office
rail, the agent's top bar, the sign-in page. That is a placeholder, and a
placeholder on the first screen of the morning reads as "this is not
finished". The app now carries **the office's own logo**: the one uploaded
under Settings → The office → Office logo, or the one WordPress already uses
under Site Identity, or the mark shipped inside the plugin — in that order,
and never a broken image. The sign-in page draws the whole logo, name
included; the rail and the top bar draw the mark alone, because 252px is not
enough room for a name that long.

The spacing complaint turned out to be a real bug rather than a taste.
`.estat-pocket-tab` carries `flex: 1` for the **bottom bar**, where five
buttons share the width. The desktop rail drew the same class in a column, so
`flex: 1` handed every row an equal slice of the whole column: seven rows in a
594px column came out **84px tall each**, label floating in the middle of a
half-empty box. Rows are their own height now (38px), the column's spare room
sits below them, and the office rail is tighter in the same way — 35px rows,
12px between sections rather than 24px, and each section heading sitting on
the rows it names.

Two quiet repairs went in with it, both of them things the website promised
and did not do: a heart on a **society** card used to come back as "not found"
(now the same ten questions are answered for a society as for a flat), and the
send button on a visitor's shortlist had no ticket to send, so the office never
heard about it. Both fixed; the check is `tests/rest_property_check.php`.
