# 05 — Office Day-to-Day

## Simple meaning (Hinglish)

Ye chapter aapke roz ke kaam ka hai. Subah **Today** screen kholo — wahan likha hota hai ki aaj kya karna hai. Phir Properties, Enquiries, Visits. Din khatam hone par sab kuch "clear" hone ke liye koi extra kaam nahi hai.

---

## 1. The morning routine (five minutes)

1. Open **Estat.OS → Today**.
2. Read the **worklist** — `Data\Worklist::tasks()` builds it from six real sources:

| Task group | Where it comes from | What it means |
|---|---|---|
| Overdue follow-ups | `overdue_followups()` | An enquiry whose follow-up date has passed |
| Visits today | `visits_today()` | Visits scheduled for today |
| New enquiries | `new_enquiries()` | Arrived and not yet touched |
| Unassigned enquiries | `unassigned_enquiries()` | Nobody owns them |
| Incomplete listings | `incomplete_listings()` | Below the completeness threshold |
| Change requests | `field_requests()` | Waiting for your yes or no |

3. Work the list top-down. It is ordered by urgency, and each entry links straight to the record.
4. Three tiles at the top tell you the shape of the day: how much inventory, how many open enquiries, how much needs attention.

**That is the whole morning.** No other screen is required to know what to do.

---

## 2. Adding a property

**Estat.OS → Add a home.** Four groups, in the order your hand naturally moves:

1. **Basics** — headline, what it is (apartment/villa/plot/shop/office…), sale or rent, locality, society/project, address, bedrooms, bathrooms, balconies, parking, floor, facing, furnishing, age.
2. **Price** — price, price type (fixed / negotiable / starting from / on request), rent, deposit, maintenance, area and unit.
3. **Photo** — cover photo first, then the gallery.
4. **Highlights** — pick from the curated list or type your own.

While you type, the duplicate engine runs. If it finds something that looks the same you get a plain-language warning: *"This looks like the same one"*, with the other record's name and a link to open it. You may **keep both** — and once you do, it stops asking about that pair.

**Save as draft** or **Publish**. In `verification_mode = required`, publishing needs the verified tick first.

---

## 3. Adding a society or project

**Estat.OS → Societies / Projects.** One form, seven groups:
identity (name, builder, locality), category, stage, price range, units, possession, highlights.

Once saved, the project shows: how many properties belong to it, how many are available, and a button to see them.

---

## 4. Working an enquiry

**Estat.OS → Enquiries.** Each card shows the person, the property they asked about, where it came from, the timeline, and any duplicate badge.

The normal path:

```
New ──► Contacted ──► Scheduled ──► Won
  │           │            │
  └───────────┴────────────┴──► Lost
```

| Action | Where | What it does |
|---|---|---|
| Add a note | Card → note box | Appended to the timeline with your name and the time |
| Set follow-up | Card → follow-up date | Surfaces in the worklist when the date passes |
| Assign | Card → agent dropdown | Transfers ownership and logs it |
| Schedule a visit | Card → Schedule | Creates a visit, offers an `.ics` download |
| Move status | Card → status buttons | Only legal moves are offered |
| Erase | Card → Erase | Blanks personal data, keeps the row for reports |

> **Duplicate protection is automatic.** If the same person submits the same form twice, the second submission attaches to the first lead instead of creating a new one. The card shows a small badge when that happened.

---

## 5. Running a visit

1. From the enquiry: **Schedule a visit** → date, time, agent, property.
2. **Download .ics** → open it in your phone's calendar.
3. After the visit, open **Site Visits**, find it, and mark the outcome: **Completed**, **No-show**, or **Cancelled**.
4. The enquiry status follows: `scheduled → won` or `scheduled → lost`.

Visits also appear in the mobile **Pocket** app, so an agent can update the outcome from the site.

---

## 6. Approving change requests

**Estat.OS → Change Requests.** An agent asked to change something they do not own. Each item shows the field, the old value, the new value, who asked, and when.

Press **Approve** or **Decline** (with a reason). Either way it is logged, and the asker is told.

---

## 7. Weekly housekeeping (fifteen minutes, Monday)

| Task | Screen | Why |
|---|---|---|
| Check incomplete listings | Today → attention | Below threshold, still visible on the site |
| Look at Duplicates | Duplicates → **Look again** | Catches things imported from different sources |
| Clear the Bin | Bin | Restores mistakes; deletes what is genuinely finished |
| Check the reports | Reports | Where enquiries come from, which areas move |
| Check change requests | Change Requests | Do not let agents wait |

---

## 8. Common situations

### "A client called about a property I no longer have"
Open the property → set **Availability → Sold** (or Rented). It stays on the website as sold unless you also set it to draft. Many offices keep sold properties live because they prove volume.

### "I need to take a property off the website for a week"
Set publication to **Paused** (`private`). It stays in the office, disappears from the website, and one click puts it back.

### "An agent left"
**Team** → open the agent → reassign their properties and enquiries to someone else, then remove them. `Data\Agents::on_delete()` never strands a record.

### "I imported a file and it went wrong"
**Import & export** → the **Undo this import** button appears right after every import. It reverses the whole batch, and only that batch.

### "The website shows an old price"
Purge the cache: **Settings → Advanced → Purge caches**. Most "the site is stale" reports are page cache, not data.

### "Two agents are chasing the same client"
The duplicate badge on the enquiry card tells you. Open both, keep the older one, and merge the notes by hand.

---

## 9. What the office never has to do

- Touch the WordPress media library (use **Gallery & Media**).
- Look at custom post types or meta boxes (there are none).
- Rebuild anything by hand — the search index self-heals on save, and the daily cron repairs drift.
- Worry about deactivating the plugin — nothing is lost by deactivating.

---

## Compare, and the Add buttons (4.1.3)

**Compare.** Properties → **Compare** opens a drawer with the office's own
homes and a tick beside each. Two to four ticks and the same drawer shows them
side by side on ten questions. Any column opens that home in full. The ten
questions live in `Ajax::compare_table()` — one list, so two people looking at
the same pair read the same ten things.

**Add.** Three things were broken and are fixed:

* **Add a project** (quick-add, and `?new=1`) used to reload the page and do
  nothing — no screen ever read the flag. It now opens the project drawer.
* **The Add buttons on Enquiries and Site visits** opened a drawer that only
  worked for records that already existed, so they failed with "no longer
  here". Both now open a real blank form.
* **A project had no way to carry photographs.** The drawer now has a cover
  photo and a photo gallery, picked from the WordPress media library the office
  already keeps its pictures in.
