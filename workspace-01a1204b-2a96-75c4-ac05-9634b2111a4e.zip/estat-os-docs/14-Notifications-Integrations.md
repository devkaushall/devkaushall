# 14 — Notifications, Integrations & Operational Settings

## Simple meaning (Hinglish)

Jab koi enquiry aaye to aapko email/WhatsApp chahiye — wo **Notifications** karta hai. Agar aap CRM ya Google Sheet use karte hain to **Webhook** usko khabar bhejta hai. **Cron** (scheduled jobs) roz ka hisaab aur safai karta hai.

---

## Part A — Email notifications

### The four emails

| Email | Setting | When | Function |
|---|---|---|---|
| New enquiry | `notify_new_lead` (default on) | A lead is created | `Notifier::new_lead()` |
| Listing needs approval | `notify_listing_approval` (default on) | An agent sends one up | `Notifier::listing_needs_approval()` |
| Daily summary | `notify_daily_summary` (default on) | 8 am daily | `Notifier::daily_summary()` |
| Weekly report | `notify_weekly_report` (default on) | Monday 8 am | `Notifier::weekly_report()` |

### Configuration
**Settings → Leads & enquiries:**
- `notify_email` — where they go
- `email_from_name` / `email_from_address` — should be on your own domain
- `email_footer_text` — appended to every mail

`Notifier::mail_from_name()` / `mail_from_address()` filter WordPress's defaults, so all plugin mail is consistently identified.

### Testing
**Settings → Integrations → Send test email** (`Admin::ajax_test_mail()`). Always press it after changing mail settings — it is the only way to know before a real enquiry depends on it.

### WordPress note
WordPress sends with PHP `mail()`, which many hosts block or spam-filter. **Install an SMTP plugin.** If enquiry emails never arrive, this is almost always why.

---

## Part B — Webhooks

### What it does
Posts a JSON payload to one or two URLs when something happens in the office. Use it to push enquiries into a CRM, a Google Sheet, a Slack channel, or your own system.

### The 12 events

| Event | Fires when |
|---|---|
| `lead.created` | A new enquiry arrives |
| `lead.updated` | Any enquiry field changes |
| `lead.status_changed` | New → Contacted → Scheduled → Won/Lost |
| `lead.assigned` | An enquiry is assigned to a team member |
| `visit.scheduled` | A site visit is arranged |
| `visit.completed` | A visit is marked done / no-show |
| `listing.published` | A property goes live |
| `listing.verified` | A property gets the verified tick |
| `project.stage_changed` | A project's stage changes |
| `form.submitted` | Any form is submitted |
| `alert.created` | A visitor creates a search alert |
| `share.logged` | A property is shared |

### Configuration
**Settings → Integrations:**
- `webhook_enabled` (default off)
- `webhook_url`, `webhook_url_2`
- `webhook_secret` — HMAC-SHA256 signing key
- `webhook_version` (`v2`)
- `webhook_retry` (default on)
- `webhook_events` — tick the ones you want

### Delivery
`Webhooks::deliver( $event, $payload, $attempt )`:
1. Build the payload (event, timestamp, object id, data).
2. Sign it: `Webhooks::sign( $message, $secret )` — HMAC-SHA256 in an `X-Estat-Signature` header.
3. POST with a short timeout (never block a visitor's request).
4. Log to `estat_webhook_log` (event, object id, status code, success, attempt, error).
5. On failure, retry with exponential backoff via the `estat_webhook_retry` cron hook — up to three attempts.

`Webhooks::test()` sends a sample; **Send test webhook** uses it. `Webhooks::recent( $limit )` shows the last 20 deliveries.

### Verifying a payload
```php
$is_real = Webhooks::verify( $raw_body, $secret, $_SERVER['HTTP_X_ESTAT_SIGNATURE'] ?? '' );
```
Always verify before trusting a payload.

### Operational advice
- Use a **queueing endpoint** (Zapier, Make, n8n, Apps Script) rather than a slow CRM API — retries protect you, but a fast receiver is better.
- Keep the secret in a constant or environment variable where you can.
- Check the log after any change; it records the HTTP status and the error text.

---

## Part C — WhatsApp

`Frontend\WhatsApp`

| Function | Job |
|---|---|
| `enabled()` | Is the CTA on? |
| `number()` | From the `whatsapp` setting |
| `message()` | Pre-fills the property name and link |
| `button()` | Renders the button |
| `shortcode()` | `[estat_whatsapp]` |
| `tap()` | Records the click as a share event |

There is **no WhatsApp API key and no paid service**. It uses `wa.me` deep links, which work everywhere. Clicks are logged as `share.logged` events.

---

## Part D — Scheduled jobs (cron)

`Cron\Scheduler`

| Hook | Constant | Schedule | Job |
|---|---|---|---|
| `estat_daily_maintenance` | `Scheduler::DAILY` | daily | Expire listings, apply retention, purge audit, process import jobs |
| `estat_daily_summary` | `Scheduler::SUMMARY` | daily, 8 am | Send the daily summary email |
| `estat_weekly_report` | `Scheduler::WEEKLY` | weekly, Mon 8 am | Send the weekly report email |
| `estat_webhook_retry` | `Webhooks::RETRY_HOOK` | as needed | Retry failed deliveries |
| `estat_hourly_maintenance` | — | hourly | Index repair, alert queue |

Scheduling uses `next_hour( 8 )` and `next_weekday_hour( 1, 8 )` so jobs land at a sensible local time rather than whenever the plugin happened to be activated.

### What the daily job does
1. `expire_listings()` — move stale listings to draft when `listing_expiry_days` is set.
2. `Leads::apply_retention( $days )` — erase old personal data.
3. `AuditLog::purge_older_than( $days )`.
4. `process_import_jobs()` — finish anything interrupted.
5. `repair_index()` — 200-row batches, resumable via `estat_index_repair_offset`.
6. Audit-log the run.

### If WordPress cron is unreliable
Many hosts disable `WP-Cron`. Either:
- Set up a real system cron hitting `wp-cron.php` every five minutes, **or**
- Add `define( 'DISABLE_WP_CRON', true );` plus a system cron.

Without working cron you lose: daily/weekly emails, listing expiry, retention, index repair, webhook retries and alert sending. Everything else keeps working.

Check status with **WP Crontrol** or any cron-inspection plugin: look for `estat_daily_maintenance`, `estat_daily_summary`, `estat_weekly_report`.

---

## Part E — REST API

Two namespaces, registered by `Rest\RestApi`:

| Namespace | Purpose |
|---|---|
| `estat/v1` | The original contract — stable, kept for compatibility |
| `estat/v2` | The documented, versioned, fully-argued contract |

### v1 endpoints
| Method | Path | Permission |
|---|---|---|
| GET | `/health` | Public |
| GET | `/properties` | Public |
| GET | `/properties/{id}` | Public |
| GET | `/projects/{id}/stats` | Public |
| GET | `/agents` | Public |
| POST | `/forms/{id}/submit` | Public |
| GET/POST | `/leads` | `estat_manage_leads` |
| POST | `/leads/{id}` | `estat_manage_leads` |
| GET/POST | `/visits` | `estat_manage_visits` |
| POST | `/visits/{id}` | `estat_manage_visits` |
| GET/POST | `/alerts` | read: `estat_manage_leads`; create: Public |
| POST | `/share` | Public |
| POST | `/maintenance` | `estat_run_maintenance` |

### v2 endpoints
| Method | Path | Permission |
|---|---|---|
| GET | `/properties` (with full `search_args()`) | Public |
| GET | `/properties/{id}` | Public |
| GET | `/projects` | Public |
| GET | `/projects/{id}` | Public |
| GET | `/projects/stages` | Public |
| GET | `/agents` | Public |
| GET | `/localities` | Public |

Every v2 argument is declared with `validate_callback` and `sanitize_callback`, so an invalid request is refused by WordPress before your code runs.

### Authentication for writes
Use an **Application Password** (WordPress 5.6+) with a user holding the right capability, over HTTPS. Or a logged-in cookie plus a REST nonce.

---

## Part F — Integrations that need no configuration

| Integration | How it works |
|---|---|
| **OpenStreetMap** | Default map provider, no key |
| **Google Maps** | Set `google_maps_key`, switch `map_provider` |
| **Rank Math** | Robots, canonical, title, description — Estat.OS yields when Rank Math owns a field |
| **Yoast SEO** | Robots filter |
| **Elementor** | Widgets, Theme Builder, native forms → enquiries |
| **WP privacy tools** | Exporter and eraser registered |
| **Caching plugins** | `Support\Cache::purge_all()` clears WP Rocket, W3 Total Cache, LiteSpeed, SiteGround, Autoptimize, WP Engine and more |
| **Backup plugins** | Standard tables and uploads — nothing exotic |

---

## Part G — Operational checklist

**Weekly**
- [ ] Confirm enquiry emails arrived (not just that enquiries arrived).
- [ ] Check **Settings → Integrations → Recent webhook deliveries** if webhooks are on.
- [ ] Confirm cron ran (Site Health or WP Crontrol).

**Monthly**
- [ ] Send a test email and a test webhook.
- [ ] Review `webhook_events` — unsubscribe from noise.
- [ ] Check `estat_audit` and `estat_webhook_log` sizes.

**After any change to mail, webhooks, or cron**
- [ ] Send test email
- [ ] Send test webhook
- [ ] Confirm the three cron hooks are scheduled

---

## Part H — Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| No enquiry emails | No SMTP on the server | Install an SMTP plugin |
| Emails go to spam | From-address on another domain | Set `email_from_address` on your domain |
| Wrong recipient | `notify_email` empty or stale | Settings → Leads |
| Webhook never fires | `webhook_enabled` off, or event unticked | Settings → Integrations |
| Webhook fires but receiver rejects it | Signature mismatch | Check the secret on both sides; use `verify()` |
| Webhook slow | Receiver is slow, or timeout | Use a queueing endpoint |
| Daily summary never arrives | WP-Cron not running | Set up system cron |
| Listings never expire | `listing_expiry_days` = 0, or cron off | Set days; fix cron |
| Everything is one hour off | Server timezone | Settings → General → Timezone |
| `/health` returns 404 | Permalinks plain | Settings → Permalinks → Save |
