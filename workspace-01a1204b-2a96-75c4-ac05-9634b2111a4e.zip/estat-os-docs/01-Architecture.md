# 01 — Architecture & Implementation

## Simple meaning (Hinglish)

Plugin ek hi jagah se shuru hota hai (`estat-os.php`), phir **40 alag-alag module** khud register karte hain — jaise properties, enquiries, forms, search. Har module apna kaam khud sambhalta hai. Isse ek kaam doosre ko todta nahi, aur naya feature jodna aasaan hota hai.

Data do jagah rehta hai: **WordPress ki post/meta** mein (property, project, team), aur plugin ki **apni 14 tables** mein (enquiries, visits, forms, search index).

---

## 1. Boot sequence

Everything starts in `estat-os.php`. The file does five things, in this order:

1. **Guard.** Declares `ESTAT_VERSION` (3.6.6), `ESTAT_DB_VERSION` (12), `ESTAT_FILE`, `ESTAT_DIR`, `ESTAT_URL`, `ESTAT_BASENAME`, plus the two floor constants `ESTAT_MIN_PHP = '7.4'` and `ESTAT_MIN_WP = '6.0'`. If either floor fails, it hooks `admin_notices`, prints one polite message and `return`s. No class is loaded, nothing is registered, the site stays up.

2. **Load the autoloader** (`includes/Autoloader.php`) and the shared helpers (`includes/functions.php`).

3. **Register activation / deactivation hooks** → `Install\Activator::activate()` and `Install\Deactivator::deactivate()`.

4. **Instantiate and boot the `Plugin` singleton** at the bottom of the file.

5. `Plugin::boot()` wires four hooks:

```php
add_action( 'plugins_loaded',      array( $this, 'register_modules' ), 1 );
add_action( 'after_setup_theme',   array( $this, 'load_textdomain'  ), 999 );
add_action( 'wp_loaded',           array( $this, 'load_textdomain'  ), 999 );
add_action( 'init', array( Install\Migrator::class, 'maybe_upgrade' ), 1 );
```

> **Why the language is loaded three times.** WordPress — and most themes — re-load the site language during boot, which silently resets every plugin's text domain back to English. Loading once is not enough; the shipped Hinglish `.mo` never appears. So the plugin loads it right after the theme is ready (priority 999) and **once more** at `wp_loaded` (priority 999). `I18n\Language` must also register its `plugin_locale` filter on `plugins_loaded` at priority 1, i.e. *before* the translation file is chosen.

---

## 2. Module map

`Plugin::register_modules()` holds an array of **forty** `key => class` pairs. Each class is instantiated; if it has a `register()` method, that method is called. The instance is stored so `Plugin::module( $key )` can fetch it.

| Key | Class | Responsibility |
|---|---|---|
| `i18n` | `I18n\Language` | Office vs public language, Hinglish, visitor switch |
| `settings` | `Settings\Settings` | One option array, `estat_settings` |
| `roles` | `Security\Roles` | Two roles, 24 capabilities |
| `post_types` | `Data\PostTypes` | Six custom post types |
| `taxonomies` | `Data\Taxonomies` | Five taxonomies + Elementor safety guard |
| `meta` | `Data\Meta` | Registers and sanitises every meta field |
| `listings` | `Data\Listings` | Listing save/validate/derive/completeness |
| `bin` | `Data\Bin` | Recycle bin, bulk, undo |
| `projects` | `Data\Projects` | Societies and projects |
| `agents` | `Data\Agents` | Team members |
| `leads` | `Leads\Leads` | Enquiries |
| `lead_events` | `Leads\LeadEvents` | Enquiry timeline |
| `visits` | `Leads\Visits` | Site visits + `.ics` |
| `forms` | `Forms\Forms` | Form definitions |
| `submissions` | `Forms\Submissions` | Form intake → lead |
| `search` | `Search\SearchIndex` | The flat search index |
| `query` | `Search\Query` | The fast filter/sort query |
| `alerts` | `Search\Alerts` | Saved-search email alerts |
| `templates` | `Data\Templates` | Page block order |
| `audit` | `Audit\AuditLog` | Activity history |
| `requests` | `Field\Requests` | Change-request workflow |
| `webhooks` | `Webhooks\Webhooks` | Outbound events, HMAC, retry |
| `notify` | `Notifications\Notifier` | Outbound email |
| `csv` | `Csv\Spreadsheet` | Import/export, bridge mappings |
| `rest` | `Rest\RestApi` | `estat/v1` and `estat/v2` |
| `frontend` | `Frontend\Frontend` | Public assets and routing |
| `shortcodes` | `Frontend\Shortcodes` | 18 shortcodes |
| `pages` | `Frontend\Pages` | 14 built pages |
| `seo` | `Frontend\Schema` | JSON-LD structured data |
| `seo_contract` | `Frontend\Seo` | Index/canonical/title/description |
| `share` | `Frontend\Share` | Share log |
| `whatsapp` | `Frontend\WhatsApp` | WhatsApp CTA and tap tracking |
| `cron` | `Cron\Scheduler` | Three recurring jobs |
| `privacy` | `Privacy\Privacy` | WP privacy exporter/eraser |
| `practice` | `Support\PracticeMode` | Practice/demo data |
| `design_tokens` | `Support\DesignTokens` | Inline CSS variables |
| `pocket` | `Pocket\Pocket` | Field Agent OS (mobile) |
| `office` | `Office\Dashboard` | Front-end office dashboard |
| `elementor` | `Integrations\Elementor\Bridge` | Elementor bridge |
| `admin` | `Admin\Admin` | **Only when `is_admin()`** |

Two extension points surround this:

```php
$classes = (array) apply_filters( 'estat_modules', $classes );
// ... after all modules registered:
do_action( 'estat_loaded', $this );
```

A developer can add a module, replace a module, or hook in after boot — without editing the plugin.

---

## 3. Namespaces, autoloading, file layout

Namespace root is `EstatOS\`. The autoloader maps namespace segments to directories under `includes/`:

```
EstatOS\Data\Listings        → includes/Data/Listings.php
EstatOS\Admin\Screens\BinScreen → includes/Admin/Screens/BinScreen.php
EstatOS\Integrations\Elementor\Bridge → includes/Integrations/Elementor/Bridge.php
```

```
estat-os/
├── estat-os.php              entry point, version guard, constants
├── uninstall.php             opt-in data erasure only
├── readme.txt                WordPress.org readme
├── includes/
│   ├── Autoloader.php
│   ├── Plugin.php            singleton + module map
│   ├── functions.php         shared helpers
│   ├── Admin/                menu, one action handler, 20 screens
│   ├── Audit/                AuditLog
│   ├── Cron/                 Scheduler
│   ├── Csv/                  Spreadsheet (import/export/bridge)
│   ├── Data/                 PostTypes, Taxonomies, Meta, Listings,
│   │                         Projects, Agents, Bin, Duplicate, Health,
│   │                         Highlights, Insights, Media, Meta, Picker,
│   │                         Templates, Undo, Worklist
│   ├── Field/                Requests (change-request workflow)
│   ├── Forms/                Forms, FieldTypes, Renderer, Style,
│   │                         Submissions, Templates
│   ├── Frontend/             Frontend, Pages, Components, Shortcodes,
│   │                         Seo, Schema, Share, WhatsApp + templates/
│   ├── I18n/                 Language
│   ├── Install/              Activator, Deactivator, Migrator, Pages,
│   │                         RepairData, Schema
│   ├── Integrations/Elementor/ Bridge, BaseWidget, Widgets
│   ├── Leads/                Leads, LeadEvents, Visits
│   ├── Notifications/        Notifier
│   ├── Office/               Dashboard, Screens
│   ├── Pocket/               Pocket, Screens, Steps, Actions
│   ├── Privacy/              Privacy
│   ├── Rest/                 RestApi
│   ├── Search/               SearchIndex, Query, Alerts
│   ├── Security/             Roles
│   ├── Settings/             Settings
│   ├── Support/              Cache, DesignTokens, Format, Icon,
│   │                         PracticeMode, Qr, Sanitize, Status, Vocabulary
│   ├── Webhooks/             Webhooks
│   └── Work/                 MyDay
├── assets/                   css/ js/ backgrounds/ demo/
└── languages/                en_US, en_IN_hinglish, .pot
```

---

## 4. The four layers

```
┌──────────────────────────────────────────────────────────────┐
│ PRESENTATION                                                 │
│  Admin\Admin (menu, assets) · Admin\Screens\* (20 screens)   │
│  Pocket\Screens (mobile) · Office\Screens (front dashboard)  │
│  Frontend\Components + templates · Elementor widgets         │
├──────────────────────────────────────────────────────────────┤
│ ACTION                                                       │
│  Admin\Actions::handle()   — one entry point, one nonce each  │
│  Pocket\Actions · Office\Dashboard::post()                    │
│  Rest\RestApi · Forms\Submissions                             │
├──────────────────────────────────────────────────────────────┤
│ DOMAIN                                                       │
│  Data\*  Leads\*  Forms\*  Search\*  Field\Requests            │
│  Support\Status (legal moves) · Support\Vocabulary (words)    │
│  Data\Duplicate (sameness) · Data\Health (readiness)          │
├──────────────────────────────────────────────────────────────┤
│ PERSISTENCE                                                  │
│  WP posts + postmeta + terms  (6 CPTs, 5 taxonomies)          │
│  14 custom tables via Schema  (leads, visits, index, audit…)  │
│  Options: estat_settings (one array)                          │
└──────────────────────────────────────────────────────────────┘
```

### Why data is split two ways

- **WordPress posts + meta** hold anything a human edits slowly: a property, a project, a team member, an article. This gives you revisions, the media library, SEO plugins, and standard WordPress tooling for free.
- **Custom tables** hold anything that grows fast and must be queried fast: enquiries, visits, form submissions, the search index, the audit trail, webhook deliveries. A `WP_Query` with six meta filters over 10,000 listings is slow; one indexed query against `estat_index` is not.

`Search\SearchIndex` keeps `estat_index` in step with the posts. It re-indexes on save, on status change, and on term change, and the daily cron repairs any drift in batches (`rebuild_batch( 100, $offset )`, resumable via the `estat_index_repair_offset` option).

---

## 5. The single action handler

Every form submission and every action link in the admin goes through **one** function:

```php
Admin\Actions::handle()   // hooked on admin_post_ + admin_post_ajax_
```

The pattern is identical for all ~60 actions:

1. Read the `action` key.
2. Verify the nonce for *that* action (`check_admin_referer`).
3. Check the capability for *that* action (`current_user_can`).
4. Do the work through the domain class.
5. `wp_safe_redirect()` back — **always**, so a browser refresh never repeats the work.

`Admin\Actions::bulk_operations()` publishes the list of legal bulk operations, and `Partials::bulk_open()/bulk_close()` draw the shared bulk-select bar, so every screen's bulk behaviour is the same code.

---

## 6. Cross-cutting services

| Service | Class | Job |
|---|---|---|
| Sanitisation | `Support\Sanitize` | Every value from `$_GET`/`$_POST`/CSV passes through typed helpers |
| Status law | `Support\Status` | Legal transitions, labels, tone |
| Words | `Support\Vocabulary` | Every fixed list in the product |
| Sameness | `Data\Duplicate` | Fingerprints, scoring, the three bands |
| Readiness | `Data\Health` | Per-listing rules, attention list, CSV |
| Undo | `Data\Undo` | Snapshots chosen meta before a change; restores them |
| Audit | `Audit\AuditLog` | Append-only history with purge |
| Cache | `Support\Cache` | Purges WP Rocket, W3TC, LiteSpeed, SG, Autoptimize, WP Engine, and more |
| Format | `Support\Format` | Indian price format, abbreviations, dates |
| Icons | `Support\Icon` | Inline SVG set |
| QR | `Support\Qr` | QR codes for Pocket links |
| Tokens | `Support\DesignTokens` | Turns saved colour/font choices into inline CSS |

---

## 7. Design rules you must not break

1. **No business logic in screens.** A screen renders. It calls a domain class. If you find an SQL query in `Admin\Screens\*.php`, it is a bug.
2. **Escape at the point of output.** `Partials::field()`, every card, every table cell. Never escape early and store escaped data.
3. **Sanitise at the point of input.** `Support\Sanitize`, `Settings::sanitize()`, `Meta::sanitize_value()`.
4. **Capability, then nonce, then work.** In that order, every time.
5. **One vocabulary.** Never hard-code a status word in a template. Use `Support\Status::label()` / `Support\Vocabulary::*()`.
6. **One duplicate engine.** Never write a second comparison. Call `Data\Duplicate::check()`.
7. **No jQuery dependency on the public site.** `assets/js/public.js` is vanilla.
8. **Elementor is optional.** Any Elementor code path must be guarded by `Integrations\Elementor\Bridge::active()`.

---

## 8. Extension points (summary)

| Hook | Type | Purpose |
|---|---|---|
| `estat_modules` | filter | Add/replace a module before boot |
| `estat_loaded` | action | Runs after all modules register |
| `estat_form_field_types` | filter | Add a form field type |
| `estat_setting_*` | filter | Add a settings field |
| `estat_duplicate_*` | filter | Tune duplicate scoring |

The full list with signatures is in **`19-Developer-Reference.md`**.
