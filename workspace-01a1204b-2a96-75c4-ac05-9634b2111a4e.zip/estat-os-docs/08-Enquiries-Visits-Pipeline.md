# 08 — Enquiries, Visits, Pipeline, Requests & Reports

## Simple meaning (Hinglish)

Ye chapter poore "client" hisse ka hai: enquiry aayi → usko aage badhao → visit fix karo → jeeta ya haara likho. Saath mein **Pipeline** (board), **Change Requests** (approval), aur **Reports** (hisaab).

---

## 1. Where enquiries come from

| Source | Path | Notes |
|---|---|---|
| Website form | `Forms\Submissions::handle()` | The main one |
| Elementor native form | `Integrations\Elementor\Bridge::form_record()` | Turn on in Integrations |
| Pocket capture | `Pocket\Actions` | From the field |
| REST API | `POST /wp-json/estat/v1/leads` | Needs `estat_manage_leads` |
| CSV import | `Csv\Spreadsheet` | Kind = `leads` |
| Manual add | Office / Pocket | |

All six land in the same table, through the same `Leads\Leads::create()`.

---

## 2. What happens when an enquiry arrives

`Leads\Leads::create()` runs this sequence every time:

1. **Prepare** (`prepare()`) — trim, normalise phone, extract UTM, hash the IP.
2. **Validate** (`validate()`) — name, a contact route, consent if required.
3. **Dedupe** — build `dedupe_hash` (phone + listing + time window) and look for an existing lead. If found, **attach** instead of creating.
4. **Idempotency** — `idempotency_key` has a `UNIQUE KEY`; a re-submitted form cannot create a second row.
5. **Auto-assign** (`auto_agent()`) — by assignment rules, locality, or round-robin.
6. **Insert** with `status = new`.
7. **Log the event** (`LeadEvents::add('created')`).
8. **Notify** (`Notifier::new_lead()`) if `notify_new_lead` is on.
9. **Fire the webhook** (`Webhooks::on_lead_created()`) if `lead.created` is enabled.

### Phone normalisation (important for India)
`Leads\Leads::normalize_phone()` handles `+91`, `0091`, leading `0`, spaces, hyphens and brackets, reducing them to a 10-digit identity. Without this, "98765 43210" and "+91-98765-43210" would look like two different people.

---

## 3. The Enquiries screen

`Admin\Screens\Enquiries`

Each card (`lead_card()`) shows:
- Name, phone (tap to call), email
- The property they asked about, with a link
- Source, submission source, UTM
- **Duplicate badge** when a repeat was merged
- The **timeline** (`LeadEvents::for_lead()`) — every note, move, assignment and visit
- Actions: note, follow-up date, assign, status move, schedule visit, `.ics`, erase

### Statuses (fixed)
| Stored | Shown |
|---|---|
| `new` | New |
| `contacted` | Contacted |
| `scheduled` | Scheduled |
| `won` | Won |
| `lost` | Lost |
| (`spam`) | Deleted |

Legacy aliases folded: `qualified`→contacted, `visit_scheduled`→scheduled, `converted`→won.

### Legal moves
```
new       → contacted, lost
contacted → scheduled, lost
scheduled → won, lost
won/lost  → contacted, won, lost
```
Anything not on this list is refused by the server even if a browser asks for it.

---

## 4. Visits

`Leads\Visits`

| Function | Purpose |
|---|---|
| `schedule()` | Creates a visit; `dedupe_hash` blocks a double booking |
| `update()` | Change time, agent, or outcome |
| `query()` | Filtered list |
| `counts()` | Dashboard numbers |
| `ics()` | A real RFC 5545 calendar file |

Outcomes (fixed): `pending` (Scheduled), `done` (Completed), `no_show`, `cancelled`.

### Day to day
1. From the enquiry → **Schedule a visit**.
2. Pick date, time, agent, property.
3. **Download .ics** → your phone's calendar.
4. After the visit → mark the outcome in Enquiries, Site Visits, or Pocket.

Cron flags `reminder_sent` so a reminder is sent once, not every hour.

---

## 5. Pipeline (Kanban)

`Admin\Screens\PipelineScreen` + `Admin::ajax_move_pipeline()`

```
┌──────────┬────────────┬────────────┬──────────────┐
│   NEW    │ CONTACTED  │ SCHEDULED  │  WON / LOST  │
├──────────┼────────────┼────────────┼──────────────┤
│  card    │   card     │   card     │    card      │
│  card    │   card     │            │    card      │
└──────────┴────────────┴────────────┴──────────────┘
```

Drag a card → an AJAX call → `Support\Status::can()` on the server → move or refuse. If refused, the card snaps back with a plain-language reason.

---

## 6. Change Requests

`Field\Requests` — for when an agent wants to change a record they do not own.

```
Agent edits  ──►  Request (pending)  ──►  Office approves / declines
                                              │
                                              ▼
                                    Applied + logged + noted
```

| Function | Job |
|---|---|
| `create()` | Snapshots current values, stores typed changes |
| `current_values()` / `current_value()` | What it is now |
| `describe()` | A human sentence: "Price: 1.2 cr → 1.35 cr" |
| `approve()` | Applies the change, logs it, appends a note |
| `decline()` | Records a reason, notifies the asker |
| `pending_count()` | Badge on the menu |
| `may_edit_directly()` | Office bypasses the whole workflow |

States: `pending` (Waiting for office), `approved`, `declined`.

---

## 7. Reports

`Admin\Screens\Reports` — built from `estat_index` and the lead tables, so it stays fast at ten thousand listings.

| Section | What it tells you |
|---|---|
| **Enquiry summary** | How many arrived, how many won/lost, average time to first response |
| **Pipeline** | How many sit in each stage right now |
| **Agent table** | Per agent: assigned, contacted, visits, won |
| **Inventory** | Counts by type, offer, status, completeness |
| **Localities** | Which areas have stock and which have enquiries |
| **Sources** | Website / Pocket / import / API — where the business comes from |

A date range control sits at the top. Every number is a real query, not an estimate.

---

## 8. Erasure, retention, privacy

| Concern | Mechanism |
|---|---|
| Right to erasure | `Leads\Leads::erase()` — blanks name, phone, email, message; keeps the row with `erased = 1` for reporting |
| Bulk retention | `Leads\Leads::apply_retention( $days )` — cron-driven, per `retention_days` |
| Consent record | `consent` + `consent_text_version` stored with each lead |
| IP handling | Stored **hashed** (`ip_hash CHAR(64)`), never raw |
| WP privacy tools | `Privacy\Privacy` registers an exporter and an eraser, so WordPress's own Erase Personal Data finds enquiry data |
| Policy link | `privacy_url` shown under every form |

---

## 9. Day-to-day patterns

### A normal working day
```
Morning   Today → worklist
09:30     New enquiries → call → move to Contacted
11:00     Schedule two visits → send .ics
13:00     Visit 1 → mark Completed
16:00     Visit 2 → mark No-show → move enquiry back to Contacted
17:00     One approval from the field
End       Anything unassigned? Assign it.
```

### Friday
- Reports → sources: which channel is producing?
- Reports → agent table: is work spread evenly?
- Change Requests: clear to zero.

---

## 10. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Enquiry form submits but nothing arrives | No mail sender; or form not linked | Check **Submissions** tab of the form; install SMTP |
| Two cards for one person | Different phone formats | Merge by hand; future ones dedupe automatically |
| Status button missing | Not a legal move from here | Use the correct intermediate step |
| `.ics` will not open | Calendar app not associated | Save the file and import it |
| Pipeline drag snaps back | Illegal move (server refused) | Follow the legal path |
| Agent cannot see an enquiry | Not assigned to them and not office | Assign it, or grant office role |
| Report numbers look stale | Object cache | Purge caches |
| Erased data still counted | By design — the row stays for reporting | Only personal fields are blanked |
