# 15 — Security, Validation, Error Handling & Performance

## Simple meaning (Hinglish)

Security ka matlab: koi bahar wala aapka data na chura sake, na bigaad sake. Plugin teen cheezein har baar check karta hai — **permission** (kaun ho aap), **nonce** (sahi jagah se request aayi), **sanitisation** (data saaf hai). Performance ke liye search apni table se chalta hai.

---

## 1. The security model in one page

Every write in the plugin passes three gates, in this order:

```
1. CAPABILITY  → current_user_can( 'estat_...' )
2. NONCE       → check_admin_referer( 'estat_<action>_<id>' )
3. SANITISE    → Support\Sanitize::*()  /  Meta::sanitize_value()
        │
        ▼
   WORK  →  domain class
        │
        ▼
   REDIRECT → wp_safe_redirect()   (so refresh never repeats it)
```

`Admin\Actions::handle()` is the single place this happens for all ~60 admin actions. `Pocket\Actions` and `Office\Dashboard::post()` repeat the same shape for their surfaces. REST routes use `permission_callback`.

---

## 2. Input: sanitisation

`Support\Sanitize` provides typed helpers, and every entry point uses them.

| Entry point | Sanitisation |
|---|---|
| `$_GET` / `$_POST` in admin | `Admin\Actions` → `Sanitize::*` |
| REST arguments | `validate_callback` + `sanitize_callback` per arg |
| Form submissions | `Forms\Submissions::validate_fields()` per field type |
| CSV import | `Spreadsheet::translate_row()` per column type |
| Settings | `Settings::sanitize()` per key |
| Meta | `Meta::sanitize_value( $value, $field )` |

Rules:
- **Nothing is trusted from the browser.** A form definition posted back from the builder is re-validated from scratch (`Forms::sanitize_definition()`).
- **Whitelists, not blacklists.** Statuses, offers, property types and unit values are checked against `Support\Vocabulary`. Unknown values fall to a safe default rather than being stored.
- **Numbers are numbers.** `Sanitize::int( $v, $min, $max )`, `Sanitize::money()`, `Sanitize::bool()`.

### A real trap this avoids
`Csv\Spreadsheet::rescue_project_row()` scans free-text fields for price-like patterns. A note reading *"plots from 40 – 100 Cr"* would be parsed as a **price of 40**. So:
- Prices live **only** in `price_min` / `price_max` / `price_unit`.
- Free-text fields ( `notes`, `highlights`, `unit_types` ) must never contain a currency amount written as a bare number.

---

## 3. Output: escaping

Everything is escaped **at the point of output**, never before storage.

| Context | Function |
|---|---|
| HTML text | `esc_html()` |
| Attribute | `esc_attr()` |
| URL | `esc_url()` |
| Textarea | `esc_textarea()` |
| JS inline | `wp_json_encode()` + `esc_js()` |
| Allowed HTML | `wp_kses_post()` |

`Admin\Partials` encapsulates this: `field()`, `card_open()`, `stat()`, `record_actions()`, `pagination()` — all escape internally, so a screen author cannot forget.

**Never store escaped data.** Escaping early produces double-escaped output and hides XSS rather than preventing it.

---

## 4. SQL safety

- `$wpdb->prepare()` for every statement with variable input.
- No string concatenation of user input into SQL.
- Every table reference goes through `Schema::table()`, which prefixes properly.
- Filter queries build their `WHERE` from a fixed column whitelist, never from a raw key.

---

## 5. Files and uploads

| Control | Where |
|---|---|
| Uploads must be WordPress attachments | `Admin::ajax_upload()` |
| Mime types restricted per media kind | `Data\Media::mimes_for()` |
| **CSV opens only inside the uploads directory** | `Spreadsheet::open()` — realpath check, refuses anything outside |
| Imported files are hashed (`file_hash`) | `estat_import_jobs` |
| No `eval`, no `include` of user input, no remote file fetch | throughout |

That CSV path check is worth calling out: it is what stops a crafted path from reading arbitrary files off the server.

---

## 6. Privacy by construction

| Concern | Mechanism |
|---|---|
| IP addresses | Stored **hashed** — `ip_hash CHAR(64)`. Raw IPs are never persisted |
| Consent | `consent` + `consent_text_version` stored with every lead |
| Erasure | `Leads::erase()` blanks personal fields, keeps the row (erased = 1) for reporting |
| Retention | `Leads::apply_retention( $days )` via cron |
| Export | `Privacy\Privacy::export()` registered with `wp_privacy_personal_data_exporters` |
| Erase | `Privacy\Privacy::erase()` registered with `wp_privacy_personal_data_erasers` |
| Policy link | `privacy_url` shown under every form |

Registration with WordPress's own privacy tools means **Dashboard → Tools → Erase Personal Data** finds enquiry data automatically — a legal requirement in many jurisdictions.

---

## 7. Error handling philosophy

**Never show a stack trace to an office user. Never hide the reason either.**

| Layer | Behaviour |
|---|---|
| Validation | Returns `[ ok, errors, warnings ]` — the screen shows plain-language messages next to the field |
| Domain failure | Returns a result array with a `why` string; the screen shows it |
| Unexpected exception | Caught, written to `error_log`, and surfaced as: *"Something went wrong. It has been logged."* |
| Elementor bridge | `Bridge::note( Throwable $e )` — a widget failure never takes down the page |
| Cron | Each job is wrapped; one failure does not stop the others |
| Webhooks | Failures are logged and retried; a dead endpoint never blocks the office |
| Front-end | A missing record renders an empty state, never a PHP warning |

### Debug logging
Enable `WP_DEBUG` and `WP_DEBUG_LOG` in `wp-config.php`; entries land in `wp-content/debug.log`. The plugin writes structured, greppable messages prefixed with the class name.

---

## 8. Validation rules by record

### Listing (`Data\Listings::validate()`)
- Title required.
- Offer must be in `Vocabulary::offers()`.
- Property type must be in `Vocabulary::property_types()`.
- Price required unless price type is `on_request`.
- Area must be positive when given.
- Bedrooms required for residential types.
- Locality recommended (warning, not error).
- Possession date must be `YYYY-MM-DD` when given.

### Lead (`Leads\Leads::validate()`)
- Name required.
- At least one of phone or email.
- Phone must normalise to a plausible number.
- Consent required when a consent field is present.

### Project (`Data\Projects::save()`)
- Name required.
- Category and status must be in vocabulary.
- `price_min` ≤ `price_max` when both given.
- `available_units` ≤ `total_units` when both given.

### Form submission (`Forms\Submissions::validate_fields()`)
- Per field type: required, format (`email`, `tel`, `url`, `number`), choice membership, consent ticked.

---

## 9. Performance

### Query shape
| Operation | Queries |
|---|---|
| Filtered directory | 1 on `estat_index` + 1 fetch by IDs |
| Project listing counts | 1 batched (`Projects::listing_counts()`) |
| Locality counts | Pre-computed (`Seo::listing_counts()`) |
| Reports | Against `estat_index` |
| No N+1 anywhere on public pages | enforced by the batched helpers |

### Caching
- `Support\Cache::purge_all()` clears every known page/object cache after imports, settings changes and activation.
- Search results are **not** cached long-term — they must reflect office changes immediately.
- `Seo` memoises per-request counts.
- `Duplicate` memoises fingerprints (`Duplicate::forget_cache()` clears).

### Indexing
Every filter has a matching index on `estat_index` (see `11-Data-Structure-Schema.md` §4.6). `price_sort` exists so sale and rent can be sorted by one column.

### Recommended scale

| Inventory | Expectation |
|---|---|
| ≤ 1,000 listings | Fast on any shared host |
| 1,000–10,000 | Fine with a page cache |
| 10,000+ | Use object cache (Redis/Memcached) and a real cron |

### Asset behaviour
- Public CSS and JS are small and versioned.
- Public JS is vanilla — **no jQuery on the front end**.
- Images use native lazy loading.
- Admin assets load only on Estat.OS screens (`Admin::assets()` checks the hook).

---

## 10. Hardening checklist

- [ ] HTTPS everywhere (needed for consent and webhooks).
- [ ] `DISABLE_FILE_EDIT` / `DISABLE_FILE_MODS` in `wp-config.php`.
- [ ] Real system cron instead of WP-Cron.
- [ ] SMTP plugin so mail actually sends.
- [ ] Object cache (Redis) above 10,000 listings.
- [ ] Page cache, with `Support\Cache` able to purge it.
- [ ] Backups that include the 14 `estat_*` tables **and** `uploads/`.
- [ ] Least privilege: agents on `estat_office_agent`, never administrator.
- [ ] Keep `estat_delete_listings` with owners only.
- [ ] Review `estat_audit` monthly.
- [ ] Rotate `webhook_secret` if a receiver is compromised.
- [ ] Keep WordPress, PHP and the plugin current.

---

## 11. Known limits (honest)

| Limit | Why | Workaround |
|---|---|---|
| No row-level encryption at rest | Would break every query | Rely on host-level disk encryption |
| No built-in 2FA | WordPress's concern | Use a 2FA plugin |
| No rate limiting on REST reads | Reads are public by design | Put Cloudflare or similar in front |
| Duplicate detection is heuristic | No algorithm is perfect | The `maybe` band exists precisely so it can be wrong politely |
| `estat_index` must be rebuilt after a bulk direct-DB edit | It is a cache of the posts | Advanced → Rebuild search index |
| Media lives in the standard library | Deliberate — keeps every CDN/backup plugin working | Use Gallery for the office view |
