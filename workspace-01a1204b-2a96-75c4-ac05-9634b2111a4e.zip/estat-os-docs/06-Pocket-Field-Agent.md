# 06 — Pocket (Field Agent OS)

## Simple meaning (Hinglish)

Pocket = agent ke phone ke liye chhota app. Agent site par khada ho kar photo le sakta hai, property daal sakta hai, enquiry dekh sakta hai, visit update kar sakta hai. Internet na ho to data phone mein save ho jaata hai, aur network milte hi apne-aap chala jaata hai.

Koi app install nahi karni padti — browser mein khul jaata hai.

---

## 1. What Pocket is

A mobile-first front-end application served from the same WordPress install at:

```
https://your-site.com/pocket/
```

Registered by `Pocket\Pocket::add_rewrites()`. It is **not** a separate app, needs no app store, and shares one database with the office.

---

## 2. Logging in

Three ways, in the order they are tried:

1. **Already logged in to WordPress** — Pocket opens straight away.
2. **Phone number + password** — `Pocket\Pocket::phone_auth()` hooks `authenticate` and resolves a phone number to a WordPress user via `agent_by_phone()`.
3. **Login screen** — standard WordPress credentials.

Requirements:
- The person must have a WordPress user.
- That user should have the `estat_office_agent` or `estat_office_owner` role.
- Their agent record must carry the same phone number (`Data\Agents::for_user()` maps user ⇒ agent).

`Pocket::can_use()` gates the whole surface; `Pocket::is_office()` decides whether they see everyone's records or only their own.

---

## 3. The five home tabs

```
┌─────────┬──────────┬─────────┬────────┬────────┐
│  Today  │  Leads   │ Visits  │ Search │  More  │
└─────────┴──────────┴─────────┴────────┴────────┘
```

| Tab | What is on it |
|---|---|
| **Today** | The next task, then the rest of the queue, with urgency chips |
| **Leads** | Enquiries assigned to this agent |
| **Visits** | Today's visits first, then upcoming, each with a one-tap outcome |
| **Search** | Search the whole inventory |
| **More** | Listings, approvals, the offline queue, profile, log out |

---

## 4. Capture (the big green button)

`Pocket\Steps` drives a guided flow. Four capture doors, each a short form:

| Door | What it captures |
|---|---|
| **capture-lead** | A person who called or walked in — name, phone, what they want |
| **capture-want** | A requirement ("wants a 3 BHK in Sector 82 under 1.2 cr") |
| **capture-visit** | A visit that just happened or is about to |
| **capture-owner** | An update from a property owner |

The flow is deliberately **one question per screen**, thumb-sized, and works on a three-year-old Android phone on a weak connection.

---

## 5. Offline queue

**This is the feature that makes Pocket usable at a site with no signal.**

`Pocket\Screens::queue_page()` + `queue_rows_script()`:

1. Every capture is written to `localStorage` **first**.
2. A service-worker-free, dependency-free script retries when the connection returns.
3. Each row shows its state: waiting, sending, sent, failed.
4. Failed rows can be retried individually or deleted.
5. The **Queue** tab under More shows everything still held on this phone.

Because the retry is a plain fetch against the same REST endpoints, a queued item goes through **exactly the same validation** as a live one. Nothing bypasses the server.

---

## 6. Permissions: what an agent may and may not do

| Action | Agent (own record) | Agent (someone else's) | Office |
|---|---|---|---|
| View | ✅ | ❌ | ✅ |
| Edit | ✅ if `pocket_agents_edit_live` | ❌ — becomes a **Change Request** | ✅ |
| Add a property | ✅ | — | ✅ |
| Move to bin | ✅ | ❌ | ✅ |
| Restore from bin | ✅ | ❌ | ✅ |
| Delete permanently | ❌ | ❌ | ✅ (`estat_delete_listings`) |
| See enquiries | if `pocket_show_enquiries` | own only | all |
| Approve change requests | ❌ | ❌ | ✅ |

Enforced on the **server** by `Pocket::owns()`, `Pocket::can_see()`, `Pocket\Screens::may_see_enquiries()` and `Pocket\Screens::lead_is_mine()`. Hiding a button in the browser is cosmetic; the server check is the real gate.

`Pocket::sees_everything()` is the office override.

---

## 7. Status moves an agent may make

`Support\Status::transitions()` is the law, and Pocket only offers what is legal:

```
draft    → pending, trash
pending  → publish, draft, trash
publish  → private, trash
private  → publish, trash
trash    → draft, publish
```

An agent sending a draft up for approval (`draft → pending`) creates a notification to the office. The office may publish it, send it back (`pending → draft`), or decline it with a reason.

---

## 8. Visits from the field

`Pocket\Screens::visit_mode()` is a focused, single-purpose screen: property at the top, the client's phone number as a big tap-to-call button, and three huge outcome buttons.

```
[ Completed ]   [ No-show ]   [ Cancelled ]
```

Then a short note. Two taps and the agent is done and back on the bike.

---

## 9. Setting Pocket up

1. **Team** → add the agent → fill in their **phone** exactly as they will type it.
2. WordPress **Users** → give them a user with role **Office Agent**.
3. Send them `https://your-site.com/pocket/`.
4. Tell them to **Add to Home Screen** — it then opens like an app.
5. Decide `pocket_agents_edit_live`:
   - `true` — agents change their own records directly (small, trusted teams).
   - `false` — every change becomes a request you approve (recommended above three agents).

---

## 10. Troubleshooting Pocket

| Symptom | Cause | Fix |
|---|---|---|
| `/pocket/` 404 | Rewrite rules stale | Settings → Permalinks → Save |
| Login always fails | No WordPress user, or wrong role | Create the user, assign `estat_office_agent` |
| Phone login fails | Phone on the agent record does not match | Team → fix the phone number |
| Agent sees nothing | Owns no records and is not office | Assign records, or make them office |
| Agent sees everything unexpectedly | They have an office role | Change to `estat_office_agent` |
| Queue never sends | Browser blocks storage (private mode) | Use a normal tab |
| Photos fail to upload | `upload_max_filesize` too small | Ask the host to raise it to 8M+ |
| Buttons do nothing on an old phone | Very old browser | Update the browser; the JS is ES2017 |

---

## 9. The shell, as rebuilt in 4.1.x

One page, three shapes. The same five doors are reached differently at each
size, and nothing is simply shrunk:

| | Computer (≥1024px) | Tablet (768–1023) | Phone (<768) |
|---|---|---|---|
| Where the doors live | dark rail down the left, 252px (224px under 1280) | bottom bar | bottom bar |
| Bottom bar | not drawn at all | five doors, Add raised in the middle | five doors, Add raised |
| Columns on Today | a twelve-column bento: numbers across the top, work + what is coming side by side, tasks across the foot | two | one |
| Number cards | five in one line | two in a line, the fifth takes the whole line | the same |
| Top bar | name · search · the person | name · search · the person | search drops to its own line; the name steps aside under 430px |

### The desktop, as it fills the window (4.1.5)

The shell carried `max-width: 1400px` and the screen `1280px`, both left over
from the first version of the layout, so a wide screen showed the app in a
column with the page visible either side. Both caps are gone under 1024px of
window: the shell fills what it is given.

From 1200px, Today is a mosaic instead of a stack:

| Row | Left | Right |
|---|---|---|
| 1 | the greeting and the date, across the full width | — |
| 2 | the five numbers, across the full width | — |
| 3 | **Next best action** | **Today's visits** |
| 4 | **Quick actions** | **Recently added** |
| 5 | **Today's tasks**, across the full width | — |

The wrappers in the markup (`daymain`, `dayaside`) become `display: contents`,
so the cards take their place in the mosaic without an element moving — which
is why the tablet and phone layouts below 1200px are untouched. Below 1024px a
page keeps a 1040px reading column; only Today sets `is-wide` and uses the
whole width. From 1600px the side cards take more of the mosaic and the quick
actions sit four across.

### The office's own face (4.1.6)

The mark at the top of the rail is the office's logo, not a letter in a box.
`Support/Logo.php` is the one place that decides which picture that is:
Settings → `logo_id`, then WordPress's own Site Identity logo, then the mark
shipped in the plugin (`assets/img/`), and a filter (`estat_logo_url`) for an
office that wants a fourth answer. The rail and the top bar draw the **mark**;
the sign-in page draws the whole **lockup**, name and all. On a dark rail the
light-inked version of the same file is used, because a logo drawn for a white
page disappears on a black one.

And the spacing, which was a bug rather than a preference: `.estat-pocket-tab`
is `flex: 1` for the bottom bar. In the rail's column that made every row an
equal slice of the whole column — **84px tall**, label floating halfway down a
mostly empty box. In the rail the rows are now their own height (38px), the
spare room falls below them, and sign-out keeps the bottom corner.

Shell files: `includes/Pocket/Screens.php` (`shell()`, `head()`, `sidebar_tabs()`,
`tabs()`, `my_day()`) and the three-breakpoint block at the **end** of
`assets/css/pocket.css`. That block must stay at the end: a rule written before
it is silently overruled by it.

### The shortlist (4.1.3)

* **Star** — every property row carries one. It is a small form of its own
  (`toggle_fav`), so the shortlist works with no JavaScript at all, which is
  what matters on a phone in a basement.
* **My shortlist** — `/agent/favourites/`. Kept in the user's own meta
  (`_estat_favs`, sixty at most), so two agents starring the same flat never
  overwrite each other. Nothing about the property itself changes.
* **Side by side** — `/agent/compare/`. Two to four of them, ten questions,
  the same ten in the same order. On a phone the columns become cards one under
  the other with the labels lining up.
* **In the office** — the same idea, the whole inventory rather than one
  agent's stars: Properties → **Compare** → tick two to four → the drawer lays
  them out with the same ten questions.

### The waiting screen

`/agent/queue/` shows what the phone is still holding: every save made with no
network, each one line with *Send now* and *Take it off this phone*. Until
4.1.3 the screen existed but was never handed its body by the router, so the
address fell through to Today — the one line was missing. Fixed, and checked
against the plugin's own scripts: rows draw, the offline count is right,
sending clears the phone, and removing one asks first.
