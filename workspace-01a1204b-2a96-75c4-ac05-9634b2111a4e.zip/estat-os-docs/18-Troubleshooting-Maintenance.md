# 18 — Troubleshooting & Maintenance

## Simple meaning (Hinglish)

Koi problem aaye to pehle **ye 4 kaam** karo: Permalinks Save, Cache Purge, Rebuild index, Repair data. Isse aadhi problems apne-aap theek ho jaati hain. Neeche har common problem ka ilaaj likha hai.

---

## 1. The four fixes that solve most problems

Try these in order, before anything else.

| # | Fix | Where | Solves |
|---|---|---|---|
| 1 | **Settings → Permalinks → Save** | WordPress | 404s on properties, projects, `/pocket/`, `/office/`, REST |
| 2 | **Estat.OS → Settings → Advanced → Purge caches** | Plugin | "The website shows old data" |
| 3 | **Advanced → Rebuild search index** | Plugin | Missing or stale properties in search |
| 4 | **Advanced → Repair data** | Plugin | Missing pages, broken locality links |

If a problem survives all four, work through the tables below.

---

## 2. Diagnostic first steps

1. **`/wp-json/estat/v1/health`** — is the plugin alive, and is it the version you think?
2. **Enable debug logging:**
   ```php
   define( 'WP_DEBUG', true );
   define( 'WP_DEBUG_LOG', true );
   define( 'WP_DEBUG_DISPLAY', false );
   ```
   Then reproduce the problem and read `wp-content/debug.log`.
3. **Rule out a conflict** — deactivate every other plugin. If the problem disappears, reactivate one at a time.
4. **Rule out the theme** — switch to Twenty Twenty-Four. If the problem disappears, it is the theme (usually a template override).
5. **Query Monitor** — shows slow queries, hooks and HTTP calls.

---

## 3. Install & activation

| Symptom | Likely cause | Fix |
|---|---|---|
| "needs PHP 7.4 / WP 6.0" | Host too old | Upgrade, then activate |
| White screen on activate | Fatal from another plugin or the theme | Check `debug.log` |
| Setup screen never appears | `estat_installed_at` already set | Estat.OS → Finish setup |
| Tables missing | `dbDelta` blocked by DB grants | Grant `CREATE`/`ALTER`; re-activate |
| REST 404 | Permalinks | Permalinks → Save |
| Menu missing | Capability | Check the role |

---

## 4. Properties

| Symptom | Cause | Fix |
|---|---|---|
| Not on the website | Status not `publish` | Publish it |
| On the website but stale | Page cache | Purge caches |
| Page 404 | Rewrite rules | Permalinks → Save |
| Missing from search | Index stale | Rebuild search index |
| Stuck in search after deletion | Index row not removed | Rebuild index |
| Photos not showing | Wrong kind or unlinked | Gallery → check |
| Map blank | No coordinates | Fill lat/lng; the map provider defaults to OSM |
| Completeness stuck low | A rule you consider irrelevant | Fill it, or lower the threshold |
| Duplicate warning will not stop | Not marked "keep both" | Open the pair → Keep both |
| Price shows "Price on request" wrongly | Price empty and type `on_request` | Fill the price, or accept it |
| Wrong currency symbol | `currency_symbol` | Settings → General |

---

## 5. Projects

| Symptom | Cause | Fix |
|---|---|---|
| Property not listed under its project | `project_id` not set | Edit the property → pick the project |
| Unit counts wrong | Manual counts vs real listings | Rebuild index; the counts are derived |
| Project page empty | Stage/category filters, or no listings | Check the block order |
| Deleting a project deleted nothing extra | Correct — properties are unlinked, never deleted | Expected |

---

## 6. Enquiries & visits

| Symptom | Cause | Fix |
|---|---|---|
| Form submits but no enquiry | Intake failed, or consent required | Check the form's **Submissions** tab |
| No notification email | No SMTP on the server | Install an SMTP plugin |
| Two cards for one person | Different phone formats | Merge by hand; future ones dedupe |
| Status button missing | Illegal move | Use the correct intermediate step |
| `.ics` will not open | No calendar app associated | Save and import the file |
| Visit double-booked | Different lead, same slot | Allowed by design; adjust manually |
| Erased data still counted | By design — the row is kept | Personal fields only are blanked |

---

## 7. Import & export

| Symptom | Cause | Fix |
|---|---|---|
| "Cannot open file" | Outside uploads, or permissions | Upload through the screen |
| All columns unmapped | Header not on row 1 | Remove title rows |
| Prices wrong | Commas or ₹ in number cells | Digits only |
| Multi-value shows as one blob | Wrong separator | Newline inside a quoted cell |
| Everything imported as draft | `status` column empty | Add `status = publish` |
| Import half-done | PHP timeout | Raise limits; smaller files |
| Duplicates after import | No stable `external_id` | Add IDs; re-import in `update` mode |
| Excel shows garbage | Encoding | Re-save as UTF-8 |
| "Where did my RERA number go?" | Column not mapped | Read the **column plan** before confirming |

---

## 8. Website & Elementor

| Symptom | Cause | Fix |
|---|---|---|
| Shortcode prints as text | Container does not run shortcodes | Use a Shortcode block |
| Elementor widgets missing | Elementor off, or filtered | Turn Elementor on; clear the search box |
| Elementor fatal about `wp_kses_post` | Elementor Pro before taxonomies register | Update Elementor; the guard is already in the plugin |
| Theme Builder template ignored | Cached template answer | Clear Elementor cache |
| Design changes invisible | Page cache | Purge caches |
| WhatsApp button missing | Setting off, or number empty | Settings → Leads |
| Language switcher missing | `allow_visitor_lang` off | Settings → General |

---

## 9. Performance

| Symptom | Cause | Fix |
|---|---|---|
| Directory page slow | Index empty or stale | Rebuild index |
| Reports slow | Object cache missing | Add Redis |
| Admin slow on 10,000+ | No object cache, or heavy theme | Object cache; check Query Monitor |
| Duplicate scan times out | Very large inventory | Run it from the screen; it is time-budgeted |
| Import slow | Server limits | Raise limits; chunk the file |

---

## 10. Maintenance schedule

### Daily (automatic via cron)
- Listing expiry (`listing_expiry_days`)
- Lead retention (`retention_days`)
- Audit purge
- Import job completion
- Search index repair (200-row batches)
- Webhook retries
- Search alert queue

### Weekly (you, 15 minutes)
- [ ] Read the **Today** worklist and clear it
- [ ] Look at **Duplicates → Look again**
- [ ] Clear the **Bin** (restore mistakes, delete what is finished)
- [ ] Check **Reports**
- [ ] Clear **Change Requests**
- [ ] Confirm enquiry emails are arriving

### Monthly (you, 30 minutes)
- [ ] Send a test email and a test webhook
- [ ] Check `estat_webhook_log` and `estat_audit` sizes; purge if large
- [ ] Verify a backup restores
- [ ] Review who has which role
- [ ] Check `uploads/` size
- [ ] Update WordPress, plugins, and Estat.OS

### Quarterly
- [ ] Full restore rehearsal on staging
- [ ] Review SEO: sitemap, canonicals, structured data
- [ ] Review the form field list — remove fields nobody fills
- [ ] Review localities and amenities for junk terms

---

## 11. Repair tools reference

| Tool | Screen | Function | Use when |
|---|---|---|---|
| **Repair data** | Advanced | `Install\RepairData::run()` | Missing pages, broken locality links |
| **Rebuild search index** | Advanced | `SearchIndex::rebuild_batch()` | Search mismatch |
| **Rescan duplicates** | Duplicates | `Duplicate::scan()` | After a big import |
| **Purge caches** | Advanced | `Support\Cache::purge_all()` | Stale website |
| **Run maintenance now** | Advanced | `Scheduler::run_daily()` | Cron not firing |
| **Export settings** | Advanced | — | Before a big change |
| **Undo last import** | Import & export | `Actions::undo_import()` | Immediately after a bad import |
| **Clear practice data** | Advanced | `PracticeMode::clear()` | After training |

---

## 12. Emergency procedures

### "We imported 5,000 wrong rows"
1. **Import & export → Undo this import** — reverses exactly that batch.
2. If the banner is gone: restore from the pre-import backup.
3. Purge caches and rebuild the index afterwards.

### "Someone deleted properties permanently"
1. Stop writing to the site if you can.
2. Restore the database from backup to a **staging** copy.
3. Export the missing properties as CSV from staging.
4. Re-import them into live in `update` mode.
5. Photos: copy them back from the `uploads/` backup.

### "The site is down after an update"
1. Maintenance mode.
2. If it is a PHP fatal, rename `wp-content/plugins/estat-os` via FTP to force WordPress to skip it — the site comes back.
3. Restore the previous version's folder.
4. Rename it back and run the smoke test.

### "Enquiries have stopped for two days"
1. Submit a test enquiry yourself.
2. If it lands but no email → SMTP.
3. If it does not land → check the form is on the page, and the form's **Submissions** tab.
4. Check the host's mail queue and any spam folder.

---

## 13. Getting help productively

When you report a problem, have these ready — they answer most questions before they are asked:

1. Plugin version and `estat_db_version`.
2. WordPress and PHP versions.
3. Theme name, and whether Elementor is active.
4. The exact steps to reproduce.
5. The relevant lines from `wp-content/debug.log`.
6. A screenshot of the screen where it happens.
7. What you already tried from §1.
