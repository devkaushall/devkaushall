#!/usr/bin/env python3
"""Compare in the office: pick two to four homes, see them side by side.

Same idea as the phone's shortlist, but the office compares the whole
inventory, not one agent's stars. No new menu entry — it opens from the
Properties screen as a drawer, because a screen nobody visits is a screen
that does not exist.
"""
import sys
BASE = '/home/user/plugin/estat-os/'

def patch(path, pairs):
    s = open(BASE + path).read()
    for label, old, new in pairs:
        if old not in s:
            print('  !! MISSING: ' + label); sys.exit(1)
        s = s.replace(old, new, 1); print('  ok  ' + path + ' :: ' + label)
    open(BASE + path, 'w').write(s)

# ------------------------------------------------------- 1. the button ----
# ------------------------------------------------- 2. the two drawers -----
patch('includes/Admin/Os/Ajax.php', [
    ('route',
     """			case 'source':
				$out = self::drawer_source( $id );
				break;""",
     """			case 'source':
				$out = self::drawer_source( $id );
				break;
			case 'compare':
				$out = self::drawer_compare();
				break;"""),
    ('ids in the payload',
     """		$id   = isset( $_POST['id'] ) ? absint( wp_unslash( $_POST['id'] ) ) : 0;

		$out = array( 'title' => '', 'html' => '', 'foot' => '' );""",
     """		$id   = isset( $_POST['id'] ) ? absint( wp_unslash( $_POST['id'] ) ) : 0;
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$ids  = isset( $_POST['ids'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array( $_POST['ids'] ) ? '' : $_POST['ids'] ) ) ) : '';

		if ( '' !== $ids ) {
			$ids = implode( ',', array_slice( array_filter( array_map( 'absint', explode( ',', $ids ) ) ), 0, 4 ) );
		}

		$out = array( 'title' => '', 'html' => '', 'foot' => '' );"""),
    ('drawer bodies',
     """	/**
	 * A blank enquiry sheet — what the Add button on Enquiries opens.""",
     """	/**
	 * Compare — the pick list, and then the answer.
	 *
	 * One drawer, two states. With nothing picked it lists the office's own
	 * properties with a tick beside each; with two to four picked it puts
	 * them side by side and asks the same ten questions of every one. The
	 * questions live here, once, so an agent's screen and an owner's screen
	 * cannot disagree about what "comparable" means.
	 *
	 * @return array<string,string>
	 */
	private static function drawer_compare(): array {
		if ( ! current_user_can( 'estat_manage_listings' ) ) {
			return array( 'title' => '', 'html' => self::denied(), 'foot' => '' );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$raw  = isset( $_POST['ids'] ) ? sanitize_text_field( wp_unslash( (string) ( is_array( $_POST['ids'] ) ? '' : $_POST['ids'] ) ) ) : '';
		$picked = array_values( array_filter( array_map( 'absint', explode( ',', $raw ) ) ) );
		$picked = array_slice( array_unique( $picked ), 0, 4 );

		if ( count( $picked ) >= 2 ) {
			return self::compare_table( $picked );
		}

		$found = get_posts(
			array(
				'post_type'      => PostTypes::LISTING,
				'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
				'posts_per_page' => 60,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);

		ob_start();
		echo '<div class="dr__b">';
		printf(
			'<p class="mut" style="margin:0 0 var(--s4)">%1$s</p>',
			esc_html__( 'Tick two, three or four homes and press Compare. They are put beside each other with the same questions asked of every one.', 'estat-os' )
		);

		if ( ! $found ) {
			echo '<div class="empty"><div class="empty__t">' . esc_html__( 'No properties yet', 'estat-os' ) . '</div>'
				. '<div class="empty__d">' . esc_html__( 'Add a home first, then there is something to compare.', 'estat-os' ) . '</div></div></div>';
			return array( 'title' => __( 'Compare', 'estat-os' ), 'html' => (string) ob_get_clean(), 'foot' => '' );
		}

		echo '<div class="cmp__pick">';
		foreach ( $found as $home ) {
			$id    = (int) $home->ID;
			$money = (string) get_post_meta( $id, '_estat_price', true );
			printf(
				'<label class="cmp__pickrow"><input type="checkbox" class="cmp-pick" value="%1$d">'
				. '<span class="cmp__pickn"><b>%2$s</b><i>%3$s</i></span>'
				. '<span class="cmp__pickp">%4$s</span></label>',
				$id,
				esc_html( get_the_title( $id ) ),
				esc_html( (string) ( Format::money( (float) $money ) ?: __( 'No price', 'estat-os' ) ) ),
				esc_html( (string) get_post_status( $id ) )
			);
		}
		echo '</div></div>';

		return array(
			'title' => __( 'Compare properties', 'estat-os' ),
			'html'  => (string) ob_get_clean(),
			'foot'  => '<button type="button" class="btn btn--ghost" data-act="close-drawer">' . esc_html__( 'Cancel', 'estat-os' ) . '</button>'
				. '<button type="button" class="btn btn--bronze" data-act="compare-run">' . esc_html__( 'Compare', 'estat-os' ) . '</button>',
		);
	}

	/**
	 * The same ten questions, asked of every property.
	 *
	 * @param int[] $ids Two to four property IDs.
	 * @return array<string,string>
	 */
	private static function compare_table( array $ids ): array {
		$questions = array(
			'price'        => __( 'Price', 'estat-os' ),
			'area'         => __( 'Size', 'estat-os' ),
			'bedrooms'     => __( 'Bedrooms', 'estat-os' ),
			'bathrooms'    => __( 'Bathrooms', 'estat-os' ),
			'floor'        => __( 'Floor', 'estat-os' ),
			'furnishing'   => __( 'Furnishing', 'estat-os' ),
			'parking'      => __( 'Parking', 'estat-os' ),
			'locality'     => __( 'Where', 'estat-os' ),
			'availability' => __( 'Availability', 'estat-os' ),
			'agent_name'   => __( 'Handled by', 'estat-os' ),
		);

		$cols = '';
		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( ! $post || PostTypes::LISTING !== $post->post_type ) {
				continue;
			}
			$data = method_exists( Listings::class, 'to_array' ) ? Listings::to_array( $id ) : array();

			$facts = array(
				'price'        => (string) ( $data['price_display'] ?? '' ),
				'area'         => ! empty( $data['area'] ) ? Format::area( (float) $data['area'], (string) ( $data['area_unit'] ?? 'sqft' ) ) : '',
				'bedrooms'     => ! empty( $data['bedrooms'] ) ? (string) $data['bedrooms'] : '',
				'bathrooms'    => ! empty( $data['bathrooms'] ) ? (string) $data['bathrooms'] : '',
				'floor'        => ! empty( $data['floor'] ) ? (string) $data['floor'] : '',
				'furnishing'   => (string) ( $data['furnishing'] ?? '' ),
				'parking'      => ! empty( $data['parking'] ) ? (string) $data['parking'] : '',
				'locality'     => implode( ', ', (array) ( $data['locality'] ?? array() ) ),
				'availability' => '' !== (string) ( $data['availability'] ?? '' )
					? Status::label( Status::AVAILABILITY, (string) $data['availability'] )
					: '',
				'agent_name'   => (string) ( $data['agent_name'] ?? '' ),
			);

			if ( '' === $facts['price'] && ! empty( $data['price'] ) ) {
				$facts['price'] = Format::money( (float) $data['price'] );
			}

			$rows = '';
			foreach ( $questions as $key => $word ) {
				$value = trim( (string) $facts[ $key ] );
				$rows .= '<div class="cmp__row"><span>' . esc_html( $word ) . '</span><b>'
					. ( '' !== $value ? esc_html( $value ) : '<i class="mut">' . esc_html__( 'not said', 'estat-os' ) . '</i>' )
					. '</b></div>';
			}

			$cover = get_the_post_thumbnail( $id, 'medium' );
			$cols .= '<div class="cmp__col">'
				. '<button type="button" class="cmp__head" data-drawer="listing" data-id="' . $id . '">'
				. '<span class="cmp__cov' . ( $cover ? '' : ' is-empty' ) . '">' . $cover . '</span>'
				. '<b>' . esc_html( get_the_title( $id ) ) . '</b></button>' . $rows . '</div>';
		}

		$return = array_map( 'absint', $ids );

		return array(
			'title' => __( 'Side by side', 'estat-os' ),
			'html'  => '<div class="dr__b"><div class="cmp" style="--cols:' . count( $return ) . '">' . $cols . '</div></div>',
			'foot'  => '<button type="button" class="btn btn--ghost" data-act="close-drawer">' . esc_html__( 'Close', 'estat-os' ) . '</button>'
				. '<button type="button" class="btn btn--bronze" data-act="compare-pick" data-ids="' . esc_attr( implode( ',', $return ) ) . '">'
				. esc_html__( 'Pick different ones', 'estat-os' ) . '</button>',
		);
	}

	/**
	 * A blank enquiry sheet — what the Add button on Enquiries opens."""),
])

# ------------------------------------------------ 3. what the buttons do ---
patch('assets/js/admin-os.js', [
    ('drawer payload carries ids',
     """		ask({
			action: 'estat_os_drawer',
			os_action: 'drawer',
			kind: kind,
			id: id,
			name: (extra && extra.name) || ''
		})""",
     """		ask({
			action: 'estat_os_drawer',
			os_action: 'drawer',
			kind: kind,
			id: id,
			ids: (extra && extra.ids) || '',
			name: (extra && extra.name) || ''
		})"""),
    ('the two acts',
     """			case 'save-lead':""",
     """			case 'compare-run': {
				var picked = $$('.cmp-pick:checked').map(function (box) { return box.value; });
				if (picked.length < 2) {
					toast('Tick at least two properties to compare.', 'err');
					return;
				}
				if (picked.length > 4) {
					toast('Four at a time is the most that stays readable.', 'err');
					return;
				}
				openDrawer('compare', 0, { ids: picked.join(',') });
				return;
			}

			case 'compare-pick':
				openDrawer('compare', 0, { ids: node.getAttribute('data-ids') || '' });
				return;

			case 'save-lead':"""),
])

# ------------------------------------------------------------------ CSS ---
css = """
/* ==========================================================================
   4.1.3 — Compare, in the office
   Tick two to four homes on the Properties screen, then read them side by
   side in the drawer. Ten questions, always the same ten, so two people
   looking at the same pair reach the same answer.
   ========================================================================== */
.estat-os .cmp__pick { display: flex; flex-direction: column; gap: 2px; }
.estat-os .cmp__pickrow {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 8px;
  border-radius: 10px;
  cursor: pointer;
}
.estat-os .cmp__pickrow:hover { background: var(--inset, #f4f2ec); }
.estat-os .cmp__pickrow input { flex: none; margin: 0; }
.estat-os .cmp__pickn { flex: 1 1 auto; min-width: 0; display: flex; flex-direction: column; }
.estat-os .cmp__pickn b { font-size: 13.5px; font-weight: 600; }
.estat-os .cmp__pickn i { font-style: normal; font-size: 11.5px; color: var(--mut, #6f6d66); }
.estat-os .cmp__pickp { flex: none; font-size: 12px; font-weight: 600; color: var(--mut, #6f6d66); }

.estat-os .cmp {
  display: grid;
  grid-template-columns: repeat(var(--cols, 2), minmax(0, 1fr));
  gap: 12px;
  align-items: start;
}
.estat-os .cmp__col {
  border: 1px solid var(--line, #e6e2d9);
  border-radius: 12px;
  background: var(--panel, #fff);
  padding: 12px;
  min-width: 0;
}
.estat-os .cmp__head {
  display: flex;
  flex-direction: column;
  gap: 8px;
  width: 100%;
  border: 0;
  background: transparent;
  padding: 0 0 10px;
  text-align: left;
  cursor: pointer;
  color: inherit;
}
.estat-os .cmp__cov {
  display: block;
  height: 92px;
  border-radius: 10px;
  background: var(--inset, #f0eee9) center/cover no-repeat;
}
.estat-os .cmp__cov img { width: 100%; height: 100%; object-fit: cover; border-radius: 10px; }
.estat-os .cmp__head b { font-size: 13.5px; font-weight: 700; }
.estat-os .cmp__row {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 8px 0;
  border-top: 1px solid var(--line, #e6e2d9);
}
.estat-os .cmp__row span {
  font-size: 10.5px;
  letter-spacing: .06em;
  text-transform: uppercase;
  color: var(--mut, #6f6d66);
}
.estat-os .cmp__row b { font-size: 13px; font-weight: 600; line-height: 1.35; }
@media (max-width: 900px) {
  .estat-os .cmp { grid-template-columns: minmax(0, 1fr); }
}
"""
open(BASE + 'assets/css/admin-os.css', 'a').write(css)
print('  ok  admin-os.css :: compare styles')
print('done')
