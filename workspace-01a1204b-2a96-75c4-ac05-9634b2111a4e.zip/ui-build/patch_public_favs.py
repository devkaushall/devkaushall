#!/usr/bin/env python3
"""One question list for the office, the pocket and the website, plus the
visitor's handoff: their shortlist becomes a real enquiry and a WhatsApp
message in one press.
"""
import sys
BASE = '/home/user/plugin/estat-os/'

def patch(path, pairs, must=True):
    s = open(BASE + path).read()
    for label, old, new in pairs:
        if old not in s:
            print('  !! MISSING: ' + label)
            if must:
                sys.exit(1)
            continue
        s = s.replace(old, new, 1); print('  ok  ' + path + ' :: ' + label)
    open(BASE + path, 'w').write(s)

# ============================ 1. office ==================================
patch('includes/Admin/Os/Ajax.php', [
    ('office uses the shared list',
     """		$questions = array(
			'price'        => __( 'Price', 'estat-os' ),
			'area'         => __( 'Size', 'estat-os' ),
			'bedrooms'     => __( 'Bedrooms', 'estat-os' ),
			'bathrooms'    => __( 'Bathrooms', 'estat-os' ),
			'floor'        => __( 'Floor', 'estat-os' ),
			'furnishing'   => __( 'Furnishing', 'estat-os' ),
			'parking'      => __( 'Parking', 'estat-os' ),
			'locality'     => __( 'Where', 'estat-os' ),
			'availability' => __( 'Availability', 'estat-os' ),
			'agent_name'   => __( 'Handled by', 'estat-os' ),
		);

		$cols = '';
		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( ! $post || PostTypes::LISTING !== $post->post_type ) {
				continue;
			}
			$data = method_exists( Listings::class, 'to_array' ) ? Listings::to_array( $id ) : array();

			$facts = array(
				'price'        => (string) ( $data['price_display'] ?? '' ),
				'area'         => ! empty( $data['area'] ) ? Format::area( (float) $data['area'], (string) ( $data['area_unit'] ?? 'sqft' ) ) : '',
				'bedrooms'     => ! empty( $data['bedrooms'] ) ? (string) $data['bedrooms'] : '',
				'bathrooms'    => ! empty( $data['bathrooms'] ) ? (string) $data['bathrooms'] : '',
				'floor'        => ! empty( $data['floor'] ) ? (string) $data['floor'] : '',
				'furnishing'   => (string) ( $data['furnishing'] ?? '' ),
				'parking'      => ! empty( $data['parking'] ) ? (string) $data['parking'] : '',
				'locality'     => implode( ', ', (array) ( $data['locality'] ?? array() ) ),
				'availability' => '' !== (string) ( $data['availability'] ?? '' )
					? Status::label( Status::AVAILABILITY, (string) $data['availability'] )
					: '',
				'agent_name'   => (string) ( $data['agent_name'] ?? '' ),
			);

			if ( '' === $facts['price'] && ! empty( $data['price'] ) ) {
				$facts['price'] = Format::money( (float) $data['price'] );
			}
""",
     """		// One list, written down once, shared with the pocket and the website.
		$questions = Comparison::questions();

		$cols = '';
		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( ! $post || PostTypes::LISTING !== $post->post_type ) {
				continue;
			}

			$facts = Comparison::facts( $id );
"""),
    ('office import',
     """use EstatOS\\Support\\Format;""",
     """use EstatOS\\Support\\Comparison;
use EstatOS\\Support\\Format;"""),
])

# ============================ 2. pocket =================================
patch('includes/Pocket/Screens.php', [
    ('pocket uses the shared list',
     """		$questions = array(
			'price'        => __( 'Price', 'estat-os' ),
			'area'         => __( 'Size', 'estat-os' ),
			'bedrooms'     => __( 'Bedrooms', 'estat-os' ),
			'bathrooms'    => __( 'Bathrooms', 'estat-os' ),
			'floor'        => __( 'Floor', 'estat-os' ),
			'furnishing'   => __( 'Furnishing', 'estat-os' ),
			'parking'      => __( 'Parking', 'estat-os' ),
			'locality'     => __( 'Where', 'estat-os' ),
			'availability' => __( 'Availability', 'estat-os' ),
			'society'      => __( 'Society', 'estat-os' ),
		);
""",
     """		// One list, written down once, shared with the office and the website.
		$questions = \\EstatOS\\Support\\Comparison::questions();
"""),
])

# ============================ 3. REST ===================================
patch('includes/Rest/RestApi.php', [
    ('facts on the property reply',
     """		$data            = Listings::to_array( $id, false );
		$data['agent']   = (int) $data['agent_id'] > 0 ? Agents::to_array( (int) $data['agent_id'] ) : null;""",
     """		$data            = Listings::to_array( $id, false );
		$data['agent']   = (int) $data['agent_id'] > 0 ? Agents::to_array( (int) $data['agent_id'] ) : null;

		/*
		 * The ten answers, from the same list the office and the pocket use,
		 * with the questions already in the reader's language. The website
		 * therefore cannot drift into asking eight questions of its own.
		 */
		$data['questions'] = Comparison::questions();
		$data['facts']     = Comparison::facts( $id );"""),
    ('import',
     """use EstatOS\\Support\\Format;""",
     """use EstatOS\\Support\\Comparison;
use EstatOS\\Support\\Format;"""),
    ('the shortlist handoff route',
     """		register_rest_route(
			self::NS,
			'/enquiries',""",
     """		/*
		 * The visitor's shortlist, sent to the office.
		 *
		 * A visitor who has put three homes together is the warmest enquiry
		 * the website produces, and until now that work vanished when they
		 * closed the tab. This turns it into an ordinary enquiry — the same
		 * Leads::create() the forms use, so it appears in the office list,
		 * is assigned and chased like any other — and hands back the
		 * WhatsApp link carrying the same three homes.
		 */
		register_rest_route(
			self::NS,
			'/shortlist',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'send_shortlist' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			self::NS,
			'/enquiries',"""),
    ('the shortlist handler',
     """	/**
	 * Office enquiry list.""",
     """	/**
	 * Send the visitor's shortlist to the office, and hand back WhatsApp.
	 *
	 * Three guards, the same shape the public forms use: a nonce so the
	 * request comes from a page we drew, a honeypot field so a bot filling
	 * every input is caught, and a per-address rate limit so one person
	 * cannot post the same list forty times.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function send_shortlist( WP_REST_Request $request ) {
		$params = (array) $request->get_params();

		$nonce = Sanitize::text( $params['estat_nonce'] ?? '' );
		if ( ! wp_verify_nonce( $nonce, 'estat_shortlist' ) ) {
			return new WP_Error( 'estat_bad_nonce', __( 'This page has been open a while. Please refresh and try again.', 'estat-os' ), array( 'status' => 403 ) );
		}

		// Honeypot: a field no person can see is always empty for a person.
		if ( '' !== Sanitize::text( $params['estat_website'] ?? '' ) ) {
			return new WP_Error( 'estat_spam', __( 'That could not be sent.', 'estat-os' ), array( 'status' => 422 ) );
		}

		$name  = Sanitize::text( $params['name'] ?? '' );
		$phone = Sanitize::phone( (string) ( $params['phone'] ?? '' ) );
		$email = Sanitize::email( (string) ( $params['email'] ?? '' ) );

		if ( '' === $name || ( '' === $phone && '' === $email ) ) {
			return new WP_Error(
				'estat_need_contact',
				__( 'Please leave a name and a phone number so the office can call you back.', 'estat-os' ),
				array( 'status' => 422 )
			);
		}

		$ids = array_values( array_filter( array_map( 'absint', explode( ',', (string) ( $params['ids'] ?? '' ) ) ) ) );
		$ids = array_slice( array_unique( $ids ), 0, 4 );
		if ( ! $ids ) {
			return new WP_Error( 'estat_nothing_picked', __( 'Put at least one property in the shortlist first.', 'estat-os' ), array( 'status' => 422 ) );
		}

		// Per-address limit, so one visitor cannot flood the office list.
		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$key = 'estat_sl_' . substr( hash( 'sha256', $ip . '|' . wp_salt( 'auth' ) ), 0, 32 );
		$has = (int) get_transient( $key );
		if ( $has >= 5 ) {
			return new WP_Error(
				'estat_slow_down',
				__( 'That is a few times already. Please call the office instead.', 'estat-os' ),
				array( 'status' => 429 )
			);
		}
		set_transient( $key, $has + 1, 10 * MINUTE_IN_SECONDS );

		$lines = array();
		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( ! $post || 'publish' !== $post->post_status ) {
				continue;
			}
			if ( ! in_array( $post->post_type, array( PostTypes::LISTING, PostTypes::PROJECT ), true ) ) {
				continue;
			}
			$line = '• ' . get_the_title( $id );
			$want = Comparison::facts( $id );
			if ( '' !== trim( (string) ( $want['price'] ?? '' ) ) ) {
				$line .= ' — ' . (string) $want['price'];
			}
			$line .= ' — ' . (string) get_permalink( $id );
			$lines[] = $line;
		}

		if ( ! $lines ) {
			return new WP_Error( 'estat_nothing_picked', __( 'Those properties are no longer on the website.', 'estat-os' ), array( 'status' => 422 ) );
		}

		$message = sprintf(
			/* translators: %d: how many properties. */
			_n( 'Shortlist from the website — %d property:', 'Shortlist from the website — %d properties:', count( $lines ), 'estat-os' ),
			count( $lines )
		) . "\\n" . implode( "\\n", $lines );

		$lead = Leads::create(
			array(
				'name'        => $name,
				'phone'       => $phone,
				'email'       => $email,
				'message'     => $message,
				'source'      => 'comparison',
				'source_url'  => Sanitize::url( (string) ( $params['page_url'] ?? '' ) ),
				'consent'     => true,
				'idempotency_key' => Sanitize::text( (string) ( $params['idempotency_key'] ?? '' ) ),
			)
		);

		if ( is_wp_error( $lead ) ) {
			$lead->add_data( array( 'status' => 422 ) );
			return $lead;
		}

		$digits  = \\EstatOS\\Frontend\\WhatsApp::number();
		$wa_text = $message;

		return new WP_REST_Response(
			array(
				'ok'       => true,
				'lead_id'  => (int) $lead,
				'whatsapp' => '' !== $digits ? 'https://wa.me/' . $digits . '?text=' . rawurlencode( $wa_text ) : '',
				'message'  => __( 'Sent to the office. Tap continue to send the same list on WhatsApp.', 'estat-os' ),
			),
			200
		);
	}

	/**
	 * Office enquiry list."""),
])

# ============================ 4. what the browser knows =================
patch('includes/Frontend/Frontend.php', [
    ('localized config',
     """				'currency'  => (string) Settings::get( 'currency_symbol' ),
				'priceStyle' => (string) Settings::get( 'price_format' ),
				'i18n'      => $strings,""",
     """				'currency'  => (string) Settings::get( 'currency_symbol' ),
				'priceStyle' => (string) Settings::get( 'price_format' ),

				// The site-wide WhatsApp number, so a visitor's shortlist can be
				// sent to the same place every other enquiry goes.
				'whatsapp'  => \\EstatOS\\Frontend\\WhatsApp::number(),
				// Guards the shortlist handoff; a page we did not draw has no nonce.
				'shortlistNonce' => wp_create_nonce( 'estat_shortlist' ),
				'compareMax' => 4,
				'i18n'      => $strings,"""),
])
print('done php')
