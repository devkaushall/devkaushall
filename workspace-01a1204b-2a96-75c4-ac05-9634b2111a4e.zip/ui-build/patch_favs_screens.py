#!/usr/bin/env python3
"""The shortlist screens: a star on every row, a list, and a comparison."""
import sys
BASE = '/home/user/plugin/estat-os/'
P = 'includes/Pocket/Screens.php'
s = open(BASE + P).read()

def sub(label, old, new):
    global s
    if old not in s:
        print('  !! MISSING: ' + label); sys.exit(1)
    s = s.replace(old, new, 1); print('  ok  ' + label)

# ------------------------------------- 1. titles (render cases already applied) ----
sub('titles',
"""			'you'       => __( 'You', 'estat-os' ),""",
"""			'you'       => __( 'You', 'estat-os' ),
			'favourites' => __( 'My shortlist', 'estat-os' ),
			'compare'    => __( 'Side by side', 'estat-os' ),""")

# ------------------------------------------------------- 2. star on row ---
sub('record_row star',
"""		return sprintf(
			'<a class="estat-pocket-row" href="%1$s"><span class="estat-pocket-thumbwrap">%2$s</span>' .
			'<span class="estat-pocket-rowmain"><b>%3$s</b><i>%4$s%5$s</i>%8$s</span>' .
			( '' !== $label ? '<span class="estat-pocket-pill %6$s">%7$s</span>' : '' ) . '</a>',
			esc_url( Pocket::url( 'listing', $record_id ) ),
			$thumb,
			esc_html( get_the_title( $record_id ) ),
			esc_html( $line ),
			'' !== $line ? '' : esc_html( $standing[ (string) $post->post_status ] ?? '' ),
			'' !== $tone ? 'is-' . $tone : '',
			esc_html( $label ),
			$facts
		);
	}""",
"""		/*
		 * The star sits beside the row, not inside it: a button inside a
		 * link is a button nobody can press. It posts on its own, so the
		 * shortlist works with no script at all.
		 */
		$starred = Pocket::is_fav( $record_id );
		$star    = '<form class="estat-pocket-starform" method="post" action="'
			. esc_url( Pocket::url( 'listings' ) ) . '">'
			. '<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">'
			. '<input type="hidden" name="estat_pocket_action" value="toggle_fav">'
			. '<input type="hidden" name="record" value="' . (int) $record_id . '">'
			. '<input type="hidden" name="back" value="' . esc_attr( 'favourites' === (string) ( $_GET['from'] ?? '' ) ? 'favourites' : 'listings' ) . '">'
			. '<button type="submit" class="estat-pocket-star' . ( $starred ? ' is-on' : '' ) . '" aria-label="'
			. esc_attr( $starred ? __( 'Take it off the shortlist', 'estat-os' ) : __( 'Put it on the shortlist', 'estat-os' ) ) . '">'
			. Pocket::icon( 'star', 17 ) . '</button></form>';

		return '<div class="estat-pocket-rowwrap">' . sprintf(
			'<a class="estat-pocket-row" href="%1$s"><span class="estat-pocket-thumbwrap">%2$s</span>' .
			'<span class="estat-pocket-rowmain"><b>%3$s</b><i>%4$s%5$s</i>%8$s</span>' .
			( '' !== $label ? '<span class="estat-pocket-pill %6$s">%7$s</span>' : '' ) . '</a>',
			esc_url( Pocket::url( 'listing', $record_id ) ),
			$thumb,
			esc_html( get_the_title( $record_id ) ),
			esc_html( $line ),
			'' !== $line ? '' : esc_html( $standing[ (string) $post->post_status ] ?? '' ),
			'' !== $tone ? 'is-' . $tone : '',
			esc_html( $label ),
			$facts
		) . $star . '</div>';
	}

	/**
	 * My shortlist — the homes the agent is holding for a client.
	 *
	 * Deliberately a short list. Past four, nobody is comparing anything,
	 * they are scrolling; so four are shown side by side and the rest wait
	 * below in one line each, ready to be swapped in.
	 *
	 * @return string
	 */
	private static function favourites(): string {
		$all = Pocket::fav_posts( 60 );

		$out = '<a class="estat-pocket-back" href="' . esc_url( Pocket::url( 'listings' ) ) . '">'
			. Pocket::icon( 'arrow-left', 14 ) . ' ' . esc_html__( 'Back', 'estat-os' ) . '</a>';

		if ( ! $all ) {
			return $out . self::empty_state(
				__( 'Nothing on the shortlist yet', 'estat-os' ),
				__( 'Open a property and press the star. The ones your client liked stay here, in the order you found them.', 'estat-os' ),
				Pocket::url( 'listings' ),
				__( 'Open my properties', 'estat-os' )
			);
		}

		$n = count( $all );

		$out .= '<p class="estat-pocket-lead">'
			. esc_html( sprintf(
				/* translators: %d: how many properties. */
				_n( '%d property is on your shortlist.', '%d properties are on your shortlist.', $n, 'estat-os' ),
				$n
			) ) . '</p>';

		/*
		 * Compare needs two things to compare. One star is a note to self;
		 * two is a decision.
		 */
		$out .= '<div class="estat-pocket-chips">';
		if ( $n >= 2 ) {
			$out .= '<a class="is-on" href="' . esc_url( Pocket::url( 'compare' ) ) . '">'
				. Pocket::icon( 'columns', 14 ) . ' ' . esc_html__( 'Side by side', 'estat-os' ) . '</a>';
		}
		$out .= '<a href="' . esc_url( Pocket::url( 'listings' ) ) . '">' . esc_html__( 'All properties', 'estat-os' ) . '</a>';
		$out .= '</div>';

		foreach ( $all as $post ) {
			$out .= self::record_row( (int) $post->ID );
		}

		$out .= '<form class="estat-pocket-card estat-pocket-clearform" method="post" action="'
			. esc_url( Pocket::url( 'favourites' ) ) . '">'
			. '<input type="hidden" name="_estat_pocket" value="' . esc_attr( wp_create_nonce( 'estat_pocket' ) ) . '">'
			. '<input type="hidden" name="estat_pocket_action" value="fav_clear">'
			. '<button type="submit" class="estat-pocket-btn is-quiet">' . esc_html__( 'Empty the shortlist', 'estat-os' ) . '</button>'
			. '<p class="estat-pocket-hint" style="margin:8px 0 0">'
			. esc_html__( 'This only clears your own list. Nothing about the properties themselves changes.', 'estat-os' ) . '</p></form>';

		return $out;
	}

	/**
	 * Two, three or four properties, side by side.
	 *
	 * On a phone the columns fall one under the other and the labels line
	 * up, because four columns of numbers on a 390px screen is not a
	 * comparison — it is a squint.
	 *
	 * @return string
	 */
	private static function compare(): string {
		$posts = Pocket::fav_posts( 4 );

		$out = '<a class="estat-pocket-back" href="' . esc_url( Pocket::url( 'favourites' ) ) . '">'
			. Pocket::icon( 'arrow-left', 14 ) . ' ' . esc_html__( 'Back', 'estat-os' ) . '</a>';

		if ( count( $posts ) < 2 ) {
			return $out . self::empty_state(
				__( 'Two are needed to compare', 'estat-os' ),
				__( 'Star one more property and this screen will put them beside each other — price, size, rooms, floor, what is included.', 'estat-os' ),
				Pocket::url( 'listings' ),
				__( 'Open my properties', 'estat-os' )
			);
		}

		/*
		 * The same list of questions for every property, in the same order,
		 * so the eye can run across. A question with no answer says so
		 * rather than being left out: a missing row reads as a missing fact
		 * only when the gap is visible.
		 */
		$questions = array(
			'price'        => __( 'Price', 'estat-os' ),
			'area'         => __( 'Size', 'estat-os' ),
			'bedrooms'     => __( 'Bedrooms', 'estat-os' ),
			'bathrooms'    => __( 'Bathrooms', 'estat-os' ),
			'floor'        => __( 'Floor', 'estat-os' ),
			'furnishing'   => __( 'Furnishing', 'estat-os' ),
			'parking'      => __( 'Parking', 'estat-os' ),
			'locality'     => __( 'Where', 'estat-os' ),
			'availability' => __( 'Availability', 'estat-os' ),
			'society'      => __( 'Society', 'estat-os' ),
		);

		$cols = array();
		foreach ( $posts as $post ) {
			$id    = (int) $post->ID;
			$facts = array();

			if ( PostTypes::PROJECT === $post->post_type ) {
				// A society compares on size and price; the rest of these
				// questions belong to a single home.
				$lo = (string) get_post_meta( $id, '_estat_price_min', true );
				$hi = (string) get_post_meta( $id, '_estat_price_max', true );
				$facts['price']        = '' !== $lo ? Format::price_range( (float) $lo, (float) ( '' !== $hi ? $hi : $lo ), 'sale' ) : '';
				$facts['area']         = '';
				$facts['bedrooms']     = (string) get_post_meta( $id, '_estat_unit_types', true );
				$facts['bathrooms']    = '';
				$facts['floor']        = '';
				$facts['furnishing']   = (string) get_post_meta( $id, '_estat_project_type', true );
				$facts['parking']      = '';
				$facts['locality']     = self::first_term( $id );
				$facts['availability'] = (string) get_post_meta( $id, '_estat_possession_date', true );
				$facts['society']      = (string) get_post_meta( $id, '_estat_developer', true );
			} else {
				$data = class_exists( '\\EstatOS\\Data\\Listings' ) ? \EstatOS\Data\Listings::to_array( $id ) : array();

				$money = '';
				if ( ! empty( $data['price_display'] ) ) {
					$money = (string) $data['price_display'];
				} elseif ( ! empty( $data['rent'] ) ) {
					$money = Format::money( (float) $data['rent'] );
				} elseif ( ! empty( $data['price'] ) ) {
					$money = Format::money( (float) $data['price'] );
				}

				$facts['price']        = $money;
				$facts['area']         = ! empty( $data['area'] ) ? Format::area( (float) $data['area'], (string) ( $data['area_unit'] ?? 'sqft' ) ) : '';
				$facts['bedrooms']     = ! empty( $data['bedrooms'] ) ? (string) $data['bedrooms'] : '';
				$facts['bathrooms']    = ! empty( $data['bathrooms'] ) ? (string) $data['bathrooms'] : '';
				$facts['floor']        = ! empty( $data['floor'] ) ? (string) $data['floor'] : '';
				$facts['furnishing']   = (string) ( $data['furnishing'] ?? '' );
				$facts['parking']      = ! empty( $data['parking'] ) ? (string) $data['parking'] : '';
				$facts['locality']     = implode( ', ', (array) ( $data['locality'] ?? array() ) );
				$facts['availability'] = '' !== (string) ( $data['availability'] ?? '' )
					? Status::label( Status::AVAILABILITY, (string) $data['availability'] )
					: '';
				$facts['society']      = (string) ( $data['project_name'] ?? '' );
			}

			$thumb = get_the_post_thumbnail( $id, 'thumbnail', array( 'class' => 'estat-pocket-thumb' ) );
			$rows  = '';
			foreach ( $questions as $key => $word ) {
				$value = trim( (string) ( $facts[ $key ] ?? '' ) );
				$rows .= '<div class="estat-pocket-cmprow"><span>' . esc_html( $word ) . '</span><b>'
					. ( '' !== $value ? esc_html( $value ) : '<i class="estat-pocket-none">' . esc_html__( 'not said', 'estat-os' ) . '</i>' )
					. '</b></div>';
			}

			$cols[] = '<div class="estat-pocket-cmpcol">'
				. '<a class="estat-pocket-cmphead" href="' . esc_url( Pocket::url( 'listing', $id ) ) . '">'
				. '<span class="estat-pocket-thumbwrap">' . ( $thumb ? $thumb : '<span class="estat-pocket-thumb is-empty">' . Pocket::icon( 'image', 18 ) . '</span>' ) . '</span>'
				. '<b>' . esc_html( get_the_title( $id ) ) . '</b></a>' . $rows . '</div>';
		}

		$count = count( $cols );

		return $out
			. '<p class="estat-pocket-lead">' . esc_html( sprintf(
				/* translators: %d: how many properties are being compared. */
				_n( 'Two homes, side by side.', 'These %d, side by side.', $count, 'estat-os' ),
				$count
			) ) . '</p>'
			. '<div class="estat-pocket-cmp" style="--cols:' . $count . '">' . implode( '', $cols ) . '</div>';
	}

	/**
	 * The first locality written on a record, as a word.
	 *
	 * @param int $id Record.
	 * @return string
	 */
	private static function first_term( int $id ): string {
		$terms = wp_get_object_terms( $id, 'estat_locality', array( 'fields' => 'names' ) );
		return is_wp_error( $terms ) || ! $terms ? '' : (string) $terms[0];
	}""")

open(BASE + P, 'w').write(s)
print('Screens.php patched', len(s), 'bytes')
