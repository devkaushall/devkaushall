const fs = require('fs');
const P = '/home/user/plugin/estat-os/assets/js/public.js';
let s = fs.readFileSync(P, 'utf8');

// --- 1. the compare table now uses the server's own ten answers -----------
const oldCompare = s.slice(s.indexOf('\tfunction renderCompare() {'), s.indexOf('\tfunction renderFavorites() {'));
if (!oldCompare) { console.log('!! compare block'); process.exit(1); }

const newCompare = `\t/*
\t * The comparison table.
\t *
\t * The rows are not written here. Each property arrives from the server
\t * with the same ten questions the office and the agent's phone ask —
\t * already in the reader's language — and this only lays them out. That
\t * is the whole point: one website cannot end up asking a different ten
\t * things from the office.
\t *
\t * A question with no answer prints the words "Not said" rather than
\t * being dropped, because a gap you can see is a gap the office can fill.
\t */
\tfunction say( key, fallback ) {
\t\treturn ( settings.i18n && settings.i18n[ key ] ) || fallback;
\t}

\tfunction notSaid() {
\t\treturn '<span class="estat-compare-none">' + say( 'notSaid', 'Not said' ) + '</span>';
\t}

\tfunction cell( value ) {
\t\tvar text = ( value === null || value === undefined ) ? '' : String( value ).trim();
\t\tif ( '' === text || '0' === text ) {
\t\t\treturn notSaid();
\t\t}
\t\treturn document.createTextNode( text ).textContent === text
\t\t\t? '<span>' + text.replace( /[&<>"]/g, function ( c ) {
\t\t\t\treturn { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ c ];
\t\t\t} ) + '</span>'
\t\t\t: '';
\t}

\tfunction renderCompare() {
\t\tvar panel = document.querySelector( '#estat-compare-panel .estat-compare-table' );
\t\tif ( ! panel ) {
\t\t\treturn;
\t\t}
\t\tvar ids = read( CMP_KEY );
\t\tvar note = document.querySelector( '#estat-compare-panel .estat-compare-note' );
\t\tvar send = document.querySelector( '#estat-compare-panel .estat-compare-send' );

\t\tif ( ! ids.length ) {
\t\t\tpanel.innerHTML = '';
\t\t\tif ( note ) { note.textContent = ''; }
\t\t\tif ( send ) { send.hidden = true; }
\t\t\treturn;
\t\t}

\t\tPromise.all( ids.map( function ( id ) {
\t\t\treturn fetch( settings.restUrl + 'properties/' + id ).then( function ( r ) {
\t\t\t\treturn r.ok ? r.json() : null;
\t\t\t} ).catch( function () {
\t\t\t\treturn null;
\t\t\t} );
\t\t} ) ).then( function ( items ) {
\t\t\titems = items.filter( Boolean );
\t\t\tpanel.innerHTML = '';
\t\t\tif ( ! items.length ) {
\t\t\t\tif ( note ) { note.textContent = ''; }
\t\t\t\tif ( send ) { send.hidden = true; }
\t\t\t\treturn;
\t\t\t}

\t\t\tif ( note ) {
\t\t\t\tnote.textContent = items.length === 1
\t\t\t\t\t? say( 'onePicked', 'One property is in the comparison. Add another to see them side by side.' )
\t\t\t\t\t: ( ( settings.i18n && settings.i18n.picked ) || '%d are side by side.' ).replace( '%d', items.length );
\t\t\t}
\t\t\tif ( send ) { send.hidden = items.length < 1; }

\t\t\tvar questions = items[ 0 ].questions || {};
\t\t\tvar keys = Object.keys( questions );

\t\t\tvar table = document.createElement( 'table' );
\t\t\ttable.className = 'estat-compare-grid';
\t\t\tvar head = document.createElement( 'tr' );
\t\t\thead.appendChild( document.createElement( 'th' ) );
\t\t\titems.forEach( function ( item ) {
\t\t\t\tvar th = document.createElement( 'th' );
\t\t\t\tvar link = document.createElement( 'a' );
\t\t\t\tlink.href = item.url;
\t\t\t\tlink.textContent = item.title;
\t\t\t\tth.appendChild( link );
\t\t\t\tvar drop = document.createElement( 'button' );
\t\t\t\tdrop.type = 'button';
\t\t\t\tdrop.className = 'estat-compare-drop';
\t\t\t\tdrop.setAttribute( 'data-listing', String( item.id ) );
\t\t\t\tdrop.textContent = say( 'remove', 'Remove' );
\t\t\t\tth.appendChild( drop );
\t\t\t\thead.appendChild( th );
\t\t\t} );
\t\t\ttable.appendChild( head );

\t\t\tkeys.forEach( function ( key ) {
\t\t\t\tvar tr = document.createElement( 'tr' );
\t\t\t\tvar label = document.createElement( 'th' );
\t\t\t\tlabel.scope = 'row';
\t\t\t\tlabel.textContent = questions[ key ];
\t\t\t\ttr.appendChild( label );
\t\t\t\titems.forEach( function ( item ) {
\t\t\t\t\tvar td = document.createElement( 'td' );
\t\t\t\t\ttd.innerHTML = cell( ( item.facts || {} )[ key ] );
\t\t\t\t\ttr.appendChild( td );
\t\t\t\t} );
\t\t\t\ttable.appendChild( tr );
\t\t\t} );

\t\t\tpanel.appendChild( table );
\t\t} );
\t}

\t/**
\t * "Send this list to the office."
\t *
\t * The shortlist becomes an ordinary enquiry — the same one the contact
\t * form makes — and then WhatsApp opens with the same list written out,
\t * so the visitor can carry on in the app they already use.
\t */
\tfunction wireShortlistForm() {
\t\tvar form = document.querySelector( '#estat-compare-panel .estat-shortlist-form' );
\t\tif ( ! form ) {
\t\t\treturn;
\t\t}

\t\tform.addEventListener( 'submit', function ( event ) {
\t\t\tevent.preventDefault();

\t\t\tvar ids = read( CMP_KEY );
\t\t\tif ( ! ids.length ) {
\t\t\t\treturn;
\t\t\t}

\t\t\tvar button = form.querySelector( 'button[type=submit]' );
\t\t\tvar said   = form.querySelector( '.estat-shortlist-said' );
\t\t\tvar name   = form.querySelector( '[name=name]' );
\t\t\tvar phone  = form.querySelector( '[name=phone]' );

\t\t\tif ( name && '' === name.value.trim() ) {
\t\t\t\tif ( said ) { said.textContent = say( 'needName', 'Please leave your name.' ); }
\t\t\t\tif ( name ) { name.focus(); }
\t\t\t\treturn;
\t\t\t}
\t\t\tif ( phone && phone.value.replace( /\\D+/g, '' ).length < 8 ) {
\t\t\t\tif ( said ) { said.textContent = say( 'needPhone', 'Please leave a phone number the office can call.' ); }
\t\t\t\tif ( phone ) { phone.focus(); }
\t\t\t\treturn;
\t\t\t}

\t\t\tif ( button ) { button.disabled = true; }
\t\t\tif ( said ) { said.textContent = say( 'sending', 'Sending…' ); }

\t\t\tvar body = new FormData( form );
\t\t\tbody.append( 'ids', ids.join( ',' ) );
\t\t\tbody.append( 'estat_nonce', settings.shortlistNonce || '' );
\t\t\tbody.append( 'page_url', window.location.href );
\t\t\tbody.append( 'idempotency_key', 'sl-' + ids.join( '-' ) + '-' + Math.floor( Date.now() / 60000 ) );

\t\t\tfetch( settings.restUrl + 'shortlist', {
\t\t\t\tmethod: 'POST',
\t\t\t\tcredentials: 'same-origin',
\t\t\t\tbody: body
\t\t\t} ).then( function ( r ) {
\t\t\t\treturn r.json();
\t\t\t} ).then( function ( res ) {
\t\t\t\tif ( button ) { button.disabled = false; }
\t\t\t\tif ( ! res || ! res.ok ) {
\t\t\t\t\tif ( said ) {
\t\t\t\t\t\tsaid.textContent = ( res && res.message ) || say( 'failed', 'That did not go through. Please try again.' );
\t\t\t\t\t}
\t\t\t\t\treturn;
\t\t\t\t}
\t\t\t\tif ( said ) { said.textContent = res.message || say( 'sent', 'Sent to the office.' ); }
\t\t\t\tif ( res.whatsapp ) {
\t\t\t\t\twindow.open( res.whatsapp, '_blank', 'noopener' );
\t\t\t\t}
\t\t\t} ).catch( function () {
\t\t\t\tif ( button ) { button.disabled = false; }
\t\t\t\tif ( said ) { said.textContent = say( 'failed', 'That did not go through. Please try again.' ); }
\t\t\t} );
\t\t} );
\t}

`;

s = s.replace(oldCompare, newCompare, 1);
console.log('  ok  compare table rebuilt');

// --- 2. the favourites list, as cards a person can act on -----------------
const oldFav = s.slice(s.indexOf('\tfunction renderFavorites() {'), s.indexOf('\tdocument.addEventListener( \'click\', function ( event ) {'));
const newFav = `/*
\t * The saved list.
\t *
\t * Cards, not names: a visitor recognises their own shortlist by the
\t * photographs, not by a title. Each one carries the one action worth
\t * taking from here — put it in the comparison, or take it off the list.
\t */
\tfunction renderFavorites() {
\t\tvar section = document.querySelector( '#estat-favorites .estat-grid' );
\t\tif ( ! section ) {
\t\t\treturn;
\t\t}
\t\tvar empty = document.querySelector( '#estat-favorites .estat-empty' );
\t\tvar count = document.querySelector( '#estat-favorites .estat-favorites-count' );
\t\tvar ids = read( FAV_KEY );

\t\tif ( ! ids.length ) {
\t\t\tsection.innerHTML = '';
\t\t\tif ( empty ) { empty.hidden = false; }
\t\t\tif ( count ) { count.textContent = ''; }
\t\t\treturn;
\t\t}
\t\tif ( empty ) { empty.hidden = true; }
\t\tif ( count ) {
\t\t\tcount.textContent = ( ( settings.i18n && settings.i18n.savedCount ) || '%d saved' ).replace( '%d', ids.length );
\t\t}

\t\tPromise.all( ids.map( function ( id ) {
\t\t\treturn fetch( settings.restUrl + 'properties/' + id ).then( function ( r ) {
\t\t\t\treturn r.ok ? r.json() : null;
\t\t\t} ).catch( function () {
\t\t\t\treturn null;
\t\t\t} );
\t\t} ) ).then( function ( items ) {
\t\t\titems = items.filter( Boolean );
\t\t\tsection.innerHTML = '';

\t\t\titems.forEach( function ( item ) {
\t\t\t\tvar card = document.createElement( 'article' );
\t\t\t\tcard.className = 'estat-card estat-fav-card';

\t\t\t\tif ( item.cover ) {
\t\t\t\t\tvar shot = document.createElement( 'a' );
\t\t\t\t\tshot.className = 'estat-fav-shot';
\t\t\t\t\tshot.href = item.url;
\t\t\t\t\tshot.style.backgroundImage = 'url(' + item.cover + ')';
\t\t\t\t\tshot.setAttribute( 'aria-hidden', 'true' );
\t\t\t\t\tcard.appendChild( shot );
\t\t\t\t}

\t\t\t\tvar body = document.createElement( 'div' );
\t\t\t\tbody.className = 'estat-card-body';

\t\t\t\tvar title = document.createElement( 'h3' );
\t\t\t\ttitle.className = 'estat-card-title';
\t\t\t\tvar link = document.createElement( 'a' );
\t\t\t\tlink.href = item.url;
\t\t\t\tlink.textContent = item.title;
\t\t\t\ttitle.appendChild( link );

\t\t\t\tvar price = document.createElement( 'p' );
\t\t\t\tprice.className = 'estat-card-price';
\t\t\t\tprice.textContent = item.price_display || say( 'onRequest', 'Price on request' );

\t\t\t\tbody.appendChild( title );
\t\t\t\tbody.appendChild( price );

\t\t\t\tvar where = ( item.facts && item.facts.locality ) || '';
\t\t\t\tif ( where ) {
\t\t\t\t\tvar line = document.createElement( 'p' );
\t\t\t\t\tline.className = 'estat-fav-where';
\t\t\t\t\tline.textContent = where;
\t\t\t\t\tbody.appendChild( line );
\t\t\t\t}

\t\t\t\tvar acts = document.createElement( 'div' );
\t\t\t\tacts.className = 'estat-fav-acts';

\t\t\t\tvar cmp = document.createElement( 'button' );
\t\t\t\tcmp.type = 'button';
\t\t\t\tcmp.className = 'estat-compare estat-btn estat-btn--ghost';
\t\t\t\tcmp.setAttribute( 'data-listing', String( item.id ) );
\t\t\t\tcmp.textContent = say( 'compareThis', 'Compare' );
\t\t\t\tacts.appendChild( cmp );

\t\t\t\tvar off = document.createElement( 'button' );
\t\t\t\toff.type = 'button';
\t\t\t\toff.className = 'estat-fav estat-btn estat-btn--quiet';
\t\t\t\toff.setAttribute( 'data-listing', String( item.id ) );
\t\t\t\toff.textContent = say( 'remove', 'Remove' );
\t\t\t\tacts.appendChild( off );

\t\t\t\tbody.appendChild( acts );
\t\t\t\tcard.appendChild( body );
\t\t\t\tsection.appendChild( card );
\t\t\t} );

\t\t\tsyncButtons();
\t\t} );
\t}

`;
s = s.replace(oldFav, newFav, 1);
console.log('  ok  favourites rebuilt');

// --- 3. the drop button in the compare header ----------------------------
s = s.replace(`\t\tvar cmp = event.target.closest ? event.target.closest( '.estat-compare' ) : null;`,
`\t\tvar drop = event.target.closest ? event.target.closest( '.estat-compare-drop' ) : null;
\t\tif ( drop ) {
\t\t\ttoggle( CMP_KEY, parseInt( drop.getAttribute( 'data-listing' ), 10 ), 0 );
\t\t\tsyncButtons();
\t\t\trenderCompare();
\t\t\treturn;
\t\t}

\t\tvar cmp = event.target.closest ? event.target.closest( '.estat-compare' ) : null;`, 1);

// after adding to the comparison, take the visitor to the table
s = s.replace(`\t\t\tsyncButtons();
\t\t\trenderCompare();
\t\t}
\t} );`,
`\t\t\tsyncButtons();
\t\t\trenderCompare();

\t\t\t/*
\t\t\t * If the table is somewhere else on this page, take them to it.
\t\t\t * Choosing three properties one after another and never being
\t\t\t * shown the result is how a comparison gets forgotten.
\t\t\t */
\t\t\tvar panel = document.querySelector( '#estat-compare-panel' );
\t\t\tif ( panel && ! panel.contains( cmp ) && typeof panel.scrollIntoView === 'function' ) {
\t\t\t\tpanel.scrollIntoView( { behavior: 'smooth', block: 'start' } );
\t\t\t}
\t\t}
\t} );`, 1);

s = s.replace(`\tdocument.addEventListener( 'DOMContentLoaded', function () {
\t\tsyncButtons();
\t\trenderCompare();
\t\trenderFavorites();
\t} );`,
`\tdocument.addEventListener( 'DOMContentLoaded', function () {
\t\tsyncButtons();
\t\trenderCompare();
\t\trenderFavorites();
\t\twireShortlistForm();
\t} );`, 1);

fs.writeFileSync(P, s);
console.log('  ok  public.js written', s.length, 'bytes');
