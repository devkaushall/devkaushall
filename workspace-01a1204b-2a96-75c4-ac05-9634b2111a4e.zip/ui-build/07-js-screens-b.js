/* ==========================================================================
   ESTAT.OS — screens (part 2 of 2)
   ========================================================================== */

/* ------------------------------------------------------------ E · PIPELINE */
const COLTONE = { New: 'var(--info)', Contacted: 'var(--warn)', Scheduled: 'var(--bronze)', Won: 'var(--pos)', Lost: 'var(--dang)' };

VIEWS.pipeline = {
  mount() {
    const host = $('#kb');
    const draw = () => {
      host.innerHTML = Object.keys(DATA.deals).map(col => {
        const list = DATA.deals[col];
        const sum = list.reduce((s, d) => s + d.amt, 0);
        return '<div class="kb__col" data-col="' + col + '">' +
          '<div class="kb__h"><i class="dotc" style="background:' + COLTONE[col] + '"></i>' +
          '<h4>' + col + '</h4><span class="kb__n">' + list.length + '</span></div>' +
          '<div class="kb__amt">' + (sum ? short(sum) : '—') + '</div>' +
          '<div class="kb__list">' + list.map((d, i) =>
            '<div class="kcard" data-col="' + col + '" data-i="' + i + '" style="animation:rise 340ms var(--e-out) both;animation-delay:' + (i * 40) + 'ms">' +
            '<div class="kcard__t">' + esc(d.t) + '</div>' +
            '<div class="kcard__m">' + ico('home') + esc(d.p) + '</div>' +
            '<div class="kcard__f"><span class="kcard__av">' + d.a + '</span>' +
            '<span class="kcard__amt">' + short(d.amt) + '</span></div></div>').join('') +
          '</div></div>';
      }).join('');

      $$('.kcard', host).forEach(card => {
        draggable({
          nodes: [card],
          ghostClass: 'is-ghost',
          hitTest: (x, y) => {
            const el = elementAt(x, y);
            return el ? el.closest('.kb__col') : null;
          },
          onEnter: t => t.classList.add('is-over'),
          onLeave: t => t.classList.remove('is-over'),
          dropRect: t => {
            const list = $('.kb__list', t);
            const first = list.firstElementChild;
            const r = (first || list).getBoundingClientRect();
            return { left: r.left, top: first ? r.top : r.top + 4 };
          },
          onEnd: (node, target) => {
            $$('.kb__col').forEach(c => c.classList.remove('is-over'));
            if (!target) return;
            const from = node.dataset.col, to = target.dataset.col;
            if (from === to) return;
            const item = DATA.deals[from].splice(+node.dataset.i, 1)[0];
            DATA.deals[to].unshift(item);
            draw();
            toast('Moved to ' + to, item.t + ' · ' + short(item.amt), 'ok',
              { label: 'Undo', run: () => { DATA.deals[to].shift(); DATA.deals[from].splice(+node.dataset.i, 0, item); draw(); } });
          }
        });
      });
    };
    draw();
  }
};

/* ----------------------------------------------------------- F · VISITS */
VIEWS.visits = {
  mount() {
    const cal = $('#cal');
    if (!cal.dataset.done) {
      cal.dataset.done = '1';
      cal.innerHTML = DOW.map(d => '<div class="cal__dh">' + d + '</div>').join('') +
        (() => {
          let out = '';
          for (let i = 0; i < 2; i++) out += '<div class="cal__d is-out"></div>';     // Oct 1 2025 is a Wednesday
          for (let d = 1; d <= 31; d++) {
            const ev = DATA.visits.filter(v => v.day === d);
            out += '<div class="cal__d' + (d === 8 ? ' is-today' : '') + '">' +
              '<div class="cal__n">' + d + '</div>' +
              ev.map(v => '<div class="cal__e" style="--mc:var(--' + v.tone + ')" data-v="' + DATA.visits.indexOf(v) + '">' +
                v.time + ' · ' + esc(v.client) + '</div>').join('') + '</div>';
          }
          return out;
        })();
      $$('.cal__e', cal).forEach(e => e.addEventListener('click', () => openVisit(DATA.visits[+e.dataset.v])));
    }

    const list = $('#visitList');
    if (!list.dataset.done) {
      list.dataset.done = '1';
      list.innerHTML = DATA.visits.map((v, i) =>
        '<div class="panel" style="padding:var(--s3);animation:rise 320ms var(--e-out) both;animation-delay:' + (i * 50) + 'ms">' +
        '<div style="display:flex;align-items:center;gap:var(--s2);margin-bottom:6px">' +
        '<span class="badge badge--bronze">' + v.time + '</span>' +
        '<b style="font-size:var(--fs-name)">' + esc(v.client) + '</b></div>' +
        '<div class="mut" style="font-size:var(--fs-meta);margin-bottom:var(--s3)">' + esc(v.prop) + ' · ' + esc(v.agent) + ' · ' + v.day + ' Oct</div>' +
        '<div style="display:flex;gap:var(--s2)">' +
        '<button class="btn btn--sm btn--ok" data-vs="done">' + ico('check') + 'Completed</button>' +
        '<button class="btn btn--sm btn--ghost" data-vs="no">' + ico('x') + 'No-show</button>' +
        '<button class="btn btn--sm btn--quiet" data-vs="cancel">' + ico('trash') + '</button>' +
        '</div></div>').join('');

      $$('[data-vs]', list).forEach(b => b.addEventListener('click', () => {
        const card = b.closest('.panel');
        const name = $('.b', card) ? $('.b', card).textContent : 'the visit';
        if (b.dataset.vs === 'cancel') {
          card.style.transition = 'opacity 240ms,transform 240ms';
          card.style.opacity = '0'; card.style.transform = 'translateX(20px)';
          setTimeout(() => card.remove(), 240);
          toast('Visit cancelled', name, 'warn', { label: 'Undo', run: () => toast('Visit restored', name, 'ok') });
        } else {
          card.style.borderColor = b.dataset.vs === 'done' ? 'var(--pos-line)' : 'var(--warn-line)';
          card.style.background = b.dataset.vs === 'done' ? 'var(--pos-soft)' : 'var(--warn-soft)';
          toast(b.dataset.vs === 'done' ? 'Marked completed' : 'Marked no-show', name, b.dataset.vs === 'done' ? 'ok' : 'warn');
        }
      }));
    }
  }
};

function openVisit(v) {
  Drawer.open({
    kicker: 'Site visit · ' + v.day + ' October',
    title: v.client,
    sub: v.time + ' · ' + v.prop,
    body:
      '<div class="panel panel--pad"><div class="lbl" style="margin-bottom:var(--s3)">Who is going</div><div class="kv">' +
      '<div class="kv__r"><span>Agent</span><b>' + esc(v.agent) + '</b></div>' +
      '<div class="kv__r"><span>Property</span><b>' + esc(v.prop) + '</b></div>' +
      '<div class="kv__r"><span>Time</span><b>' + v.time + ', ' + v.day + ' Oct 2025</b></div>' +
      '</div></div>' +
      '<div class="panel panel--pad"><div class="lbl" style="margin-bottom:var(--s3)">Outcome</div>' +
      '<div style="display:flex;gap:var(--s2)"><button class="btn btn--ok" style="flex:1">' + ico('check') + 'Completed</button>' +
      '<button class="btn btn--ghost" style="flex:1">' + ico('x') + 'No-show</button>' +
      '<button class="btn btn--quiet">' + ico('trash') + '</button></div></div>',
    foot: '<button class="btn btn--ghost">' + ico('phone') + 'Call ' + esc(v.client) + '</button>'
  });
}

/* --------------------------------------------------------------- G · TEAM */
VIEWS.team = {
  mount() {
    const host = $('#teamGrid');
    if (host.dataset.done) return;
    host.dataset.done = '1';
    host.innerHTML = DATA.agents.map((a, i) =>
      '<button class="card card--lift anim" style="--d:' + (i * 50) + 'ms;padding:var(--s5);text-align:left">' +
      '<div style="display:flex;align-items:center;gap:var(--s3);margin-bottom:var(--s4)">' +
      '<span style="width:46px;height:46px;border-radius:99px;display:grid;place-items:center;color:#fff;font-weight:700;font-size:15px;background:linear-gradient(150deg,' + a.tone + ',rgba(0,0,0,.35))">' + initials(a.name) + '</span>' +
      '<span style="min-width:0"><b class="dsp" style="font-size:var(--fs-card);display:block">' + esc(a.name) + '</b>' +
      '<span class="mut" style="font-size:var(--fs-meta)">' + esc(a.role) + '</span></span></div>' +
      '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:var(--s2);text-align:center;padding-top:var(--s3);border-top:1px solid var(--line)">' +
      '<div><b class="dsp" style="font-size:20px;display:block">' + a.props + '</b><span class="lbl">Properties</span></div>' +
      '<div><b class="dsp" style="font-size:20px;display:block">' + a.leads + '</b><span class="lbl">Leads</span></div>' +
      '<div><b class="dsp" style="font-size:20px;display:block;color:var(--pos-deep)">' + a.won + '</b><span class="lbl">Won</span></div>' +
      '</div>' +
      '<div style="display:flex;gap:var(--s2);margin-top:var(--s4)">' +
      '<span class="btn btn--ghost btn--sm" style="flex:1">' + ico('phone') + esc(a.phone) + '</span>' +
      '<span class="btn btn--ghost btn--sm">' + ico('mail') + '</span></div>' +
      '</button>').join('');
    $$('.card', host).forEach((c, i) => c.addEventListener('click', () => {
      const a = DATA.agents[i];
      Drawer.open({
        kicker: a.role, title: a.name, sub: a.phone,
        body:
          '<div style="display:flex;gap:var(--s4);flex-wrap:wrap">' +
          '<div style="flex:1;min-width:110px"><div class="lbl">Properties</div><b class="dsp" style="font-size:26px">' + a.props + '</b></div>' +
          '<div style="flex:1;min-width:110px"><div class="lbl">Open leads</div><b class="dsp" style="font-size:26px">' + a.leads + '</b></div>' +
          '<div style="flex:1;min-width:110px"><div class="lbl">Won this year</div><b class="dsp" style="font-size:26px;color:var(--pos-deep)">' + a.won + '</b></div></div>' +
          '<div class="divider"></div>' +
          '<div class="lbl" style="margin-bottom:var(--s3)">Carrying right now</div>' +
          DATA.properties.slice(0, 3).map((p, k) =>
            '<div class="wl__i" style="border:1px solid var(--line);animation:rise 300ms var(--e-out) both;animation-delay:' + (k * 45) + 'ms">' +
            '<span class="tthumb" style="background:linear-gradient(140deg,' + p.tone + ',rgba(0,0,0,.18));width:38px;height:30px">' + ico('home') + '</span>' +
            '<div class="wl__b"><div class="wl__t">' + esc(p.title) + '</div><div class="wl__m">' + short(p.price) + '</div></div>' +
            statusBadge(p.status) + '</div>').join(''),
        foot: '<button class="btn btn--ghost">' + ico('phone') + 'Call</button><button class="btn btn--bronze">' + ico('chart') + 'Full report</button>'
      });
    }));
  }
};

/* ------------------------------------------------------ H · CHANGE REQUESTS */
VIEWS.requests = {
  mount() {
    const host = $('#reqList');
    if (host.dataset.done) return;
    host.dataset.done = '1';
    host.innerHTML = DATA.requests.map((r, i) =>
      '<div class="panel anim" data-r="' + i + '" style="--d:' + (i * 60) + 'ms">' +
      '<div class="panel__h">' +
      '<span class="tthumb" style="background:var(--bronze-soft);color:var(--bronze)">' + ico('shuffle') + '</span>' +
      '<div><h3>' + esc(r.field) + '</h3><div class="lbl">' + esc(r.prop) + '</div></div>' +
      '<div class="panel__hr"><span class="mut" style="font-size:var(--fs-meta)">' + esc(r.who) + ' · ' + esc(r.when) + '</span></div>' +
      '</div>' +
      '<div class="panel__b">' +
      '<div class="diff">' +
      '<div class="diff__c diff__c--old"><div class="diff__h">On the website now</div><div class="diff__v"><del class="dif">' + esc(r.old) + '</del></div></div>' +
      '<div class="diff__arw">' + ico('chev-r') + '</div>' +
      '<div class="diff__c diff__c--new"><div class="diff__h">Proposed</div><div class="diff__v"><ins class="dif">' + esc(r.neo) + '</ins></div></div>' +
      '</div>' +
      '<p class="mut" style="font-size:var(--fs-name);margin-top:var(--s3)">' + esc(r.note) + '</p>' +
      '</div>' +
      '<div class="panel__f" style="justify-content:flex-end">' +
      '<button class="btn btn--ghost" data-dec="decline">' + ico('x') + 'Decline</button> ' +
      '<button class="btn btn--ok" data-dec="approve">' + ico('check') + 'Approve</button>' +
      '</div></div>').join('');

    $$('[data-dec]', host).forEach(b => b.addEventListener('click', () => {
      const card = b.closest('.panel');
      const r = DATA.requests[+card.dataset.r];
      const ok = b.dataset.dec === 'approve';
      card.style.transition = 'opacity 320ms,transform 320ms';
      card.style.opacity = '0';
      card.style.transform = ok ? 'translateX(26px)' : 'translateX(-26px)';
      setTimeout(() => {
        card.style.height = card.offsetHeight + 'px';
        card.style.overflow = 'hidden';
        card.style.transition = 'height 320ms var(--e-out),margin 320ms,padding 320ms,opacity 200ms';
        card.style.height = '0'; card.style.margin = '0'; card.style.padding = '0'; card.style.opacity = '0';
        setTimeout(() => card.remove(), 340);
      }, 200);
      toast(ok ? 'Approved' : 'Declined', r.field + ' on ' + r.prop, ok ? 'ok' : 'warn',
        { label: 'Undo', run: () => toast('Reversed', 'Back to the queue', 'info') });
    }));
  }
};

/* -------------------------------------------------------- I · GALLERY */
const GAL = { kind: 'photos', sel: {} };
VIEWS.gallery = {
  mount() {
    const grid = $('#galGrid');

    function draw() {
      const items = DATA.media[GAL.kind];
      grid.innerHTML = items.map((m, i) =>
        '<div class="tile' + (GAL.sel[GAL.kind + i] ? ' is-sel' : '') + '" data-t="' + i + '" ' +
        'style="animation:rise 380ms var(--e-out) both;animation-delay:' + Math.min(i * 35, 300) + 'ms">' +
        '<div class="tile__img" style="height:' + m.h + 'px;background:linear-gradient(140deg,' + m.c1 + ',' + m.c2 + ')"></div>' +
        '<span class="tile__ex">' + m.tag + '</span>' +
        '<span class="tile__cb cbrow"><i class="cb" aria-checked="' + (GAL.sel[GAL.kind + i] ? 'true' : 'false') + '"></i></span>' +
        '<div class="tile__ov"><span>' + esc(m.n) + '</span></div></div>').join('');
      $('#galCount').textContent = items.length + ' items';
      $$('.tile', grid).forEach(t => {
        t.addEventListener('click', e => {
          if (e.target.closest('.tile__cb')) {
            const k = GAL.kind + t.dataset.t;
            GAL.sel[k] = !GAL.sel[k];
            draw(); syncGal();
            return;
          }
          const m = items[+t.dataset.t];
          Drawer.open({
            kicker: GAL.kind, title: m.n,
            sub: m.tag + ' · ' + (m.h * 4) + ' KB',
            body: '<div style="height:260px;border-radius:var(--r-md);background:linear-gradient(140deg,' + m.c1 + ',' + m.c2 + ')"></div>' +
              '<div class="panel panel--pad"><div class="lbl" style="margin-bottom:var(--s3)">Used on</div>' +
              DATA.properties.slice(0, 2).map(p => '<div class="wl__i" style="padding:0;margin-bottom:8px">' +
                '<span class="tthumb" style="background:linear-gradient(140deg,' + p.tone + ',rgba(0,0,0,.18));width:36px;height:28px">' + ico('home') + '</span>' +
                '<div class="wl__b"><div class="wl__t">' + esc(p.title) + '</div></div></div>').join('') + '</div>',
            foot: '<button class="btn btn--ghost">' + ico('download') + 'Download</button>' +
              '<button class="btn btn--danger">' + ico('trash') + 'Delete</button>'
          });
        });
      });
    }
    function syncGal() {
      const n = Object.keys(GAL.sel).filter(k => GAL.sel[k]).length;
      $('#galSelectAll').textContent = n ? 'Clear selection' : 'Select all';
    }

    draw(); syncGal();

    if (!$('#galTabs').dataset.done) {
      $('#galTabs').dataset.done = '1';
      $$('#galTabs .seg__b').forEach(b => b.addEventListener('click', () => {
        $$('#galTabs .seg__b').forEach(x => x.classList.remove('is-on'));
        b.classList.add('is-on');
        GAL.kind = b.dataset.kind;
        draw();
      }));
      $('#galSelectAll').addEventListener('click', () => {
        const items = DATA.media[GAL.kind];
        const any = Object.keys(GAL.sel).some(k => GAL.sel[k]);
        items.forEach((m, i) => GAL.sel[GAL.kind + i] = !any);
        draw(); syncGal();
        toast(any ? 'Selection cleared' : items.length + ' items selected', '', 'info');
      });

      // Upload: files land one at a time with their own progress.
      const dz = $('#galDrop'), ups = $('#galUploads');
      let n = 0;
      dz.addEventListener('click', () => addFiles(2 + Math.floor(Math.random() * 2)));
      ['dragenter', 'dragover'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.add('is-over'); }));
      ['dragleave', 'drop'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.remove('is-over'); }));
      dz.addEventListener('drop', e => addFiles(Math.max(1, e.dataTransfer.files.length)));

      function addFiles(count) {
        for (let i = 0; i < count; i++) {
          const id = 'up' + (++n);
          const row = document.createElement('div');
          row.className = 'uprow'; row.id = id;
          row.innerHTML = '<span class="uprow__ico">' + ico('file') + '</span>' +
            '<div class="uprow__b"><div class="uprow__n">' + 'IMG_' + (2400 + n) + '.jpg</div>' +
            '<div class="uprow__bar"><i class="uprow__fill"></i></div></div>' +
            '<span class="mut uprow__p" style="font-size:var(--fs-meta);font-variant-numeric:tabular-nums">0%</span>';
          ups.appendChild(row);
          setTimeout(() => runUpload(id, 380 + Math.random() * 700), i * 260);
        }
      }
      function runUpload(id, dur) {
        const row = $('#' + id); if (!row) return;
        const fill = $('.uprow__fill', row), pct = $('.uprow__p', row);
        const t0 = performance.now();
        (function step(now) {
          const p = clamp((now - t0) / dur, 0, 1);
          fill.style.width = (p * 100).toFixed(0) + '%';
          pct.textContent = Math.round(p * 100) + '%';
          if (p < 1) raf(step);
          else {
            setTimeout(() => {
              row.style.transition = 'opacity 300ms,transform 300ms';
              row.style.opacity = '0'; row.style.transform = 'translateY(-6px)';
              setTimeout(() => { row.remove(); toast('Upload complete', 'IMG_' + id.slice(2) + '.jpg is in the gallery', 'ok'); }, 300);
            }, 420);
          }
        })(t0);
      }
    }
  }
};

/* ---------------------------------------------------------------- J · FORMS */
const FB = { fields: [], sel: null };
const FBTOOLS = [
  { id: 'text', l: 'Text', i: 'type' }, { id: 'email', l: 'Email', i: 'mail' },
  { id: 'phone', l: 'Phone', i: 'phone' }, { id: 'select', l: 'Dropdown', i: 'chev-d' },
  { id: 'check', l: 'Checkbox', i: 'check' }, { id: 'radio', l: 'Choice', i: 'star' },
  { id: 'textarea', l: 'Long text', i: 'form' }, { id: 'date', l: 'Date', i: 'calendar' }
];
VIEWS.forms = {
  mount() {
    $('#fbTools').innerHTML = FBTOOLS.map(t =>
      '<button class="fbtool" data-tool="' + t.id + '">' + ico(t.i) + esc(t.l) + '</button>').join('');

    const canvas = $('#fbCanvas');
    function field(i) {
      const f = FB.fields[i];
      let inner = '';
      if (f.type === 'textarea') inner = '<textarea class="in" placeholder="' + esc(f.ph) + '"></textarea>';
      else if (f.type === 'select') inner = '<select class="in"><option>' + esc(f.ph) + '</option></select>';
      else if (f.type === 'check') inner = '<span class="cbrow"><i class="cb"></i><span style="font-size:var(--fs-name)">' + esc(f.l) + '</span></span>';
      else if (f.type === 'date') inner = '<input class="in" type="date">';
      else inner = '<input class="in" type="text" placeholder="' + esc(f.ph) + '">';
      return '<div class="fbfield' + (FB.sel === i ? ' is-on' : '') + '" data-f="' + i + '">' +
        '<span class="fbfield__grip">' + ico('grip') + '</span>' +
        (f.type === 'check' ? '' : '<div class="field__lbl" style="margin-bottom:6px">' + esc(f.l) + (f.req ? ' *' : '') + '</div>') +
        inner +
        '<button class="fbfield__x">' + ico('x') + '</button></div>';
    }
    /* Two separate redraws on purpose. `draw()` rebuilds BOTH panels; typing
       in the settings panel must only call `redrawCanvas()`, because rebuilding
       the settings panel destroys the very input being typed into — the caret
       and the focus vanish after the first keystroke. */
    function redrawCanvas() {
      canvas.innerHTML = FB.fields.map((f, i) => field(i)).join('');
      $('#fbEmpty').hidden = FB.fields.length > 0;
      bind();
    }
    function draw() { redrawCanvas(); drawSettings(); }
    function drawSettings() {
      const host = $('#fbSettings');
      if (FB.sel === null || !FB.fields[FB.sel]) {
        host.innerHTML = '<div class="mut" style="font-size:var(--fs-name);line-height:1.6">Click a field on the canvas to change it.</div>';
        return;
      }
      const f = FB.fields[FB.sel];
      host.innerHTML =
        '<div class="field" style="margin-bottom:var(--s3)"><label class="field__lbl">Label</label><input class="in" data-set="l" value="' + esc(f.l) + '"></div>' +
        '<div class="field" style="margin-bottom:var(--s3)"><label class="field__lbl">Placeholder</label><input class="in" data-set="ph" value="' + esc(f.ph) + '"></div>' +
        '<div style="display:flex;align-items:center;gap:var(--s3);padding:var(--s2) 0">' +
        '<span style="font-size:var(--fs-name);flex:1">Required</span><i class="tgl" data-set="req" role="switch" aria-checked="' + !!f.req + '"></i></div>';
      $$('[data-set]', host).forEach(i => i.addEventListener('input', () => {
        if (i.dataset.set === 'req') return;
        f[i.dataset.set] = i.value;
        redrawCanvas();          // canvas only — this input keeps focus
      }));
      $('[data-set="req"]', host).addEventListener('click', function () {
        f.req = this.getAttribute('aria-checked') !== 'true';
        this.setAttribute('aria-checked', !!f.req);
        redrawCanvas();
      });
    }
    function bind() {
      $$('.fbfield', canvas).forEach(el => {
        el.addEventListener('click', e => {
          if (e.target.closest('.fbfield__x')) {
            FB.fields.splice(+el.dataset.f, 1); FB.sel = null; draw();
            toast('Field removed', '', 'info'); return;
          }
          FB.sel = +el.dataset.f; draw();
        });
      });
      // Reorder inside the canvas.
      $$('.fbfield', canvas).forEach(el => {
        draggable({
          nodes: [el],
          ghostClass: 'is-ghost',
          hitTest: (x, y) => {
            const e2 = elementAt(x, y);
            return e2 ? e2.closest('.fbfield') : null;
          },
          dropRect: t => { const r = t.getBoundingClientRect(); return { left: r.left, top: r.top }; },
          onEnd: (node, t) => {
            if (!t || t === node) return;
            const a = +node.dataset.f, b = +t.dataset.f;
            const it = FB.fields.splice(a, 1)[0];
            FB.fields.splice(b, 0, it);
            FB.sel = b; draw();
            toast('Reordered', it.l + ' moved', 'ok');
          }
        });
      });
    }

    // Drag a tool from the palette onto the canvas.
    $$('.fbtool').forEach(t => {
      t.addEventListener('click', () => {
        const d = FBTOOLS.find(x => x.id === t.dataset.tool);
        FB.fields.push({ type: d.id, l: d.l, ph: 'Enter ' + d.l.toLowerCase(), req: d.id === 'text' });
        FB.sel = FB.fields.length - 1; draw();
        toast('Field added', d.l, 'ok');
      });
    });

    if (!canvas.dataset.done) {
      canvas.dataset.done = '1';
      ['text', 'phone', 'select', 'check'].forEach(id => {
        const d = FBTOOLS.find(x => x.id === id);
        FB.fields.push({ type: d.id, l: d.l, ph: 'Enter ' + d.l.toLowerCase(), req: id === 'text' });
      });
    }
    draw();
  }
};

/* ------------------------------------------------------ K · IMPORT WIZARD */
const WIZ = { step: 1 };
VIEWS.import = {
  mount() {
    const body = $('#wizBody');
    const steps = $$('#wiz .wiz__s');

    function paint() {
      steps.forEach((s, i) => {
        const n = i + 1;
        s.classList.toggle('is-on', n === WIZ.step);
        s.classList.toggle('is-done', n < WIZ.step);
        $('.wiz__n', s).innerHTML = n < WIZ.step ? ico('check') : n;
      });
      body.innerHTML = CONTENT[WIZ.step - 1]();
      body.style.animation = 'none'; void body.offsetWidth; body.style.animation = '';
      if (AFTER[WIZ.step - 1]) AFTER[WIZ.step - 1]();
    }

    const MAP = [
      ['Property Title', 'title', 'Property title'], ['Price', 'price', 'Price'],
      ['Locality', 'locality', 'Locality'], ['Bedrooms', 'bedrooms', 'Bedrooms'],
      ['Area', 'area', 'Area (sq ft)'], ['Description', 'description', 'Description'],
      ['Agent', 'agent', 'Team member in charge']
    ];

    const CONTENT = [
      () => '<div class="panel anim" style="--d:0ms"><div class="panel__b">' +
        '<div class="dropzone" data-dropzone style="padding:var(--s8)">' +
        ico('upload') + '<h4>Drop your CSV here</h4><p>We read the first row as column names. Nothing is saved until you press Import.</p></div>' +
        '<div style="display:flex;gap:var(--s2);margin-top:var(--s4)">' +
        '<span class="chipf">' + ico('file') + 'societies-october.csv</span>' +
        '<span class="mut" style="font-size:var(--fs-meta);align-self:center">142 rows · 7 columns</span></div>' +
        '<div class="panel__f" style="margin:var(--s5) calc(-1*var(--s5)) calc(-1*var(--s5));justify-content:flex-end">' +
        '<button class="btn btn--ghost">' + ico('download') + 'Download the template</button>' +
        '<button class="btn btn--bronze" data-next>Map columns ' + ico('chev-r') + '</button></div>' +
        '</div></div>',

      () => '<div class="panel anim" style="--d:0ms"><div class="panel__h"><div><h3>Match your columns</h3>' +
        '<div class="lbl">We had a good guess at each one — change anything that looks wrong</div></div></div>' +
        '<div class="tw__scroll"><table class="tb"><thead><tr><th>Your column</th><th></th><th>System field</th><th style="width:120px">Sample</th></tr></thead><tbody>' +
        MAP.map(([a, b, c], i) =>
          '<tr style="animation:rise 260ms var(--e-out) both;animation-delay:' + (i * 30) + 'ms">' +
          '<td><b>' + esc(a) + '</b></td>' +
          '<td style="color:var(--pos-deep)">' + ico('chev-r') + '</td>' +
          '<td><select class="in" style="height:32px"><option>' + esc(c) + '</option><option>— ignore —</option></select></td>' +
          '<td class="mut" style="font-size:var(--fs-meta)">' + ['3 BHK, Sector 57', '1,24,00,000', 'Sector 57', '3', '1,450', 'A west-facing floor…', 'Priya Nair'][i] + '</td>' +
          '</tr>').join('') +
        '</tbody></table></div>' +
        '<div class="panel__f" style="justify-content:space-between">' +
        '<button class="btn btn--quiet" data-back>' + ico('chev-l') + ' Back</button>' +
        '<button class="btn btn--bronze" data-next>Start import ' + ico('chev-r') + '</button></div></div>',

      () => '<div class="panel anim" style="--d:0ms"><div class="panel__b">' +
        '<div style="display:flex;align-items:baseline;gap:var(--s3);margin-bottom:var(--s3)">' +
        '<b class="dsp" style="font-size:30px" id="impPct">0%</b>' +
        '<span class="mut" id="impMsg" style="font-size:var(--fs-name)">Reading the file…</span></div>' +
        '<div class="meter" style="min-width:0"><div class="meter__track" style="height:8px"><i class="meter__fill" id="impBar" style="width:0"></i></div></div>' +
        '<div class="divider"></div>' +
        '<div id="impLog" style="display:grid;gap:6px;font-size:var(--fs-meta);color:var(--ink-3)"></div>' +
        '</div></div>',

      () => '<div class="panel anim" style="--d:0ms"><div class="panel__b" style="text-align:center;padding:var(--s8) var(--s5)">' +
        '<div style="width:64px;height:64px;border-radius:99px;background:var(--pos-soft);color:var(--pos-deep);display:grid;place-items:center;margin:0 auto var(--s4);animation:rise 480ms var(--e-spring) both">' +
        '<svg style="width:30px;height:30px"><use href="#i-check"/></svg></div>' +
        '<h3 class="dsp" style="font-size:var(--fs-h2);margin-bottom:6px">142 properties imported</h3>' +
        '<p class="mut" style="max-width:46ch;margin:0 auto">Every one arrived as a draft, so nothing is on your website until you have looked at it. ' +
        'You can undo the whole import for the next hour.</p>' +
        '<div style="display:flex;gap:var(--s2);justify-content:center;margin-top:var(--s5)">' +
        '<button class="btn btn--ghost" id="impUndo">' + ico('restore') + 'Undo import</button>' +
        '<button class="btn btn--bronze" data-nav="properties">Review the drafts</button></div>' +
        '</div></div>'
    ];

    const AFTER = [null, null, runImport, null];

    function runImport() {
      const bar = $('#impBar'), pct = $('#impPct'), msg = $('#impMsg'), log = $('#impLog');
      const lines = ['Reading 142 rows…', 'Checking for duplicates…', 'Matching localities…', 'Attaching agents…', 'Saving drafts…', 'Done.'];
      let p = 0;
      const t0 = performance.now(), dur = REDUCED ? 1 : 5200;
      (function step(now) {
        p = clamp((now - t0) / dur, 0, 1);
        const e = 1 - Math.pow(1 - p, 2.4);
        bar.style.width = (e * 100).toFixed(0) + '%';
        pct.textContent = Math.round(e * 100) + '%';
        const li = Math.min(lines.length - 1, Math.floor(e * lines.length));
        msg.textContent = lines[li];
        if (log.children.length < li + 1) {
          const d = document.createElement('div');
          d.style.animation = 'rise 260ms var(--e-out) both';
          d.textContent = '✓ ' + lines[li];
          log.appendChild(d);
        }
        if (p < 1) raf(step);
        else setTimeout(() => { WIZ.step = 4; paint(); }, 420);
      })(t0);
    }

    body.addEventListener('click', e => {
      if (e.target.closest('[data-next]')) { WIZ.step = Math.min(4, WIZ.step + 1); paint(); }
      else if (e.target.closest('[data-back]')) { WIZ.step = Math.max(1, WIZ.step - 1); paint(); }
      else if (e.target.closest('#impUndo')) {
        WIZ.step = 1; paint();
        toast('Import undone', 'All 142 drafts removed', 'warn', { label: 'Redo', run: () => toast('Redone', '142 drafts restored', 'ok') });
      }
    });
    paint();
  }
};

/* ---------------------------------------------------------- L · DUPLICATES */
let DUPI = 0;
VIEWS.duplicates = {
  mount() {
    const host = $('#dupBody');
    const draw = () => {
      const d = DATA.dups[DUPI];
      if (!d) { host.innerHTML = '<div class="panel"><div class="empty">' + ico('check') + '<h4>All clear</h4><p>Every pair has been decided. The sweep runs again at 6 am.</p></div></div>'; return; }
      $('#dupIdx').textContent = (DUPI + 1) + ' of ' + DATA.dups.length;
      const tone = d.kind === 'Same' ? 'var(--dang)' : d.kind === 'Near' ? 'var(--warn)' : 'var(--bronze)';
      const side = p => '<div class="panel"><div class="panel__h"><div><h3>' + esc(p.title) + '</h3>' +
        '<div class="lbl">' + (p.ref || '—') + ' · ' + esc(p.kind || 'Property') + '</div></div></div><div class="panel__b">' +
        '<div class="cmp__row"><span>Price</span><b>' + (p.price ? money(p.price) : '—') + '</b></div>' +
        '<div class="cmp__row' + '"><span>Area</span><b>' + (p.area ? inr(p.area) + ' sq ft' : '—') + '</b></div>' +
        '<div class="cmp__row"><span>Locality</span><b>' + esc(p.loc) + '</b></div>' +
        '<div class="cmp__row"><span>Status</span><b>' + statusBadge(p.status) + '</b></div>' +
        '<div class="cmp__row"><span>Completeness</span><b>' + p.pct + '%</b></div>' +
        '</div></div>';
      host.innerHTML =
        '<div class="panel anim" style="--d:0ms;margin-bottom:var(--s4)"><div class="panel__b" style="display:flex;align-items:center;gap:var(--s4);padding:var(--s4) var(--s5)">' +
        '<svg style="width:20px;height:20px;color:' + tone + ';flex:none"><use href="#i-alert"/></svg>' +
        '<div><b style="font-size:var(--fs-name)">' + d.kind + ' match · ' + d.score + '%</b>' +
        '<div class="mut" style="font-size:var(--fs-meta);margin-top:2px">' + esc(d.why) + '</div></div></div></div>' +
        '<div class="cmp anim" style="--d:60ms">' + side(d.a) +
        '<div class="cmp__mid"><div class="score" style="--p:' + d.score + ';--sc:' + tone + '"><b>' + d.score + '</b></div>' +
        '<div class="lbl">' + d.kind + '</div></div>' +
        side(d.b) + '</div>' +
        '<div style="display:flex;gap:var(--s2);justify-content:center;margin-top:var(--s5);flex-wrap:wrap">' +
        '<button class="btn btn--ghost" data-dd="both">' + ico('check') + 'Keep both</button>' +
        '<button class="btn btn--ok" data-dd="keepA">Keep the left one</button>' +
        '<button class="btn btn--ok" data-dd="keepB">Keep the right one</button>' +
        '<button class="btn btn--danger" data-dd="bin">' + ico('trash') + 'Move both to bin</button>' +
        '</div>';
      $$('[data-dd]', host).forEach(b => b.addEventListener('click', () => {
        const label = { both: 'Kept both', keepA: 'Kept the left record', keepB: 'Kept the right record', bin: 'Moved to bin' }[b.dataset.dd];
        DATA.dups.splice(DUPI, 1);
        if (DUPI >= DATA.dups.length) DUPI = Math.max(0, DATA.dups.length - 1);
        draw();
        toast(label, 'The sweep will not raise it again', b.dataset.dd === 'bin' ? 'warn' : 'ok');
      }));
    };
    $('#dupPrev').onclick = () => { DUPI = Math.max(0, DUPI - 1); draw(); };
    $('#dupNext').onclick = () => { DUPI = Math.min(DATA.dups.length - 1, DUPI + 1); draw(); };
    draw();
  }
};

/* ------------------------------------------------------------- M · REPORTS */
function svgBar(data, w, h) {
  const pad = 26, bw = (w - pad * 2) / data.length;
  const max = Math.max.apply(null, data.map(d => d[1]));
  const base = h - 30;
  return '<svg class="chart" viewBox="0 0 ' + w + ' ' + h + '" style="width:100%;height:auto">' +
    [0, .25, .5, .75, 1].map(g => '<line class="gl" x1="' + pad + '" x2="' + (w - pad) + '" y1="' + (base - g * (base - 14)) + '" y2="' + (base - g * (base - 14)) + '"/>').join('') +
    data.map((d, i) => {
      const bh = Math.max(3, d[1] / max * (base - 22));
      const x = pad + i * bw + bw * .18, bwi = bw * .64;
      return '<rect class="bar" x="' + x + '" y="' + (base - bh) + '" width="' + bwi + '" height="' + bh + '" rx="4" ' +
        'fill="' + (d[2] || 'var(--bronze)') + '" style="transform-box:fill-box;transform-origin:bottom;--d:' + (i * 90) + 'ms"/>' +
        '<text x="' + (x + bwi / 2) + '" y="' + (base - bh - 7) + '" text-anchor="middle" style="font-weight:700;fill:var(--ink-2)">' + d[1] + '</text>' +
        '<text x="' + (x + bwi / 2) + '" y="' + (h - 10) + '" text-anchor="middle">' + esc(d[0]) + '</text>';
    }).join('') + '</svg>';
}
function svgDonut(data) {
  const r = 66, c = 2 * Math.PI * r; let off = 0;
  return '<svg class="chart" viewBox="0 0 200 200" style="width:100%;max-width:230px;height:auto;margin:0 auto;display:block">' +
    '<circle cx="100" cy="100" r="' + r + '" fill="none" stroke="var(--inset)" stroke-width="14"/>' +
    data.map((d, i) => {
      const len = d[1] / data.reduce((s, x) => s + x[1], 0) * c;
      const s = '<circle class="ring" cx="100" cy="100" r="' + r + '" stroke="' + d[2] + '" ' +
        'style="transform-box:fill-box;--len:' + c + ';--off:' + (c - len) + ';--d:' + (i * 120) + 'ms" ' +
        'stroke-dasharray="' + len + ' ' + (c - len) + '" transform="rotate(' + (off / c * 360 - 90) + ' 100 100)"/>';
      off += len; return s;
    }).join('') +
    '<text x="100" y="96" text-anchor="middle" style="font-size:24px;font-weight:700;fill:var(--ink)">248</text>' +
    '<text x="100" y="114" text-anchor="middle" style="font-size:10px">properties</text></svg>';
}
function svgLine(series, w, h) {
  const pad = 30, base = h - 26;
  const max = Math.max.apply(null, series.reduce((a, s) => a.concat(s.data), []));
  const stepX = (w - pad * 2) / (series[0].data.length - 1);
  return '<svg class="chart" viewBox="0 0 ' + w + ' ' + h + '" style="width:100%;height:auto">' +
    [0, .5, 1].map(g => '<line class="gl" x1="' + pad + '" x2="' + (w - pad) + '" y1="' + (base - g * (base - 20)) + '" y2="' + (base - g * (base - 20)) + '"/>').join('') +
    series.map((s, si) => {
      const pts = s.data.map((v, i) => [pad + i * stepX, base - v / max * (base - 20)]);
      const d = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
      const area = d + ' L' + pts[pts.length - 1][0] + ' ' + base + ' L' + pad + ' ' + base + ' Z';
      return '<path class="area" d="' + area + '" fill="' + s.color + '" opacity=".10" style="--d:' + (si * 140) + 'ms"/>' +
        '<path class="ln" d="' + d + '" stroke="' + s.color + '" style="--len:900;--d:' + (si * 140) + 'ms"/>' +
        pts.map(p => '<circle cx="' + p[0].toFixed(1) + '" cy="' + p[1].toFixed(1) + '" r="3" fill="var(--panel)" stroke="' + s.color + '" stroke-width="2"/>').join('');
    }).join('') +
    ['W1', 'W2', 'W3', 'W4', 'W5', 'W6'].map((l, i) => '<text x="' + (pad + i * stepX) + '" y="' + (h - 8) + '" text-anchor="middle">' + l + '</text>').join('') +
    '</svg>';
}

VIEWS.reports = {
  mount() {
    if ($('#chtBar').dataset.done) return;
    $('#chtBar').dataset.done = '1';
    const src = [['Website', 42], ['WhatsApp', 28], ['Referral', 18], ['Instagram', 14], ['Walk-in', 9]];
    $('#chtBar').innerHTML = svgBar(src, 520, 230);

    const inv = [['Apartment', 96, 'var(--bronze)'], ['Plot', 44, 'var(--pos)'], ['Builder floor', 38, 'var(--info)'],
    ['Shop', 26, 'var(--warn)'], ['Villa', 22, 'var(--dang)'], ['Other', 22, 'var(--ink-4)']];
    $('#chtDonut').innerHTML = svgDonut(inv);
    $('#donutLgd').innerHTML = inv.map(d => '<span class="lgd__i"><i class="lgd__sw" style="background:' + d[2] + '"></i>' + d[0] + ' <b>' + d[1] + '</b></span>').join('');

    const series = [
      { name: 'Priya Nair', color: 'var(--pos)', data: [2, 3, 2, 5, 4, 6] },
      { name: 'Ravi Mehra', color: 'var(--bronze)', data: [1, 2, 4, 3, 5, 4] },
      { name: 'Amit Joshi', color: 'var(--info)', data: [0, 1, 1, 2, 3, 3] }
    ];
    $('#chtLine').innerHTML = svgLine(series, 520, 230);
    $('#lineLgd').innerHTML = series.map(s => '<span class="lgd__i"><i class="lgd__sw" style="background:' + s.color + '"></i>' + s.name + '</span>').join('');
  }
};

/* ------------------------------------------------------------ N · SETTINGS */
const SET = {
  office: () => '<div class="panel anim" style="--d:0ms"><div class="panel__h"><div><h3>The office</h3><div class="lbl">What customers see, and how they reach you</div></div></div>' +
    '<div class="panel__b" style="display:grid;gap:var(--s4);grid-template-columns:1fr 1fr">' +
    '<div class="field" style="grid-column:1/-1"><label class="field__lbl">Office name</label><input class="in" value="Mayfair Properties & Developers"></div>' +
    '<div class="field"><label class="field__lbl">Phone</label><input class="in" value="+91 124 400 9000"></div>' +
    '<div class="field"><label class="field__lbl">Email</label><input class="in" value="hello@mayfairproperties.in"></div>' +
    '<div class="field" style="grid-column:1/-1"><label class="field__lbl">Address</label><input class="in" value="Shop 14, Gold Souk, Sector 43, Gurugram"></div>' +
    '<div class="field"><label class="field__lbl">WhatsApp number</label><input class="in" value="+91 98100 00001"></div>' +
    '<div class="field"><label class="field__lbl">Working hours</label><input class="in" value="Mon–Sat, 10 am – 7 pm"></div>' +
    '</div><div class="panel__f"><button class="btn btn--bronze">Save</button>' +
    '<span class="mut" style="font-size:var(--fs-meta)">Shows on every page of your website</span></div></div>',

  integrations: () => '<div class="panel anim" style="--d:0ms"><div class="panel__h"><div><h3>Integrations</h3><div class="lbl">Where else your data goes</div></div></div>' +
    '<div class="panel__b" style="display:grid;gap:var(--s3)">' +
    [['WhatsApp Business', 'Sends enquiries straight to your phone.', 'pos'],
    ['Google Maps', 'Puts a map on every property page.', 'pos'],
    ['Rank Math', 'Writes your search-engine tags.', 'pos'],
    ['Mailchimp', 'Not connected.', 'ink4'],
    ['Zoho CRM', 'Not connected.', 'ink4']].map(([n, d, t]) =>
      '<div style="display:flex;align-items:center;gap:var(--s3);padding:var(--s3);border:1px solid var(--line);border-radius:var(--r-md)">' +
      '<b style="font-size:var(--fs-name);flex:1">' + n + '</b>' +
      '<span class="mut" style="font-size:var(--fs-meta)">' + d + '</span>' +
      '<i class="tgl" role="switch" aria-checked="' + (t === 'pos') + '"></i></div>').join('') +
    '</div></div>',

  alerts: () => '<div class="panel anim" style="--d:0ms"><div class="panel__h"><div><h3>Search alerts</h3><div class="lbl">A visitor can ask to be told when something matching arrives</div></div></div>' +
    '<div class="panel__b" style="display:grid;gap:var(--s4)">' +
    '<div style="display:flex;align-items:center;gap:var(--s3)"><div style="flex:1"><b style="font-size:var(--fs-name)">Let visitors save a search</b>' +
    '<div class="mut" style="font-size:var(--fs-meta);margin-top:2px">They leave an email, we email them when a match appears.</div></div>' +
    '<i class="tgl" role="switch" aria-checked="false"></i></div>' +
    '<div class="field"><label class="field__lbl">How often to check</label><select class="in"><option>Once a day</option><option>Twice a day</option><option>Once a week</option></select></div>' +
    '<div class="field"><label class="field__lbl">Send from this address</label><input class="in" value="alerts@mayfairproperties.in"></div>' +
    '</div><div class="panel__f"><button class="btn btn--bronze">Save</button></div></div>',

  tokens: () => {
    const sw = [
      { k: '--bronze', l: 'Accent', d: 'Buttons, links, active states' },
      { k: '--pos', l: 'Positive', d: 'Live, approved, won' },
      { k: '--warn', l: 'Warning', d: 'Pending, overdue' },
      { k: '--dang', l: 'Danger', d: 'Declined, deleted' },
      { k: '--ink', l: 'Ink', d: 'Headings and primary buttons' },
      { k: '--linen', l: 'Background', d: 'The canvas everything sits on' }
    ];
    return '<div class="tok">' +
      '<div class="panel anim" style="--d:0ms"><div class="panel__h"><div><h3>Design tokens</h3><div class="lbl">Change a colour and watch the preview</div></div></div>' +
      '<div class="panel__b"><div class="tokgrid">' +
      sw.map(s => '<div class="tokrow"><span class="sw" style="background:' + 'var(' + s.k + ')' + '">' +
        '<input type="color" data-tok="' + s.k + '" value="' + readTok(s.k) + '"></span>' +
        '<div class="tokrow__l"><div class="tokrow__n">' + s.l + '</div><div class="tokrow__v">' + s.k + '</div></div></div>').join('') +
      '</div><div class="divider"></div>' +
      '<div class="field" style="margin-bottom:var(--s4)"><label class="field__lbl">Heading typeface</label>' +
      '<select class="in" data-tok="--font-display">' +
      ['"Source Serif 4",Georgia,serif', 'Georgia,"Times New Roman",serif', 'Inter,system-ui,sans-serif', '"Trebuchet MS",sans-serif']
        .map(f => '<option value="' + esc(f) + '">' + f.split(',')[0].replace(/"/g, '') + '</option>').join('') + '</select></div>' +
      '<div class="field"><label class="field__lbl">Corner rounding — <b id="radV">16</b>px</label>' +
      '<input class="in" type="range" min="0" max="26" value="16" data-tok="--r-lg" style="padding:0;height:auto"></div>' +
      '<div style="display:flex;gap:var(--s2);margin-top:var(--s5)">' +
      '<button class="btn btn--bronze" id="tokApply">Apply to the whole interface</button>' +
      '<button class="btn btn--ghost" id="tokReset">Reset</button></div>' +
      '</div></div>' +
      '<div class="panel anim" style="--d:80ms"><div class="panel__h"><div><h3>Live preview</h3><div class="lbl">A property card, exactly as a visitor sees it</div></div></div>' +
      '<div class="panel__b"><div class="preview" id="tokPrev">' +
      '<div class="preview__bar"><i></i><i></i><i></i><span>your-website.com/property/3-bhk-sushant-lok</span></div>' +
      '<div class="preview__b"><div class="prevcard"><span class="tag">Live</span>' +
      '<h4>3 BHK apartment in Sushant Lok II</h4>' +
      '<p>A west-facing corner unit on the ninth floor, with a covered parking for two cars and a park view.</p>' +
      '<div style="display:flex;align-items:baseline;gap:var(--s3);margin-bottom:var(--s4)">' +
      '<b class="dsp" style="font-size:24px">₹1,85,00,000</b><span class="mut" style="font-size:var(--fs-meta)">₹10,571 / sq ft</span></div>' +
      '<button class="btn">Enquire about this home</button></div></div></div></div>' +
      '</div></div>';
  },

  blocks: () => '<div class="panel anim" style="--d:0ms"><div class="panel__h"><div><h3>Page blocks</h3>' +
    '<div class="lbl">Drag to reorder what appears on a property page, and in what order</div></div>' +
    '<div class="panel__hr"><button class="btn btn--ghost btn--sm" id="blkReset">Reset to default</button></div></div>' +
    '<div class="panel__b"><div class="blocks" id="blkList"></div>' +
    '<div class="field__hint" style="margin-top:var(--s3)">A block with nothing to show is never drawn — so a project with no floor plan simply has no floor-plan section.</div>' +
    '</div></div>'
};

const BLOCKS = [
  { n: 'Header', d: 'Title, badges, locality, price, enquiry button' },
  { n: 'Gallery', d: 'Cover photograph, thumbnails, full-screen viewer' },
  { n: 'At a glance', d: 'The ten facts in a grid' },
  { n: 'About this project', d: 'The long description, folded to one screen' },
  { n: 'What stands out', d: 'Highlights as a scannable grid' },
  { n: 'Floor plans & brochures', d: 'Media cards for each attachment' },
  { n: 'Map & locality', d: 'Interactive map and nearby links' },
  { n: 'Homes in this project', d: 'Filterable list of properties' },
  { n: 'Share', d: 'WhatsApp, copy link, native share' },
  { n: 'Enquiry form', d: 'Inline form, answers in place' }
];

function readTok(k) {
  const v = getComputedStyle(document.documentElement).getPropertyValue(k).trim();
  if (/^#/.test(v)) return v;
  if (/rgb/.test(v)) {
    const m = v.match(/\d+/g);
    return '#' + m.slice(0, 3).map(x => ('0' + (+x).toString(16)).slice(-2)).join('');
  }
  return '#725b2f';
}

VIEWS.settings = {
  mount() {
    const body = $('#setBody');
    const paint = key => {
      body.innerHTML = SET[key]();
      body.style.animation = 'none'; void body.offsetWidth; body.style.animation = '';
      if (key === 'tokens') mountTokens();
      if (key === 'blocks') mountBlocks();
      $$('.tgl', body).forEach(t => t.addEventListener('click', () =>
        t.setAttribute('aria-checked', t.getAttribute('aria-checked') !== 'true')));
    };
    $$('#setnav .setnav__b').forEach(b => {
      if (b.dataset.done) return;
      b.dataset.done = '1';
      b.addEventListener('click', () => {
        $$('#setnav .setnav__b').forEach(x => x.classList.remove('is-on'));
        b.classList.add('is-on');
        paint(b.dataset.set);
      });
    });

    function mountTokens() {
      const prev = $('#tokPrev');
      $$('[data-tok]').forEach(inp => {
        const k = inp.dataset.tok;
        if (inp.type === 'color') inp.value = readTok(k);
        inp.addEventListener('input', () => {
          const v = k === '--r-lg' ? inp.value + 'px' : inp.value;
          prev.style.setProperty(k, v);
          if (k === '--r-lg') $('#radV').textContent = inp.value;
        });
      });
      $('#tokApply').addEventListener('click', () => {
        $$('[data-tok]').forEach(inp => {
          const k = inp.dataset.tok;
          document.documentElement.style.setProperty(k, k === '--r-lg' ? inp.value + 'px' : inp.value);
        });
        toast('Applied', 'The whole interface now uses these tokens', 'ok', { label: 'Undo', run: () => location.reload() });
      });
      $('#tokReset').addEventListener('click', () => {
        $$('[data-tok]').forEach(inp => { prev.style.removeProperty(inp.dataset.tok); document.documentElement.style.removeProperty(inp.dataset.tok); });
        toast('Reset', 'Back to the office default', 'info');
      });
    }

    function mountBlocks() {
      const host = $('#blkList');
      const draw = () => {
        host.innerHTML = BLOCKS.map((b, i) =>
          '<div class="block" data-b="' + i + '" style="animation:rise 300ms var(--e-out) both;animation-delay:' + (i * 35) + 'ms">' +
          '<span class="block__grip">' + ico('grip') + '</span>' +
          '<div class="block__b"><div class="block__n">' + esc(b.n) + '</div><div class="block__d">' + esc(b.d) + '</div></div>' +
          '<span class="mono mut">' + (i + 1) + '</span></div>').join('');
        $$('.block', host).forEach(el => {
          draggable({
            nodes: [el],
            ghostClass: 'is-ghost',
            hitTest: (x, y) => {
              const e2 = elementAt(x, y);
              return e2 ? e2.closest('.block') : null;
            },
            dropRect: t => { const r = t.getBoundingClientRect(); return { left: r.left, top: r.top }; },
            onEnd: (node, t) => {
              if (!t || t === node) return;
              const a = +node.dataset.b, b = +t.dataset.b;
              const it = BLOCKS.splice(a, 1)[0];
              BLOCKS.splice(b, 0, it);
              draw();
              toast('Reordered', it.n + ' is now ' + (b + 1) + ' on the page', 'ok');
            }
          });
        });
      };
      draw();
      $('#blkReset').addEventListener('click', () => {
        BLOCKS.length = 0;
        [['Header', 'Title, badges, locality, price, enquiry button'], ['Gallery', 'Cover photograph, thumbnails, full-screen viewer'],
        ['At a glance', 'The ten facts in a grid'], ['About this project', 'The long description, folded to one screen'],
        ['What stands out', 'Highlights as a scannable grid'], ['Floor plans & brochures', 'Media cards for each attachment'],
        ['Map & locality', 'Interactive map and nearby links'], ['Homes in this project', 'Filterable list of properties'],
        ['Share', 'WhatsApp, copy link, native share'], ['Enquiry form', 'Inline form, answers in place']]
          .forEach(x => BLOCKS.push({ n: x[0], d: x[1] }));
        draw(); toast('Reset to default', 'Page order restored', 'info');
      });
    }

    paint($('.setnav__b.is-on').dataset.set || 'office');
  }
};

/* ----------------------------------------------------------------- O · BIN */
VIEWS.bin = {
  mount() {
    const host = $('#binList');
    const state = {};
    const draw = () => {
      host.innerHTML = DATA.binRows.map((b, i) =>
        '<div class="wl__i" data-id="' + b.id + '" style="padding:var(--s3) var(--s4);border-bottom:1px solid var(--line);animation:rise 300ms var(--e-out) both;animation-delay:' + (i * 40) + 'ms">' +
        '<span class="cbrow"><i class="cb" data-bincb aria-checked="' + (!!state[b.id]) + '"></i></span>' +
        '<span class="tthumb" style="background:linear-gradient(140deg,' + b.tone + ',rgba(0,0,0,.18))">' + ico('home') + '</span>' +
        '<div class="wl__b"><div class="wl__t">' + esc(b.title) + '</div>' +
        '<div class="wl__m">' + esc(b.why) + ' · ' + esc(b.when) + '</div></div>' +
        '<b class="num" style="font-size:var(--fs-name)">' + short(b.price) + '</b>' +
        '<button class="iconbtn" data-b="restore" title="Restore">' + ico('restore') + '</button>' +
        '<button class="iconbtn is-danger" data-b="gone" title="Delete forever">' + ico('trash') + '</button>' +
        '</div>').join('') ||
        '<div class="empty">' + ico('trash') + '<h4>The bin is empty</h4><p>Anything you delete rests here before it goes for good.</p></div>';
      sync();
    };
    // Select-all lives outside the list and drives every row — and back.
    function sync() {
      const rows = $$('[data-bincb]', host);
      const on = rows.filter(r => r.getAttribute('aria-checked') === 'true').length;
      $('#binAll').setAttribute('aria-checked', on === 0 ? 'false' : on === rows.length ? 'true' : 'mixed');
      $('#binCount').textContent = DATA.binRows.length + ' items · deleted in the last 30 days are kept here';
      const bar = $('#bulkbar');
      bar.classList.toggle('is-on', on > 0);
      $('#bulkN').textContent = on + ' selected';
    }
    if (!host.dataset.done) {
      host.dataset.done = '1';
      host.addEventListener('click', e => {
        const cb = e.target.closest('[data-bincb]');
        if (cb) { state[cb.closest('[data-id]').dataset.id] = cb.getAttribute('aria-checked') !== 'true'; cb.setAttribute('aria-checked', cb.getAttribute('aria-checked') !== 'true'); sync(); return; }
        const b = e.target.closest('[data-b]');
        if (!b) return;
        const id = +b.closest('[data-id]').dataset.id;
        const row = b.closest('.wl__i');
        const item = DATA.binRows.find(x => x.id === id);
        row.style.transition = 'opacity 260ms,transform 260ms';
        row.style.opacity = '0'; row.style.transform = 'translateX(22px)';
        setTimeout(() => {
          DATA.binRows = DATA.binRows.filter(x => x.id !== id);
          delete state[id];
          draw();
        }, 260);
        toast(b.dataset.b === 'restore' ? 'Restored' : 'Deleted forever',
          item.title, b.dataset.b === 'restore' ? 'ok' : 'err',
          b.dataset.b === 'restore' ? null : { label: 'Undo', run: () => { DATA.binRows.push(item); draw(); toast('Restored', item.title, 'ok'); } });
      });
      $('#binAllWrap').addEventListener('click', () => {
        const on = $('#binAll').getAttribute('aria-checked') !== 'true';
        DATA.binRows.forEach(b => state[b.id] = on);
        $('#binAll').setAttribute('aria-checked', on ? 'true' : 'false');
        $$('[data-bincb]', host).forEach(cb => cb.setAttribute('aria-checked', on ? 'true' : 'false'));
        sync();
      });
      $('#bulkX').addEventListener('click', () => {
        DATA.binRows.forEach(b => state[b.id] = false);
        $$('[data-bincb]', host).forEach(cb => cb.setAttribute('aria-checked', 'false'));
        $('#binAll').setAttribute('aria-checked', 'false');
        $('#bulkbar').classList.remove('is-on');
      });
      $$('.bulkbar .btn')[0].addEventListener('click', () => {
        const n = DATA.binRows.filter(b => state[b.id]).length;
        if (!n) return;
        DATA.binRows = DATA.binRows.filter(b => !state[b.id]);
        draw(); $('#bulkbar').classList.remove('is-on');
        toast('Restored', n + (n === 1 ? ' property' : ' properties'), 'ok');
      });
      $$('.bulkbar .btn')[1].addEventListener('click', () => {
        const n = DATA.binRows.filter(b => state[b.id]).length;
        if (!n) return;
        const gone = DATA.binRows.filter(b => state[b.id]);
        DATA.binRows = DATA.binRows.filter(b => !state[b.id]);
        draw(); $('#bulkbar').classList.remove('is-on');
        toast('Deleted forever', n + (n === 1 ? ' property' : ' properties'), 'err',
          { label: 'Undo', run: () => { gone.forEach(g => DATA.binRows.push(g)); draw(); toast('Restored', n + ' properties', 'ok'); } });
      });
      $('#binEmpty').addEventListener('click', () => {
        if (!DATA.binRows.length) return toast('Nothing to empty', 'The bin is already empty', 'info');
        const gone = DATA.binRows.slice();
        DATA.binRows = []; draw();
        toast('Bin emptied', gone.length + ' properties deleted for good', 'err',
          { label: 'Undo', run: () => { DATA.binRows = gone; draw(); toast('Restored', gone.length + ' properties', 'ok'); } });
      });
    }
    draw();
  }
};

/* ==========================================================================
   Boot
   ========================================================================== */
$('#railToggle').addEventListener('click', () => {
  $('#app').classList.toggle('rail-collapsed');
});

// Drop zones that are not owned by a screen (prevents the browser navigating
// away when a file misses the target).
['dragover', 'drop'].forEach(ev => window.addEventListener(ev, e => {
  if (e.target.closest('[data-dropzone]')) return;
  e.preventDefault();
}));

const start = location.hash.replace('#', '');
Router.go(SCREENS[start] ? start : 'today', { force: true });
setTimeout(() => toast('Welcome back, Ravi', 'Six things need you today', 'info'), 900);
