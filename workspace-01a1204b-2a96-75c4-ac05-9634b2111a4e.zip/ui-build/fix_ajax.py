#!/usr/bin/env python3
"""Project drawer: cover photo + gallery.
Lead / Visit drawers: a real create form instead of a 404.
Save: allow the new fields, and handle lead + visit."""
import sys
BASE = '/home/user/plugin/estat-os/'
P = 'includes/Admin/Os/Ajax.php'
s = open(BASE + P).read()

def sub(label, old, new):
    global s
    if old not in s:
        print('  !! MISSING: ' + label); sys.exit(1)
    s = s.replace(old, new, 1)
    print('  ok  ' + label)

# ------------------------------------------------- 1. cover photo field ----
sub('project cover field',
"""			esc_attr__( 'For example: Trehan Iris Broadway', 'estat-os' )
		);
""",
"""			esc_attr__( 'For example: Trehan Iris Broadway', 'estat-os' )
		);

		/*
		 * The cover photograph.
		 *
		 * A project without one is a grey card in a row of grey cards, so
		 * the picker sits directly under the name rather than at the
		 * bottom where nobody reaches it.
		 */
		$cover_id  = $post ? (int) get_post_thumbnail_id( $id ) : 0;
		$cover_url = $cover_id ? (string) get_the_post_thumbnail_url( $id, 'medium' ) : '';

		echo '<div class="field"><label class="field__lbl" for="pf-cover">'
			. esc_html__( 'Cover photo', 'estat-os' ) . '</label><div class="pickrow">';
		printf(
			'<span class="pickprev%1$s" data-cover-prev%2$s></span>',
			$cover_url ? ' is-on' : '',
			$cover_url ? ' style="background-image:url(' . esc_url( $cover_url ) . ')"' : ''
		);
		printf( '<input type="hidden" id="pf-cover" name="cover_id" value="%1$d">', $cover_id );
		echo '<span class="pickrow__b">'
			. '<button type="button" class="btn btn--sm" data-pick="cover" data-target="cover_id" data-multiple="0">'
			. esc_html__( 'Choose photo', 'estat-os' ) . '</button>'
			. '<button type="button" class="btn btn--sm btn--ghost" data-clear-pick data-target="cover_id">'
			. esc_html__( 'Remove', 'estat-os' ) . '</button></span></div>';
		echo '<p class="mut" style="margin:6px 0 0">'
			. esc_html__( 'The photograph at the top of the project page, and the one on its card.', 'estat-os' )
			. '</p></div>';
""")

# ---------------------------------------------------- 2. gallery field ----
sub('project gallery field',
"""		printf(
			'<div class="field"><label class="field__lbl" for="pf-desc">%1$s</label>'
			. '<textarea class="in" id="pf-desc" name="description" rows="5" style="min-height:110px">%2$s</textarea></div>',
			esc_html__( 'What should be said about it', 'estat-os' ),
			esc_textarea( $post ? (string) $post->post_content : '' )
		);

		echo '</div>';
""",
"""		printf(
			'<div class="field"><label class="field__lbl" for="pf-desc">%1$s</label>'
			. '<textarea class="in" id="pf-desc" name="description" rows="5" style="min-height:110px">%2$s</textarea></div>',
			esc_html__( 'What should be said about it', 'estat-os' ),
			esc_textarea( $post ? (string) $post->post_content : '' )
		);

		/*
		 * The gallery.
		 *
		 * The same photographs the website shows, picked from the media
		 * library the office already keeps them in — not a second upload
		 * area with its own copies.
		 */
		$raw = $id > 0 ? get_post_meta( $id, '_estat_gallery', true ) : '';
		$raw = is_array( $raw ) ? $raw : explode( ',', (string) $raw );
		$gal = array_values( array_unique( array_filter( array_map( 'absint', (array) $raw ) ) ) );

		$tiles = '';
		foreach ( $gal as $aid ) {
			$thumb = (string) wp_get_attachment_image_url( $aid, 'thumbnail' );
			if ( '' === $thumb ) {
				continue;
			}
			$tiles .= '<span class="picktile" data-tile="' . (int) $aid . '" style="background-image:url(' . esc_url( $thumb ) . ')">'
				. '<button type="button" class="picktile__x" data-rm-pick="' . (int) $aid . '" data-target="gallery" aria-label="'
				. esc_attr__( 'Remove this photo', 'estat-os' ) . '">&times;</button></span>';
		}

		echo '<div class="field"><label class="field__lbl">' . esc_html__( 'Photo gallery', 'estat-os' ) . '</label>';
		printf( '<input type="hidden" name="gallery" value="%1$s">', esc_attr( implode( ',', $gal ) ) );
		printf( '<div class="pickgrid" data-gal-grid data-target="gallery">%1$s</div>', $tiles );
		echo '<button type="button" class="btn btn--sm" data-pick="gallery" data-target="gallery" data-multiple="1">'
			. esc_html__( 'Add photos', 'estat-os' ) . '</button></div>';

		echo '</div>';
""")

# ------------------------------------------- 3. lead drawer: create form ----
sub('lead drawer new',
"""		$lead = Leads::get( $id );
		if ( ! $lead ) {
			wp_send_json_error( array( 'message' => __( 'That enquiry is no longer here.', 'estat-os' ) ), 404 );
		}

		ob_start();
		echo '<div class="dr__b">';
		foreach ( array(
			'name'    => __( 'Name', 'estat-os' ),""",
"""		$lead = $id > 0 ? Leads::get( $id ) : null;
		if ( $id > 0 && ! $lead ) {
			wp_send_json_error( array( 'message' => __( 'That enquiry is no longer here.', 'estat-os' ) ), 404 );
		}

		if ( 0 === $id ) {
			return self::drawer_lead_new();
		}

		ob_start();
		echo '<div class="dr__b">';
		foreach ( array(
			'name'    => __( 'Name', 'estat-os' ),""")

# ------------------------------------------ 4. visit drawer: create form ----
sub('visit drawer new',
"""		$visit = method_exists( Visits::class, 'get' ) ? Visits::get( $id ) : null;
		if ( ! $visit ) {
			wp_send_json_error( array( 'message' => __( 'That visit is no longer here.', 'estat-os' ) ), 404 );
		}
""",
"""		$visit = $id > 0 && method_exists( Visits::class, 'get' ) ? Visits::get( $id ) : null;
		if ( $id > 0 && ! $visit ) {
			wp_send_json_error( array( 'message' => __( 'That visit is no longer here.', 'estat-os' ) ), 404 );
		}

		if ( 0 === $id ) {
			return self::drawer_visit_new();
		}
""")

# --------------------------------------------- 5. project save allow-list ---
sub('project save fields',
"""				'possession_date',
				'address',
				'locality',
			) as $key ) {
				if ( isset( $input[ $key ] ) ) {
					$clean[ $key ] = is_array( $input[ $key ] ) ? $input[ $key ] : sanitize_text_field( (string) $input[ $key ] );
				}
			}

			$saved = Projects::save( $clean, $id );""",
"""				'possession_date',
				'address',
				'locality',
				'category',
				'unit_types',
				'highlights',
				'gallery',
				'cover_id',
			) as $key ) {
				if ( isset( $input[ $key ] ) ) {
					$clean[ $key ] = is_array( $input[ $key ] ) ? $input[ $key ] : sanitize_text_field( (string) $input[ $key ] );
				}
			}

			$saved = Projects::save( $clean, $id );""")

# ------------------------------------------------ 6. lead + visit saves ----
sub('lead + visit save branches',
"""		if ( 'agent' === $what ) {
			self::need( 'estat_manage_team' );""",
"""		if ( 'lead' === $what ) {
			self::need( 'estat_manage_leads' );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$id    = isset( $_POST['id'] ) ? absint( wp_unslash( $_POST['id'] ) ) : 0;
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$input = isset( $_POST['fields'] ) ? (array) wp_unslash( $_POST['fields'] ) : array();

			$clean = array();
			foreach ( array( 'name', 'phone', 'email', 'message', 'status', 'source' ) as $key ) {
				if ( isset( $input[ $key ] ) ) {
					$clean[ $key ] = sanitize_text_field( (string) $input[ $key ] );
				}
			}

			if ( $id > 0 ) {
				$ok = Leads::update( $id, $clean );
				if ( is_wp_error( $ok ) ) {
					wp_send_json_error( array( 'message' => $ok->get_error_message() ), 422 );
				}
				wp_send_json_success( array( 'done' => true, 'id' => $id, 'say' => __( 'Enquiry saved', 'estat-os' ) ) );
			}

			$clean['source'] = $clean['source'] ?? 'office';
			$new             = Leads::create( $clean );
			if ( is_wp_error( $new ) ) {
				wp_send_json_error( array( 'message' => $new->get_error_message() ), 422 );
			}
			wp_send_json_success( array( 'done' => true, 'id' => (int) $new, 'say' => __( 'Enquiry added', 'estat-os' ) ) );
		}

		if ( 'visit' === $what ) {
			self::need( 'estat_manage_visits' );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$input  = isset( $_POST['fields'] ) ? (array) wp_unslash( $_POST['fields'] ) : array();
			$when_s = sanitize_text_field( (string) ( $input['scheduled_at'] ?? '' ) );

			$clean = array(
				'lead_id'      => absint( $input['lead_id'] ?? 0 ),
				'listing_id'   => absint( $input['listing_id'] ?? 0 ),
				'agent_id'     => absint( $input['agent_id'] ?? 0 ),
				'scheduled_at' => $when_s,
			);

			$new = Visits::schedule( $clean );
			if ( is_wp_error( $new ) ) {
				wp_send_json_error( array( 'message' => $new->get_error_message() ), 422 );
			}
			wp_send_json_success( array( 'done' => true, 'id' => (int) $new, 'say' => __( 'Visit booked', 'estat-os' ) ) );
		}

		if ( 'agent' === $what ) {
			self::need( 'estat_manage_team' );""")

# --------------------------------------- 7. the two new drawer builders ----
sub('new drawer builders',
"""	/**
	 * An enquiry, in full.
	 *
	 * @param int $id Lead.
	 * @return array<string,string>
	 */""",
"""	/**
	 * A blank enquiry sheet — what the Add button on Enquiries opens.
	 *
	 * @return array<string,string>
	 */
	private static function drawer_lead_new(): array {
		ob_start();
		echo '<div class="dr__b">';
		printf(
			'<p class="mut" style="margin:0 0 var(--s4)">%1$s</p>',
			esc_html__( 'An enquiry somebody made by phone, at the desk, or on the website. Name and one way to reach them is enough.', 'estat-os' )
		);

		printf(
			'<div class="field"><label class="field__lbl" for="lf-name">%1$s</label>'
			. '<input class="in" id="lf-name" name="name" value="" placeholder="%2$s"></div>',
			esc_html__( 'Name', 'estat-os' ),
			esc_attr__( 'Who is it', 'estat-os' )
		);

		echo '<div class="fb__row">';
		printf(
			'<div class="field"><label class="field__lbl" for="lf-phone">%1$s</label>'
			. '<input class="in" id="lf-phone" name="phone" inputmode="tel" value="" placeholder="%2$s"></div>',
			esc_html__( 'Phone', 'estat-os' ),
			esc_attr__( '+91 98765 43210', 'estat-os' )
		);
		printf(
			'<div class="field"><label class="field__lbl" for="lf-email">%1$s</label>'
			. '<input class="in" id="lf-email" name="email" type="email" value="" placeholder="%2$s"></div>',
			esc_html__( 'Email', 'estat-os' ),
			esc_attr__( 'name@example.com', 'estat-os' )
		);
		echo '</div>';

		printf(
			'<div class="field"><label class="field__lbl" for="lf-msg">%1$s</label>'
			. '<textarea class="in" id="lf-msg" name="message" rows="3" style="min-height:80px" placeholder="%2$s"></textarea></div>',
			esc_html__( 'What they are after', 'estat-os' ),
			esc_attr__( '3 BHK in Sector 57, ready to move', 'estat-os' )
		);

		printf( '<input type="hidden" name="status" value="%1$s">', esc_attr( 'new' ) );
		printf( '<input type="hidden" name="source" value="%1$s">', esc_attr( 'office' ) );
		echo '</div>';

		return array(
			'title' => __( 'New enquiry', 'estat-os' ),
			'html'  => (string) ob_get_clean(),
			'foot'  => '<button type="button" class="btn btn--ghost" data-act="close-drawer">' . esc_html__( 'Cancel', 'estat-os' ) . '</button>'
				. '<button type="button" class="btn btn--bronze" data-act="save-lead" data-id="0">' . esc_html__( 'Add the enquiry', 'estat-os' ) . '</button>',
		);
	}

	/**
	 * A blank visit sheet — what the Add button on Visits opens.
	 *
	 * @return array<string,string>
	 */
	private static function drawer_visit_new(): array {
		$leads = Leads::query( array( 'per_page' => 60, 'page' => 1 ) );
		$opts  = '<option value="0">' . esc_html__( 'Nobody in particular', 'estat-os' ) . '</option>';
		foreach ( (array) ( $leads['items'] ?? array() ) as $lead ) {
			$name = trim( (string) ( $lead['name'] ?? '' ) );
			if ( '' === $name ) {
				continue;
			}
			$phone = trim( (string) ( $lead['phone'] ?? '' ) );
			$opts .= '<option value="' . (int) $lead['id'] . '">' . esc_html( $name . ( '' !== $phone ? ' · ' . $phone : '' ) ) . '</option>';
		}

		$homes = '<option value="0">' . esc_html__( 'No property named', 'estat-os' ) . '</option>';
		$found = get_posts(
			array(
				'post_type'      => PostTypes::LISTING,
				'post_status'    => array( 'publish', 'draft', 'pending' ),
				'posts_per_page' => 60,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);
		foreach ( (array) $found as $home ) {
			$homes .= '<option value="' . (int) $home->ID . '">' . esc_html( (string) $home->post_title ) . '</option>';
		}

		$soon = gmdate( 'Y-m-d H:i', time() + 2 * HOUR_IN_SECONDS );

		ob_start();
		echo '<div class="dr__b">';
		printf(
			'<p class="mut" style="margin:0 0 var(--s4)">%1$s</p>',
			esc_html__( 'Book a visit. Pick who is coming and where, then say when.', 'estat-os' )
		);

		echo '<div class="field"><label class="field__lbl" for="vf-lead">' . esc_html__( 'Who is coming', 'estat-os' ) . '</label>'
			. '<select class="in" id="vf-lead" name="lead_id">' . $opts . '</select></div>';

		echo '<div class="field"><label class="field__lbl" for="vf-home">' . esc_html__( 'Which property', 'estat-os' ) . '</label>'
			. '<select class="in" id="vf-home" name="listing_id">' . $homes . '</select></div>';

		printf(
			'<div class="field"><label class="field__lbl" for="vf-when">%1$s</label>'
			. '<input class="in" id="vf-when" name="scheduled_at" type="datetime-local" value="%2$s"></div>',
			esc_html__( 'Date and time', 'estat-os' ),
			esc_attr( $soon )
		);
		echo '</div>';

		return array(
			'title' => __( 'Schedule a visit', 'estat-os' ),
			'html'  => (string) ob_get_clean(),
			'foot'  => '<button type="button" class="btn btn--ghost" data-act="close-drawer">' . esc_html__( 'Cancel', 'estat-os' ) . '</button>'
				. '<button type="button" class="btn btn--bronze" data-act="save-visit" data-id="0">' . esc_html__( 'Book the visit', 'estat-os' ) . '</button>',
		);
	}

	/**
	 * An enquiry, in full.
	 *
	 * @param int $id Lead.
	 * @return array<string,string>
	 */""")

open(BASE + P, 'w').write(s)
print('Ajax.php patched,', len(s), 'bytes')
