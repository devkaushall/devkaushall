#!/usr/bin/env python3
"""Favourites & Compare, in the pocket (the field agent's phone).

An agent standing in front of a client needs three things: a way to keep the
four homes that client liked, a way to look at them together, and a way to
say which of them is the better buy. This is that, and nothing else.
"""
import sys
BASE = '/home/user/plugin/estat-os/'

def patch(path, pairs):
    s = open(BASE + path).read()
    for label, old, new in pairs:
        if old not in s:
            print('  !! MISSING: ' + label); sys.exit(1)
        s = s.replace(old, new, 1); print('  ok  ' + path + ' :: ' + label)
    open(BASE + path, 'w').write(s)

# --------------------------------------------------------- 1. views ------
patch('includes/Pocket/Pocket.php', [
    ('views',
     """			'search'    => 'search',""",
     """			'search'    => 'search',
			// Pocket 4.1.3 — the client's shortlist, and two of them side by
			// side. A favourite is not a second copy of a property: it is a
			// note the agent keeps for themselves.
			'favourites' => 'favourites',
			'compare'    => 'compare',"""),
    ('fav helpers',
     """	public static function my_records( string $search = '', string $kind = '' ): array {""",
     """	/**
	 * The properties this person has put a star on, newest last.
	 *
	 * Kept on the person, not on the property: two agents disagreeing about
	 * a flat must not overwrite each other. Sixty is the ceiling — a list
	 * longer than that stops being a shortlist.
	 *
	 * @return int[]
	 */
	public static function favs(): array {
		$raw = get_user_meta( get_current_user_id(), '_estat_favs', true );
		$raw = is_array( $raw ) ? $raw : explode( ',', (string) $raw );

		return array_values( array_unique( array_filter( array_map( 'absint', (array) $raw ) ) ) );
	}

	/**
	 * Is this one of them?
	 *
	 * @param int $id Record.
	 * @return bool
	 */
	public static function is_fav( int $id ): bool {
		return in_array( $id, self::favs(), true );
	}

	/**
	 * Star it, or take the star off. Answers what it did.
	 *
	 * @param int $id Record.
	 * @return bool True when it is now starred.
	 */
	public static function toggle_fav( int $id ): bool {
		$favs = self::favs();
		$at   = array_search( $id, $favs, true );

		if ( false !== $at ) {
			unset( $favs[ $at ] );
			$on = false;
		} else {
			$favs[] = $id;
			$on     = true;
		}

		update_user_meta( get_current_user_id(), '_estat_favs', array_slice( array_values( $favs ), -60 ) );

		return $on;
	}

	/**
	 * The records behind the stars, in the order they were starred, minus
	 * anything this person may no longer look at (a bin, a listing that was
	 * moved to another agent).
	 *
	 * @param int $limit How many to bring back.
	 * @return \\WP_Post[]
	 */
	public static function fav_posts( int $limit = 4 ): array {
		$ids = self::favs();
		if ( ! $ids ) {
			return array();
		}

		$posts = get_posts(
			array(
				'post_type'      => array( 'estat_listing', 'estat_project' ),
				'post__in'       => $ids,
				'orderby'        => 'post__in',
				'posts_per_page' => max( 1, $limit ),
				'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
			)
		);

		return array_values(
			array_filter(
				$posts,
				static function ( $post ) {
					return $post instanceof \\WP_Post && self::can_see( $post );
				}
			)
		);
	}

	public static function my_records( string $search = '', string $kind = '' ): array {"""),
])

# -------------------------------------------------------- 2. actions -----
patch('includes/Pocket/Actions.php', [
    ('actions list',
     """		'owner_update',
	);""",
     """		'owner_update',
		// 4.1.3 — the star on a property row, and clearing the whole list.
		'toggle_fav',
		'fav_clear',
	);"""),
    ('action cases',
     """			case 'visit_checks':""",
     """			case 'toggle_fav':
				self::toggle_fav();
				break;
			case 'fav_clear':
				self::fav_clear();
				break;
			case 'visit_checks':"""),
    ('action bodies',
     """	/**
	 * Send a draft to the office.""",
     """	/**
	 * The star on a property row.
	 *
	 * The property itself is not touched: the star is the agent's own note,
	 * so it needs the right to read the record and nothing more.
	 *
	 * @return void
	 */
	private static function toggle_fav(): void {
		$id   = self::int_post( 'record' );
		$post = $id > 0 ? get_post( $id ) : null;

		if ( ! $post || ! Pocket::can_see( $post ) ) {
			Pocket::fail_to_today( 'nope' );
		}

		$on = Pocket::toggle_fav( $id );

		Pocket::redirect( self::$view, self::$id, $on ? 'starred' : 'unstarred' );
	}

	/**
	 * "Nothing in here." — the whole shortlist, gone in one press.
	 *
	 * @return void
	 */
	private static function fav_clear(): void {
		update_user_meta( get_current_user_id(), '_estat_favs', array() );
		Pocket::redirect( 'favourites', 0, 'cleared' );
	}

	/**
	 * Send a draft to the office."""),
])

print('pocket + actions done')
