#!/usr/bin/env python3
"""Rewrite the Agent Pocket preview so its shell and its Today screen match
the three approved designs: desktop rail + two columns, tablet two columns +
five doors, phone one column + five doors."""
import re

P = '/home/user/build_pocket_preview.py'
src = open(P).read()

# ---------------------------------------------------------------- chrome ---
NEW_CHROME_TOP = '''NAV = [('today', 'home', 'Today'),
       ('leads', 'inbox', 'Leads'),
       ('listings', 'buildings', 'Properties'),
       ('visits', 'calendar', 'Visits')]

AGENT_NAME = 'Dev Kumar'
AGENT_INIT = 'DK'
AGENT_ROLE = 'Field Agent'
PLACE = 'Gurugram, Haryana'


def tab_link(slug, icon, label, door):
    on = ' is-on' if door == slug else ''
    return (f'<a class="estat-pocket-tab{on}" href="#" data-go="{slug}">'
            f'{ico(icon, 22)}<span>{label}</span></a>')


def add_door(door, cls):
    on = ' is-on' if door == 'capture' else ''
    return (f'<a class="{cls} estat-pocket-door estat-pocket-door--add{on}" href="#" '
            f'data-go="capture" aria-label="Add something new">'
            f'{ico("plus", 24)}<span>Add</span></a>')


def doors(door, add_cls):
    """The same five doors, in the same order, wherever they are placed."""
    split = len(NAV) // 2
    out = ''.join(tab_link(s, i, l, door) for s, i, l in NAV[:split])
    out += add_door(door, add_cls)
    out += ''.join(tab_link(s, i, l, door) for s, i, l in NAV[split:])
    return out


def topnav(door):
    """Across the top — kept for the tablet, where the brand needs room."""
    return ('<nav class="estat-pocket-topnav" aria-label="Sections">'
            + doors(door, 'estat-pocket-tab') + '</nav>')


TITLES = {'today': 'Today', 'leads': 'Leads', 'listings': 'My listings',
          'projects': 'Societies & projects',
          'visits': 'Site visits', 'listing': 'Listing', 'capture': 'Add something',
          'more': 'More', 'you': 'You', 'queue': 'Waiting to go up', 'login': 'Sign in'}


def tabs(door):
    """Along the bottom, for a phone and a tablet."""
    return ('<nav class="estat-pocket-tabs" aria-label="Sections">'
            + doors(door, 'estat-pocket-capture') + '</nav>')


# The desktop rail: the five doors first, then the two quieter places, with
# Add sitting where it sits on the bar — between Leads and Properties.
RAIL_BEFORE = [('today', 'home', 'Today'),
               ('leads', 'inbox', 'Leads')]
RAIL_AFTER = [('listings', 'buildings', 'Properties'),
              ('visits', 'calendar', 'Visits'),
              ('projects', 'compass', 'Societies & projects'),
              ('you', 'person', 'Your details')]


def sidebar(door):
    rows = ''.join(tab_link(s, i, l, door) for s, i, l in RAIL_BEFORE)
    on = ' is-on' if door == 'capture' else ''
    rows += (f'<a class="estat-pocket-tab estat-pocket-door estat-pocket-door--add{on}" href="#" '
             f'data-go="capture">{ico("plus", 18)}<span>Add</span></a>')
    rows += ''.join(tab_link(s, i, l, door) for s, i, l in RAIL_AFTER)
    return f"""<aside class="estat-pocket-sidebar" aria-label="Navigation">
      <a class="estat-pocket-sidebar-brand" href="#" data-go="today">MAYFAIR<small>PROPERTIES</small></a>
      <nav class="estat-pocket-sidebar-nav" aria-label="Sections">{rows}</nav>
      <div class="estat-pocket-sidebar-foot">
        <a class="estat-pocket-out" href="#" data-do="Signed out (preview only)">{ico("lock", 16)}
          <span class="estat-pocket-out-word">Sign out</span></a>
        <div class="estat-pocket-hint" style="margin:0">/agent</div>
      </div>
    </aside>"""


def head(door):
    """One bar for every size: the name, a search box, and the person."""
    return f"""<header class="estat-pocket-head">
    <a class="estat-pocket-brand" href="#" data-go="today">
      <span class="estat-pocket-brandmark">M</span>
      <span class="estat-pocket-brandtext"><span>MAYFAIR</span><i>PROPERTIES</i></span>
    </a>
    <form class="estat-pocket-search" method="get" action="#" role="search">
      {ico("search", 18)}<input class="estat-pocket-input" type="search" name="q" value=""
      placeholder="Search leads, properties, clients..." enterkeyhint="search">
    </form>
    <div class="estat-pocket-headend">
      <a class="estat-pocket-bell" href="#" data-do="Nothing new to tell you" aria-label="Notifications">{ico("bell", 18)}</a>
      <span class="estat-pocket-user">
        <span class="estat-pocket-avatar">{AGENT_INIT}</span>
        <span class="estat-pocket-usernames"><b>{AGENT_NAME}</b><i>{AGENT_ROLE}</i></span>
      </span>
    </div>
  </header>"""


def search_bar():
    return (f'<form class="estat-pocket-search" method="get" action="#" role="search">'
            f'{ico("search", 18)}<input type="search" name="q" value="" '
            f'placeholder="Search a client, a property, a visit" enterkeyhint="search"></form>')


# ---------------------------------------------------------------- screens --
'''

start = src.index('NAV = [')
end = src.index('def screen_today():')
src = src[:start] + NEW_CHROME_TOP + src[end:]

# ------------------------------------------------------------ today screen --
NEW_TODAY = '''def stat(icon, number, word, go):
    return (f'<a class="estat-pocket-stat" href="#" data-go="{go}">{ico(icon, 18)}'
            f'<span class="estat-pocket-statnum"><b>{number}</b><i>{word}</i></span></a>')


def block(title, link, go, body):
    return (f'<section class="estat-pocket-block"><div class="estat-pocket-blockhead">'
            f'<h3>{title}</h3><a class="estat-pocket-blocklink" href="#" data-go="{go}">{link}</a>'
            f'</div>{body}</section>')


def taskrow(icon, when, title, detail, go):
    clock = f'<span class="estat-pocket-taskrowtime">{when}</span>' if when else ''
    return (f'<a class="estat-pocket-taskrow" href="#" data-go="{go}">'
            f'<span class="estat-pocket-well">{ico(icon, 16)}</span>{clock}'
            f'<span class="estat-pocket-taskrowtext"><b>{title}</b><i>{detail}</i></span></a>')


def visitrow(when, name, project, pill, tone):
    return (f'<a class="estat-pocket-visitrow" href="#" data-go="visits">'
            f'<span class="estat-pocket-visitwhen">{when}</span>'
            f'<span class="estat-pocket-taskrowtext"><b>{name}</b><i>{project}</i></span>'
            f'<span class="estat-pocket-pill {tone}">{pill}</span></a>')


def propcard(name, place, unit, price, pill, tone):
    tag = f'<span class="estat-pocket-pill {tone}">{pill}</span>' if pill else ''
    return (f'<a class="estat-pocket-prop" href="#" data-go="listing">'
            f'<span class="estat-pocket-propmedia">{ico("image", 22)}</span>'
            f'<span class="estat-pocket-taskrowtext"><b>{name}</b>'
            f'<span class="estat-pocket-propfacts"><span>{ico("map-pin", 12)} {place}</span>'
            f'<span>{ico("bed", 12)} {unit}</span></span></span>'
            f'<span class="estat-pocket-propprice"><b>{price}</b>{tag}</span></a>')


def screen_today():
    """Today, laid out the way the approved design shows it."""
    stats = ''.join(stat(*s) for s in [
        ('inbox', 12, 'New enquiries', 'leads'),
        ('phone', 8, 'Follow-ups due', 'leads'),
        ('calendar', 3, 'Site visit today', 'visits'),
        ('buildings', 24, 'Your properties', 'listings'),
        ('clock', 5, 'Waiting for approval', 'queue')])

    nxt = f"""<section class="estat-pocket-next">
      <div class="estat-pocket-nexttop">
        <span class="estat-pocket-well is-initial"><b>RS</b></span>
        <span class="estat-pocket-nexttext"><b>Rahul Sharma</b>
          <i>Looking for 3 BHK in Sector 57</i></span>
        <span class="estat-pocket-pill is-accent">New enquiry</span>
      </div>
      <div class="estat-pocket-nextmeta">
        <span>{ico("phone", 14)} +91 98765 43210</span>
        <span>{ico("map-pin", 14)} Sector 57, Gurugram</span>
      </div>
      <div class="estat-pocket-nextacts">
        <a class="estat-pocket-btn is-go" href="#" data-do="Calling Rahul Sharma (preview)">{ico("phone", 14)} Call now</a>
        <a class="estat-pocket-btn" href="#" data-go="leads">View details</a>
      </div>
    </section>"""

    quick = ''.join(
        f'<a class="estat-pocket-quickbtn" href="#" {how}="{to}">{ico(ic, 18)}<span>{word}</span></a>'
        for ic, word, how, to in [
            ('plus', 'Add property', 'data-go', 'capture'),
            ('inbox', 'Add enquiry', 'data-go', 'capture-lead'),
            ('camera', 'Take photos &amp; details', 'data-do', 'Camera opened (preview)'),
            ('person', 'New client enquiry', 'data-go', 'capture-lead'),
            ('calendar', 'Book visit', 'data-go', 'visits'),
            ('list-checks', 'Add preference', 'data-do', 'Preferences opened (preview)'),
            ('clock', 'Schedule site visit', 'data-go', 'visits'),
            ('form', 'Client requirements', 'data-do', 'Requirements opened (preview)')])
    quick = f'<div class="estat-pocket-quick">{quick}</div>'

    tasks = ''.join(taskrow(*t) for t in [
        ('phone', '11:00 AM', 'Follow up with Priya Singh', '2 BHK in Sector 56', 'leads'),
        ('map-pin', '3:00 PM', 'Site visit with Amit Verma', 'Mayfair Residency', 'visits'),
        ('camera', '', 'Add photos for property', 'DLF Phase 5', 'listings'),
        ('phone', '4:00 PM', 'Call Neha Gupta', 'Independent house in Sector 46', 'leads')])

    visits = ''.join(visitrow(*v) for v in [
        ('10:30 AM', 'Amit Verma', 'Mayfair Residency', 'Confirmed', 'is-good'),
        ('1:00 PM', 'Neha Gupta', 'DLF Phase 4', 'Reschedule', 'is-warn'),
        ('3:30 PM', 'Rajesh Mehta', 'Golf View Apartments', 'Pending', 'is-quiet')])

    props = ''.join(propcard(*p) for p in [
        ('Mayfair Residency', 'Sector 57', '3 BHK', '&#8377;1.8 Cr', '', ''),
        ('DLF Phase 5', 'Sector 53', '4 BHK', '&#8377;2.4 Cr', 'Pending', 'is-warn'),
        ('Ardee City Villa', 'Sector 52', '5 BHK', '&#8377;4.5 Cr', 'Draft', 'is-quiet')])

    lead = (f'<p class="estat-pocket-greet">Good morning, Dev</p>'
            f'<p class="estat-pocket-daymeta"><span>{ico("calendar", 14)} Tue, 7 Oct 2026</span>'
            f'<span>{ico("map-pin", 14)} {PLACE}</span></p>'
            f'<p class="estat-pocket-daylead">Here is your work for today</p>')

    left = (lead
            + f'<div class="estat-pocket-stats">{stats}</div>'
            + nxt
            + block('Quick actions', '', 'capture', quick)
            + block("Today's tasks", 'View all', 'today', tasks))

    right = (block("Today's visits", 'See all', 'visits', visits)
             + block('Your recent properties', 'See all', 'listings', props))

    return (f'<div class="estat-pocket-day"><div class="estat-pocket-daymain">{left}</div>'
            f'<div class="estat-pocket-dayaside">{right}</div></div>')


'''

s = src.index('def screen_today():')
e = src.index('def lead_card(')
src = src[:s] + NEW_TODAY + src[e:]

# ------------------------------------------------- a real Societies screen --
src = src.replace(
    "def screen_listing():",
    '''def screen_projects():
    """The same list, with the Societies & projects chip picked."""
    body = screen_listings()
    body = body.replace('<a class="is-on" href="#" data-do="Showing properties">Properties</a>',
                        '<a href="#" data-do="Showing properties">Properties</a>')
    body = body.replace('<a href="#" data-do="Showing societies &amp; projects">Societies &amp; Projects</a>',
                        '<a class="is-on" href="#" data-do="Showing societies &amp; projects">Societies &amp; Projects</a>')
    return body.replace('My listings', 'Societies &amp; projects')


def screen_listing():''', 1)

# ------------------------------------------------------------- screen list --
src = src.replace(
    "SCREENS = [('today', screen_today), ('leads', screen_leads), ('visits', screen_visits),\n"
    "           ('listings', screen_listings), ('listing', screen_listing),",
    "SCREENS = [('today', screen_today), ('leads', screen_leads), ('visits', screen_visits),\n"
    "           ('listings', screen_listings), ('projects', screen_projects), ('listing', screen_listing),", 1)

src = src.replace(
    "DOORS = {'today': 'today', 'leads': 'leads', 'visits': 'visits', 'listings': 'listings',\n"
    "         'listing': 'listings', 'capture': 'capture', 'capture-lead': 'capture',\n"
    "         'search': '', 'more': 'more', 'you': 'more',\n"
    "         'queue': 'more', 'login': 'today'}",
    "DOORS = {'today': 'today', 'leads': 'leads', 'visits': 'visits', 'listings': 'listings',\n"
    "         'projects': 'listings', 'listing': 'listings', 'capture': 'capture',\n"
    "         'capture-lead': 'capture',\n"
    "         'search': '', 'more': 'more', 'you': 'more',\n"
    "         'queue': 'more', 'login': 'today'}", 1)

src = src.replace(
    "    ('today', 'Today'), ('leads', 'Leads'), ('visits', 'Visits'),\n"
    "    ('listings', 'Properties'), ('listing', 'Listing'), ('capture', 'Add'),",
    "    ('today', 'Today'), ('leads', 'Leads'), ('visits', 'Visits'),\n"
    "    ('listings', 'Properties'), ('projects', 'Societies'), ('listing', 'Listing'), ('capture', 'Add'),", 1)

# --------------------------------------------------------------- chrome css --
old_chrome_start = src.index('CHROME = """')
old_chrome_end = src.index('SCREEN_NAMES = {s: n for s, n in [')
NEW_CHROME = '''CHROME = """
<style>
  html, body { margin: 0; padding: 0; }
  body { background: #20211f; font: 13px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
  .pkbar { position: fixed; top: 0; left: 0; right: 0; height: 46px; z-index: 99999;
    display: flex; align-items: center; gap: 8px; padding: 0 14px; overflow-x: auto;
    background: #16171a; border-bottom: 1px solid #2f3134; color: #b6b8bd; }
  .pkbar b { color: #f2f0eb; font-size: 13px; font-weight: 600; margin-right: 6px; white-space: nowrap; }
  .pkbar .lbl { font-size: 9px; text-transform: uppercase; letter-spacing: .09em; color: #7d7f85; white-space: nowrap; }
  .pkbar .sep { width: 1px; height: 22px; background: #33353a; margin: 0 4px; flex: none; }
  .pkbar .chip { padding: 4px 10px; border-radius: 99px; border: 1px solid #33353a; background: #1e2023;
    color: #b6b8bd; font: 12px/1 inherit; cursor: pointer; white-space: nowrap; flex: none; }
  .pkbar .chip:hover { border-color: #4a4d52; color: #f2f0eb; }
  .pkbar .chip.is-on { background: #a68b5b; border-color: #a68b5b; color: #16171a; font-weight: 700; }
  .pkwrap { padding-top: 46px; }
  .pktoasts { position: fixed; left: 50%; bottom: 22px; transform: translateX(-50%);
    z-index: 999999; display: flex; flex-direction: column; gap: 8px; align-items: center;
    pointer-events: none; width: max-content; max-width: calc(100vw - 32px); }
  .pktoast { background: #16171a; color: #f6f5f1; font-size: 12.5px; font-weight: 500;
    padding: 9px 15px; border-radius: 10px; box-shadow: 0 10px 28px rgba(0,0,0,.38);
    opacity: 0; transform: translateY(8px); transition: opacity .22s ease, transform .22s ease; }
  .pktoast.is-in { opacity: 1; transform: translateY(0); }
  /* The bar takes the top 46px, so the pocket's sticky furniture starts below it. */
  .pkwrap .estat-pocket-head { top: 46px; }
  .pkwrap .estat-pocket-main { min-height: calc(100vh - 46px); }
  .pkwrap .estat-pocket-sidebar { top: 46px; height: calc(100vh - 46px); }
</style>
"""

'''
src = src[:old_chrome_start] + NEW_CHROME + src[old_chrome_end:]

# --------------------------------------------------------------- section() --
src = src.replace(
    """    bare   = slug == 'login'
    return ('' if bare else sidebar(door)) \\
        + '<main class="estat-pocket-main"><div class="estat-pocket-screen">' \\
        + ('' if bare else head(door)) + body + '</div></main>' \\
        + ('' if bare else tabs(door))""",
    """    bare   = slug == 'login'
    wide   = ' is-wide' if slug == 'today' else ''
    return ('' if bare else sidebar(door)) \\
        + '<main class="estat-pocket-main"><div class="estat-pocket-screen">' \\
        + ('' if bare else head(door)) \\
        + f'<div class="estat-pocket-page{wide}">' + body + '</div></div></main>' \\
        + ('' if bare else tabs(door))""", 1)

open(P, 'w').write(src)
print('patched', len(src), 'bytes')
