#!/usr/bin/env python3
"""Fix the office's broken "Add" paths:

1. ?new=1 used to reload the page and do nothing. It now opens the drawer.
2. The Add buttons on Enquiries / Visits opened a drawer that only worked
   for records that already existed, so they died with a 404. They now
   render a real create form.
3. The project drawer had no way to add a cover photo or a gallery.
"""
import re, sys

BASE = '/home/user/plugin/estat-os/'

def patch(path, pairs):
    s = open(BASE + path).read()
    for label, old, new in pairs:
        if old not in s:
            print('  !! ANCHOR MISSING: ' + label)
            sys.exit(1)
        s = s.replace(old, new, 1)
        print('  ok  ' + label)
    open(BASE + path, 'w').write(s)

# ------------------------------------------------------------ 1. Shell ----
patch('includes/Admin/Os/Shell.php', [(
    'maybe_open_new',
    """	/* ---------------------------------------------------------------------
	 * Menus handed to JavaScript
	 * ------------------------------------------------------------------ */

	/**
	 * Open the create drawer when a screen is reached with ?new=1.
	 *
	 * The quick-add menu used to send the office to `...&new=1`, which no
	 * screen ever read: the page simply reloaded and nothing happened. Now
	 * the drawer opens itself, and the flag is taken back out of the
	 * address so a later refresh does not open it again.
	 *
	 * @param string $kind Drawer kind: 'project', 'lead', 'visit'…
	 * @return void
	 */
	public static function maybe_open_new( string $kind ): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- reading a flag, not acting on input.
		if ( empty( $_GET['new'] ) ) {
			return;
		}

		echo '<script>(function(){'
			. 'function go(){'
			. 'if(window.EstatOS&&window.EstatOS.openDrawer){window.EstatOS.openDrawer(' . wp_json_encode( $kind ) . ',"0");}'
			. 'if(window.history&&window.history.replaceState){try{var u=new URL(window.location.href);'
			. 'u.searchParams.delete("new");window.history.replaceState({},"",u.toString());}catch(e){}}'
			. '}'
			. 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",go);}else{go();}'
			. '})();</script>';
	}

	/** Quick-add entries. */""",
    """	/* ---------------------------------------------------------------------
	 * Menus handed to JavaScript
	 * ------------------------------------------------------------------ */

	/**
	 * Open the create drawer when a screen is reached with ?new=1.
	 *
	 * The quick-add menu used to send the office to `...&new=1`, which no
	 * screen ever read: the page simply reloaded and nothing happened. Now
	 * the drawer opens itself, and the flag is taken back out of the
	 * address so a later refresh does not open it again.
	 *
	 * @param string $kind Drawer kind: 'project', 'lead', 'visit'.
	 * @return void
	 */
	public static function maybe_open_new( string $kind ): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a flag, not data.
		if ( empty( $_GET['new'] ) ) {
			return;
		}

		echo '<script>(function(){'
			. 'function go(){'
			. 'if(window.EstatOS&&window.EstatOS.openDrawer){window.EstatOS.openDrawer(' . wp_json_encode( $kind ) . ',"0");}'
			. 'if(window.history&&window.history.replaceState){try{var u=new URL(window.location.href);'
			. 'u.searchParams.delete("new");window.history.replaceState({},"",u.toString());}catch(e){}}'
			. '}'
			. 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",go);}else{go();}'
			. '})();</script>';
	}

	/** Quick-add entries. */"""
)])

# ------------------------------------------------- 2. the three screens ----
patch('includes/Admin/Os/Screens/ProjectsScreen.php', [(
    'projects new',
    """		Shell::close();
	}""",
    """		/*
		 * "Add a project" in the quick-add menu lands here with ?new=1.
		 * Without this the address is read by nobody and the button looks
		 * broken: the page reloads and nothing happens.
		 */
		Shell::maybe_open_new( 'project' );
		Shell::close();
	}"""
)])

patch('includes/Admin/Os/Screens/EnquiriesScreen.php', [(
    'enquiries new',
    """		Shell::close();
	}""",
    """		Shell::maybe_open_new( 'enquiry' );
		Shell::close();
	}"""
)])

patch('includes/Admin/Os/Screens/VisitsScreen.php', [(
    'visits new',
    """		Shell::close();
	}""",
    """		Shell::maybe_open_new( 'visit' );
		Shell::close();
	}"""
)])
print('done screens')
