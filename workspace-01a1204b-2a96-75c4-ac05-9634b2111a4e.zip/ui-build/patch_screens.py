#!/usr/bin/env python3
"""Port the new Pocket shell + Today screen into the plugin's PHP."""
import re

P = '/home/user/plugin/estat-os/includes/Pocket/Screens.php'
s = open(P).read()
orig = s

def rep(old, new, label, count=1):
    global s
    if old not in s:
        raise SystemExit('ANCHOR NOT FOUND: ' + label)
    s = s.replace(old, new, count)
    print('ok  ' + label)

# --------------------------------------------------------------- 1. doors --
rep("""		$items = array(
			''         => array( 'home', __( 'Today', 'estat-os' ), 'today' ),
			'leads'    => array( 'inbox', __( 'Leads', 'estat-os' ), 'leads' ),
			'listings' => array( 'list-checks', __( 'Properties', 'estat-os' ), 'listings' ),
			'visits'   => array( 'calendar', __( 'Visits', 'estat-os' ), 'visits' ),
			'more'     => array( 'menu', __( 'More', 'estat-os' ), 'more' ),
		);""",
"""		/*
		 * Five doors, and only five. Today and Leads sit before Add,
		 * Properties and Visits sit after it, so Add is always the middle
		 * one of the five — the same five on a phone and on a tablet. A
		 * computer does not get a bar at all: it gets the rail beside
		 * this, which carries the doors *and* the quieter places.
		 */
		$items = array(
			''         => array( 'home', __( 'Today', 'estat-os' ), 'today' ),
			'leads'    => array( 'inbox', __( 'Leads', 'estat-os' ), 'leads' ),
			'listings' => array( 'list-checks', __( 'Properties', 'estat-os' ), 'listings' ),
			'visits'   => array( 'calendar', __( 'Visits', 'estat-os' ), 'visits' ),
		);""", 'nav_items -> five doors')

# -------------------------------------------------------------- 2. shell ---
rep("""			$out .= '<a class="estat-pocket-sidebar-brand" href="' . esc_url( Pocket::url() ) . '">' . esc_html( get_bloginfo( 'name' ) ) . '</a>';""",
"""			$out .= '<a class="estat-pocket-sidebar-brand" href="' . esc_url( Pocket::url() ) . '">' . esc_html( get_bloginfo( 'name' ) ) . '<small>' . esc_html( Pocket::is_office() ? __( 'Office', 'estat-os' ) : __( 'Field agent', 'estat-os' ) ) . '</small></a>';""",
     'sidebar brand + role')

rep("""			$out .= '<div class="estat-pocket-sidebar-foot">';
			$out .= '<div class="estat-pocket-device" data-device="mobile">' . esc_html__( 'Mobile', 'estat-os' ) . '</div>';
			$out .= '<div class="estat-pocket-device" data-device="tablet">' . esc_html__( 'Tablet', 'estat-os' ) . '</div>';
			$out .= '<div class="estat-pocket-device" data-device="desktop">' . esc_html__( 'Desktop', 'estat-os' ) . '</div>';
			$out .= '<a class="estat-pocket-out" href="' . esc_url( wp_logout_url( Pocket::url() ) ) . '">' . Pocket::icon( 'lock', 14 ) . esc_html__( 'Sign out', 'estat-os' ) . '</a>';
			$out .= '<div class="estat-pocket-hint" style="margin:0">/agent • ' . esc_html( wp_get_current_user()->display_name ) . '</div>';
			$out .= '</div>';""",
"""			$out .= '<div class="estat-pocket-sidebar-foot">';
			$out .= '<a class="estat-pocket-out" href="' . esc_url( wp_logout_url( Pocket::url() ) ) . '">' . Pocket::icon( 'lock', 16 ) . '<span class="estat-pocket-out-word">' . esc_html__( 'Sign out', 'estat-os' ) . '</span></a>';
			$out .= '<div class="estat-pocket-hint" style="margin:0">/agent</div>';
			$out .= '</div>';""",
     'sidebar foot: sign out only')

old_head = """		if ( ! $bare ) {
			$out .= '<header class="estat-pocket-head">';
			$out .= '<a class="estat-pocket-brand" href="' . esc_url( Pocket::url() ) . '">' . esc_html( get_bloginfo( 'name' ) ) . '</a>';

			/*
			 * Five doors, in one row.
			 *
			 * On a computer the doors belong across the top, the way every
			 * other product the office already uses puts them; the phone and
			 * the tablet keep the same five, but along the bottom where a
			 * thumb already is. Add is the middle one of the five and it is
			 * dark, so the one thing that starts work is the one thing the
			 * eye lands on first.
			 */
			$out .= self::topnav( self::door_for( $active ) );

			$out .= '<div class="estat-pocket-headend">';
			$out .= '<span class="estat-pocket-device" data-device="mobile">' . esc_html__( 'Mobile', 'estat-os' ) . '</span>';
			$out .= '<span class="estat-pocket-device" data-device="tablet">' . esc_html__( 'Tablet', 'estat-os' ) . '</span>';
			$out .= '<span class="estat-pocket-device" data-device="desktop">' . esc_html__( 'PC', 'estat-os' ) . '</span>';
			$out .= '<span class="estat-pocket-me" aria-hidden="true">' . esc_html( strtoupper( mb_substr( (string) wp_get_current_user()->display_name, 0, 1 ) ) ) . '</span>';
			$out .= '<a class="estat-pocket-out" href="' . esc_url( wp_logout_url( Pocket::url() ) ) . '">' . Pocket::icon( 'lock', 14 ) . '<span class="estat-pocket-out-word">' . esc_html__( 'Sign out', 'estat-os' ) . '</span></a>';
			$out .= '</div>';
			$out .= '</header>';
		}"""

new_head = """		if ( ! $bare ) {
			/*
			 * One bar for every size: the name, a search box, and the
			 * person. On a computer the name steps aside, because the rail
			 * beside this already says whose app it is; on a phone the
			 * search drops to its own line so the name and the person
			 * stay side by side.
			 */
			$me       = wp_get_current_user();
			$initial  = strtoupper( mb_substr( trim( (string) $me->display_name ), 0, 1 ) );
			$roleword = Pocket::is_office() ? __( 'Office', 'estat-os' ) : __( 'Field Agent', 'estat-os' );

			$out .= '<header class="estat-pocket-head">';
			$out .= '<a class="estat-pocket-brand" href="' . esc_url( Pocket::url() ) . '">'
				. '<span class="estat-pocket-brandmark" aria-hidden="true">' . esc_html( '' !== $initial ? $initial : 'E' ) . '</span>'
				. '<span class="estat-pocket-brandtext"><span>' . esc_html( get_bloginfo( 'name' ) ) . '</span></span></a>';

			$out .= self::search_bar();

			$out .= '<div class="estat-pocket-headend">';
			$out .= '<a class="estat-pocket-bell" href="' . esc_url( Pocket::url( 'queue' ) ) . '" aria-label="'
				. esc_attr__( 'Waiting to go up', 'estat-os' ) . '">' . Pocket::icon( 'clock', 18 ) . '</a>';
			$out .= '<span class="estat-pocket-user">'
				. '<span class="estat-pocket-avatar" aria-hidden="true">' . esc_html( '' !== $initial ? $initial : 'E' ) . '</span>'
				. '<span class="estat-pocket-usernames"><b>' . esc_html( (string) $me->display_name ) . '</b>'
				. '<i>' . esc_html( $roleword ) . '</i></span></span>';
			$out .= '</div>';
			$out .= '</header>';
		}"""

rep(old_head, new_head, 'shell -> new head bar')

rep("""		$out .= '<script>' . self::queue_script() . '</script>';

		$out .= $body;
		$out .= '</div>'; // .estat-pocket-screen""",
"""		$out .= '<script>' . self::queue_script() . '</script>';

		/*
		 * Only Today is allowed the full width; every other screen stays
		 * in a reading column so forms and lists are never stretched.
		 */
		$out .= '<div class="estat-pocket-page' . ( 'today' === self::door_for( $active ) ? ' is-wide' : '' ) . '">';
		$out .= $body;
		$out .= '</div>'; // .estat-pocket-page
		$out .= '</div>'; // .estat-pocket-screen""",
     'shell -> page wrapper')

# --------------------------------------------------------------- 3. rail ---
old_rail = s[s.index("\t\t$rows = array(\n\t\t\tarray( 'search', 'search',"):s.index("\t\tforeach ( $rows as $row ) {\n\t\t\tlist( , $icon, $word, $url, $lit ) = $row;")]
new_rail = """		$door = self::door_for( $active );

		/*
		 * The rail is the navigation on a computer. The five doors come
		 * first, in the same order they sit on the bar, with Add in the
		 * middle; below them are the two places an agent goes to look
		 * something up. Sign out is pinned to the bottom of the column.
		 */
		$rows = array(
			array( 'today', 'home', __( 'Today', 'estat-os' ), Pocket::url(), 'today' ),
			array( 'leads', 'inbox', __( 'Leads', 'estat-os' ), Pocket::url( 'leads' ), 'leads' ),
		);

		$out = '';
		foreach ( $rows as $row ) {
			list( , $icon, $word, $url, $lit ) = $row;
			$out .= '<a class="estat-pocket-tab' . ( $lit === $door ? ' is-on' : '' ) . '" href="' . esc_url( $url ) . '">'
				. Pocket::icon( $icon, 18 ) . '<span>' . esc_html( $word ) . '</span></a>';
		}

		// ＋ Add — the middle one of the five, the one thing that starts work.
		$out .= '<a class="estat-pocket-tab estat-pocket-door estat-pocket-door--add' . ( 'capture' === $door ? ' is-on' : '' ) . '" href="'
			. esc_url( Pocket::url( 'capture' ) ) . '" aria-label="' . esc_attr__( 'Add something new', 'estat-os' ) . '">'
			. Pocket::icon( 'plus', 18 ) . '<span>' . esc_html__( 'Add', 'estat-os' ) . '</span></a>';

		if ( ! self::may_see_enquiries() ) {
			$out = str_replace(
				'<a class="estat-pocket-tab" href="' . esc_url( Pocket::url( 'leads' ) ) . '">',
				'',
				$out
			);
		}

		$rows = array(
			array( 'listings', 'buildings', __( 'Properties', 'estat-os' ), Pocket::url( 'listings' ), 'listings' ),
			array( 'visits', 'calendar', __( 'Visits', 'estat-os' ), Pocket::url( 'visits' ), 'visits' ),
			array( 'projects', 'compass', __( 'Societies & projects', 'estat-os' ), add_query_arg( 'show', 'societies', Pocket::url( 'listings' ) ), 'listings' ),
			array( 'you', 'person', __( 'Your details', 'estat-os' ), Pocket::url( 'you' ), 'you' ),
		);

		foreach ( $rows as $row ) {
			list( , $icon, $word, $url, $lit ) = $row;
			$out .= '<a class="estat-pocket-tab' . ( $lit === $door ? ' is-on' : '' ) . '" href="' . esc_url( $url ) . '">'
				. Pocket::icon( $icon, 18 ) . '<span>' . esc_html( $word ) . '</span></a>';
		}

		return $out;
	}

	private static function sidebar_tabs_unused( string $active ): string {
		$rows = array(
			array( 'search', 'search', __( 'Search everything', 'estat-os' ), Pocket::url( 'search' ), 'search' ),
			array( 'more', 'menu', __( 'Waiting for you', 'estat-os' ), Pocket::url( 'more' ), 'more' ),
			array( 'queue', 'clock', __( 'Waiting to go up', 'estat-os' ), Pocket::url( 'queue' ), 'queue' ),
			array( 'listings', 'buildings', __( 'Societies & projects', 'estat-os' ), add_query_arg( 'show', 'societies', Pocket::url( 'listings' ) ), '' ),
			array( 'you', 'person', __( 'Your details', 'estat-os' ), Pocket::url( 'you' ), 'you' ),
		);

"""
s = s.replace(old_rail, new_rail, 1)
print('ok  sidebar_tabs -> new rail')

# The old function had its own $door line before $rows; drop the duplicate.
s = s.replace("""	private static function sidebar_tabs( string $active ): string {
		$door = self::door_for( $active );
		$out  = '';

		/*
		 * The five doors live across the top on a computer, so the column
		 * beside them holds what is not a door: the places an agent goes
		 * to look something up, and the things waiting quietly. Short rows,
		 * tight spacing — the column is a tool rail, not a second menu.
		 */
""", """	private static function sidebar_tabs( string $active ): string {
""", 1)
print('ok  sidebar_tabs header trimmed')

open(P, 'w').write(s)
print('\nwritten', len(s), 'bytes (was', len(orig), ')')
