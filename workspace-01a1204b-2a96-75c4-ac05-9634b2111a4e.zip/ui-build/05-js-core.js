/* ==========================================================================
   ESTAT.OS — core: routing, motion, feedback, data
   Plain ES2019. No libraries, no build step, no network calls.
   ========================================================================== */
'use strict';

/* ---------- tiny helpers ---------------------------------------------- */
const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.prototype.slice.call(r.querySelectorAll(s));
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function ico(name, cls) {
  return '<svg' + (cls ? ' class="' + cls + '"' : '') + '><use href="#i-' + name + '"/></svg>';
}

/** Indian number grouping: 18500000 -> 1,85,00,000 */
function inr(n) {
  const s = String(Math.round(n)).split('.');
  let x = s[0], out = '', i = x.length;
  if (i > 3) { out = x.slice(i - 3); i -= 3; } else return x;
  while (i > 0) { out = x.slice(Math.max(0, i - 2), i) + ',' + out; i -= 2; }
  return out;
}
function money(n) { return '₹' + inr(n); }
function short(n) {
  if (n >= 10000000) return '₹' + (n / 10000000).toFixed(2).replace(/\.?0+$/, '') + ' Cr';
  if (n >= 100000) return '₹' + (n / 100000).toFixed(2).replace(/\.?0+$/, '') + ' L';
  return money(n);
}
function initials(name) {
  return name.split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
}
function daysAgo(n) {
  const d = new Date(); d.setDate(d.getDate() - n);
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}
const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const DOW = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];

/* ==========================================================================
   Toast — every save, delete and move reports back. Never in the way.
   ========================================================================== */
const Toasts = (() => {
  const host = $('#toasts');
  const ICON = { ok: 'check', warn: 'alert', err: 'alert', info: 'send' };
  function show(title, msg, kind, action) {
    const t = document.createElement('div');
    t.className = 'toast toast--' + (kind || 'ok');
    t.innerHTML =
      '<span class="toast__ico">' + ico(ICON[kind] || 'check') + '</span>' +
      '<div class="toast__b"><div class="toast__t">' + esc(title) + '</div>' +
      (msg ? '<div class="toast__m">' + esc(msg) + '</div>' : '') + '</div>' +
      (action ? '<button class="toast__undo">' + esc(action.label) + '</button>' : '') +
      '<button class="toast__x" aria-label="Dismiss">' + ico('x') + '</button>';
    host.appendChild(t);
    const kill = () => {
      if (t.dataset.dead) return;
      t.dataset.dead = '1';
      t.classList.add('is-out');
      setTimeout(() => t.remove(), 260);
    };
    let timer = setTimeout(kill, action ? 6500 : 3800);
    t.addEventListener('mouseenter', () => clearTimeout(timer));
    t.addEventListener('mouseleave', () => { timer = setTimeout(kill, action ? 5000 : 2600); });
    $('.toast__x', t).addEventListener('click', kill);
    if (action) $('.toast__undo', t).addEventListener('click', () => { action.run(); kill(); });
    // Never stack more than four.
    while (host.children.length > 4) host.firstElementChild.remove();
    return kill;
  }
  return { show };
})();
const toast = (t, m, k, a) => Toasts.show(t, m, k, a);

/* ==========================================================================
   Count-up — a number never just appears.
   ========================================================================== */
/* Motion respects the system setting. The guard matters: if a browser is old
   enough not to have matchMedia, the interface must still run — it should
   never be one missing API away from a blank screen. */
const REDUCED = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
const raf = window.requestAnimationFrame
  ? cb => window.requestAnimationFrame(cb)
  : cb => setTimeout(() => cb(performance.now()), 16);

function countUp(el, to, dur) {
  const target = Number(to) || 0;
  if (REDUCED) { el.textContent = inr(target); return; }
  const d = dur || 1150, t0 = performance.now();
  const from = Math.abs(target) > 60 ? 0 : 0;
  function frame(now) {
    const p = clamp((now - t0) / d, 0, 1);
    const e = 1 - Math.pow(1 - p, 3.2);           // ease-out cubic
    el.textContent = inr(Math.round(from + (target - from) * e));
    if (p < 1) raf(frame);
  }
  raf(frame);
}
function runCounts(root) {
  // Numbers climb from zero every time the screen is shown, not just the
  // first time — a figure that appears already-finished reads as stale.
  $$('[data-count]', root).forEach((el, i) => {
    el.textContent = '0';
    setTimeout(() => countUp(el, el.dataset.count), 90 * i);
  });
  $$('.meter__fill', root).forEach((el, i) => {
    const w = el.dataset.w != null ? el.dataset.w + '%' : (el.style.width || '0%');
    el.style.width = '0%';
    setTimeout(() => { el.style.width = w; }, 60 + i * 60);
  });
}

/* ==========================================================================
   Drawer — context lives to the right, never a new page.
   ========================================================================== */
const Drawer = (() => {
  const scrim = $('#scrim'), panel = $('#drawer');
  let lastFocus = null;

  function open(o) {
    lastFocus = document.activeElement;
    $('#dwKicker').textContent = o.kicker || '';
    $('#dwKicker').hidden = !o.kicker;
    $('#dwTitle').textContent = o.title || '';
    $('#dwSub').textContent = o.sub || '';
    $('#dwSub').hidden = !o.sub;
    $('#dwBody').innerHTML = o.body || '';
    $('#dwFoot').innerHTML = o.foot || '';
    $('#dwFoot').hidden = !o.foot;
    panel.classList.toggle('drawer--wide', !!o.wide);
    panel.hidden = false;
    requestAnimationFrame(() => {
      panel.classList.add('is-on');
      scrim.classList.add('is-on');
    });
    scrim.hidden = false;
    if (o.mount) o.mount($('#dwBody'));
    const f = panel.querySelector('button,input,select,[tabindex]');
    if (f) setTimeout(() => f.focus(), 340);
  }
  function close() {
    panel.classList.remove('is-on');
    scrim.classList.remove('is-on');
    setTimeout(() => { panel.hidden = true; scrim.hidden = true; }, 520);
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }
  $('#dwClose').addEventListener('click', close);
  scrim.addEventListener('click', close);
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && panel.classList.contains('is-on')) close();
  });
  return { open, close, isOpen: () => panel.classList.contains('is-on') };
})();

/* ==========================================================================
   Router — one canvas, no page loads, always a transition.
   ========================================================================== */
const SCREENS = {};
$$('.screen').forEach(s => { SCREENS[s.dataset.screen] = s; });

const Router = (() => {
  let current = 'today';

  function go(name, opts) {
    if (!SCREENS[name]) name = 'today';
    if (name === current && !(opts && opts.force)) { closeCmdk(); return; }
    const from = SCREENS[current], to = SCREENS[name];

    if (!REDUCED) {
      from.classList.add('is-leaving');
      const done = () => {
        from.classList.remove('is-leaving');
        from.hidden = true;
        to.hidden = false;
        // restart the entrance animation
        to.style.animation = 'none';
        void to.offsetWidth;
        to.style.animation = '';
        mount(name);
        $('#canvas').scrollTop = 0;
      };
      setTimeout(done, 140);
    } else {
      from.hidden = true; to.hidden = false; mount(name); $('#canvas').scrollTop = 0;
    }

    current = name;
    $$('.nav').forEach(b => b.classList.toggle('is-active', b.dataset.nav === name));
    const crumb = $('.nav.is-active .nav__txt');
    $('#crumb').textContent = crumb ? crumb.textContent : 'Today';
    document.title = (crumb ? crumb.textContent : 'Today') + ' · Estat.OS';
    closeCmdk();
    Drawer.close();
    hidePop();
    /* Some browsers refuse to touch history on pages opened straight off
       disk (file://) — if that happens we just skip the address update,
       the interface itself does not need it. */
    try { history.replaceState(null, '', '#' + name); } catch (err) { /* no-op */ }
  }

  /* A screen is built the first time it is opened, and only then.
     Building it again on every visit would attach a second copy of every
     click handler — so one click would fire twice, and a wizard would
     advance two steps at a time. The screen keeps its own state in the
     DOM, and each view re-draws itself when its data changes.
     Counters and meters still re-run on every visit (see runCounts). */
  function mount(name) {
    const root = SCREENS[name];
    runCounts(root);
    const v = VIEWS[name];
    if (v && !v.built && typeof v.mount === 'function') {
      v.built = true;
      v.mount(root);
    }
  }

  document.addEventListener('click', e => {
    const b = e.target.closest('[data-nav]');
    if (b) { e.preventDefault(); go(b.dataset.nav); }
  });
  window.addEventListener('hashchange', () => {
    const h = location.hash.replace('#', '');
    if (h && SCREENS[h]) go(h);
  });

  return { go, current: () => current };
})();
const go = Router.go;

/* ==========================================================================
   Command palette
   ========================================================================== */
const CMDK = (() => {
  const box = $('#cmdk'), input = $('#cmdkIn'), list = $('#cmdkList');
  let items = [], sel = 0;

  function build() {
    items = [];
    $$('.nav').forEach(b => items.push({
      icon: $('use', b).getAttribute('href').replace('#i-', ''),
      label: $('.nav__txt', b) ? $('.nav__txt', b).textContent : '',
      hint: 'Go to', run: () => go(b.dataset.nav)
    }));
    DATA.properties.slice(0, 6).forEach(p => items.push({
      icon: 'home', label: p.title, hint: short(p.price), run: () => openProperty(p)
    }));
    DATA.leads.slice(0, 5).forEach(l => items.push({
      icon: 'user', label: l.name, hint: 'Lead', run: () => openLead(l)
    }));
  }
  function render(q) {
    const f = q.trim().toLowerCase();
    const shown = items.filter(i => !f || i.label.toLowerCase().indexOf(f) >= 0);
    sel = 0;
    list.innerHTML = shown.length ? '' : '<div class="empty" style="padding:28px"><p>Nothing matched.</p></div>';
    shown.forEach((it, i) => {
      const b = document.createElement('button');
      b.className = 'cmdk__i' + (i === 0 ? ' is-on' : '');
      b.innerHTML = ico(it.icon) + '<b>' + esc(it.label) + '</b><span>' + esc(it.hint) + '</span>';
      b.addEventListener('click', () => { it.run(); closeCmdk(); });
      b.addEventListener('mouseenter', () => { sel = i; paint(); });
      list.appendChild(b);
    });
    function paint() { $$('.cmdk__i', list).forEach((n, i) => n.classList.toggle('is-on', i === sel)); }
    list._paint = paint; list._shown = shown;
  }
  function openCmdk() {
    build(); render('');
    box.classList.add('is-on'); input.value = '';
    setTimeout(() => input.focus(), 60);
  }
  function closeCmdk() { box.classList.remove('is-on'); input.blur(); }
  input.addEventListener('input', () => render(input.value));
  input.addEventListener('keydown', e => {
    const n = list._shown ? list._shown.length : 0;
    if (e.key === 'ArrowDown') { sel = (sel + 1) % Math.max(1, n); list._paint(); e.preventDefault(); }
    else if (e.key === 'ArrowUp') { sel = (sel - 1 + n) % Math.max(1, n); list._paint(); e.preventDefault(); }
    else if (e.key === 'Enter') { const it = list._shown[sel]; if (it) { it.run(); closeCmdk(); } e.preventDefault(); }
  });
  box.addEventListener('click', e => { if (e.target === box) closeCmdk(); });
  return { open: openCmdk, close: closeCmdk };
})();
function closeCmdk() { CMDK.close(); }

$('#searchIn').addEventListener('focus', CMDK.open);
document.addEventListener('keydown', e => {
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); CMDK.open(); }
  if (e.key === 'Escape') CMDK.close();
});

/* ==========================================================================
   Popover (profile, notifications, quick add)
   ========================================================================== */
const pop = $('#pop');
/* hidePop() waits for the fade-out before flipping `hidden`. If that timer is
   left running it will happily close a popover that has just been reopened —
   which is exactly what killed Quick Add: the "click outside closes it"
   listener below ran BEFORE the Quick Add handler on the very same click and
   queued a close, so the menu appeared and then vanished 180ms later. Every
   close is now cancelled by the next open. */
let popCloseT = 0;
function showPop(anchor, html, mount) {
  clearTimeout(popCloseT);
  pop.innerHTML = html;
  pop.hidden = false;
  const r = anchor.getBoundingClientRect();
  pop.style.top = (r.bottom + 8) + 'px';
  const w = pop.offsetWidth;
  pop.style.left = clamp(r.right - w, 12, window.innerWidth - w - 12) + 'px';
  raf(() => pop.classList.add('is-on'));
  if (mount) mount(pop);
}
function hidePop() {
  pop.classList.remove('is-on');
  clearTimeout(popCloseT);
  popCloseT = setTimeout(() => { pop.hidden = true; }, 180);
}
/* A click on one of the buttons that OWN a popover must not count as a click
   "outside" it — otherwise it closes itself the instant it opens. */
document.addEventListener('click', e => {
  if (e.target.closest('#pop')) return;
  if (e.target.closest('#bellBtn, #meBtn, [data-quickadd]')) return;
  hidePop();
});

$('#bellBtn').addEventListener('click', e => {
  e.stopPropagation();
  if (pop.classList.contains('is-on') && pop._who === 'bell') return hidePop();
  pop._who = 'bell';
  const n = DATA.notifications;
  showPop(e.currentTarget,
    '<div style="padding:8px 12px" class="lbl">Notifications</div>' +
    n.map(x =>
      '<div class="notif"><span class="notif__i" style="background:var(--' + x.tone + '-soft);color:var(--' + x.tone + ')">' +
      ico(x.icon) + '</span><div class="notif__b"><div class="notif__t">' + esc(x.title) +
      '<time>' + esc(x.when) + '</time></div><div class="notif__m">' + esc(x.msg) + '</div></div></div>').join('') +
    '<div class="pop__sep"></div><button class="pop__i" data-nav="requests">' + ico('shuffle') + 'Open change requests</button>');
});
$('#meBtn').addEventListener('click', e => {
  e.stopPropagation();
  if (pop.classList.contains('is-on') && pop._who === 'me') return hidePop();
  pop._who = 'me';
  showPop(e.currentTarget,
    '<div style="padding:10px 12px"><div style="font-weight:600">' + 'Ravi Mehra' + '</div>' +
    '<div class="mut" style="font-size:12px">ravi@mayfairproperties.in</div></div><div class="pop__sep"></div>' +
    '<button class="pop__i" data-nav="settings">' + ico('settings') + 'Settings</button>' +
    '<button class="pop__i" data-nav="team">' + ico('users') + 'Team</button>' +
    '<div class="pop__sep"></div><button class="pop__i is-danger">' + ico('logout') + 'Sign out</button>');
});
document.addEventListener('click', e => {
  const b = e.target.closest('[data-quickadd]');
  if (!b) return;
  e.stopPropagation();
  if (pop.classList.contains('is-on') && pop._who === 'qa') return hidePop();
  pop._who = 'qa';
  showPop(b,
    '<button class="pop__i" data-nav="add-home">' + ico('home') + 'Add a home</button>' +
    '<button class="pop__i" data-nav="enquiries">' + ico('inbox') + 'New enquiry</button>' +
    '<button class="pop__i" data-nav="visits">' + ico('calendar') + 'Schedule a visit</button>' +
    '<button class="pop__i" data-nav="team">' + ico('users') + 'Add a team member</button>');
});

/** What sits under a point. Guarded for the same reason as matchMedia:
    a drag must never be one missing browser API away from throwing. */
function elementAt(x, y) {
  return (document.elementFromPoint && document.elementFromPoint(x, y)) || null;
}

/* ==========================================================================
   Shared drag engine — kanban cards, page blocks, form fields.
   One implementation so every drag in the product behaves identically:
   pick up, lift, follow, snap back with a spring.
   ========================================================================== */
function draggable(opts) {
  let ghost = null, startX = 0, startY = 0, armed = false, target = null, node = null;

  function down(e) {
    if (e.button !== undefined && e.button !== 0) return;
    node = e.currentTarget;
    armed = true;
    startX = e.clientX; startY = e.clientY;
    node.setPointerCapture && node.setPointerCapture(e.pointerId);
    node.addEventListener('pointermove', move);
    node.addEventListener('pointerup', up);
    node.addEventListener('pointercancel', up);
  }

  function move(e) {
    if (!armed) return;
    const dx = e.clientX - startX, dy = e.clientY - startY;
    if (!ghost && Math.hypot(dx, dy) < 5) return;

    if (!ghost) {
      ghost = node.cloneNode(true);
      const r = node.getBoundingClientRect();
      ghost.style.width = r.width + 'px';
      ghost.style.left = r.left + 'px';
      ghost.style.top = r.top + 'px';
      ghost.classList.add(opts.ghostClass || 'is-ghost');
      ghost.classList.remove('is-snap');
      document.body.appendChild(ghost);
      node.classList.add('is-drag');
      document.body.style.cursor = 'grabbing';
      document.body.style.userSelect = 'none';
      if (opts.onStart) opts.onStart(node, ghost);
    }
    ghost.style.transform = 'translate3d(' + dx + 'px,' + dy + 'px,0) rotate(' + clamp(dx * 0.035, -4, 4) + 'deg) scale(1.03)';

    const hit = opts.hitTest ? opts.hitTest(e.clientX, e.clientY, ghost) : null;
    if (hit !== target) { if (target && opts.onLeave) opts.onLeave(target); target = hit; if (target && opts.onEnter) opts.onEnter(target); }
    if (opts.onMove) opts.onMove(e.clientX, e.clientY, ghost, target);
    e.preventDefault();
  }

  function up() {
    armed = false;
    node.removeEventListener('pointermove', move);
    node.removeEventListener('pointerup', up);
    node.removeEventListener('pointercancel', up);
    document.body.style.cursor = '';
    document.body.style.userSelect = '';
    if (!ghost) return;

    const g = ghost, n = node, t = target;
    const finish = () => {
      g.remove();
      n.classList.remove('is-drag');
      if (opts.onEnd) opts.onEnd(n, t);
    };
    if (t && opts.dropRect) {
      // Spring snap: fly the ghost to where the card will actually live.
      const r = opts.dropRect(t, n);
      if (r) {
        g.classList.add('is-snap');
        g.style.setProperty('--snap', 'translate3d(' + (r.left - parseFloat(g.style.left)) + 'px,' +
          (r.top - parseFloat(g.style.top)) + 'px,0) rotate(0deg) scale(1)');
        g.style.transform = 'none';
        setTimeout(finish, REDUCED ? 0 : 430);
      } else { g.remove(); n.classList.remove('is-drag'); if (opts.onEnd) opts.onEnd(n, null); }
    } else {
      // Rejected drop — spring back to where it was picked up.
      g.classList.add('is-snap');
      g.style.setProperty('--snap', 'translate3d(0,0,0) rotate(0deg) scale(1)');
      g.style.transform = 'none';
      setTimeout(() => { g.remove(); n.classList.remove('is-drag'); if (opts.onEnd) opts.onEnd(n, null); }, REDUCED ? 0 : 380);
    }
    target = null; ghost = null;
  }

  opts.nodes.forEach(n => {
    n.style.touchAction = 'none';
    n.addEventListener('pointerdown', down);
  });
}

/* ==========================================================================
   Data — stands in for the database. Shapes match what the plugin stores.
   ========================================================================== */
const DATA = {
  properties: [
    { id: 1, title: '3 BHK apartment in Sushant Lok II', kind: 'Apartment', price: 18500000, area: 1750, loc: 'Sushant Lok II', status: 'Live', pct: 92, beds: 3, tone: '#c9b48a', owner: 'Priya Nair', ref: 'ES-1042' },
    { id: 2, title: 'Builder floor, Sector 57', kind: 'Builder floor', price: 12400000, area: 1450, loc: 'Sector 57', status: 'Draft', pct: 46, beds: 3, tone: '#b8c2ae', owner: 'Ravi Mehra', ref: 'ES-1043' },
    { id: 3, title: 'Corner plot, Sector 92', kind: 'Plot', price: 9800000, area: 2700, loc: 'Sector 92', status: 'Pending', pct: 71, beds: 0, tone: '#d3c3ad', owner: 'Amit Joshi', ref: 'ES-1044' },
    { id: 4, title: '4 BHK penthouse, Golf Course Road', kind: 'Apartment', price: 62000000, area: 4200, loc: 'Golf Course Road', status: 'Live', pct: 100, beds: 4, tone: '#a9b7c4', owner: 'Priya Nair', ref: 'ES-1045' },
    { id: 5, title: 'Shop in Sadar Bazar', kind: 'Shop', price: 7600000, area: 620, loc: 'Sadar Bazar', status: 'Live', pct: 83, beds: 0, tone: '#cbb9a4', owner: 'Amit Joshi', ref: 'ES-1046' },
    { id: 6, title: '2 BHK, Sushant Lok II', kind: 'Apartment', price: 17950000, area: 1740, loc: 'Sushant Lok II', status: 'Live', pct: 88, beds: 2, tone: '#c2b39c', owner: 'Priya Nair', ref: 'ES-1047' },
    { id: 7, title: 'Villa, DLF Phase 1', kind: 'Villa', price: 41000000, area: 3600, loc: 'DLF Phase 1', status: 'Pending', pct: 64, beds: 5, tone: '#b5c0b0', owner: 'Ravi Mehra', ref: 'ES-1048' },
    { id: 8, title: '1 BHK, Sohna Road', kind: 'Apartment', price: 5200000, area: 720, loc: 'Sohna Road', status: 'Live', pct: 95, beds: 1, tone: '#cdbfae', owner: 'Sana Khan', ref: 'ES-1049' },
    { id: 9, title: 'Office unit, Cyber City', kind: 'Office', price: 28500000, area: 2100, loc: 'Cyber City', status: 'Draft', pct: 33, beds: 0, tone: '#aeb8c6', owner: 'Sana Khan', ref: 'ES-1050' },
    { id: 10, title: '3 BHK, Nirvana Country', kind: 'Apartment', price: 21000000, area: 1980, loc: 'Nirvana Country', status: 'Live', pct: 97, beds: 3, tone: '#c7b498', owner: 'Amit Joshi', ref: 'ES-1051' }
  ],
  projects: [
    { name: 'M3M Capital', builder: 'M3M India', stage: 'Under construction', total: 412, avail: 96, tone: '#b9c3d1', loc: 'Sector 113', poss: 'Dec 2027' },
    { name: 'Trehan Iris Broadway', builder: 'Trehan Group', stage: 'Ready', total: 188, avail: 12, tone: '#c9c0ae', loc: 'Sector 85', poss: 'Ready' },
    { name: 'Emaar Business Centre', builder: 'Emaar India', stage: 'Under construction', total: 240, avail: 71, tone: '#b3c2b8', loc: 'Sector 65', poss: 'Mar 2028' },
    { name: 'Chintels Corporate Park', builder: 'Chintels', stage: 'Ready', total: 96, avail: 4, tone: '#c8b6a2', loc: 'Sector 114', poss: 'Ready' },
    { name: 'Magnum Towers', builder: 'Magnum', stage: 'Early', total: 320, avail: 233, tone: '#b0bdc9', loc: 'Sector 58', poss: 'Jun 2029' },
    { name: 'Vatika Crossover', builder: 'Vatika', stage: 'Ready', total: 144, avail: 18, tone: '#c5bdac', loc: 'Sector 82', poss: 'Ready' },
    { name: 'Global Foyer JMD', builder: 'JMD', stage: 'Under construction', total: 210, avail: 58, tone: '#b7c1c9', loc: 'Sector 43', poss: 'Sep 2027' },
    { name: 'Reach 3 Roads', builder: 'Reach Group', stage: 'Early', total: 168, avail: 141, tone: '#cdc0b0', loc: 'Sector 68', poss: 'Nov 2029' }
  ],
  leads: [
    { id: 1, name: 'Ananya Sharma', phone: '+91 98102 44556', prop: '3 BHK, Sushant Lok II', src: 'Website', stage: 'New', next: 'Overdue by 2 days', tone: 'warn', when: '2 hours ago', budget: '1.8 Cr' },
    { id: 2, name: 'Vikram Sethi', phone: '+91 99111 20304', prop: 'Corner plot, Sector 92', src: 'WhatsApp', stage: 'Contacted', next: 'Today, 5 pm', tone: 'warn', when: '5 hours ago', budget: '1 Cr' },
    { id: 3, name: 'Meera Iyer', phone: '+91 98111 66778', prop: '4 BHK penthouse, Golf Course Rd', src: 'Referral', stage: 'Scheduled', next: 'Tomorrow, 11 am', tone: 'info', when: 'Yesterday', budget: '6 Cr' },
    { id: 4, name: 'Harpreet Singh', phone: '+91 98123 90001', prop: 'Builder floor, Sector 57', src: 'Website', stage: 'Won', next: '—', tone: 'pos', when: '3 days ago', budget: '1.2 Cr' },
    { id: 5, name: 'Fatima Begum', phone: '+91 99717 44556', prop: 'Shop, Sadar Bazar', src: 'Walk-in', stage: 'Contacted', next: 'Fri, 3 pm', tone: 'info', when: '4 days ago', budget: '76 L' },
    { id: 6, name: 'Rohit Malhotra', phone: '+91 98100 11223', prop: 'Villa, DLF Phase 1', src: 'Website', stage: 'New', next: 'Overdue by 1 day', tone: 'warn', when: '6 hours ago', budget: '4 Cr' },
    { id: 7, name: 'Sneha Kulkarni', phone: '+91 98222 33445', prop: '2 BHK, Sushant Lok II', src: 'Instagram', stage: 'Lost', next: '—', tone: 'dang', when: 'Last week', budget: '1.7 Cr' }
  ],
  agents: [
    { name: 'Ravi Mehra', role: 'Office Owner', phone: '+91 98100 00001', props: 84, leads: 12, tone: '#725b2f', won: 6 },
    { name: 'Priya Nair', role: 'Senior Agent', phone: '+91 98100 00002', props: 62, leads: 18, tone: '#3f6b4f', won: 9 },
    { name: 'Amit Joshi', role: 'Agent', phone: '+91 98100 00003', props: 47, leads: 9, tone: '#3c5a7a', won: 4 },
    { name: 'Sana Khan', role: 'Agent', phone: '+91 98100 00004', props: 31, leads: 7, tone: '#8a6a1f', won: 3 },
    { name: 'Deepak Yadav', role: 'Field Agent', phone: '+91 98100 00005', props: 14, leads: 5, tone: '#8c3b32', won: 2 },
    { name: 'Kavita Rao', role: 'Field Agent', phone: '+91 98100 00006', props: 10, leads: 4, tone: '#5a4522', won: 1 }
  ],
  visits: [
    { day: 8, time: '11:00 AM', agent: 'Priya Nair', prop: '3 BHK, Sushant Lok II', client: 'Ananya Sharma', tone: 'info' },
    { day: 8, time: '4:30 PM', agent: 'Amit Joshi', prop: 'Villa, DLF Phase 1', client: 'Rohit Malhotra', tone: 'bronze' },
    { day: 9, time: '10:00 AM', agent: 'Ravi Mehra', prop: '4 BHK penthouse', client: 'Meera Iyer', tone: 'pos' },
    { day: 10, time: '12:30 PM', agent: 'Sana Khan', prop: 'Corner plot, Sector 92', client: 'Vikram Sethi', tone: 'warn' },
    { day: 12, time: '3:00 PM', agent: 'Priya Nair', prop: 'Shop, Sadar Bazar', client: 'Fatima Begum', tone: 'info' }
  ],
  requests: [
    { id: 1, who: 'Deepak Yadav', when: '2 hours ago', prop: 'Builder floor, Sector 57', field: 'Price', old: '₹1,24,00,000', neo: '₹1,19,00,000', note: 'Owner agreed to reduce after negotiation.' },
    { id: 2, who: 'Sana Khan', when: 'Yesterday', prop: 'Office unit, Cyber City', field: 'Availability', old: 'Available', neo: 'Under offer', note: 'Token amount received.' },
    { id: 3, who: 'Kavita Rao', when: '2 days ago', prop: 'Corner plot, Sector 92', field: 'Area (sq ft)', old: '2,400', neo: '2,700', note: 'Registry shows a larger plot than the sheet.' },
    { id: 4, who: 'Amit Joshi', when: '3 days ago', prop: 'Villa, DLF Phase 1', field: 'Bedrooms', old: '4', neo: '5', note: 'There is a study on the ground floor.' }
  ],
  deals: {
    New: [{ t: 'Ananya Sharma', p: '3 BHK, Sushant Lok II', a: 'PN', amt: 18500000 }, { t: 'Rohit Malhotra', p: 'Villa, DLF Phase 1', a: 'RM', amt: 41000000 }],
    Contacted: [{ t: 'Vikram Sethi', p: 'Corner plot, Sector 92', a: 'AJ', amt: 9800000 }, { t: 'Fatima Begum', p: 'Shop, Sadar Bazar', a: 'SK', amt: 7600000 }, { t: 'Sunil Verma', p: '2 BHK, Sushant Lok II', a: 'PN', amt: 17950000 }],
    Scheduled: [{ t: 'Meera Iyer', p: '4 BHK penthouse', a: 'RM', amt: 62000000 }],
    Won: [{ t: 'Harpreet Singh', p: 'Builder floor, Sector 57', a: 'RM', amt: 12400000 }, { t: 'Nisha Agarwal', p: '1 BHK, Sohna Road', a: 'SK', amt: 5200000 }],
    Lost: [{ t: 'Sneha Kulkarni', p: '2 BHK, Sushant Lok II', a: 'AJ', amt: 17950000 }]
  },
  work: [
    { t: 'Call Ananya Sharma back', m: 'Enquiry · overdue by 2 days', due: 'Today', tone: 'dang' },
    { t: 'Call Rohit Malhotra back', m: 'Enquiry · overdue by 1 day', due: 'Today', tone: 'dang' },
    { t: 'Add photographs — Builder floor, Sector 57', m: 'Listing · 46% complete', due: 'Today', tone: 'warn' },
    { t: 'Approve 4 change requests', m: 'Team · waiting on you', due: 'Today', tone: 'warn' },
    { t: 'Review 7 duplicate pairs', m: 'Inventory', due: 'This week', tone: 'bronze' },
    { t: 'Confirm Meera Iyer site visit', m: 'Visit · tomorrow 11 am', due: 'Tomorrow', tone: 'info' },
    { t: 'Send brochure to Vikram Sethi', m: 'Enquiry · WhatsApp', due: 'Tomorrow', tone: 'info' }
  ],
  notifications: [
    { icon: 'shuffle', tone: 'warn', title: '4 change requests waiting', msg: 'Deepak, Sana, Kavita and Amit proposed edits', when: '2h' },
    { icon: 'copy', tone: 'bronze', title: '7 possible duplicates found', msg: 'The daily sweep finished at 6 am', when: '6h' },
    { icon: 'calendar', tone: 'info', title: '2 site visits today', msg: '11:00 Ananya Sharma · 16:30 Rohit Malhotra', when: '7h' },
    { icon: 'check', tone: 'pos', title: 'Harpreet Singh marked Won', msg: 'Builder floor, Sector 57 · ₹1.24 Cr', when: '3d' }
  ],
  media: {
    photos: [
      { n: 'Living room — 3 BHK, Sushant Lok II', h: 190, c1: '#cbb79c', c2: '#a89478', tag: 'JPG' },
      { n: 'Kitchen — 3 BHK, Sushant Lok II', h: 150, c1: '#bfc6bb', c2: '#98a294', tag: 'JPG' },
      { n: 'Master bedroom', h: 220, c1: '#d2c4b0', c2: '#ab9b84', tag: 'JPG' },
      { n: 'Balcony view', h: 140, c1: '#b6c2ce', c2: '#8d9bad', tag: 'JPG' },
      { n: 'Plot — Sector 92', h: 200, c1: '#c9c2b4', c2: '#a29a89', tag: 'JPG' },
      { n: 'Tower elevation — M3M Capital', h: 260, c1: '#bcc5d0', c2: '#93a0b0', tag: 'JPG' },
      { n: 'Clubhouse', h: 160, c1: '#cdc3b1', c2: '#a89d88', tag: 'JPG' },
      { n: 'Entrance lobby', h: 210, c1: '#c3bdae', c2: '#9c9585', tag: 'JPG' },
      { n: 'Parking', h: 130, c1: '#b9b6b0', c2: '#918e88', tag: 'JPG' },
      { n: 'Floor plate', h: 180, c1: '#c8bfae', c2: '#a39985', tag: 'JPG' }
    ],
    brochures: [
      { n: 'M3M Capital — brochure.pdf', h: 150, c1: '#c6b8a0', c2: '#9c8c72', tag: 'PDF' },
      { n: 'Trehan Iris — brochure.pdf', h: 130, c1: '#bfc4b8', c2: '#95a08e', tag: 'PDF' },
      { n: 'Emaar Business Centre.pdf', h: 170, c1: '#bcc7d2', c2: '#93a0b0', tag: 'PDF' }
    ],
    documents: [
      { n: 'Sale deed — Sector 92.pdf', h: 160, c1: '#cdc6b6', c2: '#a49c88', tag: 'PDF' },
      { n: 'RERA certificate.pdf', h: 140, c1: '#c2c9c0', c2: '#98a094', tag: 'PDF' },
      { n: 'NOC — Sushant Lok II.pdf', h: 190, c1: '#c9bda9', c2: '#a0967d', tag: 'PDF' }
    ],
    plans: [
      { n: '3 BHK — floor plan.pdf', h: 220, c1: '#c4bcab', c2: '#9b9382', tag: 'PDF' },
      { n: '4 BHK penthouse — plan.pdf', h: 180, c1: '#bcc4cc', c2: '#94a0aa', tag: 'PDF' },
      { n: 'Plot layout — Sector 92.pdf', h: 200, c1: '#cec4b2', c2: '#a69b86', tag: 'PDF' }
    ]
  },
  binRows: [
    { id: 1, title: '2 BHK, Palam Vihar', kind: 'Apartment', price: 8900000, why: 'Deleted by Ravi Mehra', when: '2 days ago', tone: '#c5bda9' },
    { id: 2, title: 'Plot, Manesar', kind: 'Plot', price: 4200000, why: 'Duplicate of ES-1044', when: '4 days ago', tone: '#b9c1c8' },
    { id: 3, title: 'Shop, Sector 14', kind: 'Shop', price: 15500000, why: 'Owner withdrew', when: '6 days ago', tone: '#ccc0ad' },
    { id: 4, title: '1 BHK, Sohna Road', kind: 'Apartment', price: 5100000, why: 'Deleted by Sana Khan', when: '1 week ago', tone: '#bfc7bd' }
  ],
  bin: []   /* filled in below */
};

/* Pairs the duplicate sweep found. Written here rather than inside the literal
   above because these point back at entries in DATA.properties. */
DATA.dups = [
  { score: 94, kind: 'Same', a: DATA.properties[0], b: DATA.properties[5], why: 'Same society and block, floor area within 10 sq ft, price within 3%.' },
  { score: 71, kind: 'Near', a: DATA.properties[2], b: { title: 'Corner plot, Sector 92 (second entry)', price: 10100000, area: 2680, loc: 'Sector 92', status: 'Draft', pct: 40, kind: 'Plot', ref: 'ES-1039' }, why: 'Same sector and near-identical area; the price differs by 3%.' },
  { score: 58, kind: 'Maybe', a: DATA.properties[9], b: { title: '3 BHK, Nirvana Country (tower 2)', price: 21400000, area: 2010, loc: 'Nirvana Country', status: 'Pending', pct: 62, kind: 'Apartment', ref: 'ES-0998' }, why: 'Same locality and a similar size — this may be two units in the same building.' }
];
