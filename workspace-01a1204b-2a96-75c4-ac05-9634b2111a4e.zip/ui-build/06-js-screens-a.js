/* ==========================================================================
   ESTAT.OS — screens (part 1 of 2)
   Each entry: { mount(root) } — called every time the screen is shown.
   ========================================================================== */
const VIEWS = {};

/* ------------------------------------------------------------- A · TODAY */
VIEWS.today = {
  mount() {
    const host = $('#worklist');
    if (host.dataset.done) return;
    host.dataset.done = '1';
    host.innerHTML = DATA.work.map((w, i) =>
      '<div class="wl__i" style="animation:rise 380ms var(--e-out) both;animation-delay:' + (i * 45) + 'ms">' +
      '<span class="wl__tick">' + ico('check') + '</span>' +
      '<div class="wl__b"><div class="wl__t">' + esc(w.t) + '</div>' +
      '<div class="wl__m">' + ico('clock') + esc(w.m) + '</div></div>' +
      '<span class="badge badge--' + (w.tone === 'dang' ? 'danger' : w.tone === 'warn' ? 'pending' : w.tone === 'pos' ? 'live' : 'bronze') + '" style="--x">' + esc(w.due) + '</span>' +
      '</div>').join('');

    $$('.wl__tick', host).forEach((t, i) => {
      t.parentElement.addEventListener('click', () => {
        const row = t.parentElement;
        row.classList.toggle('is-done');
        const w = DATA.work[i];
        if (row.classList.contains('is-done')) toast('Done', w.t, 'ok', { label: 'Undo', run: () => row.classList.remove('is-done') });
      });
    });

    const pipes = [
      ['New', DATA.deals.New.length, 'var(--info)'],
      ['Contacted', DATA.deals.Contacted.length, 'var(--warn)'],
      ['Scheduled', DATA.deals.Scheduled.length, 'var(--bronze)'],
      ['Won', DATA.deals.Won.length, 'var(--pos)']
    ];
    const total = pipes.reduce((s, p) => s + p[1], 0);
    $('#miniPipe').innerHTML = pipes.map(p =>
      '<div><div style="display:flex;font-size:var(--fs-meta);margin-bottom:5px"><span class="mut">' + p[0] +
      '</span><b style="margin-left:auto">' + p[1] + '</b></div>' +
      '<div style="height:6px;border-radius:99px;background:var(--inset);overflow:hidden">' +
      '<i style="display:block;height:100%;border-radius:99px;background:' + p[2] + ';width:0;transition:width 900ms var(--e-out)" data-w="' + (p[1] / total * 100) + '"></i></div></div>'
    ).join('');
    setTimeout(() => $$('#miniPipe i').forEach(i => i.style.width = i.dataset.w + '%'), 120);
  }
};

/* -------------------------------------------------------- B · PROPERTIES */
function statusBadge(s) {
  const m = { Live: 'live', Draft: 'draft', Pending: 'pending', Sold: 'sold' };
  return '<span class="badge badge--' + (m[s] || 'draft') + '"><i class="dot"></i>' + esc(s) + '</span>';
}
function meterFill(p) {
  const k = p >= 85 ? 'is-hi' : p >= 55 ? 'is-mid' : 'is-lo';
  return '<div class="meter"><div class="meter__track"><i class="meter__fill ' + k + '" data-w="' + p + '"></i></div><b>' + p + '%</b></div>';
}

VIEWS.properties = {
  mount(root) {
    const body = $('#propRows');
    const draw = list => {
      body.innerHTML = list.map((p, i) =>
        '<tr style="animation:rise 320ms var(--e-out) both;animation-delay:' + Math.min(i * 28, 240) + 'ms" data-id="' + p.id + '">' +
        '<td><span class="cbrow"><i class="cb" data-rowcb></i></span></td>' +
        '<td><div class="tcell">' +
        '<span class="tthumb" style="background:linear-gradient(140deg,' + p.tone + ',rgba(0,0,0,.16))">' + ico('home') + '</span>' +
        '<span class="tname"><b>' + esc(p.title) + '</b><span>' + p.ref + ' · ' + esc(p.owner) + '</span></span></div></td>' +
        '<td class="num" style="font-weight:600">' + short(p.price) + '</td>' +
        '<td class="mut">' + esc(p.loc) + '</td>' +
        '<td>' + statusBadge(p.status) + '</td>' +
        '<td>' + meterFill(p.pct) + '</td>' +
        '<td><div class="rowacts">' +
        '<button class="iconbtn" data-act="edit" title="Edit">' + ico('edit') + '</button>' +
        '<button class="iconbtn" data-act="dupe" title="Duplicate">' + ico('copy') + '</button>' +
        '<button class="iconbtn is-danger" data-act="bin" title="Move to bin">' + ico('trash') + '</button>' +
        '</div></td></tr>').join('');
      setTimeout(() => $$('.meter__fill', body).forEach(f => f.style.width = f.dataset.w + '%'), 40);
      $$('[data-rowcb]', body).forEach(cb => cb.addEventListener('click', e => {
        e.stopPropagation();
        cb.setAttribute('aria-checked', cb.getAttribute('aria-checked') === 'true' ? 'false' : 'true');
        syncSelectAll();
      }));
    };
    draw(DATA.properties);

    $('#propSearch').addEventListener('input', e => {
      const q = e.target.value.toLowerCase();
      draw(DATA.properties.filter(p => (p.title + p.loc + p.ref).toLowerCase().indexOf(q) >= 0));
    });

    body.addEventListener('click', e => {
      const b = e.target.closest('[data-act]');
      if (b) {
        e.stopPropagation();
        const p = DATA.properties.find(x => x.id == b.closest('tr').dataset.id);
        if (b.dataset.act === 'edit') { go('add-home'); toast('Editing', p.title, 'info'); }
        if (b.dataset.act === 'dupe') toast('Duplicated', p.title + ' copied as a draft', 'ok', { label: 'Undo', run: () => toast('Removed', 'Copy discarded', 'info') });
        if (b.dataset.act === 'bin') {
          const row = b.closest('tr');
          row.style.transition = 'opacity 240ms,transform 240ms';
          row.style.opacity = '0'; row.style.transform = 'translateX(18px)';
          setTimeout(() => { row.remove(); }, 240);
          toast('Moved to bin', p.title, 'warn', { label: 'Restore', run: () => toast('Restored', p.title, 'ok') });
        }
        return;
      }
      const tr = e.target.closest('tr');
      if (tr) openProperty(DATA.properties.find(x => x.id == tr.dataset.id));
    });

    // The header checkbox drives every row checkbox — and back.
    const all = $('[data-selectall]');
    all.addEventListener('click', () => {
      const on = all.getAttribute('aria-checked') !== 'true';
      all.setAttribute('aria-checked', on ? 'true' : 'false');
      $$('[data-rowcb]', body).forEach(cb => cb.setAttribute('aria-checked', on ? 'true' : 'false'));
      syncSelectAll();
    });
    function syncSelectAll() {
      const rows = $$('[data-rowcb]', body);
      const on = rows.filter(r => r.getAttribute('aria-checked') === 'true').length;
      all.setAttribute('aria-checked', on === 0 ? 'false' : on === rows.length ? 'true' : 'mixed');
      const bar = $('#bulkbar');
      bar.classList.toggle('is-on', on > 0);
      $('#bulkN').textContent = on + (on === 1 ? ' property selected' : ' properties selected');
    }
    $('#bulkX').addEventListener('click', () => {
      $$('[data-rowcb]', body).forEach(cb => cb.setAttribute('aria-checked', 'false'));
      all.setAttribute('aria-checked', 'false');
      $('#bulkbar').classList.remove('is-on');
    });
    $$('.bulkbar .btn', $('#bulkbar'))[1].addEventListener('click', () => {
      const n = $$('[data-rowcb]', body).filter(r => r.getAttribute('aria-checked') === 'true').length;
      if (!n) return;
      toast('Moved to bin', n + (n === 1 ? ' property' : ' properties'), 'warn', { label: 'Undo', run: () => toast('Restored', n + ' properties', 'ok') });
      $('#bulkX').click();
    });
  }
};

function openProperty(p) {
  Drawer.open({
    kicker: p.ref + ' · ' + p.kind,
    title: p.title,
    sub: p.loc + ' · ' + short(p.price) + (p.area ? ' · ' + inr(p.area) + ' sq ft' : ''),
    body:
      '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:var(--s2)">' +
      [0, 1, 2].map(i => '<div style="height:96px;border-radius:var(--r-md);background:linear-gradient(140deg,' + p.tone + ',rgba(0,0,0,.18));display:grid;place-items:center;color:rgba(255,255,255,.75)">' + ico('image') + '</div>').join('') +
      '</div>' +
      '<div class="panel panel--pad"><div class="lbl" style="margin-bottom:var(--s3)">Record</div><div class="kv">' +
      '<div class="kv__r"><span>Status</span><b>' + statusBadge(p.status) + '</b></div>' +
      '<div class="kv__r"><span>Price</span><b>' + money(p.price) + '</b></div>' +
      '<div class="kv__r"><span>Area</span><b>' + (p.area ? inr(p.area) + ' sq ft' : '—') + '</b></div>' +
      (p.beds ? '<div class="kv__r"><span>Bedrooms</span><b>' + p.beds + '</b></div>' : '') +
      '<div class="kv__r"><span>In charge</span><b>' + esc(p.owner) + '</b></div>' +
      '<div class="kv__r"><span>Completeness</span><b>' + p.pct + '%</b></div>' +
      '</div></div>' +
      '<div class="panel panel--pad"><div class="lbl" style="margin-bottom:var(--s3)">What is still missing</div>' +
      '<div style="display:grid;gap:var(--s2);font-size:var(--fs-name)">' +
      (p.pct >= 100 ? '<div class="mut">Nothing — this one is complete.</div>' :
        '<div class="wl__i" style="padding:0">' + ico('alert') + '<div class="wl__b"><div class="wl__t">Floor plan not uploaded</div></div></div>' +
        '<div class="wl__i" style="padding:0">' + ico('alert') + '<div class="wl__b"><div class="wl__t">Highlights need two more lines</div></div></div>') +
      '</div></div>',
    foot:
      '<button class="btn btn--ghost" data-nav="add-home">' + ico('edit') + 'Edit</button>' +
      '<button class="btn btn--bronze">' + ico('send') + 'Share with client</button>'
  });
}

/* ---------------------------------------------------------- B2 · ADD HOME */
const AH = { media: 0, hl: ['Corner unit, north-east facing', 'Modular kitchen with chimney', 'Covered parking for two cars'] };
VIEWS['add-home'] = {
  mount() {
    const checks = [
      { k: 'title', l: 'Title written', ok: () => $('#ahTitle').value.trim().length > 4 },
      { k: 'price', l: 'Price entered', ok: () => $('#ahPrice').value.trim().length > 0 },
      { k: 'area', l: 'Area entered', ok: () => $('#ahArea').value.trim().length > 0 },
      { k: 'media', l: 'At least 5 photographs', ok: () => AH.media >= 5 },
      { k: 'hl', l: 'At least 4 highlights', ok: () => AH.hl.length >= 4 },
      { k: 'cover', l: 'Cover photograph chosen', ok: () => AH.media >= 1 }
    ];

    function paint() {
      const ok = checks.filter(c => c.ok()).length;
      const pct = Math.round(ok / checks.length * 100);
      $('#ahPct').textContent = pct + '%';
      const bar = $('#ahBar');
      bar.className = 'meter__fill ' + (pct >= 85 ? 'is-hi' : pct >= 55 ? 'is-mid' : 'is-lo');
      bar.style.width = pct + '%';
      $('#ahChecks').innerHTML = checks.map(c =>
        '<div style="display:flex;align-items:center;gap:var(--s2);font-size:var(--fs-name);color:' + (c.ok() ? 'var(--pos-deep)' : 'var(--ink-3)') + '">' +
        '<span style="width:16px;height:16px;border-radius:99px;display:grid;place-items:center;flex:none;' +
        (c.ok() ? 'background:var(--pos);color:#fff' : 'box-shadow:inset 0 0 0 1.5px var(--line-strong)') + '">' +
        (c.ok() ? '<svg style="width:9px;height:9px"><use href="#i-check"/></svg>' : '') + '</span>' +
        esc(c.l) + '</div>').join('');
    }
    function paintHl() {
      /* Kept deliberately quiet: a small bronze dot, a borderless input and a
         remove button that only shows itself when the row is touched. The big
         tick icons that used to sit here were noise. */
      $('#ahHl').innerHTML = AH.hl.map((h, i) =>
        '<div class="hlrow" style="animation:rise 240ms var(--e-out) both">' +
        '<i class="hlrow__dot"></i>' +
        '<input class="in hlrow__in" value="' + esc(h) + '" data-hl="' + i + '" placeholder="Add a highlight">' +
        '<button class="iconbtn hlrow__x" data-rmhl="' + i + '" aria-label="Remove this line">' + ico('x') + '</button></div>').join('');
      $$('#ahHl [data-hl]').forEach(inp => inp.addEventListener('input', e => { AH.hl[+e.target.dataset.hl] = e.target.value; }));
      $$('#ahHl [data-rmhl]').forEach(b => b.addEventListener('click', () => {
        AH.hl.splice(+b.dataset.rmhl, 1); paintHl(); paint();
      }));
      paint();
    }
    function paintMedia() {
      $('#ahMedia').innerHTML = Array.from({ length: AH.media }).map((_, i) =>
        '<div style="aspect-ratio:4/3;border-radius:var(--r-sm);background:linear-gradient(140deg,#cbb79c,#a89478);' +
        'display:grid;place-items:center;color:rgba(255,255,255,.7);position:relative;animation:rise 300ms var(--e-out) both;animation-delay:' + (i * 40) + 'ms">' +
        ico('image') + (i === 0 ? '<span style="position:absolute;bottom:3px;left:3px;font-size:8px;background:rgba(0,0,0,.55);color:#fff;padding:1px 4px;border-radius:3px">COVER</span>' : '') + '</div>').join('');
    }

    const rate = () => {
      const p = parseFloat(String($('#ahPrice').value).replace(/[^0-9.]/g, ''));
      const a = parseFloat(String($('#ahArea').value).replace(/[^0-9.]/g, ''));
      $('#ahRate').value = (p && a) ? '₹' + inr(Math.round(p / a)) + ' / sq ft' : '';
    };
    ['#ahTitle', '#ahPrice', '#ahArea'].forEach(s => $(s).addEventListener('input', () => { rate(); paint(); }));

    if (!$('#ahHl').dataset.done) {
      $('#ahHl').dataset.done = '1';
      $('#ahAddHl').addEventListener('click', () => { AH.hl.push(''); paintHl(); });
      $('#ahPublish').addEventListener('click', () => {
        const pct = Math.round(checks.filter(c => c.ok()).length / checks.length * 100);
        if (pct < 100) return toast('Not ready yet', pct + '% complete — a few things are still missing', 'warn');
        toast('Published', '3 BHK apartment in Sushant Lok II is live', 'ok', { label: 'View', run: () => go('properties') });
      });
      $('#ahDupDismiss').addEventListener('click', () => {
        $('#ahDupCard').style.transition = 'opacity 240ms,transform 240ms';
        $('#ahDupCard').style.opacity = '0'; $('#ahDupCard').style.transform = 'translateY(-8px)';
        setTimeout(() => $('#ahDupCard').remove(), 240);
        toast('Marked as not a duplicate', 'The sweep will not raise it again', 'ok');
      });
    }
    // Drop zone: files appear one after another, each with its own progress.
    const dz = $('[data-dropzone]', $('#ahMedia').parentElement);
    if (dz && !dz.dataset.done) {
      dz.dataset.done = '1';
      dz.addEventListener('click', () => { AH.media = Math.min(6, AH.media + 2); paintMedia(); paint(); toast('Photographs added', AH.media + ' on this listing', 'ok'); });
      ['dragenter', 'dragover'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.add('is-over'); }));
      ['dragleave', 'drop'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.remove('is-over'); }));
      dz.addEventListener('drop', e => { AH.media = Math.min(24, AH.media + (e.dataTransfer.files.length || 2)); paintMedia(); paint(); toast('Photographs added', 'Drop complete', 'ok'); });
    }
    paintHl(); paintMedia(); paint(); rate();
  }
};

/* ---------------------------------------------------------- C · PROJECTS */
VIEWS.projects = {
  mount() {
    const host = $('#projGrid');
    if (host.dataset.done) return;
    host.dataset.done = '1';
    host.innerHTML = DATA.projects.map((p, i) =>
      '<button class="card card--lift anim" data-p="' + i + '" style="--d:' + (i * 45) + 'ms;text-align:left;padding:0;overflow:hidden">' +
      '<div style="height:130px;background:linear-gradient(140deg,' + p.tone + ',rgba(0,0,0,.22));position:relative">' +
      '<span class="badge badge--' + (p.stage === 'Ready' ? 'live' : p.stage === 'Early' ? 'draft' : 'pending') +
      '" style="position:absolute;top:12px;left:12px;background:rgba(255,255,255,.92)">' + esc(p.stage) + '</span></div>' +
      '<div style="padding:var(--s4)">' +
      '<h3 class="dsp" style="font-size:var(--fs-h3);margin-bottom:2px">' + esc(p.name) + '</h3>' +
      '<div class="mut" style="font-size:var(--fs-meta);margin-bottom:var(--s4)">' + esc(p.builder) + ' · ' + esc(p.loc) + '</div>' +
      '<div style="display:flex;gap:var(--s4)">' +
      '<div><div class="lbl">Total</div><b class="dsp" style="font-size:20px">' + p.total + '</b></div>' +
      '<div><div class="lbl">Available</div><b class="dsp" style="font-size:20px;color:var(--pos-deep)">' + p.avail + '</b></div>' +
      '<div style="margin-left:auto;text-align:right"><div class="lbl">Possession</div><b style="font-size:var(--fs-name)">' + esc(p.poss) + '</b></div>' +
      '</div></div></button>').join('');

    $$('[data-p]', host).forEach(b => b.addEventListener('click', () => {
      const p = DATA.projects[+b.dataset.p];
      const inside = DATA.properties.slice(0, 5);
      Drawer.open({
        wide: true,
        kicker: p.builder + ' · ' + p.loc,
        title: p.name,
        sub: p.stage + ' · possession ' + p.poss,
        body:
          '<div style="display:flex;gap:var(--s4);flex-wrap:wrap">' +
          '<div style="flex:1;min-width:150px"><div class="lbl">Total units</div><b class="dsp" style="font-size:26px">' + p.total + '</b></div>' +
          '<div style="flex:1;min-width:150px"><div class="lbl">Available</div><b class="dsp" style="font-size:26px;color:var(--pos-deep)">' + p.avail + '</b></div>' +
          '<div style="flex:1;min-width:150px"><div class="lbl">Sold out</div><b class="dsp" style="font-size:26px">' + Math.round((1 - p.avail / p.total) * 100) + '%</b></div>' +
          '</div>' +
          '<div class="meter" style="margin-top:-8px"><div class="meter__track"><i class="meter__fill is-hi" data-w="' + Math.round((1 - p.avail / p.total) * 100) + '"></i></div></div>' +
          '<div class="divider"></div>' +
          '<div style="display:flex;align-items:center"><div class="lbl">Properties in this project</div><span class="mut" style="margin-left:auto;font-size:var(--fs-meta)">' + inside.length + ' listed</span></div>' +
          '<div style="display:grid;gap:var(--s2)">' + inside.map((q, i) =>
            '<div class="wl__i" style="border:1px solid var(--line);animation:rise 300ms var(--e-out) both;animation-delay:' + (i * 40) + 'ms">' +
            '<span class="tthumb" style="background:linear-gradient(140deg,' + q.tone + ',rgba(0,0,0,.18));width:38px;height:30px">' + ico('home') + '</span>' +
            '<div class="wl__b"><div class="wl__t">' + esc(q.title) + '</div><div class="wl__m">' + short(q.price) + ' · ' + esc(q.loc) + '</div></div>' +
            statusBadge(q.status) + '</div>').join('') + '</div>',
        foot: '<button class="btn btn--ghost" data-nav="add-home">' + ico('plus') + 'Add a home here</button>' +
          '<button class="btn btn--bronze">' + ico('eye') + 'View on website</button>'
      });
      setTimeout(() => $$('#dwBody .meter__fill').forEach(f => f.style.width = f.dataset.w + '%'), 120);
    }));
  }
};

/* --------------------------------------------------------- D · ENQUIRIES */
VIEWS.enquiries = {
  mount() {
    const body = $('#enqRows');
    if (body.dataset.done) return;
    body.dataset.done = '1';
    body.innerHTML = DATA.leads.map((l, i) =>
      '<tr data-id="' + l.id + '" style="cursor:pointer;animation:rise 320ms var(--e-out) both;animation-delay:' + Math.min(i * 30, 220) + 'ms">' +
      '<td><div class="tcell"><span class="tthumb" style="background:linear-gradient(140deg,var(--bronze-lite),var(--bronze-deep));color:#fff;font-size:11px;font-weight:700">' + initials(l.name) + '</span>' +
      '<span class="tname"><b>' + esc(l.name) + '</b><span>' + esc(l.when) + '</span></span></div></td>' +
      '<td class="mono">' + esc(l.phone) + '</td>' +
      '<td>' + esc(l.prop) + '</td>' +
      '<td><span class="badge badge--bronze">' + esc(l.src) + '</span></td>' +
      '<td><span class="badge badge--' + (l.stage === 'Won' ? 'live' : l.stage === 'Lost' ? 'danger' : l.stage === 'Scheduled' ? 'bronze' : 'pending') + '"><i class="dot"></i>' + esc(l.stage) + '</span></td>' +
      '<td style="color:var(--' + l.tone + ');font-weight:600;font-size:var(--fs-meta)">' + esc(l.next) + '</td>' +
      '<td><div class="rowacts">' +
      '<button class="iconbtn" title="Call">' + ico('phone') + '</button>' +
      '<button class="iconbtn" title="Email">' + ico('mail') + '</button>' +
      '<button class="iconbtn" title="WhatsApp" style="color:var(--pos-deep)">' + ico('wa') + '</button>' +
      '</div></td></tr>').join('');
    body.addEventListener('click', e => {
      if (e.target.closest('.rowacts')) { toast('Calling', 'Dialling from the office number', 'info'); return; }
      const tr = e.target.closest('tr');
      if (tr) openLead(DATA.leads.find(l => l.id == tr.dataset.id));
    });
  }
};

function openLead(l) {
  const tl = [
    { h: 'Enquiry received', p: 'Came in from ' + l.src + '. Interested in ' + l.prop + '.', w: l.when, cls: '' },
    { h: 'First call', p: 'Spoke for six minutes. Budget around ' + l.budget + '. Wants a visit this week.', w: 'Later that day', cls: '' },
    { h: l.stage === 'Won' ? 'Deal won' : 'Follow-up scheduled', p: l.next === '—' ? 'Closed.' : 'Set for ' + l.next + '.', w: 'Most recent', cls: l.stage === 'Won' ? 'is-win' : 'is-now' }
  ];
  Drawer.open({
    kicker: l.src + ' · ' + l.stage,
    title: l.name,
    sub: l.phone + ' · budget ' + l.budget,
    body:
      '<div style="display:flex;gap:var(--s2)">' +
      '<button class="btn btn--ok" style="flex:1">' + ico('phone') + 'Call</button>' +
      '<button class="btn btn--ghost" style="flex:1">' + ico('mail') + 'Email</button>' +
      '<button class="btn btn--ghost" style="flex:1;color:var(--pos-deep)">' + ico('wa') + 'WhatsApp</button>' +
      '</div>' +
      '<div class="panel panel--pad"><div class="lbl" style="margin-bottom:var(--s3)">Schedule the next follow-up</div>' +
      '<div style="display:flex;gap:var(--s2)">' +
      '<input class="in" type="date" value="2025-10-09">' +
      '<select class="in" style="width:130px"><option>11:00 AM</option><option>1:00 PM</option><option>4:00 PM</option><option>6:00 PM</option></select>' +
      '<button class="btn btn--bronze">Set</button></div>' +
      '<div class="field__hint" style="margin-top:var(--s2)">Currently: ' + esc(l.next) + '</div></div>' +
      '<div class="panel panel--pad"><div class="lbl" style="margin-bottom:var(--s3)">Notes</div>' +
      '<textarea class="in" placeholder="Write what you learned on the call…">Very ready to move. Comparing two units in the same society — send both floor plans today.</textarea>' +
      '<button class="btn btn--ghost btn--sm" style="margin-top:var(--s3)">Save note</button></div>' +
      '<div><div class="lbl" style="margin-bottom:var(--s3)">Timeline</div>' +
      '<div class="tl">' + tl.map(t =>
        '<div class="tl__i ' + t.cls + '"><div class="tl__h"><b>' + esc(t.h) + '</b><time>' + esc(t.w) + '</time></div>' +
        '<div class="tl__p">' + esc(t.p) + '</div></div>').join('') + '</div></div>',
    foot: '<button class="btn btn--ghost">' + ico('calendar') + 'Schedule visit</button>' +
      '<button class="btn btn--bronze">' + ico('check') + 'Mark as won</button>'
  });
}
