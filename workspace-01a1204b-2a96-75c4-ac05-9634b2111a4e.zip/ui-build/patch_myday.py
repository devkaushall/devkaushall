#!/usr/bin/env python3
"""Today, laid out the way the approved designs show it."""
P = '/home/user/plugin/estat-os/includes/Pocket/Screens.php'
s = open(P).read()

start = s.index("\tprivate static function my_day(): string {")
end   = s.index("\t/**\n\t * The counts, as chips you can tap. Four separate facts, four doors.")

NEW = r'''	private static function my_day(): string {
		$agent = Pocket::agent_id();
		$user  = wp_get_current_user();

		$summary = \EstatOS\Work\MyDay::summary( $agent );
		$next    = \EstatOS\Work\MyDay::next_action( $agent );
		$tasks   = \EstatOS\Work\MyDay::tasks( $agent, 6 );

		$hour = (int) current_time( 'G' );
		if ( $hour < 12 ) {
			$greeting = __( 'Good morning', 'estat-os' );
		} elseif ( $hour < 17 ) {
			$greeting = __( 'Good afternoon', 'estat-os' );
		} else {
			$greeting = __( 'Good evening', 'estat-os' );
		}

		$first = trim( (string) $user->first_name );
		if ( '' === $first ) {
			$first = (string) $user->display_name;
		}

		/*
		 * Five numbers, in one row: what came in, what is late, what is
		 * booked, what is mine, and what is still sitting with the office.
		 * Each one is a door, so a number is never just a number.
		 */
		$mine     = Pocket::my_records( '', PostTypes::LISTING );
		$waiting  = 0;
		foreach ( (array) $mine as $post ) {
			if ( 'pending' === (string) $post->post_status ) {
				++$waiting;
			}
		}

		$stats = array(
			array( 'inbox', (int) $summary['enquiries'], __( 'New enquiries', 'estat-os' ), Pocket::url( 'leads' ) ),
			array( 'phone', (int) $summary['followups'], __( 'Follow-ups due', 'estat-os' ), Pocket::url( 'leads' ) ),
			array( 'calendar', (int) $summary['visits'], __( 'Site visit today', 'estat-os' ), Pocket::url( 'visits' ) ),
			array( 'buildings', count( (array) $mine ), __( 'Your properties', 'estat-os' ), Pocket::url( 'listings' ) ),
			array( 'clock', $waiting, __( 'Waiting for approval', 'estat-os' ), Pocket::url( 'listings' ) ),
		);

		$stats_out = '<div class="estat-pocket-stats">';
		foreach ( $stats as $stat ) {
			list( $icon, $count, $word, $url ) = $stat;
			$stats_out .= '<a class="estat-pocket-stat" href="' . esc_url( $url ) . '">' . Pocket::icon( $icon, 18 )
				. '<span class="estat-pocket-statnum"><b>' . (int) $count . '</b><i>' . esc_html( $word ) . '</i></span></a>';
		}
		$stats_out .= '</div>';

		/* ----------------------------------------------------- next action */
		$next_out = '';
		if ( $next ) {
			$phone = trim( (string) $next['phone'] );
			$next_out .= '<section class="estat-pocket-next">';
			$next_out .= '<div class="estat-pocket-nexttop">'
				. '<span class="estat-pocket-well">' . Pocket::icon( (string) $next['icon'], 18 ) . '</span>'
				. '<span class="estat-pocket-nexttext"><b>' . esc_html( (string) $next['title'] ) . '</b>'
				. '<i>' . esc_html( (string) $next['detail'] ) . '</i></span></div>';

			if ( '' !== $phone ) {
				$next_out .= '<div class="estat-pocket-nextmeta"><span>'
					. Pocket::icon( 'phone', 14 ) . esc_html( $phone ) . '</span></div>';
			}

			$next_out .= '<div class="estat-pocket-nextacts">';
			if ( '' !== $phone ) {
				$next_out .= '<a class="estat-pocket-btn is-go" href="'
					. esc_attr( 'tel:' . preg_replace( '/[^0-9+]/', '', $phone ) ) . '">'
					. Pocket::icon( 'phone', 14 ) . ' ' . esc_html__( 'Call now', 'estat-os' ) . '</a>';
			}
			$next_out .= '<a class="estat-pocket-btn" href="' . esc_url( (string) $next['url'] ) . '">'
				. esc_html( (string) $next['action'] ) . '</a>';
			$next_out .= '</div></section>';
		} else {
			$next_out .= '<section class="estat-pocket-next"><div class="estat-pocket-nexttop">'
				. '<span class="estat-pocket-well">' . Pocket::icon( 'check-circle', 18 ) . '</span>'
				. '<span class="estat-pocket-nexttext"><b>' . esc_html__( 'Nothing is waiting on you.', 'estat-os' ) . '</b>'
				. '<i>' . esc_html__( 'No enquiry to answer and no visit booked. A good moment to add something new, or check an old listing with its owner.', 'estat-os' ) . '</i></span></div>'
				. '<div class="estat-pocket-nextacts"><a class="estat-pocket-btn is-go" href="'
				. esc_url( Pocket::url( 'capture' ) ) . '">' . Pocket::icon( 'plus', 14 ) . ' '
				. esc_html__( 'Add something new', 'estat-os' ) . '</a></div></section>';
		}

		/* --------------------------------------------------- quick actions */
		$quick = array(
			array( 'plus', __( 'Add property', 'estat-os' ), Pocket::url( 'new' ) ),
			array( 'inbox', __( 'Add enquiry', 'estat-os' ), Pocket::url( 'capture-lead' ) ),
			array( 'calendar', __( 'Book visit', 'estat-os' ), Pocket::url( 'capture-visit' ) ),
			array( 'camera', __( 'Take photos &amp; details', 'estat-os' ), Pocket::url( 'listings' ) ),
			array( 'search', __( 'Search everything', 'estat-os' ), Pocket::url( 'search' ) ),
			array( 'list-checks', __( 'Client requirements', 'estat-os' ), Pocket::url( 'capture-want' ) ),
			array( 'clock', __( 'Waiting to go up', 'estat-os' ), Pocket::url( 'queue' ) ),
			array( 'person', __( 'Your details', 'estat-os' ), Pocket::url( 'you' ) ),
		);

		$quick_out = '<div class="estat-pocket-quick">';
		foreach ( $quick as $act ) {
			list( $icon, $word, $url ) = $act;
			$quick_out .= '<a class="estat-pocket-quickbtn" href="' . esc_url( $url ) . '">'
				. Pocket::icon( $icon, 18 ) . '<span>' . $word . '</span></a>';
		}
		$quick_out .= '</div>';

		/* --------------------------------------------------- today's tasks */
		$rest      = $next ? array_slice( (array) $tasks, 1 ) : (array) $tasks;
		$tasks_out = '';
		foreach ( $rest as $task ) {
			$tasks_out .= '<a class="estat-pocket-taskrow" href="' . esc_url( (string) $task['url'] ) . '">'
				. '<span class="estat-pocket-well">' . Pocket::icon( (string) $task['icon'], 16 ) . '</span>'
				. '<span class="estat-pocket-taskrowtext"><b>' . esc_html( (string) $task['title'] ) . '</b>'
				. '<i>' . esc_html( (string) $task['detail'] ) . '</i></span></a>';
		}
		if ( '' === $tasks_out ) {
			$tasks_out = '<p class="estat-pocket-hint" style="margin:0">' . esc_html__( 'Nothing else is waiting. This list shrinks as you work.', 'estat-os' ) . '</p>';
		}

		/* --------------------------------------------------- today's visits */
		$visits_out = self::day_visits( 3 );

		/* --------------------------------------------- your recent listings */
		$props_out = '';
		$recent    = array_slice( (array) $mine, 0, 3 );
		foreach ( $recent as $post ) {
			$id    = (int) $post->ID;
			$money = trim( (string) get_post_meta( $id, '_estat_price', true ) );
			$props_out .= '<a class="estat-pocket-prop" href="' . esc_url( Pocket::url( 'listing', $id ) ) . '">'
				. '<span class="estat-pocket-propmedia">'
				. ( get_the_post_thumbnail( $id, 'thumbnail' ) ? get_the_post_thumbnail( $id, 'thumbnail' ) : Pocket::icon( 'image', 22 ) )
				. '</span>'
				. '<span class="estat-pocket-taskrowtext"><b>' . esc_html( get_the_title( $id ) ) . '</b>'
				. '<span class="estat-pocket-propfacts"><span>' . Pocket::icon( 'bed', 12 ) . ' '
				. esc_html( '' !== $money ? Format::money( (float) $money ) : __( 'No price yet', 'estat-os' ) )
				. '</span></span></span>'
				. '<span class="estat-pocket-propprice">' . self::standing_pill( $post ) . '</span></a>';
		}
		if ( '' === $props_out ) {
			$props_out = '<p class="estat-pocket-hint" style="margin:0">'
				. esc_html__( 'Nothing here yet. Add starts the first one.', 'estat-os' ) . '</p>';
		}

		/*
		 * On a phone and a tablet there is no rail, so the quieter places
		 * live in a block at the foot of Today. The rail owns them on a
		 * computer, and CSS hides this there.
		 */
		$more_rows = array(
			array( 'search', __( 'Search everything', 'estat-os' ), Pocket::url( 'search' ) ),
			array( 'menu', __( 'Waiting for you', 'estat-os' ), Pocket::url( 'more' ) ),
			array( 'clock', __( 'Waiting to go up', 'estat-os' ), Pocket::url( 'queue' ) ),
			array( 'buildings', __( 'Societies & projects', 'estat-os' ), add_query_arg( 'show', 'societies', Pocket::url( 'listings' ) ) ),
			array( 'person', __( 'Your details', 'estat-os' ), Pocket::url( 'you' ) ),
		);
		$more_out = '';
		foreach ( $more_rows as $row ) {
			list( $icon, $word, $url ) = $row;
			$more_out .= '<a class="estat-pocket-taskrow" href="' . esc_url( $url ) . '">'
				. '<span class="estat-pocket-well">' . Pocket::icon( $icon, 16 ) . '</span>'
				. '<span class="estat-pocket-taskrowtext"><b>' . esc_html( $word ) . '</b></span></a>';
		}

		$main  = '<p class="estat-pocket-greet">' . esc_html( $greeting . ', ' . $first ) . '</p>';
		$main .= '<p class="estat-pocket-daymeta"><span>' . Pocket::icon( 'calendar', 14 )
			. esc_html( date_i18n( 'D, j M Y' ) ) . '</span></p>';
		$main .= '<p class="estat-pocket-daylead">' . esc_html__( 'Here is your work for today', 'estat-os' ) . '</p>';
		$main .= $stats_out . $next_out;
		$main .= self::block( __( 'Quick actions', 'estat-os' ), $quick_out );
		$main .= self::block( __( "Today's tasks", 'estat-os' ), $tasks_out );

		$aside  = self::block( __( "Today's visits", 'estat-os' ), $visits_out, Pocket::url( 'visits' ), __( 'See all', 'estat-os' ) );
		$aside .= self::block( __( 'Your recent properties', 'estat-os' ), $props_out, Pocket::url( 'listings' ), __( 'See all', 'estat-os' ) );
		$aside .= '<div class="estat-pocket-moreblock">'
			. self::block( __( 'More', 'estat-os' ), $more_out ) . '</div>';

		return '<div class="estat-pocket-day"><div class="estat-pocket-daymain">' . $main
			. '</div><div class="estat-pocket-dayaside">' . $aside . '</div></div>';
	}

	/**
	 * One card with a heading, and somewhere to go for the rest of it.
	 *
	 * @param string $title Words on the heading.
	 * @param string $body  What is inside.
	 * @param string $url   Where "see all" goes; empty for none.
	 * @param string $link  Words on that link.
	 * @return string
	 */
	private static function block( string $title, string $body, string $url = '', string $link = '' ): string {
		$head = '<div class="estat-pocket-blockhead"><h3>' . esc_html( $title ) . '</h3>';
		if ( '' !== $url && '' !== $link ) {
			$head .= '<a class="estat-pocket-blocklink" href="' . esc_url( $url ) . '">' . esc_html( $link ) . '</a>';
		}
		return '<section class="estat-pocket-block">' . $head . '</div>' . $body . '</section>';
	}

	/**
	 * Where a record stands, as a pill.
	 *
	 * @param \WP_Post $post Record.
	 * @return string
	 */
	private static function standing_pill( \WP_Post $post ): string {
		list( $label, $tone ) = Pocket::status_of( $post );
		if ( '' === $label ) {
			return '';
		}
		return '<span class="estat-pocket-pill' . ( '' !== $tone ? ' is-' . $tone : '' ) . '">' . esc_html( $label ) . '</span>';
	}

	/**
	 * Today's visits, three or four lines of them, for the side column.
	 *
	 * @param int $limit How many.
	 * @return string
	 */
	private static function day_visits( int $limit = 3 ): string {
		if ( ! current_user_can( 'estat_manage_visits' ) ) {
			return '<p class="estat-pocket-hint" style="margin:0">'
				. esc_html__( 'Site visits are not part of your work here.', 'estat-os' ) . '</p>';
		}

		$scope = Pocket::is_office() ? array() : array( 'agent_id' => Pocket::agent_id() );
		$now   = current_time( 'timestamp', true );

		$found = Visits::query(
			array_merge(
				$scope,
				array(
					'from'     => gmdate( 'Y-m-d H:i:s', $now - 3 * HOUR_IN_SECONDS ),
					'per_page' => $limit,
				)
			)
		);

		$out = '';
		$had = 0;
		foreach ( (array) ( $found['items'] ?? array() ) as $visit ) {
			$lead  = (int) $visit['lead_id'] > 0 ? Leads::get( (int) $visit['lead_id'] ) : null;
			$name  = $lead ? trim( (string) $lead['name'] ) : '';
			$name  = '' !== $name ? $name : __( 'Client', 'estat-os' );
			$where = (int) $visit['listing_id'] > 0 ? (string) get_the_title( (int) $visit['listing_id'] ) : '';

			$outcome = (string) $visit['outcome'];
			$word    = Status::label( Status::VISIT, $outcome );
			$tone    = Status::tone( Status::VISIT, $outcome );
			++$had;

			$out .= '<a class="estat-pocket-visitrow" href="' . esc_url( Pocket::url( 'visit', (int) $visit['id'] ) ) . '">'
				. '<span class="estat-pocket-visitwhen">' . esc_html( Format::time( (string) $visit['scheduled_at'] ) ) . '</span>'
				. '<span class="estat-pocket-taskrowtext"><b>' . esc_html( $name ) . '</b><i>' . esc_html( $where ) . '</i></span>'
				. '<span class="estat-pocket-pill' . ( '' !== $tone ? ' is-' . $tone : '' ) . '">' . esc_html( $word ) . '</span></a>';
		}

		if ( $had < 1 ) {
			return '<p class="estat-pocket-hint" style="margin:0">'
				. esc_html__( 'No visit booked for today.', 'estat-os' ) . '</p>';
		}

		return $out;
	}

'''

s = s[:start] + NEW + s[end:]
open(P, 'w').write(s)
print('written', len(s))
