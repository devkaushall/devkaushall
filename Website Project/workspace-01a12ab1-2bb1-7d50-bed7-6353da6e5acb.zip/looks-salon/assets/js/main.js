/* LOOKS SALON — concept demo · interactions */
(function () {
  "use strict";
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => [...c.querySelectorAll(s)];
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ================= DATA ================= */
  const SERVICES = [
    { id: "hair", num: "01", title: "Hair Cut & Styling", img: "assets/img/svc-hair.jpg",
      teaser: "Precision cuts and blowouts by award-winning stylists.",
      desc: "From sharp precision cuts to soft, lived-in shapes — every cut begins with a consultation and ends with a styled finish.",
      items: ["Advanced cuts — ladies & gents", "Blow-dry & finish", "Hair spa rituals", "Olaplex-style bond care*", "Head massage", "Styling for occasions"] },
    { id: "colour", num: "02", title: "Colour & Highlights", img: "assets/img/svc-colour.jpg",
      teaser: "Global colour, balayage and creative dimension.",
      desc: "Dimensional colour crafted with professional-grade products from partners like L'Oréal Professionnel and Redken.",
      items: ["Global colour", "Balayage & ombré", "Global highlights", "Creative / fashion colour", "Root touch-up", "Toning & gloss"] },
    { id: "keratin", num: "03", title: "Keratin & Texture", img: "assets/img/hero.jpg",
      teaser: "Smoothening, keratin and lasting frizz control.",
      desc: "Texture services that tame frizz and add mirror gloss — tailored to your hair type after a strand consultation.",
      items: ["Keratin treatment", "Smoothening", "Rebonding", "Brasil Cacau ritual", "Deep repair masques", "Aftercare guidance"] },
    { id: "skin", num: "04", title: "Skin & Facials", img: "assets/img/svc-skin.jpg",
      teaser: "Facials and skincare with professional-grade lines.",
      desc: "Skin rituals using professional ranges like Dermalogica — mapped to your skin after analysis.",
      items: ["Signature facials", "Clean-ups", "Threading", "Waxing — full body", "De-tan rituals", "Under-eye & lip care"] },
    { id: "makeup", num: "05", title: "Makeup", img: "assets/img/svc-makeup.jpg",
      teaser: "Bridal, occasion and soft-glam artistry.",
      desc: "From airbrushed bridal looks to subtle everyday glam — artistry tailored to the light you'll be seen in.",
      items: ["Bridal makeup", "Engagement & reception", "Party / soft glam", "Saree draping & styling", "Trial sessions", "Groom makeovers"] },
    { id: "grooming", num: "06", title: "Men's Grooming", img: "assets/img/svc-grooming.jpg",
      teaser: "Cuts, beards and classic grooming for gentlemen.",
      desc: "A dedicated menu for men — classic and trend-led cuts, beard sculpting and skin basics, done properly.",
      items: ["Classic & trend cuts", "Beard styling & shave", "Hair colour for men", "Scalp treatments", "Men's facials", "Express grooming"] },
  ];

  const BRANCHES = [
    { city: "delhi", cityLabel: "New Delhi", name: "Karol Bagh — The Original", addr: "17A/22, WEA Ajmal Khan Road, Karol Bagh, New Delhi — 110005", tel: "+91 99535 33412", hours: "10:00 AM – 7:30 PM" },
    { city: "delhi", cityLabel: "New Delhi", name: "Ambience Mall, Vasant Kunj", addr: "G8–G10, Ground Floor, Ambience Mall, Vasant Kunj, New Delhi — 110070", tel: "1800 212 56657", hours: "10:00 AM – 9:00 PM" },
    { city: "delhi", cityLabel: "New Delhi", name: "Vasant Kunj — Presidential Park", addr: "Unit G1, Tower 5, Pawa Presidential Business Park, C-9, Vasant Kunj, New Delhi — 110070", tel: "+91 93551 02022", hours: "10:00 AM – 9:00 PM" },
    { city: "delhi", cityLabel: "Gurugram", name: "Vista Square, Sector 82A", addr: "S-201–204, Second Floor, Vista Square, Sector 82A, Gurugram — 122001", tel: "+91 92183 01614", hours: "10:00 AM – 9:00 PM" },
    { city: "mumbai", cityLabel: "Mumbai", name: "Grand Hyatt Mumbai", addr: "Lobby Level, Grand Hyatt, Off Western Express Highway, Santacruz (E), Mumbai — 400055", tel: "+91 91373 66133", hours: "10:00 AM – 9:00 PM" },
    { city: "bengaluru", cityLabel: "Bengaluru", name: "Vega City Mall, Bannerghatta Rd", addr: "SF-10, Second Floor, Vega City Mall, Bannerghatta Road, Bengaluru — 560046", tel: "+91 97411 18304", hours: "10:00 AM – 9:00 PM" },
  ];

  const GALLERY = [
    { img: "assets/img/hero.jpg", cat: "hair", cap: "Gloss blowout — editorial finish" },
    { img: "assets/img/svc-colour.jpg", cat: "hair", cap: "Caramel balayage in progress" },
    { img: "assets/img/svc-hair.jpg", cat: "hair", cap: "Precision cutting at the chair" },
    { img: "assets/img/gal-bridal.jpg", cat: "makeup", cap: "Bridal updo & maang tikka styling" },
    { img: "assets/img/svc-makeup.jpg", cat: "makeup", cap: "Golden-hour soft glam" },
    { img: "assets/img/svc-grooming.jpg", cat: "grooming", cap: "Beard sculpting, gentleman's ritual" },
    { img: "assets/img/svc-skin.jpg", cat: "skin", cap: "Radiance facial ritual" },
    { img: "assets/img/svc-nails.jpg", cat: "skin", cap: "Champagne manicure detail" },
    { img: "assets/img/gal-interior.jpg", cat: "space", cap: "Concept salon interior" },
  ];

  const BA_PAIRS = [
    { before: "assets/img/ba1-before.jpg", after: "assets/img/ba1-after.jpg",
      beforeAlt: "Before: dull, flat hair tone", afterAlt: "After: glossy, dimensional colour finish",
      title: "The Colour & Gloss Ritual",
      steps: [
        ["Consultation", "Tone mapping against skin undertone & lifestyle"],
        ["Colour & dimension", "Professional-grade colour with bond protection"],
        ["Gloss & finish", "Toning gloss, blow-dry and styled finish"],
      ] },
    { before: "assets/img/ba2-before.jpg", after: "assets/img/ba2-after.jpg",
      beforeAlt: "Before: muted, unfinished look", afterAlt: "After: luminous bridal glam",
      title: "The Bridal Glam Ritual",
      steps: [
        ["Trial & moodboard", "Look planning around outfit, venue and light"],
        ["Skin prep & base", "Long-wear base built for photographs"],
        ["Hair & finishing", "Updo, dupatta set and final touch-ups"],
      ] },
  ];

  /* ================= HEADER ================= */
  const header = $("#siteHeader");
  const onScrollHeader = () => header.classList.toggle("scrolled", window.scrollY > 24);
  window.addEventListener("scroll", onScrollHeader, { passive: true });
  onScrollHeader();

  const navToggle = $("#navToggle");
  const mainNav = $("#mainNav");
  const setNav = (open) => {
    mainNav.classList.toggle("open", open);
    navToggle.setAttribute("aria-expanded", String(open));
    navToggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    document.body.classList.toggle("no-scroll", open);
  };
  navToggle.addEventListener("click", () => setNav(!mainNav.classList.contains("open")));
  $$("a", mainNav).forEach(a => a.addEventListener("click", () => setNav(false)));

  /* active link on scroll */
  const sections = ["story", "services", "transformations", "gallery", "locations", "contact"];
  const navLinks = $$(".main-nav a");
  const spy = new IntersectionObserver((ents) => {
    ents.forEach(e => {
      if (e.isIntersecting) {
        navLinks.forEach(a => a.classList.toggle("active", a.getAttribute("href") === "#" + e.target.id));
      }
    });
  }, { rootMargin: "-40% 0px -55% 0px" });
  sections.forEach(id => { const el = document.getElementById(id); if (el) spy.observe(el); });

  /* ================= REVEAL ON SCROLL ================= */
  const revealIO = new IntersectionObserver((ents) => {
    ents.forEach(e => { if (e.isIntersecting) { e.target.classList.add("in"); revealIO.unobserve(e.target); } });
  }, { threshold: 0.12 });
  $$(".reveal").forEach(el => revealIO.observe(el));

  /* ================= COUNT-UP STATS ================= */
  const counters = $$("[data-count]");
  const countIO = new IntersectionObserver((ents) => {
    ents.forEach(e => {
      if (!e.isIntersecting) return;
      countIO.unobserve(e.target);
      const el = e.target, target = +el.dataset.count, suffix = el.dataset.suffix || "";
      if (reduceMotion) { el.textContent = target + suffix; return; }
      const t0 = performance.now(), dur = 1600;
      const tick = (t) => {
        const p = Math.min((t - t0) / dur, 1);
        el.textContent = Math.round(target * (1 - Math.pow(1 - p, 3))) + suffix;
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    });
  }, { threshold: 0.6 });
  counters.forEach(el => countIO.observe(el));

  /* ================= HERO PARALLAX ================= */
  const heroImg = $("#heroMedia img");
  if (!reduceMotion && heroImg) {
    window.addEventListener("scroll", () => {
      const y = window.scrollY;
      if (y < window.innerHeight) heroImg.style.translate = `0 ${y * 0.18}px`;
    }, { passive: true });
  }

  /* ================= SERVICES ================= */
  const grid = $("#serviceGrid");
  const detail = $("#serviceDetail");
  SERVICES.forEach(s => {
    const btn = document.createElement("button");
    btn.className = "svc-card reveal";
    btn.setAttribute("aria-label", `${s.title} — view details`);
    btn.innerHTML = `
      <img src="${s.img}" alt="" loading="lazy" />
      <div class="svc-card-body">
        <span class="svc-num">${s.num}</span>
        <h3>${s.title}</h3>
        <p>${s.teaser}</p>
        <span class="svc-more">What's included</span>
      </div>`;
    btn.addEventListener("click", () => openDetail(s));
    grid.appendChild(btn);
    revealIO.observe(btn);
  });

  function openDetail(s) {
    $("#detailImg").src = s.img;
    $("#detailImg").alt = s.title;
    $("#detailKicker").textContent = "Ritual " + s.num;
    $("#detailTitle").textContent = s.title;
    $("#detailDesc").textContent = s.desc;
    $("#detailList").innerHTML = s.items.map(i => `<li>${i}</li>`).join("");
    detail.hidden = false;
    detail.scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth", block: "nearest" });
    $("#detailClose").focus({ preventScroll: true });
  }
  $("#detailClose").addEventListener("click", () => { detail.hidden = true; });

  /* ================= BEFORE / AFTER SLIDER ================= */
  const slider = $("#baSlider"), handle = $("#baHandle"), beforeWrap = $("#baBeforeWrap");
  const beforeImg = $("#baBefore"), afterImg = $("#baAfter");
  let baPos = 50;

  function setBA(p) {
    baPos = Math.max(2, Math.min(98, p));
    beforeWrap.style.width = baPos + "%";
    handle.style.left = baPos + "%";
    handle.setAttribute("aria-valuenow", Math.round(baPos));
  }
  function syncBeforeImg() { beforeImg.style.width = slider.getBoundingClientRect().width + "px"; }
  window.addEventListener("resize", syncBeforeImg);
  // initial sync once images load
  if (afterImg.complete) syncBeforeImg(); else afterImg.addEventListener("load", syncBeforeImg);
  setBA(50);

  function posFromEvent(ev) {
    const r = slider.getBoundingClientRect();
    const x = (ev.touches ? ev.touches[0].clientX : ev.clientX) - r.left;
    return (x / r.width) * 100;
  }
  let dragging = false;
  const start = (ev) => { dragging = true; setBA(posFromEvent(ev)); };
  const move = (ev) => { if (dragging) { setBA(posFromEvent(ev)); ev.preventDefault(); } };
  const end = () => { dragging = false; };
  slider.addEventListener("pointerdown", (e) => { slider.setPointerCapture(e.pointerId); start(e); });
  slider.addEventListener("pointermove", move);
  slider.addEventListener("pointerup", end);
  slider.addEventListener("pointercancel", end);
  handle.addEventListener("keydown", (e) => {
    if (e.key === "ArrowLeft") { setBA(baPos - 4); e.preventDefault(); }
    if (e.key === "ArrowRight") { setBA(baPos + 4); e.preventDefault(); }
    if (e.key === "Home") { setBA(2); e.preventDefault(); }
    if (e.key === "End") { setBA(98); e.preventDefault(); }
  });

  $$(".ba-tab").forEach(tab => {
    tab.addEventListener("click", () => {
      $$(".ba-tab").forEach(t => { t.classList.remove("active"); t.setAttribute("aria-selected", "false"); });
      tab.classList.add("active");
      tab.setAttribute("aria-selected", "true");
      const pair = BA_PAIRS[+tab.dataset.pair];
      afterImg.src = pair.after; afterImg.alt = pair.afterAlt;
      beforeImg.src = pair.before; beforeImg.alt = pair.beforeAlt;
      setBA(50);
      beforeImg.addEventListener("load", syncBeforeImg, { once: true });
      $("#baAsideTitle").textContent = pair.title;
      $("#baAsideSteps").innerHTML = pair.steps
        .map(([t, d]) => `<li><strong>${t}</strong><span>${d}</span></li>`).join("");
    });
  });

  /* ================= GALLERY ================= */
  const galGrid = $("#galleryGrid");
  let lbIndex = 0, visibleItems = [];
  GALLERY.forEach((g, i) => {
    const b = document.createElement("button");
    b.className = "gal-item";
    b.dataset.cat = g.cat;
    b.dataset.cap = g.cap;
    b.dataset.index = i;
    b.setAttribute("aria-label", `Open image: ${g.cap}`);
    b.innerHTML = `<img src="${g.img}" alt="${g.cap}" loading="lazy" />`;
    b.addEventListener("click", () => openLightbox(i));
    galGrid.appendChild(b);
  });

  $$(".filter-bar .chip").forEach(chip => {
    chip.addEventListener("click", () => {
      $$(".filter-bar .chip").forEach(c => c.classList.remove("active"));
      chip.classList.add("active");
      const f = chip.dataset.filter;
      $$(".gal-item", galGrid).forEach(item => {
        const show = f === "all" || item.dataset.cat === f;
        item.classList.toggle("hide", !show);
        item.classList.remove("appear");
        if (show) { void item.offsetWidth; item.classList.add("appear"); }
      });
    });
  });

  /* ================= LIGHTBOX ================= */
  const lightbox = $("#lightbox"), lbImg = $("#lbImg"), lbCap = $("#lbCap");
  let lastFocus = null;

  function currentVisible() {
    return $$(".gal-item:not(.hide)", galGrid).map(el => +el.dataset.index);
  }
  function openLightbox(i) {
    visibleItems = currentVisible();
    lbIndex = Math.max(0, visibleItems.indexOf(i));
    lastFocus = document.activeElement;
    renderLb();
    lightbox.hidden = false;
    document.body.classList.add("no-scroll");
    $("#lbClose").focus();
  }
  function renderLb() {
    const g = GALLERY[visibleItems[lbIndex]];
    lbImg.src = g.img; lbImg.alt = g.cap; lbCap.textContent = g.cap;
  }
  function closeLightbox() {
    lightbox.hidden = true;
    document.body.classList.remove("no-scroll");
    if (lastFocus) lastFocus.focus();
  }
  const lbStep = (d) => { lbIndex = (lbIndex + d + visibleItems.length) % visibleItems.length; renderLb(); };
  $("#lbClose").addEventListener("click", closeLightbox);
  $("#lbPrev").addEventListener("click", () => lbStep(-1));
  $("#lbNext").addEventListener("click", () => lbStep(1));
  lightbox.addEventListener("click", (e) => { if (e.target === lightbox) closeLightbox(); });
  document.addEventListener("keydown", (e) => {
    if (lightbox.hidden) return;
    if (e.key === "Escape") closeLightbox();
    if (e.key === "ArrowLeft") lbStep(-1);
    if (e.key === "ArrowRight") lbStep(1);
  });

  /* ================= LOCATIONS ================= */
  const locGrid = $("#locGrid");
  BRANCHES.forEach(b => {
    const card = document.createElement("article");
    card.className = "loc-card";
    card.dataset.city = b.city;
    card.innerHTML = `
      <span class="loc-city">${b.cityLabel}</span>
      <h3>${b.name}</h3>
      <address>${b.addr}</address>
      <div class="loc-meta">
        <a href="tel:${b.tel.replace(/\s/g, "")}">${b.tel}</a>
        <span>${b.hours}</span>
      </div>`;
    locGrid.appendChild(card);
  });
  $$(".city-bar .chip").forEach(chip => {
    chip.addEventListener("click", () => {
      $$(".city-bar .chip").forEach(c => c.classList.remove("active"));
      chip.classList.add("active");
      const c = chip.dataset.city;
      $$(".loc-card", locGrid).forEach(card => {
        const show = c === "all" || card.dataset.city === c;
        card.classList.toggle("hide", !show);
        card.classList.remove("appear");
        if (show) { void card.offsetWidth; card.classList.add("appear"); }
      });
    });
  });

  /* ================= BOOKING MODAL ================= */
  const modal = $("#bookingModal");
  const modalBox = $(".modal", modal);
  let bmStep = 1, bmSlot = null, bmLastFocus = null;

  const CITY_BRANCHES = {};
  BRANCHES.forEach(b => {
    const key = b.cityLabel;
    (CITY_BRANCHES[key] = CITY_BRANCHES[key] || []).push(b.name);
  });
  const citySel = $("#bmCity"), branchSel = $("#bmBranch");
  Object.keys(CITY_BRANCHES).forEach(c => {
    const o = document.createElement("option"); o.value = c; o.textContent = c; citySel.appendChild(o);
  });
  const oOther = document.createElement("option");
  oOther.value = "Other city"; oOther.textContent = "Other city (160+ salons)";
  citySel.appendChild(oOther);

  citySel.addEventListener("change", () => {
    branchSel.innerHTML = "";
    const list = CITY_BRANCHES[citySel.value] || ["Nearest Looks Salon (we'll confirm)"];
    branchSel.disabled = !citySel.value;
    branchSel.innerHTML = citySel.value
      ? list.map(n => `<option value="${n}">${n}</option>`).join("")
      : `<option value="">Select city first…</option>`;
  });

  /* date min = today */
  const dateInput = $("#bmDate");
  const today = new Date();
  const iso = (d) => d.toISOString().slice(0, 10);
  dateInput.min = iso(today);
  const maxD = new Date(today); maxD.setDate(maxD.getDate() + 30);
  dateInput.max = iso(maxD);

  /* time slots (simulated availability — deterministic pseudo-random) */
  const slotGrid = $("#bmSlots");
  function buildSlots() {
    slotGrid.innerHTML = "";
    bmSlot = null;
    const seedStr = (dateInput.value || "none") + (branchSel.value || "");
    let seed = [...seedStr].reduce((a, c) => a + c.charCodeAt(0), 7);
    for (let h = 10; h <= 20; h++) {
      for (const m of [0, 30]) {
        if (h === 20 && m === 30) continue;
        seed = (seed * 9301 + 49297) % 233280;
        const busy = (seed / 233280) < 0.3;
        const label = `${((h + 11) % 12) + 1}:${m === 0 ? "00" : "30"} ${h < 12 ? "AM" : "PM"}`;
        const b = document.createElement("button");
        b.type = "button"; b.className = "slot"; b.textContent = label; b.disabled = busy;
        b.addEventListener("click", () => {
          $$(".slot", slotGrid).forEach(s => s.classList.remove("picked"));
          b.classList.add("picked");
          bmSlot = label;
        });
        slotGrid.appendChild(b);
      }
    }
  }
  dateInput.addEventListener("change", buildSlots);
  branchSel.addEventListener("change", buildSlots);
  buildSlots();

  function showStep(n) {
    bmStep = n;
    $$(".bm-step", modal).forEach(f => { f.hidden = +f.dataset.step !== n; });
    $$("#bmSteps li").forEach(li => {
      const s = +li.dataset.step;
      li.classList.toggle("active", s === n);
      li.classList.toggle("done", s < n);
    });
    $$(".bm-error", modal).forEach(e => e.hidden = true);
    $("#bmBack").hidden = n === 1 || n === 4;
    $("#bmNav").style.display = n === 4 ? "none" : "flex";
    $("#bmNext").textContent = n === 3 ? "Request appointment" : "Continue";
    $("#bmSteps").style.display = n === 4 ? "none" : "flex";
  }

  function validateStep(n) {
    if (n === 1) return $$("input[name='svc']:checked", modal).length > 0;
    if (n === 2) return citySel.value && branchSel.value && dateInput.value && bmSlot;
    if (n === 3) {
      const name = $("#bmName").value.trim();
      const phone = $("#bmPhone").value.replace(/\D/g, "");
      return name.length >= 2 && /^[6-9]\d{9}$/.test(phone);
    }
    return true;
  }

  $("#bmNext").addEventListener("click", () => {
    if (!validateStep(bmStep)) {
      $(`.bm-error[data-err='${bmStep}']`, modal).hidden = false;
      return;
    }
    if (bmStep < 3) { showStep(bmStep + 1); return; }
    /* "submit" — simulated */
    const svcs = $$("input[name='svc']:checked", modal).map(i => i.value).join(", ");
    const d = new Date(dateInput.value + "T00:00:00");
    const dateNice = d.toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long" });
    $("#bmSummary").innerHTML =
      `<strong>${$("#bmName").value.trim()}</strong>, your request for <strong>${svcs}</strong> at ` +
      `<strong>${branchSel.value}</strong>, ${citySel.value} on <strong>${dateNice}, ${bmSlot}</strong> has been noted in this demo.`;
    showStep(4);
  });
  $("#bmBack").addEventListener("click", () => showStep(Math.max(1, bmStep - 1)));
  $("#bmDone").addEventListener("click", closeBooking);

  function openBooking() {
    bmLastFocus = document.activeElement;
    modal.hidden = false;
    document.body.classList.add("no-scroll");
    showStep(1);
    $("#bmClose").focus();
  }
  function closeBooking() {
    modal.hidden = true;
    document.body.classList.remove("no-scroll");
    $("#bmForm").reset();
    branchSel.disabled = true;
    branchSel.innerHTML = `<option value="">Select city first…</option>`;
    buildSlots();
    if (bmLastFocus) bmLastFocus.focus();
  }
  $$("[data-open-booking]").forEach(b => b.addEventListener("click", () => { setNav(false); openBooking(); }));
  $("#bmClose").addEventListener("click", closeBooking);
  modal.addEventListener("click", (e) => { if (e.target === modal) closeBooking(); });
  document.addEventListener("keydown", (e) => {
    if (!modal.hidden && e.key === "Escape") closeBooking();
  });

  /* focus trap for modal + lightbox */
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Tab") return;
    const ctx = !modal.hidden ? modalBox : (!lightbox.hidden ? lightbox : null);
    if (!ctx) return;
    const focusables = $$("button, a[href], input, select, textarea, [tabindex]:not([tabindex='-1'])", ctx)
      .filter(el => !el.disabled && el.offsetParent !== null);
    if (!focusables.length) return;
    const first = focusables[0], last = focusables[focusables.length - 1];
    if (e.shiftKey && document.activeElement === first) { last.focus(); e.preventDefault(); }
    else if (!e.shiftKey && document.activeElement === last) { first.focus(); e.preventDefault(); }
  });

  /* prevent Enter submitting the form accidentally */
  $("#bmForm").addEventListener("submit", (e) => e.preventDefault());
})();
