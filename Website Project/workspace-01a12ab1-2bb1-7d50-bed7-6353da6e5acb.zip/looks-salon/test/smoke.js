/* Headless functional smoke test (jsdom) */
const fs = require("fs");
const path = require("path");
const { JSDOM } = require("jsdom");

const root = path.join(__dirname, "..");
const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
const js = fs.readFileSync(path.join(root, "assets/js/main.js"), "utf8");

const errors = [];
const dom = new JSDOM(html, { url: "http://localhost:8080/", runScripts: "outside-only", pretendToBeVisual: true });
const { window } = dom;
const { document } = window;

/* --- stubs jsdom lacks --- */
window.matchMedia = () => ({ matches: false, addListener() {}, removeListener() {} });
window.IntersectionObserver = class { constructor(cb) { this.cb = cb; } observe() {} unobserve() {} disconnect() {} };
window.HTMLElement.prototype.scrollIntoView = function () {};
window.HTMLElement.prototype.setPointerCapture = function () {};
window.requestAnimationFrame = (f) => setTimeout(f, 0);

let pass = 0, failcnt = 0;
const t = (name, cond) => { if (cond) { pass++; } else { failcnt++; console.log("  ✗ FAIL:", name); } };

try {
  window.eval(js);
} catch (e) {
  console.log("RUNTIME ERROR:", e.message);
  process.exit(1);
}

/* structure injected by JS */
t("6 service cards rendered", document.querySelectorAll("#serviceGrid .svc-card").length === 6);
t("9 gallery items rendered", document.querySelectorAll("#galleryGrid .gal-item").length === 9);
t("6 location cards rendered", document.querySelectorAll("#locGrid .loc-card").length === 6);
t("time slots generated", document.querySelectorAll("#bmSlots .slot").length === 21);
t("city options populated", document.querySelectorAll("#bmCity option").length >= 4);

/* service detail */
document.querySelector("#serviceGrid .svc-card").click();
t("service detail opens", document.getElementById("serviceDetail").hidden === false);
t("detail list has items", document.querySelectorAll("#detailList li").length === 6);
document.getElementById("detailClose").click();
t("service detail closes", document.getElementById("serviceDetail").hidden === true);

/* gallery filter */
const groomChip = document.querySelector("[data-filter='grooming']");
groomChip.click();
const visible = [...document.querySelectorAll(".gal-item")].filter(i => !i.classList.contains("hide"));
t("grooming filter shows 1 item", visible.length === 1);
document.querySelector("[data-filter='all']").click();
t("all filter restores 9", [...document.querySelectorAll(".gal-item")].filter(i => !i.classList.contains("hide")).length === 9);

/* lightbox */
document.querySelectorAll("#galleryGrid .gal-item")[2].click();
t("lightbox opens", document.getElementById("lightbox").hidden === false);
const cap1 = document.getElementById("lbCap").textContent;
document.getElementById("lbNext").click();
t("lightbox next changes image", document.getElementById("lbCap").textContent !== cap1);
window.document.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
t("Esc closes lightbox", document.getElementById("lightbox").hidden === true);

/* location filter */
document.querySelector("[data-city='mumbai']").click();
t("mumbai filter shows 1 branch", [...document.querySelectorAll(".loc-card")].filter(c => !c.classList.contains("hide")).length === 1);
document.querySelector("[data-city='all']").click();

/* booking flow */
document.querySelector(".hero-ctas [data-open-booking]").click();
t("booking modal opens", document.getElementById("bookingModal").hidden === false);
document.getElementById("bmNext").click();
t("step1 validation blocks empty", document.querySelector(".bm-error[data-err='1']").hidden === false);
document.querySelector("input[name='svc']").click();
document.getElementById("bmNext").click();
t("advances to step 2", document.querySelector(".bm-step[data-step='2']").hidden === false);

const citySel = document.getElementById("bmCity");
citySel.value = "New Delhi";
citySel.dispatchEvent(new window.Event("change", { bubbles: true }));
t("branches populate for Delhi", document.querySelectorAll("#bmBranch option").length === 3);
const dateIn = document.getElementById("bmDate");
dateIn.value = dateIn.min;
dateIn.dispatchEvent(new window.Event("change", { bubbles: true }));
const freeSlot = [...document.querySelectorAll("#bmSlots .slot")].find(s => !s.disabled);
t("free slots exist", !!freeSlot);
freeSlot.click();
t("slot picks", freeSlot.classList.contains("picked"));
document.getElementById("bmNext").click();
t("advances to step 3", document.querySelector(".bm-step[data-step='3']").hidden === false);

document.getElementById("bmNext").click();
t("step3 validation blocks empty", document.querySelector(".bm-error[data-err='3']").hidden === false);
document.getElementById("bmName").value = "Priya Sharma";
document.getElementById("bmPhone").value = "9876543210";
document.getElementById("bmNext").click();
t("confirmation shows", document.querySelector(".bm-confirm").hidden === false);
const summary = document.getElementById("bmSummary").textContent;
t("summary includes name", summary.includes("Priya Sharma"));
t("demo disclaimer present", document.querySelector(".confirm-note").textContent.includes("simulated"));
document.getElementById("bmDone").click();
t("modal closes & form resets", document.getElementById("bookingModal").hidden === true && document.getElementById("bmName").value === "");

/* invalid phone check */
document.querySelector("[data-open-booking]").click();
document.querySelector("input[name='svc']").click();
document.getElementById("bmNext").click();
citySel.value = "Mumbai"; citySel.dispatchEvent(new window.Event("change", { bubbles: true }));
dateIn.value = dateIn.min; dateIn.dispatchEvent(new window.Event("change", { bubbles: true }));
const fs2 = [...document.querySelectorAll("#bmSlots .slot")].find(s => !s.disabled);
fs2.click();
document.getElementById("bmNext").click();
document.getElementById("bmName").value = "Test";
document.getElementById("bmPhone").value = "12345";
document.getElementById("bmNext").click();
t("invalid phone rejected", document.querySelector(".bm-error[data-err='3']").hidden === false);

/* before-after keyboard */
const handle = document.getElementById("baHandle");
const before = window.getComputedStyle ? null : null;
handle.dispatchEvent(new window.KeyboardEvent("keydown", { key: "ArrowRight", bubbles: true }));
t("BA slider responds to keys", handle.getAttribute("aria-valuenow") === "54");

/* a11y basics */
t("all imgs have alt attr", [...document.querySelectorAll("img")].every(i => i.hasAttribute("alt")));
t("skip link present", !!document.querySelector(".skip-link"));
t("footer disclaimer present", document.querySelector(".footer-legal").textContent.includes("independent"));

console.log(`\n${pass} passed, ${failcnt} failed`);
process.exit(failcnt ? 1 : 0);
