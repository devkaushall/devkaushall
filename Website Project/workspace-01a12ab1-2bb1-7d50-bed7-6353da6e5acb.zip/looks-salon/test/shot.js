const { chromium } = require("playwright");
(async () => {
  const browser = await chromium.launch();
  const errors = [];
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  page.on("console", m => { if (m.type() === "error") errors.push(m.text()); });
  page.on("pageerror", e => errors.push("PAGEERROR: " + e.message));
  await page.goto("http://localhost:8080/", { waitUntil: "networkidle" });
  await page.waitForTimeout(2500);
  await page.screenshot({ path: "test/shot-hero.png" });
  await page.evaluate(() => document.getElementById("services").scrollIntoView());
  await page.waitForTimeout(1200);
  await page.screenshot({ path: "test/shot-services.png" });
  await page.evaluate(() => document.getElementById("transformations").scrollIntoView());
  await page.waitForTimeout(1200);
  await page.screenshot({ path: "test/shot-ba.png" });
  await page.evaluate(() => document.getElementById("locations").scrollIntoView());
  await page.waitForTimeout(1200);
  await page.screenshot({ path: "test/shot-loc.png" });
  // booking modal
  await page.click(".hero-ctas [data-open-booking]", { force: true }).catch(()=>{});
  await page.waitForTimeout(600);
  await page.screenshot({ path: "test/shot-modal.png" });
  // mobile
  const mp = await browser.newPage({ viewport: { width: 390, height: 844 } });
  mp.on("pageerror", e => errors.push("MOBILE PAGEERROR: " + e.message));
  await mp.goto("http://localhost:8080/", { waitUntil: "networkidle" });
  await mp.waitForTimeout(2000);
  await mp.screenshot({ path: "test/shot-mobile.png" });
  console.log("console errors:", errors.length ? errors : "none");
  await browser.close();
})();
