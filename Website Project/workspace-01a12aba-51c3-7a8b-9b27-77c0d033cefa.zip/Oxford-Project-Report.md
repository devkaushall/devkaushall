# Oxford Institute Badshahpur — research, design & validation

**Research date:** 11 October 2026  
**Deliverable:** independent, original, interactive pitch website; not an official institute website.

## 1. Existing setup inspected

The /home/user workspace was empty. No existing application, client content, brand assets or repository was supplied. Node 20 and npm were available. A fresh React + Vite project was created; no existing website layout, code, palette or components were copied.

## 2. Research: findings and confidence

| Topic | Evidence and conflicts | Website decision |
|---|---|---|
| Business/location | Badshahpur Justdial lists Oxford School Of Language & Computers at Main Sohna Road, opposite Police Station, Jaildar Market, 122101. Its detailed address includes first floor. A secondary directory lists first floor, Jalidar Market, Teekli Road, opposite Police Station, Badshahpur, 122101. Road naming/spelling differs. | Use the common address core with “directory-listed; confirm before visiting”. Maps link performs a search, not an asserted verified pin. [3](https://www.justdial.com/Gurgaon/Oxford-School-Of-Language-Computers-Opposite-Police-Station-Jaildar-Market-Badshahpur-Gurgaon/011PXX11-XX11-140505153704-P9V2_BZDET) [6](https://www.britishschooloflanguages.com/oxford-institute-in-sohna-road-gurugram-ms-office-tally-dtp-web-development-c-c-java-spoken-english) |
| Spoken English | English/communication training appears in the local Badshahpur Justdial listing. | “Locally listed”, not guaranteed current admissions. [3](https://www.justdial.com/Gurgaon/Oxford-School-Of-Language-Computers-Opposite-Police-Station-Jaildar-Market-Badshahpur-Gurgaon/011PXX11-XX11-140505153704-P9V2_BZDET) |
| Computer courses | The secondary branch-specific listing title names MS Office, Tally, DTP, Web Development, C/C++, Java and Spoken English. Its actual page says “Unverified”. | Five additional course cards provide enquiry entry points, each marked directory-listed, with availability confirmation required. No current prospectus claim. Learning areas are explicitly illustrative, not a verified syllabus. [6](https://www.britishschooloflanguages.com/oxford-institute-in-sohna-road-gurugram-ms-office-tally-dtp-web-development-c-c-java-spoken-english) |
| Python | Search-indexed former institute About content mentioned Python, but identifies New Railway Road; live page returns 404. | Not promoted as a confirmed Badshahpur offering. [7](https://oxfordedu.co.in/about/) |
| Advanced Excel, GST, Digital Marketing | No sufficiently reliable branch-specific evidence found. Similar Delhi institutes appear in results and are not this business. | Omitted from confirmed course cards. FAQ explains that these interests can be raised by enquiry. No course fee or availability invented. |
| General phone/WhatsApp | Oxford Institute Gurugram public LinkedIn profile lists 9818112018 and New Railway Road, not Badshahpur. Main branch Justdial also mentions Badshahpur among additional locations. | Working tel/WhatsApp links use the **Gurugram general contact** with explicit branch-number disclaimer and consent. No test message or call was sent. [2](https://www.linkedin.com/in/oxfordinstitute/) [5](https://www.justdial.com/Delhi/Oxford-Institute-Near-St-Crispin-School-Opposite-Auto-Stand-New-Railway-Road/011PXX11-XX11-100821124853-E9D5_BZDET) |
| Secondary directory contact | The unverified directory mixes its own BSL branding, app promotions, multiple WhatsApp links and call number. | Do not use its phone as an authenticated Oxford branch number. [6](https://www.britishschooloflanguages.com/oxford-institute-in-sohna-road-gurugram-ms-office-tally-dtp-web-development-c-c-java-spoken-english) |
| Founding date | Former institute indexed content says 2005; local Justdial says 2008. These may refer to different locations. | No founding year, “years of experience” or similar claim displayed. [7](https://oxfordedu.co.in/about/) [3](https://www.justdial.com/Gurgaon/Oxford-School-Of-Language-Computers-Opposite-Police-Station-Jaildar-Market-Badshahpur-Gurgaon/011PXX11-XX11-140505153704-P9V2_BZDET) |
| Ratings/reviews | Local Justdial search result showed 4.7/5; the unverified directory showed 4.2/25 reviews. Main branch has separate ratings. No live Google profile authenticated. | No ratings, review counts, testimonials, student outcomes or Google review branding reused. [2](https://www.justdial.com/Gurgaon/Oxford-School-Of-Language-Computers-Opposite-Police-Station-Jaildar-Market-Badshahpur-Gurgaon/011PXX11-XX11-140505153704-P9V2_BZDET) [6](https://www.britishschooloflanguages.com/oxford-institute-in-sohna-road-gurugram-ms-office-tally-dtp-web-development-c-c-java-spoken-english) |
| Fees, facilities, qualifications, certificates, placement, batch schedules | Not independently verified at the Badshahpur branch. | No invented prices, lab/AC/Wi-Fi claims, teaching-quality claims, guarantees, faculty bios, timetables, results or accreditations. |

### Existing website — direct inspection

The public profile points to `oxfordedu.co.in`. Direct retrieval of its homepage returned unrelated casino/betting content, not institute information. Both `/contact/` and `/about/` returned 404. An older About page remained in search results, illustrating why indexed content was not accepted as current truth. The demo deliberately does not link visitors to that domain. The reason for the unrelated content was not established; no claim is made that it was hacked or that the institute owns the gambling content.

### Social media — access limitations

The public profile identifies Instagram `oxfordinstitute_english`, Facebook `OxfordSchoolOfLanguage` and YouTube `@oxford_institute_ggn`. Direct Instagram and Facebook retrieval returned HTTP 403, so their posts, recent announcements and photos could not be inspected. The YouTube handle was discovered but not independently inspected. They were not fabricated into social-proof elements. [3](https://www.linkedin.com/in/oxfordinstitute/)

### Google Business Profile

Searches were made for the exact branch and Google-related results. No authenticated live Google Business Profile was retrieved. Therefore branch ownership, open status, map pin, Google rating, current phone and opening hours remain unverified. The site offers a Google Maps search rather than presenting an embedded verified business pin.

### Other checked sources

UrbanPro and Sulekha identify the New Railway Road address, not Badshahpur. Their contact, courses and hours were not silently attributed to this branch. [1](https://www.urbanpro.com/gurgaon/oxford-institute-gurgaon-gurgaon-ho/4484055) [4](https://www.sulekha.com/oxford-school-of-language-computer-new-railway-road-gurgaon-contact-address)

## 3. Plan and design rationale

**Audience hypothesis:** local students, beginners, job seekers and working adults exploring practical language/computer skills. This is a UX hypothesis, not institute-approved demographic data.

- Original warm ivory, deep plum and lime palette. The visual language is approachable and career-oriented rather than a corporate admissions template.
- Manrope headings and DM Sans body copy, locally hosted for privacy and resilience.
- An editorial hero image, explicitly labelled AI-generated; never claimed as real campus/student photography.
- Clear hierarchy: aspiration → courses → goal exploration → location/about → enquiry → FAQs.
- Locality shown early; no invented metrics or testimonials used as trust signals.
- Six filterable course cards, honest evidence labels and keyboard-accessible detail dialogs.
- A goal picker gives transparent, deterministic exploration suggestions, not a simulated AI advisor or employability assessment.
- WhatsApp flow prepares and previews a message before the user chooses to send it.
- No unnecessary 3D libraries, video autoplay, heavy sliders or live third-party embeds.
- Smooth reveals, restrained card motion, focus visibility and reduced-motion support.

## 4. Build and functionality

- Responsive single-page website with anchored Courses, About, Goal Finder, Contact and FAQ sections.
- Sticky desktop navigation and stateful mobile menu.
- Course filters with pressed-state semantics and live results.
- Native modal course details, explicit keyboard focus loop, Escape close, focus restoration and course-specific form preselection.
- Goal-based recommendations that open the actual relevant course dialogs.
- Name, Indian mobile, course and optional question form with consent, required-field validation and encoded WhatsApp message generation.
- Editable draft invalidation prevents sending stale data.
- Copy message action, tel link, WhatsApp links and external Maps search.
- Expandable FAQs and transparent source disclosure.
- No data persistence, automated sending, fake submit confirmation, payment collection, newsletter or unimplemented login.
- Self-contained downloadable HTML: scripts, fonts and image embedded. Offline rendering and course interaction tested with external assets blocked.
- Demo marked noindex/nofollow and visibly labelled as independent.

## 5. Test → review → fix → validate

### Issues found and addressed

1. Browser test dependencies were initially missing from the sandbox; Chromium libraries installed and tests rerun.
2. Four low-contrast text instances found by axe; foreground colours darkened and image-credit background added.
3. Very narrow 320px hero decoration exceeded the viewport; intrinsic sizing and badge placement corrected. Heading size refined to retain a safe margin.
4. Native dialog tab sequence allowed focus to leave the document; explicit first/last focus wrapping implemented and tested.
5. Accessibility tests initially sampled in-progress fade animations. Tests now await fonts and settled opacity, while a separate test verifies actual scroll reveals.
6. Fonts compressed from TTF to WOFF2; hero converted to a ~64KB WebP. No external runtime font service is required.
7. Temporary Lighthouse tooling was removed after audit; final npm dependency audit reports zero vulnerabilities.

### Actual final production-browser results

**17 / 17 tests passed**, Chromium, 27.4 seconds final run.

- Filter counts and content: pass.
- Modal opening, focus loop, Escape dismissal and focus restoration: pass.
- Course-to-enquiry preselection and no automatic sending: pass.
- Goal finder changes: pass.
- Required fields, invalid mobile, consent, safe encoding and stale draft removal: pass.
- FAQ and research expansion: pass.
- 320, 390, 768, 1024 and 1440px viewports: no horizontal overflow; no page JavaScript errors or failed app resource responses.
- Mobile menu open, anchor navigation and closing: pass.
- All internal anchors and phone/Maps link schemes: pass.
- axe WCAG 2A/2AA/2.1AA automated scans at 390px and 1440px, homepage and open course modal: **zero detected violations**.
- Reduced-motion preference and natural scroll reveal: pass.
- Standalone downloadable demo rendering and modal interaction, with all external assets blocked: pass.

Screenshots at all five widths were captured. Full desktop/mobile screenshots and cropped desktop/320px hero views were visually reviewed. Automated accessibility scans do not substitute for a full manual assistive-technology audit.

### Production build / dependency check

- `npm run build`: succeeds, no build errors.
- JS: ~256.6KB raw / 80.5KB gzip; CSS: ~30.2KB raw / 7KB gzip.
- Two informational Lucide `use client` bundler warnings remain. This SPA has no server-component semantics; they do not prevent build/runtime operation.
- `npm audit`: **0 vulnerabilities** in the final installed dependency tree.

### Lighthouse mobile lab run

Measured on the local production server, Lighthouse 12.3.0, mobile simulation. This run preceded the final narrow-heading/button-size refinement; it is not a production field-performance guarantee.

| Metric | Result |
|---|---:|
| Performance | 94 / 100 |
| Accessibility | 100 / 100 |
| Best practices | 96 / 100 |
| First contentful paint | 2.4 s |
| Largest contentful paint | 2.5 s |
| Total blocking time | 80 ms |
| Cumulative layout shift | 0.004 |
| Speed index | 2.4 s |

Raw results: `review/tests.json`, `review/lighthouse-mobile.json` and `review/build.log`.

## 6. Honest remaining limitations / launch checklist

- Branch identity/current availability and direct contact need owner approval; directories are not a substitute for current verification.
- No live Google profile, real testimonial, actual campus photo, facilities inventory or approved syllabus was authenticated.
- Instagram/Facebook blocked automated access; no claim of full social audit.
- Form is a working WhatsApp handoff, not a CRM/email/backend lead collection system.
- External URL structure was checked, but no real enquiry, message, phone call or payment was sent during testing. WhatsApp account availability and institute response are not guaranteed.
- Testing used Chromium viewport emulation, not physical devices, Safari or Firefox.
- Copy-to-clipboard depends on browser permission/secure context. The visible draft can also be manually selected, and the WhatsApp link remains available.
- Live preview is temporary preview hosting, not a custom-domain production deployment.
- Client approval, privacy review for any future lead storage, confirmed business data and hosting/domain setup are required before official launch.
