# Oxford Institute — independent website concept

A complete original React + Vite demo for Oxford Institute, Badshahpur. Created 11 October 2026. This is not an official institute website or an approved admissions prospectus.

## View without coding

Open `Oxford-Institute-Demo.html` (provided alongside this project) in a browser. All fonts, scripts and imagery are embedded; no server is required for the site itself. Calling, Maps, research links and WhatsApp require the relevant app/network. The Arena live preview runs the production build on port 5173.

## Developer handoff

```sh
npm ci
npm run dev -- --port 5173
npm run build
npm run preview -- --port 5173
```

Node 20.19+ recommended. Build output goes into `dist/`. The app uses same-origin assets and accepts the preview host. No third-party analytics, form backend, cookies, API credentials or external CDN runtime.

### Run tests

```sh
npx playwright install --with-deps chromium
npm run preview -- --port 5173
# In a separate terminal:
npm test
```

The standalone test expects `../Oxford-Institute-Demo.html`. To regenerate it after building, run `python3 review/package-demo.py` (Python standard library only). Tests default to http://localhost:5173; set TEST_URL to change that.

## Main files

- `src/main.jsx`: course data, evidence labels, navigation, course dialogs, goal finder, enquiry form, FAQs and sources.
- `src/style.css`: original visual system, breakpoints and motion preferences.
- `src/fonts.css`, `public/`: self-hosted fonts and optimised hero image.
- `tests/site.spec.js`: 17 Playwright tests, including axe accessibility checks.
- `review/tests.json`: final production test run.
- `review/lighthouse-mobile.json`: measured mobile lab audit (before final small-screen heading/button refinement).
- `RESEARCH-AND-VALIDATION.md`: business research, evidence limitations and actual testing outcomes.

## Enquiry behaviour

The form validates name, Indian mobile number and explicit consent. Submit prepares a text draft only. The user reviews it and chooses “Open in WhatsApp”, then sends from WhatsApp. Data is not stored or sent by the website. Editing the form invalidates the old draft. General contact used: +91 9818112018, publicly listed for Oxford Institute at New Railway Road, Gurugram. It must not be represented as a verified Badshahpur direct number.

## Before a real launch

Obtain written owner approval of the branch identity, direct phone/WhatsApp, address, available courses and syllabi. Confirm pricing, timings and any certification or placement claims separately. Replace the illustrative image with consented real photography if desired. Select an approved lead workflow/backend and privacy policy only if enquiry collection is required. Remove concept disclosures/noindex only after approval; connect a domain and production hosting. Do not reuse/link the old domain without resolving its unrelated live content.

Build emits two harmless Lucide `use client` directive warnings; this is a client-rendered application with no server component boundary. Build exits successfully. Runtime tests report no JavaScript errors.
