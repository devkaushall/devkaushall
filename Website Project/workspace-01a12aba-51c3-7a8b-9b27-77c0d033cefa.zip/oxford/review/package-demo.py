from pathlib import Path
import re,base64
base=Path(__file__).resolve().parents[1]
def data(path,mime):return 'data:'+mime+';base64,'+base64.b64encode(path.read_bytes()).decode()
html=(base/'dist/index.html').read_text()
css=next((base/'dist/assets').glob('*.css')).read_text()
js=next((base/'dist/assets').glob('*.js')).read_text()
for font in (base/'public').glob('*.woff2'):css=css.replace('/'+font.name,data(font,'font/woff2'))
js=js.replace('/student.webp',data(base/'public/student.webp','image/webp'))
html=re.sub(r'<link rel="preload"[^>]+>','',html)
html=re.sub(r'<link rel="icon"[^>]+>','<link rel="icon" href="'+data(base/'public/favicon.svg','image/svg+xml')+'">',html)
html=re.sub(r'<script type="module"[^>]+></script>','',html)
html=re.sub(r'<link rel="stylesheet"[^>]+>','',html)
html=html.replace('</head>','<style>'+css+'</style></head>')
html=html.replace('</body>','<script type="module">'+js.replace('</script','<\\/script')+'</script></body>')
(base.parent/'Oxford-Institute-Demo.html').write_text(html)
print('Standalone demo bytes:',len(html))
