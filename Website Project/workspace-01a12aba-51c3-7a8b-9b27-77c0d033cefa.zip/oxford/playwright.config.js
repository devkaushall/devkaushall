import {defineConfig} from '@playwright/test';
export default defineConfig({testDir:'./tests',timeout:30000,use:{baseURL:process.env.TEST_URL||'http://localhost:5173',headless:true},reporter:[['list'],['json',{outputFile:'review/tests.json'}]],workers:2});
