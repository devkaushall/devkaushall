import json, sys
from playwright.sync_api import sync_playwright

URL = "http://127.0.0.1:8080/index.html"
results = []
def check(name, cond, detail=""):
    results.append({"test": name, "pass": bool(cond), "detail": str(detail)})
    print(("PASS " if cond else "FAIL ") + name + (f" :: {detail}" if detail else ""))

with sync_playwright() as p:
    browser = p.chromium.launch()
    # ---------- Desktop ----------
    ctx = browser.new_context(viewport={"width":1440,"height":900}, device_scale_factor=1)
    page = ctx.new_page()
    console_errors, failed_reqs, bad_responses = [], [], []
    page.on("console", lambda m: console_errors.append(m.text) if m.type == "error" else None)
    page.on("requestfailed", lambda r: failed_reqs.append(r.url))
    page.on("response", lambda r: bad_responses.append((r.status, r.url)) if r.status >= 400 else None)
    page.goto(URL, wait_until="load")
    page.wait_for_timeout(1500)
    page.screenshot(path="/home/user/nivaas/screenshots/desktop-hero.png")

    check("title present", "Nivaas" in page.title())
    check("single h1", page.locator("h1").count() == 1)
    imgs_missing_alt = page.evaluate("[...document.images].filter(i=>!i.alt).length")
    check("all images have alt", imgs_missing_alt == 0, imgs_missing_alt)
    check("hero image loaded", page.evaluate("document.querySelector('.hero img').naturalWidth") > 0)

    # Nav scrolled state
    page.mouse.wheel(0, 1200); page.wait_for_timeout(600)
    check("header gets scrolled state", page.evaluate("document.getElementById('siteHeader').classList.contains('is-scrolled')"))

    # Anchor scroll
    page.click("a.nav-cta[href='#consult']") if page.locator("a.nav-cta[href='#consult']").is_visible() else None
    page.wait_for_timeout(1200)
    check("nav CTA scrolls to consult", page.evaluate("Math.abs(document.getElementById('consult').getBoundingClientRect().top) < 200"))

    # Filters
    page.click("#projects .filters >> text=Commercial"); page.wait_for_timeout(800)
    vis = page.evaluate("[...document.querySelectorAll('#projectGrid .project-card')].filter(c=>getComputedStyle(c).display!=='none').length")
    check("commercial filter shows 1 project", vis == 1, vis)
    page.click("#projects .filters >> text=Kitchen"); page.wait_for_timeout(800)
    vis = page.evaluate("[...document.querySelectorAll('#projectGrid .project-card')].filter(c=>getComputedStyle(c).display!=='none').length")
    check("kitchen filter shows 1 project", vis == 1, vis)
    page.click("#projects .filters >> text=All"); page.wait_for_timeout(800)
    vis = page.evaluate("[...document.querySelectorAll('#projectGrid .project-card')].filter(c=>getComputedStyle(c).display!=='none').length")
    check("All filter restores 6 projects", vis == 6, vis)

    # Lightbox
    page.locator("#projectGrid .project-btn").nth(2).click(); page.wait_for_timeout(500)
    check("lightbox opens", page.locator("#lightbox").is_visible())
    t1 = page.inner_text("#lbTitle")
    page.keyboard.press("ArrowRight"); page.wait_for_timeout(400)
    t2 = page.inner_text("#lbTitle")
    check("lightbox arrow navigation changes project", t1 != t2, f"{t1} -> {t2}")
    page.keyboard.press("Escape"); page.wait_for_timeout(300)
    check("lightbox closes on Escape", not page.locator("#lightbox").is_visible())

    # Before/after slider
    page.locator("#baSlider").scroll_into_view_if_needed(); page.wait_for_timeout(700)
    box = page.locator("#baSlider").bounding_box()
    page.mouse.move(box["x"]+box["width"]*0.5, box["y"]+box["height"]/2)
    page.mouse.down(); page.mouse.move(box["x"]+box["width"]*0.25, box["y"]+box["height"]/2, steps=8); page.mouse.up()
    pos = int(page.get_attribute("#baSlider", "aria-valuenow"))
    check("before/after drag moves divider", 20 <= pos <= 30, pos)
    page.focus("#baSlider"); page.keyboard.press("ArrowRight"); page.keyboard.press("ArrowRight")
    pos2 = int(page.get_attribute("#baSlider", "aria-valuenow"))
    check("before/after keyboard arrows", pos2 == pos + 10, pos2)
    page.locator("#baSlider").scroll_into_view_if_needed(); page.wait_for_timeout(900)
    page.screenshot(path="/home/user/nivaas/screenshots/desktop-ba.png")

    # Services tabs
    page.click("#tab-com"); page.wait_for_timeout(300)
    check("commercial service panel visible", page.locator("#panel-com").is_visible() and not page.locator("#panel-res").is_visible())

    # Process / style explorer
    page.click(".style-chips >> text=Earthy Classic"); page.wait_for_timeout(700)
    check("style explorer switches name", page.inner_text("#styleName") == "Earthy Classic")

    # FAQ
    page.click("#faqb2"); page.wait_for_timeout(200)
    check("FAQ opens second item", page.get_attribute("#faqb2", "aria-expanded") == "true" and page.is_visible("#faq2"))
    check("FAQ items toggle independently (multi-open)", page.get_attribute("#faqb1", "aria-expanded") == "true")
    page.click("#faqb2"); page.wait_for_timeout(200)
    check("FAQ item collapses on second click", page.get_attribute("#faqb2", "aria-expanded") == "false" and not page.is_visible("#faq2"))

    # Form validation
    page.locator("#consultForm").scroll_into_view_if_needed()
    page.click("#consultForm button[type=submit]"); page.wait_for_timeout(300)
    errs = page.evaluate("[...document.querySelectorAll('#consultForm .err')].filter(e=>e.textContent).length")
    check("empty form shows validation errors", errs >= 4, errs)
    page.fill("#name", "A"); page.fill("#phone", "12345")
    page.click("#consultForm button[type=submit]"); page.wait_for_timeout(200)
    check("invalid phone rejected", "10-digit" in page.inner_text("#phone-err"))
    page.fill("#name", "Riya Sharma"); page.fill("#phone", "98765 43210"); page.fill("#email", "riya@example.com")
    page.select_option("#ptype", "Home renovation"); page.check("#consent")
    page.click("#consultForm button[type=submit]"); page.wait_for_timeout(1500)
    check("valid form shows demo success message", "Thank you" in page.inner_text("#formStatus"))
    page.locator("#consult").scroll_into_view_if_needed(); page.wait_for_timeout(500)
    page.screenshot(path="/home/user/nivaas/screenshots/desktop-consult.png")

    # WhatsApp link
    wa = page.get_attribute("#waBtn", "href")
    check("WhatsApp link has wa.me + prefilled text", "wa.me/" in wa and "text=" in wa, wa)
    check("floating WhatsApp exists", page.locator(".wa-float").count() == 1)

    # Page-wide checks
    page.wait_for_timeout(600)
    page.screenshot(path="/home/user/nivaas/screenshots/desktop-full.png", full_page=True)
    ov = page.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
    check("no horizontal overflow desktop", ov <= 0, ov)
    ctx.close()

    # ---------- Tablet & Mobile ----------
    for name, vp in [("tablet",{"width":834,"height":1112}),("mobile",{"width":390,"height":844})]:
        c = browser.new_context(viewport=vp, device_scale_factor=1, is_mobile=(name=="mobile"), has_touch=(name=="mobile"))
        pg = c.new_page()
        pg.on("pageerror", lambda e, n=name: check(f"{n} no JS page errors", False, str(e)))
        pg.goto(URL, wait_until="load"); pg.wait_for_timeout(1500)
        ov = pg.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
        check(f"no horizontal overflow {name}", ov <= 0, ov)
        pg.screenshot(path=f"/home/user/nivaas/screenshots/{name}-hero.png")
        pg.screenshot(path=f"/home/user/nivaas/screenshots/{name}-full.png", full_page=True)
        if name == "mobile":
            pg.click("#menuToggle"); pg.wait_for_timeout(700)
            check("mobile menu opens", pg.get_attribute("#menuToggle","aria-expanded") == "true" and pg.locator("#primaryNav a").first.is_visible())
            pg.screenshot(path="/home/user/nivaas/screenshots/mobile-menu.png")
            pg.click("#primaryNav a[href='#faq']"); pg.wait_for_timeout(1200)
            check("mobile menu link navigates and closes", pg.get_attribute("#menuToggle","aria-expanded") == "false")
            pg.locator("#consult").scroll_into_view_if_needed()
            pg.wait_for_timeout(600)
            pg.screenshot(path="/home/user/nivaas/screenshots/mobile-consult.png")
            # tap-target size check for primary CTA
            h = pg.evaluate("document.querySelector('.hero .btn-primary').getBoundingClientRect().height")
            check("primary button tap target >= 44px", h >= 44, h)
        c.close()

    # Assets / errors
    real_errors = [e for e in console_errors if "fonts.g" not in e and "ERR_NAME" not in e and "Failed to load resource" not in e]
    font_only = [u for u in failed_reqs if "googleapis" in u or "gstatic" in u]
    other_failed = [u for u in failed_reqs if u not in font_only]
    check("no local 4xx/5xx responses", not [b for b in bad_responses if "127.0.0.1" in b[1] or "localhost" in b[1]], bad_responses)
    check("no non-font failed requests", not other_failed, other_failed)
    check("no console JS errors (excluding offline Google Fonts)", not real_errors, real_errors)
    print("NOTE font requests blocked by sandbox (expected offline):", len(font_only))
    browser.close()

passed = sum(r["pass"] for r in results)
print(f"\nRESULT: {passed}/{len(results)} passed")
json.dump(results, open("/home/user/nivaas/tests/results.json","w"), indent=2)
