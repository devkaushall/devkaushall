# Nivaas Studio — Demo Website Plan

## 1. Research (summary)
- Gurugram/NCR competitors (Studio Interplay, Hammer & Tongs, Epic Studio, Interior A to Z, Chalk Studio, The Workroom, MADS, The Interia) mostly show:
  dense service lists, "Free site visit / 2D-3D / budget consultation" offers, turnkey + modular kitchen + PMC messaging, generic hero carousels, big grids of unlabelled photos.
- Gap: clear process, honest pricing-transparency, before/after proof, room-style browsing, and a warm editorial feel that does not look like a template.
- 2026 trends (Indian residential coverage): warm neutrals (terracotta, clay, sand, olive), natural materials (limewash, oak, linen, travertine, jute), "personally composed" over perfectly matched, warm minimalism, sustainable/low-VOC defaults, artisanal details.

## 2. Brand (FICTIONAL DEMO — not a real business)
- Name: **Nivaas Studio** — Interiors & Home Renovation, Gurugram (Demo)
- Tagline: "Spaces, composed slowly." / "Quiet rooms, considered details."
- Contact: all phone/email/address are placeholders (+91 00000 00000, hello@nivaas-demo.example, Sector 00, Gurugram). WhatsApp link uses placeholder number.
- No real testimonials, awards, or client names. Testimonials labelled "Sample testimonial — demo content". Stats labelled "illustrative".

## 3. Visual direction
- Palette: warm ivory #F5EFE6, sand #E7DCCB, clay/terracotta #B4663F, olive #5E6B4E, espresso #2B211B, muted stone #8C8175.
- Type: Cormorant Garamond (display, editorial) + Inter (UI/body); fallbacks Georgia / system-ui.
- Textures: subtle SVG noise overlay, thin hairline dividers, generous spacing (8px scale), 12-column grid.
- Imagery: AI-generated illustrative interiors (labelled "Illustrative imagery").

## 4. Sections (single page + anchors)
1. Sticky header with nav, mobile menu, "Book consultation" CTA
2. Hero — large image, headline, split reveal animation, CTAs
3. Intro strip / studio introduction with founder-style copy (fictional)
4. Featured projects — filterable gallery (All / Residential / Commercial / Kitchen / Bedroom), lightbox with prev/next, keyboard support
5. Before/after renovation slider (drag, touch, keyboard)
6. Services — residential & commercial tabs/cards with hover effects
7. Design process — 5 steps, scroll-reveal
8. Room style explorer — chip filter (Warm Minimal, Organic Modern, Earthy Classic) changing a palette card
9. Materials board — hover reveal
10. Testimonials — sample/demo labelled
11. FAQ accordion
12. Consultation form (validated, success state, localStorage-free demo) + WhatsApp button + contact details
13. Footer

## 5. Tech decisions
- Static HTML/CSS/vanilla JS (no build step, fast, easy to host and hand over).
- No heavy 3D library: a 3D room is not needed for the brief; instead a subtle CSS 3D tilt on feature cards (useful, cheap). Stated honestly in final report.
- Accessibility: semantic landmarks, alt text, focus-visible, reduced-motion support, ARIA on tabs/accordion/dialog/slider.
- Performance: lazy-loaded images, width/height attributes, WebP not generated (JPG kept), passive scroll listeners, IntersectionObserver for reveals.

## 6. Test plan
- Playwright (Chromium) headless: page load, console errors, 404 assets, nav links, mobile menu, filters, lightbox open/close/keyboard, before/after drag, FAQ toggle, form validation + success, WhatsApp link href.
- Screenshots at 1440px, 834px (tablet), 390px (mobile); check horizontal overflow.
- Fix → re-run → report results.
