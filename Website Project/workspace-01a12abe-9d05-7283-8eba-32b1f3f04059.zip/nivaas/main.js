(function(){
  'use strict';
  const $ = (s, c=document) => c.querySelector(s);
  const $$ = (s, c=document) => Array.from(c.querySelectorAll(s));
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* Header scrolled state + parallax hero */
  const header = $('#siteHeader');
  const heroMedia = $('[data-parallax]');
  function onScroll(){
    header.classList.toggle('is-scrolled', window.scrollY > 40);
    if (heroMedia && !reduce && window.scrollY < window.innerHeight){
      heroMedia.style.transform = `translate3d(0, ${window.scrollY * 0.25}px, 0)`;
    }
  }
  window.addEventListener('scroll', onScroll, {passive:true});
  onScroll();

  /* Mobile menu */
  const toggle = $('#menuToggle'), nav = $('#primaryNav');
  function setMenu(open){
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    nav.classList.toggle('is-open', open);
    document.body.style.overflow = open ? 'hidden' : '';
  }
  toggle.addEventListener('click', () => setMenu(toggle.getAttribute('aria-expanded') !== 'true'));
  $$('#primaryNav a').forEach(a => a.addEventListener('click', () => setMenu(false)));
  document.addEventListener('keydown', e => { if (e.key === 'Escape') setMenu(false); });

  /* Reveal on scroll */
  const io = new IntersectionObserver((entries) => {
    entries.forEach(en => {
      if (en.isIntersecting){
        en.target.classList.add('is-visible');
        io.unobserve(en.target);
        // count-up for hero stats
        $$('[data-count]', en.target).forEach(countUp);
      }
    });
  }, {threshold: 0.15, rootMargin: '0px 0px -40px 0px'});
  $$('.reveal').forEach(el => io.observe(el));
  // heros reveal immediately
  $$('.hero .reveal').forEach(el => el.classList.add('is-visible'));
  $$('.hero-meta').forEach(el => $$('[data-count]', el).forEach(countUp));

  function countUp(el){
    if (el.dataset.done) return; el.dataset.done = '1';
    const target = +el.dataset.count;
    if (reduce){ el.textContent = target; return; }
    const dur = 1400, t0 = performance.now();
    (function step(t){
      const p = Math.min((t - t0) / dur, 1);
      el.textContent = Math.round(target * (1 - Math.pow(1 - p, 3)));
      if (p < 1) requestAnimationFrame(step);
    })(t0);
  }

  /* Project filters */
  const filterBtns = $$('.filters .chip');
  const cards = $$('#projectGrid .project-card');
  const emptyNote = $('#emptyNote');
  filterBtns.forEach(btn => btn.addEventListener('click', () => {
    const f = btn.dataset.filter;
    filterBtns.forEach(b => { b.classList.toggle('is-active', b === btn); b.setAttribute('aria-selected', String(b === btn)); });
    let shown = 0;
    cards.forEach(c => {
      const match = f === 'all' || c.dataset.cats.split(' ').includes(f);
      if (match){
        c.classList.remove('is-hidden'); shown++;
        requestAnimationFrame(() => c.classList.remove('is-out'));
      } else {
        c.classList.add('is-out');
        setTimeout(() => { if (c.classList.contains('is-out')) c.classList.add('is-hidden'); }, reduce ? 0 : 500);
      }
    });
    emptyNote.hidden = shown !== 0;
  }));

  /* Lightbox */
  const lb = $('#lightbox'), lbImg = $('#lbImg'), lbTitle = $('#lbTitle'), lbDesc = $('#lbDesc');
  let visibleCards = [], current = 0, lastFocus = null;
  function getVisible(){ return cards.filter(c => !c.classList.contains('is-hidden') && !c.classList.contains('is-out')); }
  function show(i){
    const c = visibleCards[(i + visibleCards.length) % visibleCards.length];
    current = (i + visibleCards.length) % visibleCards.length;
    const img = $('img', c), title = $('h3', c).textContent, meta = $('p', c).textContent;
    lbImg.style.opacity = 0;
    setTimeout(() => {
      lbImg.src = img.currentSrc || img.src;
      lbImg.alt = img.alt;
      lbImg.style.opacity = 1;
    }, reduce ? 0 : 180);
    lbTitle.textContent = title;
    lbDesc.textContent = meta + ' · Illustrative image';
  }
  function open(card){
    lastFocus = document.activeElement;
    visibleCards = getVisible();
    show(visibleCards.indexOf(card));
    lb.hidden = false;
    document.body.style.overflow = 'hidden';
    $('#lbClose').focus();
  }
  function close(){
    lb.hidden = true;
    document.body.style.overflow = '';
    if (lastFocus) lastFocus.focus();
  }
  $$('.project-btn').forEach(btn => btn.addEventListener('click', () => open(btn.closest('.project-card'))));
  $('#lbClose').addEventListener('click', close);
  $('#lbPrev').addEventListener('click', () => show(current - 1));
  $('#lbNext').addEventListener('click', () => show(current + 1));
  lb.addEventListener('click', e => { if (e.target === lb || e.target.classList.contains('lb-inner')) close(); });
  document.addEventListener('keydown', e => {
    if (lb.hidden) return;
    if (e.key === 'Escape') close();
    if (e.key === 'ArrowLeft') show(current - 1);
    if (e.key === 'ArrowRight') show(current + 1);
    if (e.key === 'Tab'){ // focus trap
      const f = $$('button', lb).filter(b => !b.disabled);
      const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first){ e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last){ e.preventDefault(); first.focus(); }
    }
  });

  /* Before / After slider */
  const slider = $('#baSlider'), before = $('#baBefore'), handle = $('#baHandle');
  function setPos(pct){
    pct = Math.max(0, Math.min(100, pct));
    slider.style.setProperty('--pos', pct + '%');
    slider.setAttribute('aria-valuenow', Math.round(pct));
  }
  function posFromEvent(e){
    const r = slider.getBoundingClientRect();
    const x = (e.touches ? e.touches[0].clientX : e.clientX);
    return ((x - r.left) / r.width) * 100;
  }
  let dragging = false;
  slider.addEventListener('pointerdown', e => { dragging = true; slider.setPointerCapture(e.pointerId); setPos(posFromEvent(e)); });
  slider.addEventListener('pointermove', e => { if (dragging) setPos(posFromEvent(e)); });
  ['pointerup','pointercancel'].forEach(ev => slider.addEventListener(ev, () => dragging = false));
  slider.addEventListener('keydown', e => {
    const cur = +slider.getAttribute('aria-valuenow');
    if (e.key === 'ArrowLeft'){ setPos(cur - 5); e.preventDefault(); }
    if (e.key === 'ArrowRight'){ setPos(cur + 5); e.preventDefault(); }
    if (e.key === 'Home'){ setPos(0); e.preventDefault(); }
    if (e.key === 'End'){ setPos(100); e.preventDefault(); }
  });

  /* Service tabs */
  const tabs = $$('.service-tabs [role="tab"]');
  tabs.forEach((tab, i) => {
    tab.addEventListener('click', () => activate(tab));
    tab.addEventListener('keydown', e => {
      if (e.key === 'ArrowRight' || e.key === 'ArrowLeft'){
        const n = tabs[(i + (e.key === 'ArrowRight' ? 1 : tabs.length - 1)) % tabs.length];
        n.focus(); activate(n); e.preventDefault();
      }
    });
  });
  function activate(tab){
    tabs.forEach(t => { const on = t === tab; t.classList.toggle('is-active', on); t.setAttribute('aria-selected', String(on)); t.tabIndex = on ? 0 : -1; });
    $$('.service-panel').forEach(p => {
      const on = p.id === tab.getAttribute('aria-controls');
      p.hidden = !on; p.classList.toggle('is-active', on);
    });
  }

  /* Room style explorer */
  const styles = [
    {name:'Warm Minimal', desc:'Soft ivory walls, pale oak and calm, uncluttered surfaces.', c:['#F5EFE6','#E7DCCB','#D9C9B0','#8C8175','#2B211B']},
    {name:'Organic Modern', desc:'Limewash, travertine and curved shapes with olive and clay accents.', c:['#EDE6D6','#C9B99A','#B4663F','#5E6B4E','#3B3228']},
    {name:'Earthy Classic', desc:'Warm walnut, deeper clay tones and brass details for a heritage feel.', c:['#E9DCC8','#A9744F','#7A4B2E','#B59A5B','#2E211A']}
  ];
  const styleCard = $('#styleCard'), sw = $('#swatches');
  $$('.style-chips .chip').forEach(btn => btn.addEventListener('click', () => {
    $$('.style-chips .chip').forEach(b => { b.classList.toggle('is-active', b === btn); b.setAttribute('aria-pressed', String(b === btn)); });
    const s = styles[+btn.dataset.style];
    styleCard.classList.add('is-changing');
    setTimeout(() => {
      $('#styleName').textContent = s.name;
      $('#styleDesc').textContent = s.desc;
      sw.innerHTML = s.c.map(col => `<div style="background:${col}" aria-hidden="true"></div>`).join('');
      styleCard.classList.remove('is-changing');
    }, reduce ? 0 : 260);
  }));
  sw.innerHTML = styles[0].c.map(col => `<div style="background:${col}" aria-hidden="true"></div>`).join('');

  /* Subtle 3D tilt on project cards (desktop, pointer only) */
  if (window.matchMedia('(hover:hover) and (pointer:fine)').matches && !reduce){
    $$('.tilt').forEach(card => {
      const btn = $('.project-btn', card);
      card.addEventListener('pointermove', e => {
        const r = card.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5;
        btn.style.transform = `perspective(900px) rotateX(${(-y*4).toFixed(2)}deg) rotateY(${(x*5).toFixed(2)}deg)`;
      });
      card.addEventListener('pointerleave', () => { btn.style.transform = ''; });
    });
  }

  /* FAQ accordion */
  $$('.acc-btn').forEach(btn => btn.addEventListener('click', () => {
    const open = btn.getAttribute('aria-expanded') === 'true';
    const panel = document.getElementById(btn.getAttribute('aria-controls'));
    btn.setAttribute('aria-expanded', String(!open));
    panel.hidden = open;
  }));

  /* Consultation form validation */
  const form = $('#consultForm'), status = $('#formStatus');
  const rules = {
    name:  v => v.trim().length >= 2 ? '' : 'Please enter your full name (at least 2 characters).',
    phone: v => /^[6-9]\d{9}$/.test(v.replace(/[\s+-]/g,'').replace(/^91/,'')) ? '' : 'Enter a valid 10-digit Indian mobile number.',
    email: v => !v || /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) ? '' : 'Enter a valid email address.',
    ptype: v => v ? '' : 'Please select a project type.',
    consent: (v, el) => el.checked ? '' : 'Please give consent to be contacted.'
  };
  function validateField(el){
    const fn = rules[el.name]; if (!fn) return true;
    const msg = fn(el.type === 'checkbox' ? '' : el.value, el);
    const wrap = el.closest('.field');
    $('#' + el.name + '-err').textContent = msg;
    wrap.classList.toggle('is-invalid', !!msg);
    el.setAttribute('aria-invalid', String(!!msg));
    return !msg;
  }
  ['name','phone','email','ptype','consent'].forEach(n => {
    const el = form.elements[n];
    el.addEventListener('blur', () => validateField(el));
    el.addEventListener('input', () => { if (el.closest('.field').classList.contains('is-invalid')) validateField(el); });
  });
  form.addEventListener('submit', e => {
    e.preventDefault();
    const ok = ['name','phone','email','ptype','consent'].map(n => validateField(form.elements[n])).every(Boolean);
    if (!ok){
      status.className = 'form-status bad';
      status.textContent = 'Please fix the highlighted fields.';
      const first = form.querySelector('.is-invalid input, .is-invalid select');
      if (first) first.focus();
      return;
    }
    const btn = form.querySelector('button[type="submit"]');
    btn.disabled = true; btn.textContent = 'Sending…';
    setTimeout(() => {
      status.className = 'form-status ok';
      status.textContent = 'Thank you! This is a demo — your enquiry was not sent. In a live site, our team would reply within one working day.';
      form.reset();
      btn.disabled = false; btn.textContent = 'Send enquiry';
    }, reduce ? 0 : 900);
  });

  /* Smooth in-page anchors offset for fixed header */
  $$('a[href^="#"]').forEach(a => a.addEventListener('click', e => {
    const id = a.getAttribute('href');
    if (id.length < 2) return;
    const t = document.querySelector(id);
    if (!t) return;
    e.preventDefault();
    const y = t.getBoundingClientRect().top + window.scrollY - (header.offsetHeight + 8);
    window.scrollTo({top: y, behavior: reduce ? 'auto' : 'smooth'});
    history.replaceState(null, '', id);
  }));

  /* Floating WhatsApp button */
  const wa = document.createElement('a');
  wa.className = 'wa-float';
  wa.href = $('#waBtn').href;
  wa.target = '_blank'; wa.rel = 'noopener';
  wa.setAttribute('aria-label', 'Chat on WhatsApp (demo)');
  wa.innerHTML = '<svg width="26" height="26" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2z"/></svg>';
  document.body.appendChild(wa);
})();
