# Looks Salon — Premium Interactive Website Concept (Demo)

**Status: complete, tested, presentation-ready.**
Independent concept demo — *not* the live Looks Salon website, and not affiliated with or endorsed by the brand. All design, code and imagery are original.

Live in this workspace at: `http://localhost:8080/` (run `python3 -m http.server 8080` inside this folder, or open `index.html` via any static server).

---

## 1. What was built

A single-page, dependency-free (vanilla HTML/CSS/JS) premium experience in an
"editorial noir × champagne gold" direction: Bodoni Moda display type, Jost body
type, ivory/ink/gold palette, grain texture, marquee, Ken Burns, line-mask hero
reveal — all original, nothing copied from lookssalon.in (no markup, CSS,
images, logos or copy reused).

### Sections & interactions
| Area | Features |
|---|---|
| Hero | Masked line-reveal headline, dual editorial image collage with Ken Burns, rotating seal, partner-brand marquee, booking CTA |
| Stats band | Animated count-ups (est. 1989 · 160+ salons · 64 cities · 6,000+ team) with source attribution |
| Service explorer | Ladies/Gents switch, sticky image stage, 13 category tabs (exact official menus), indicative-price badges, tap-to-select service → carries into booking |
| Transformations | Draggable before/after comparison (pointer + touch + keyboard: arrows/Home/End, `role="slider"`), 2 pairs, honest "illustrative imagery" labelling |
| Gallery | 8-way category filter with counts, masonry grid, hover captions, lightbox (prev/next/keys/focus-trap) |
| Loyalty | Original demo card visual + interactive calculator implementing the *published* rules (10 pts/₹100, 1 pt = ₹1, 50% cap, min 250, 1-yr validity) |
| Salon finder | Stylised India SVG map with 48 pins placed at the brand's published coordinates, hover tooltips, city chips with counts, free-text search (city/mall/phone), branch cards with tel: links, Google-Maps links and "book here" |
| Story | Founder quote (sourced), pillars, official collection names, parallax interior |
| Visit | HQ address, toll-free + alt numbers, 4 emails, 5 social profiles, official ecosystem links |
| Booking | 4-step simulated drawer (service → salon → date/slot → details) with per-step validation, progress tracker, summary, reference code, explicit "no real appointment" notice + real toll-free CTA. In-memory only — nothing is transmitted or stored. |

### Quality bars met
- **Responsive:** 1120/1020/720/440 breakpoints verified in real Chromium (1440×900 & 390×844).
- **Accessible:** skip link, landmarks, tab/role/aria patterns on tabs, sliders, radiogroups & dialogs; focus traps; keyboard-only operable; `prefers-reduced-motion` honoured; visible focus rings; contrast-checked palette.
- **Fast:** no libraries; 9 requests / ~610 KB transfer to DOMContentLoaded (219 ms in headless Chromium); lazy images; optimized JPEGs (1.4 MB total incl. 13 images); font `display=swap` + preconnects.
- **Secure-ish basics:** CSP meta, `rel="noopener noreferrer"` on external links, no inline handlers/eval, `noindex` robots meta so the demo can't compete with the brand's real site.
- **SEO:** descriptive title/description/OG/Twitter tags + `HairSalon` JSON-LD with verified facts and an explicit "concept demo" description.

## 2. Research & data integrity (see `research/RESEARCH-NOTES.md`)

Everything presented as a brand fact is sourced from the official site (Oct 2026):
- Identity: unisex chain, **est. Jan 1989**, founder **Sanjay Dutta**, HQ **17A/22 Ajmal Khan Rd, Karol Bagh, New Delhi 110005**; toll-free **1800 212 56657**; alt +91 95827 15379 / +91 11 4549 1111; emails for care/franchise/academy/careers.
- Services: exact Ladies (7 categories) and Gents (6 categories) menus.
- Loyalty rules verbatim from the loyalty-card page.
- **48 branch listings** scraped from the official Salon Finder (address, phones, hours, Google-Maps URL; 40 with the site's own lat/lng, 8 flagged `coord_source:"city-approx"` in `research/branches-source.json`).
- 64-city booking list, partner brands, collection names, social profiles (IG @looksunisexsalon, FB, X @looksindia, YouTube, LinkedIn).
- **Prices:** the brand publishes none. Ranges shown are labelled *indicative* and come from third-party listings (2024–26); categories without any third-party data show "On consultation".
- **Not invented:** Dubai address/phone (announced but unpublished), current offers, testimonials, client results. Before/after visuals are labelled illustrative concept imagery.
- Known brand inconsistencies (site pages say 85+/90+/95+/162; IG says 250+) → demo uses the conservative "160+" and footnotes the source.

## 3. Testing performed

1. **Static checks:** `node --check` on JS; HTML tag-balance + asset-reference audit; CSS brace balance.
2. **jsdom interaction suite — 89/89 pass, 0 console errors:** marquee, stats, service explorer (+gender switch, tab switch, chip pick, prefill), BA slider keyboard, gallery filter + lightbox, loyalty maths (incl. 50%-cap & min-250 edge), finder search/chips/pins/empty-state, full booking flow incl. every validation branch, restart/back/Escape/scrim.
3. **Real Chromium (Playwright) — desktop 1440×900 + mobile 390×844:** zero console errors/warnings; Google fonts actually load; fonts verified via `document.fonts`; full-page + 25 section screenshots reviewed visually; mouse-drag on the before/after slider verified; map hover tooltip verified; full booking flow through the confirmation screen; **mobile horizontal overflow = 0 px**.
4. **Bugs found & fixed during testing:** drawer scrim stacking over the panel (z-index); year stat rendering "1,989"; booking drawer keeping stale state between opens; mobile ICB inflation (≈1269 px) caused by intrinsic tab-row width triggering Chromium zoom-out — fixed with `overflow-x: clip` on root + grid `min-width:0`; hero chip/badge overlap.

## 4. Known limitations (honest list)

- Booking is a **simulation** by design; confirmation screen says so and routes to the real toll-free line.
- 8 map pins use city-centroid coordinates (official data lacked coords) — flagged in the source JSON, not shown to users.
- Before/after imagery is AI-generated concept art, labelled as such on-page.
- Fonts load from Google Fonts; offline viewing falls back to the Didot/Georgia + system-sans stacks (page remains fully functional).
- No real backend; nothing persists (no localStorage/network in the flow).

## 5. Files

```
index.html                  single-page app shell + SEO/JSON-LD/CSP
assets/css/styles.css       original design system (~50 KB, no frameworks)
assets/js/data.js           verified dataset (services, 48 branches, cities, brands, map path)
assets/js/main.js           all interactions (~40 KB, vanilla)
assets/img/*                13 optimized original images + favicon
research/RESEARCH-NOTES.md  full source log & compliance decisions
research/branches-*.json    scraped branch data (raw + cleaned, with coord provenance)
```

*Concept, design & build: original work prepared as a client-facing showcase of AI-assisted design/development.*
