/* Looks Salon concept demo — data compiled from official lookssalon.in pages (Oct 2026).
   Branch list: 48 locations from the official Salon Finder. coord_source 'city-approx' = pin placed at city centre (site gave no coordinates). */
window.LOOKS = {
 "meta": {
  "brand": "Looks Salon",
  "tagline": "Let's not wait for the “Perfect Look”",
  "est": 1989,
  "tollFree": "1800 212 56657",
  "tollFreeHref": "tel:180021256657",
  "phonesAlt": [
   "+91 95827 15379",
   "+91 11 4549 1111"
  ],
  "hq": [
   "No 17A/22, Ajmal Khan Road",
   "Karol Bagh, New Delhi – 110005"
  ],
  "emails": {
   "Customer care": "customercare@lookssalon.in",
   "Franchise": "franchise@lookssalon.in",
   "Academy": "academy@lookssalon.in",
   "Careers": "careers@lookssalon.in"
  },
  "social": {
   "Instagram": "https://www.instagram.com/looksunisexsalon/",
   "Facebook": "https://www.facebook.com/Looksunisexsalon/",
   "X (Twitter)": "https://twitter.com/looksindia",
   "YouTube": "https://www.youtube.com/channel/UCumqzLQZUpcB1i5vbPHBAWw",
   "LinkedIn": "https://www.linkedin.com/company/looks-unisex-salon/"
  },
  "official": "https://www.lookssalon.in/",
  "academy": "http://www.looksschool.com/",
  "eshop": "https://www.lookskart.com/"
 },
 "stats": [
  {
   "value": 1989,
   "suffix": "",
   "label": "Established",
   "fmt": "year"
  },
  {
   "value": 160,
   "suffix": "+",
   "label": "Salons across India & Dubai"
  },
  {
   "value": 64,
   "suffix": "",
   "label": "Cities on the official booking list"
  },
  {
   "value": 6000,
   "suffix": "+",
   "label": "Team members"
  }
 ],
 "priceNote": "Indicative ranges compiled from third-party listings (2024–26); not official Looks Salon pricing. Confirm at the salon.",
 "services": {
  "ladies": [
   {
    "name": "Hair Styling",
    "img": "svc-hair.jpg",
    "blurb": "Precision cuts, blow-dries and finishing rituals shaped around your face and lifestyle.",
    "items": [
     "Hair Cut",
     "Ironing",
     "Global Colouring",
     "Blow Dry",
     "Root Touch Up",
     "Shampoo & Conditioning",
     "Head Massage",
     "Roller Setting",
     "Oiling"
    ],
    "price": "₹700 – ₹1,700",
    "priceKind": "indicative"
   },
   {
    "name": "Make Up",
    "img": "svc-bridal.jpg",
    "blurb": "From party glam to bridal artistry — makeup that photographs as beautifully as it wears.",
    "items": [
     "Party Make Up",
     "Engagement Make Up",
     "Bridal & Reception Make Up",
     "Base Make Up",
     "Eye Make Up"
    ],
    "price": "On consultation",
    "priceKind": "consult"
   },
   {
    "name": "Hair Texture",
    "img": "hero-main.jpg",
    "blurb": "Keratin, smoothening and rebonding systems for hair that stays effortlessly in place.",
    "items": [
     "Rebonding",
     "Perming",
     "Keratin",
     "Colour Protection",
     "Smoothening"
    ],
    "price": "On consultation",
    "priceKind": "consult"
   },
   {
    "name": "Hair Treatments",
    "img": "svc-colour.jpg",
    "blurb": "Salon-grade spa rituals that rebuild shine, volume and scalp health.",
    "items": [
     "Spa Treatments",
     "Volumizing",
     "Advanced Hair Moisturising",
     "Scalp Treatments"
    ],
    "price": "₹1,500 – ₹3,500",
    "priceKind": "indicative"
   },
   {
    "name": "Facials & Rituals",
    "img": "svc-skin.jpg",
    "blurb": "Luxury facials, clean-ups and body rituals for skin that glows beyond the salon.",
    "items": [
     "Bleach",
     "Luxury Facials/Rituals",
     "Clean Ups",
     "Body Polishing/Rejuvenation",
     "Threading"
    ],
    "price": "₹800 – ₹3,500",
    "priceKind": "indicative"
   },
   {
    "name": "Hand & Feet",
    "img": "svc-nails.jpg",
    "blurb": "Spa manicures, pedicures and waxing — detailed care for the finishing touches.",
    "items": [
     "Manicure",
     "Spa Pedicure",
     "Pedicure",
     "Waxing",
     "Spa Manicure"
    ],
    "price": "₹200 – ₹2,000",
    "priceKind": "indicative"
   },
   {
    "name": "Nail Care",
    "img": "svc-nails.jpg",
    "blurb": "Nail art, gel finishes and fills crafted with a steady hand and an eye for trend.",
    "items": [
     "Nail Paint",
     "Nail Art",
     "Nail Filling"
    ],
    "price": "On consultation",
    "priceKind": "consult"
   }
  ],
  "gents": [
   {
    "name": "Hair Cut & Finish",
    "img": "svc-gents.jpg",
    "blurb": "Sharp fades, classic cuts and beard work finished with a proper wash and style.",
    "items": [
     "Cut and Hair Care",
     "Shampoo & Conditioning",
     "Head Massage",
     "Beard Styling",
     "Hair/Beard Colouring"
    ],
    "price": "₹500 – ₹1,500",
    "priceKind": "indicative"
   },
   {
    "name": "Hair Colour",
    "img": "svc-colour.jpg",
    "blurb": "Ammonia and ammonia-free colour, hi-lites and beard colour with even, natural coverage.",
    "items": [
     "Hair Colour (Ammonia & Ammonia Free)",
     "Hi-Lites",
     "Beard Colour"
    ],
    "price": "₹1,200 – ₹2,000",
    "priceKind": "indicative"
   },
   {
    "name": "Hair Texture",
    "img": "hero-gents.jpg",
    "blurb": "Straightening, smoothening and perming systems engineered for men's hair.",
    "items": [
     "Straightening",
     "Smoothening",
     "Rebonding",
     "Perming"
    ],
    "price": "On consultation",
    "priceKind": "consult"
   },
   {
    "name": "Hair Treatments",
    "img": "interior.jpg",
    "blurb": "Hair spas and scalp therapies that undo the week's damage in one sitting.",
    "items": [
     "Hair Spa",
     "Advanced Moisturising",
     "Scalp Treatments",
     "Colour Protection"
    ],
    "price": "₹1,500 – ₹3,500",
    "priceKind": "indicative"
   },
   {
    "name": "Skin Care",
    "img": "svc-skin.jpg",
    "blurb": "Clean-ups, facials and organic treatments — skincare without the fuss.",
    "items": [
     "Clean Ups",
     "Facials",
     "Organic Treatments",
     "Manicure",
     "Pedicure"
    ],
    "price": "₹800 – ₹3,500",
    "priceKind": "indicative"
   },
   {
    "name": "Beard Grooming",
    "img": "hero-gents.jpg",
    "blurb": "Trims, hot-towel shaves and luxury beard spas for a defined, well-kept beard.",
    "items": [
     "Beard Trim",
     "Beard Colour",
     "Beard Styling",
     "Shave",
     "Luxury Shave & Beard Spa"
    ],
    "price": "On consultation",
    "priceKind": "consult"
   }
  ]
 },
 "brands": [
  "L'Oréal Professionnel",
  "Kérastase",
  "Moroccanoil",
  "Dermalogica",
  "GK Hair",
  "American Crew",
  "Wahl",
  "Dyson",
  "Balmain Paris",
  "Brasil Cacau",
  "Matrix",
  "Biotop",
  "Wet Brush",
  "René",
  "Swati",
  "Myolift"
 ],
 "collections": [
  "Bridal Collection",
  "Rock N Folk",
  "Launch Pad",
  "Andpersand Shoot",
  "Collection 2011",
  "Collection 2012"
 ],
 "gallery": [
  {
   "src": "hero-main.jpg",
   "cat": "hair",
   "title": "Signature gloss",
   "alt": "Woman with long glossy dark hair, editorial portrait"
  },
  {
   "src": "svc-hair.jpg",
   "cat": "hair",
   "title": "Blow-dry finish",
   "alt": "Stylist blow-drying long dark hair with a round brush"
  },
  {
   "src": "svc-colour.jpg",
   "cat": "colour",
   "title": "Caramel balayage",
   "alt": "Hair flip showing caramel and honey balayage highlights"
  },
  {
   "src": "ba-hair-after.jpg",
   "cat": "colour",
   "title": "Colour transformation",
   "alt": "After a salon colour transformation: sleek shiny hair"
  },
  {
   "src": "svc-bridal.jpg",
   "cat": "bridal",
   "title": "Bridal artistry",
   "alt": "Indian bride with gold jewellery and floral updo"
  },
  {
   "src": "hero-gents.jpg",
   "cat": "gents",
   "title": "Sharp & groomed",
   "alt": "Man with textured haircut and styled beard, side profile"
  },
  {
   "src": "svc-gents.jpg",
   "cat": "gents",
   "title": "Precision cut",
   "alt": "Barber cutting a client's hair with scissors in a premium salon"
  },
  {
   "src": "svc-skin.jpg",
   "cat": "skin",
   "title": "Glow ritual",
   "alt": "Woman receiving a luxury facial treatment"
  },
  {
   "src": "ba-skin-after.jpg",
   "cat": "skin",
   "title": "Skin transformation",
   "alt": "After a skincare ritual: clear radiant skin"
  },
  {
   "src": "svc-nails.jpg",
   "cat": "nails",
   "title": "Champagne nails",
   "alt": "Hands with nude-champagne manicure and gold nail art"
  },
  {
   "src": "interior.jpg",
   "cat": "salon",
   "title": "The floor",
   "alt": "Luxury salon interior with arched mirrors and warm lighting"
  }
 ],
 "cities": [
  "Agra",
  "Ahmedabad",
  "Aligarh",
  "Alwar",
  "Amritsar",
  "Bareilly",
  "Bathinda",
  "Bengaluru",
  "Bhagalpur",
  "Bhopal",
  "Bhubaneshwar",
  "Chandigarh",
  "Dehradun",
  "Deoria",
  "Dhanbad",
  "Faridabad",
  "Ghaziabad",
  "Goa",
  "Gorakhpur",
  "Greater Noida",
  "Gurugram",
  "Guwahati",
  "Gwalior",
  "Haldwani",
  "Haridwar",
  "Hissar",
  "Indore",
  "Jabalpur",
  "Jaipur",
  "Jalandhar",
  "Jalpaiguri",
  "Jammu",
  "Jhansi",
  "Kanpur",
  "Karnal",
  "Kolkata",
  "Lucknow",
  "Ludhiana",
  "Mandsaur",
  "Mathura",
  "Meerut",
  "Mohali",
  "Moradabad",
  "Mumbai",
  "Muzaffarpur",
  "New Delhi",
  "Noida",
  "Panchkula",
  "Panipat",
  "Pathankot",
  "Patiala",
  "Patna",
  "Prayagraj",
  "Pune",
  "Ranchi",
  "Rohtak",
  "Roorkee",
  "Rourkela",
  "Rudrapur",
  "Sonipat",
  "Srinagar",
  "Surat",
  "Udaipur",
  "Varanasi"
 ],
 "map": {
  "viewBox": "0 0 1000 1115",
  "path": "M994.3 361.4 L996.8 375.5 L985.3 382.3 L988.0 405.0 L964.6 398.3 L922.1 423.8 L923.1 444.7 L905.0 475.2 L903.4 492.8 L888.7 522.4 L863.1 514.3 L861.8 551.3 L854.4 563.4 L857.9 578.5 L841.7 586.9 L824.5 530.4 L815.4 530.5 L810.0 553.4 L792.1 534.9 L802.2 514.5 L816.9 512.4 L832.0 481.9 L813.1 475.7 L782.7 476.3 L751.5 471.3 L748.6 446.0 L733.0 444.2 L707.0 428.4 L695.4 453.2 L719.1 472.4 L698.6 485.9 L691.3 499.0 L711.5 508.7 L705.9 530.3 L717.3 557.1 L722.4 586.4 L717.7 599.3 L695.4 598.8 L654.9 606.1 L656.8 632.6 L639.3 653.3 L592.1 676.7 L555.4 717.5 L530.8 739.2 L498.1 761.7 L498.1 777.5 L481.7 785.9 L452.2 798.1 L436.9 799.9 L427.1 825.9 L433.9 869.9 L435.6 897.9 L421.7 929.8 L421.6 986.6 L404.6 988.2 L389.7 1013.6 L399.7 1024.5 L369.8 1034.0 L358.7 1056.5 L345.6 1066.0 L314.5 1035.1 L299.3 988.5 L286.8 954.9 L275.3 939.0 L257.9 906.8 L249.7 864.6 L244.1 843.5 L214.2 796.8 L200.7 730.4 L190.8 686.1 L191.0 643.9 L184.6 611.0 L136.9 632.1 L113.8 627.9 L71.0 585.2 L86.7 572.4 L77.0 558.4 L38.6 528.1 L60.4 504.2 L132.6 504.3 L126.1 473.3 L107.6 454.8 L103.9 426.7 L82.4 410.3 L118.6 371.5 L156.6 374.3 L190.9 335.3 L211.5 297.0 L243.3 258.9 L242.8 231.5 L270.8 209.1 L244.3 189.9 L232.9 163.5 L221.3 128.9 L237.4 111.7 L287.1 121.4 L323.7 115.5 L355.3 81.8 L390.6 128.7 L387.2 160.9 L400.3 181.0 L399.2 200.9 L375.7 195.7 L384.9 238.3 L417.1 262.6 L462.7 289.2 L441.9 306.4 L429.1 341.5 L460.9 355.6 L491.8 373.9 L534.6 394.7 L579.5 399.4 L598.4 418.2 L623.8 421.6 L663.2 430.2 L690.5 429.6 L694.3 415.1 L689.9 391.7 L692.5 375.7 L712.5 367.9 L715.2 397.1 L715.9 404.4 L745.7 418.4 L766.3 412.7 L794.0 415.1 L820.8 414.0 L823.1 391.4 L809.7 379.6 L836.2 375.0 L866.0 347.3 L903.8 323.4 L931.3 332.6 L954.7 316.8 L970.1 340.1 L959.0 355.8 L994.3 361.4 Z"
 },
 "branches": [
  {
   "city": "Bengaluru",
   "label": "Konanakunte Cross Metro Station",
   "addr": [
    "Konanakunte cross metro station",
    "213&214",
    "second floor",
    "Anjanadri layout",
    "Amruth nagar main road",
    "Konanakunte",
    "Bengaluru - 560078"
   ],
   "phones": [
    "+91 9845134508"
   ],
   "hrefs": [
    "tel:+919845134508"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 12.9716,
   "lng": 77.5946,
   "x": 347.4,
   "y": 899.1,
   "map": "https://www.google.com/maps/search/?api=1&query=Konanakunte+cross+metro+station%0D%0A213%26214%2C+second+floor%0D%0AAnjanadri+layout%2C+Amruth+nagar+main+road%0D%0AKonanakunte+%0D%0ABengaluru+-+560078"
  },
  {
   "city": "Bhagalpur",
   "label": "Khalifabagh Chowk, Adampur",
   "addr": [
    "Dr RP Road",
    "Khalifabagh Chowk",
    "Adampur",
    "Bhagalpur",
    "Bihar 812002"
   ],
   "phones": [
    "+91 91990 62666"
   ],
   "hrefs": [
    "tel:+919199062666"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 25.248123,
   "lng": 86.977825,
   "x": 655.0,
   "y": 472.1,
   "map": "https://www.google.com/maps/search/?api=1&query=Dr+RP+Road%0D%0AKhalifabagh+Chowk%2C+Adampur%2C+%0D%0ABhagalpur%2C+Bihar+812002"
  },
  {
   "city": "New Delhi",
   "label": "Pawa Presidential Business Park, Vasant Kunj",
   "addr": [
    "Unit No G1",
    "Ground Floor",
    "Tower No 5",
    "Pawa Presidential Business Park",
    "C-9",
    "Commercial Complex",
    "Vasant Kunj",
    "New Delhi -110070"
   ],
   "phones": [
    "+91 9355102022"
   ],
   "hrefs": [
    "tel:+919355102022"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.526132,
   "lng": 77.152695,
   "x": 332.9,
   "y": 351.5,
   "map": "https://www.google.com/maps/search/?api=1&query=Looks+Salon%2C%0D%0AUnit+No+G1%2C+Ground+Floor+%2C%0D%0ATower+No+5%2C+Pawa+Presidential+Business+Park%0D%0AC-9%2C+Commercial+Complex%2C+Vasant+Kunj%0D%0ANew+Delhi+-110070"
  },
  {
   "city": "New Delhi",
   "label": "Unity One Mall, Sector 10 Rohini",
   "addr": [
    "Unity One",
    "Shop No-120",
    "1st Floor",
    "Unityone Mall",
    "Sector-10"
   ],
   "phones": [
    "+91 9821413235",
    "+91 1140569623"
   ],
   "hrefs": [
    "tel:+919821413235",
    "tel:+911140569623"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.714877,
   "lng": 77.116618,
   "x": 331.7,
   "y": 344.5,
   "map": "https://www.google.com/maps/search/?api=1&query=Looks+Salon%2C+Unity+One%0D%0AShop+No-120%2C+1st+Floor%2C+%0D%0AUnityone+Mall%2C+Sector-10"
  },
  {
   "city": "Mumbai",
   "label": "Grand Hyatt, Santacruz East",
   "addr": [
    "Lobby Level",
    "Grand Hyatt Mumbai",
    "Off Western Express Highway",
    "Vakola",
    "Santacruz (East)",
    "Mumbai \\u2013 400055"
   ],
   "phones": [
    "+91 91373 66133"
   ],
   "hrefs": [
    "tel:+919137366133"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 19.076885,
   "lng": 72.851114,
   "x": 191.8,
   "y": 690.7,
   "map": "https://www.google.com/maps/search/?api=1&query=Looks+Salon%2C%0D%0ALobby+Level%2C+Grand+Hyatt+Mumbai%2C%0D%0AOff+Western+Express+Highway%2C%0D%0AVakola%2C+Santacruz+%28East%29%2C%0D%0AMumbai+%E2%80%93+400055"
  },
  {
   "city": "Gurugram",
   "label": "Vista Square, Sector 82A",
   "addr": [
    "Shop no. S-201-204",
    "Second Floor",
    "Vista Square",
    "Sector - 82A",
    "Gurgaon - 122001"
   ],
   "phones": [
    "+91 92183 01614"
   ],
   "hrefs": [
    "tel:+919218301614"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.4595,
   "lng": 77.0266,
   "x": 328.7,
   "y": 354.0,
   "map": "https://www.google.com/maps/search/?api=1&query=Looks+Salon%2C%0D%0AShop+no.+S-201-204%2C+%0D%0ASecond+Floor%2C+%0D%0AVista+Square%2C+Sector+-+82A%2C%0D%0AGurgaon+-+122001"
  },
  {
   "city": "Hissar",
   "label": "Rukmani Complex, Model Town",
   "addr": [
    "265 - 1st floor",
    "Rukmani Complex",
    "Model Town",
    "Near N D Hospital",
    "Gurudwara Road",
    "Hissar - 125001",
    "Haryana"
   ],
   "phones": [
    "+91 166 2247017",
    "8295445128"
   ],
   "hrefs": [
    "tel:+911662247017",
    "tel:8295445128"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 29.1492,
   "lng": 75.7217,
   "x": 286.0,
   "y": 328.2,
   "map": "https://www.google.com/maps/search/?api=1&query=Looks+Salon%2C%0D%0A265+-+1st+floor%2C%0D%0ARukmani+Complex%2C+Model+Town%2C%0D%0ANear+N+D+Hospital%2C+Gurudwara+Road%2C%0D%0AHissar+-+125001%0D%0AHaryana"
  },
  {
   "city": "Roorkee",
   "label": "Jadugar Road, Civil Lines",
   "addr": [
    "Looks Salon Roorkee",
    "Shop No-43",
    "Ground Floor",
    "Jadugar Road",
    "Civil Lines",
    "Opp. HDFC Bank",
    "Roorkee-247667",
    "Uttarakhand"
   ],
   "phones": [
    "+91 99174 77737"
   ],
   "hrefs": [
    "tel:+919917477737"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 29.867568,
   "lng": 77.887037,
   "x": 357.0,
   "y": 301.2,
   "map": "https://www.google.com/maps/search/?api=1&query=Looks+Salon+Roorkee%2C+%0D%0AShop+No-43%2C+Ground+Floor%2C%0D%0AJadugar+Road%2C+Civil+Lines%2C+%0D%0AOpp.+HDFC+Bank%2C+%0D%0ARoorkee-247667%2C+%0D%0AUttarakhand"
  },
  {
   "city": "Ranchi",
   "label": "Shri Ram Garden",
   "addr": [
    "Shri Ram Garden",
    "Ground Floor",
    "Shop no.5 & 6",
    "Kanke Road",
    "Ranchi"
   ],
   "phones": [
    "+91 9155942428"
   ],
   "hrefs": [
    "tel:+919155942428"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 23.397621,
   "lng": 85.315217,
   "x": 600.5,
   "y": 538.7,
   "map": "https://www.google.com/maps/search/?api=1&query=Shri+Ram+Garden%2C+Ground+Floor%2C+Shop+no.5+%26+6%2C+Kanke+Road%2C+Ranchi"
  },
  {
   "city": "New Delhi",
   "label": "The Amaryllis, New Rohtak Road",
   "addr": [
    "The Emperious club house",
    "Basement",
    "The Amaryllis",
    "New Rohtak Road",
    "New Delhi - 110005"
   ],
   "phones": [
    "011 - 71523435"
   ],
   "hrefs": [
    "tel:01171523435"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.658346,
   "lng": 77.194115,
   "x": 334.2,
   "y": 346.6,
   "map": "https://www.google.com/maps/search/?api=1&query=The+Emperious+club+house%2C+Basement%2C+The+Amaryllis%2C+New+Rohtak+Road%2C+New+Delhi+-+110005"
  },
  {
   "city": "Meerut",
   "label": "Downtown, Mawana Road",
   "addr": [
    "Kaseru Buxur 1st Floor F11 F12 F12/1 F14",
    "Downtown Khasra No.482 483",
    "Mawana Road Ganga Nagar",
    "Meerut - 250001 Uttar Pradesh"
   ],
   "phones": [
    "9068181115",
    "0121-4355099"
   ],
   "hrefs": [
    "tel:9068181115",
    "tel:01214355099"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.9845,
   "lng": 77.7064,
   "x": 351.0,
   "y": 334.4,
   "map": "https://www.google.com/maps/search/?api=1&query=Kaseru+Buxur+1st+Floor+F11+F12+F12%2F1+F14%2C+Downtown+Khasra+No.482+483%2C+Mawana+Road+Ganga+Nagar%2C+Meerut+-+250001+Uttar+Pradesh"
  },
  {
   "city": "Bengaluru",
   "label": "Vega City Mall, Bannerghatta Road",
   "addr": [
    "Shop No-10 Second Floor",
    "SF10 Vega City Mall",
    "Bannerghatta Road Dollars Colony",
    "BTM 2nd Stage J.P. Nagar",
    "Bengaluru - 560046 Karnataka"
   ],
   "phones": [
    "+91 97411 18304"
   ],
   "hrefs": [
    "tel:+919741118304"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 12.908844,
   "lng": 77.59928,
   "x": 347.5,
   "y": 901.2,
   "map": "https://www.google.com/maps/search/?api=1&query=Shop+No-10+Second+Floor%2C+SF10+Vega+City+Mall%2C+Bannerghatta+Road+Dollars+Colony%2C+BTM+2nd+Stage+J.P.+Nagar%2C+Bengaluru+-+560046+Karnataka"
  },
  {
   "city": "Noida",
   "label": "Sector 137 Metro Station",
   "addr": [
    "Shop no. 7",
    "Ground floor",
    "Metro station",
    "Sector 137",
    "Noida - 201305 Uttar Pradesh"
   ],
   "phones": [
    "9625227146"
   ],
   "hrefs": [
    "tel:9625227146"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.516324,
   "lng": 77.402639,
   "x": 341.1,
   "y": 351.9,
   "map": "https://www.google.com/maps/search/?api=1&query=Shop+no.+7%2C+Ground+floor%2C+Metro+station%2C+Sector+137%2C+Noida+-+201305+Uttar+Pradesh"
  },
  {
   "city": "Indore",
   "label": "23 Patrakar Square",
   "addr": [
    "23 Patrakar Square",
    "Infront of Baskin Robins Icecream",
    "Near to Starbucks Saket Indore"
   ],
   "phones": [
    "07400555561",
    "07314083748"
   ],
   "hrefs": [
    "tel:07400555561",
    "tel:07314083748"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 22.697903,
   "lng": 75.865401,
   "x": 290.7,
   "y": 563.6,
   "map": "https://www.google.com/maps/search/?api=1&query=23+Patrakar+Square%2C+Infront+of+Baskin+Robins+Icecream%2C+Near+to+Starbucks+Saket+Indore"
  },
  {
   "city": "Dehradun",
   "label": "46 EC Road, Near Dwarka Store",
   "addr": [
    "46 EC Road",
    "IDA Hotel",
    "Near Dwarka Store",
    "Dehradun-248001 Uttarakhand"
   ],
   "phones": [
    "9910460497"
   ],
   "hrefs": [
    "tel:9910460497"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 30.316019,
   "lng": 78.04992,
   "x": 362.3,
   "y": 284.2,
   "map": "https://www.google.com/maps/search/?api=1&query=46+EC+Road%2C+IDA+Hotel%2C+Near+Dwarka+Store%2C+Dehradun-248001+Uttarakhand"
  },
  {
   "city": "Indore",
   "label": "Princess Business Skypark, opp. C21 Mall",
   "addr": [
    "Unit No - 113/114 & 115 First Floor",
    "Princess Business Skypark",
    "Opp. c 21 Mall A B Road",
    "Scheme No 54",
    "Indore- 452001 Madya Pradesh"
   ],
   "phones": [
    "0731-4083748",
    "07400555561",
    "07400555562",
    "09993094444"
   ],
   "hrefs": [
    "tel:07314083748",
    "tel:07400555561",
    "tel:07400555562",
    "tel:09993094444"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 22.745802,
   "lng": 75.893103,
   "x": 291.6,
   "y": 561.9,
   "map": "https://www.google.com/maps/search/?api=1&query=Unit+No+-+113%2F114+%26+115%C2%A0First+Floor%2C+Princess+Business+Skypark%2C+Opp.+c+21+Mall+A+B+Road%2C+Scheme+No+54%2C+Indore-+452001+Madya+Pradesh"
  },
  {
   "city": "Noida",
   "label": "Tower C, Sector 142, Noida–GN Expressway",
   "addr": [
    "Tower C",
    "Shop 7",
    "Noida-Greater Noida Expy",
    "Sector 142",
    "Noida - 201305 Uttar Pradesh"
   ],
   "phones": [
    "+91 9311339780"
   ],
   "hrefs": [
    "tel:+919311339780"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.501162,
   "lng": 77.410279,
   "x": 341.3,
   "y": 352.5,
   "map": "https://www.google.com/maps/search/?api=1&query=Tower+C%2C+Shop+7%2C+Noida-Greater+Noida+Expy%2C+Sector+142%2C+Noida+-+201305+Uttar+Pradesh"
  },
  {
   "city": "New Delhi",
   "label": "The Square Pavilion, GMR Aerocity",
   "addr": [
    "The Square",
    "Pavilion",
    "GMR Aerocity",
    "New Delhi - 110037"
   ],
   "phones": [
    "+91 9990067741"
   ],
   "hrefs": [
    "tel:+919990067741"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.6139,
   "lng": 77.209,
   "x": 334.7,
   "y": 348.3,
   "map": "https://www.google.com/maps/search/?api=1&query=The+Square%2C+Pavilion%2C+GMR+Aerocity%2C+New+Delhi+-+110037"
  },
  {
   "city": "New Delhi",
   "label": "Worldmark 1, Aerocity",
   "addr": [
    "GF-16",
    "West Wing",
    "Worldmark-1 Aerocity",
    "South West Delhi",
    "New Delhi-110037"
   ],
   "phones": [
    "011 49057442",
    "011 49057452"
   ],
   "hrefs": [
    "tel:01149057442",
    "tel:01149057452"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.550896,
   "lng": 77.12286,
   "x": 331.9,
   "y": 350.6,
   "map": "https://www.google.com/maps/search/?api=1&query=GF-16%2C+West+Wing%2C+Worldmark-1+Aerocity%2C+South+West+Delhi%2C+New+Delhi-110037%0D%0A%0D%0A"
  },
  {
   "city": "New Delhi",
   "label": "AGCR Enclave, Near Karkarduma Court",
   "addr": [
    "286",
    "AGCR Enclave",
    "Opp Shanti Vihar",
    "Near Karkarduma Court",
    "Delhi-110092"
   ],
   "phones": [
    "011 40105540"
   ],
   "hrefs": [
    "tel:01140105540"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.654535,
   "lng": 77.295429,
   "x": 337.6,
   "y": 346.7,
   "map": "https://www.google.com/maps/search/?api=1&query=286%2C+AGCR+Enclave%2C+Opp+Shanti+Vihar%2C+Near+Karkarduma+Court%2CDelhi-110092"
  },
  {
   "city": "Ahmedabad",
   "label": "Ahmedabad One Mall, Vastrapur",
   "addr": [
    "3rd Floor",
    "Ahmedabad One Mall",
    "Plot no.216",
    "TP Scheme-A",
    "Near Vastrapur Lake",
    "Vastrapur",
    "Ahmedabad - 380054 Gujrat"
   ],
   "phones": [
    "09710564400",
    "09710564401"
   ],
   "hrefs": [
    "tel:09710564400",
    "tel:09710564401"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 23.040008,
   "lng": 72.531364,
   "x": 181.4,
   "y": 551.4,
   "map": "https://www.google.com/maps/search/?api=1&query=3rd+Floor%2C+Ahmedabad+One+Mall%2C+Plot+no.216%2C+TP+Scheme-A%2C+Near+Vastrapur+Lake%2C+Vastrapur%2C+Ahmedabad+-+380054+Gujrat"
  },
  {
   "city": "Gurugram",
   "label": "AIPL Joy Street, Sector 66",
   "addr": [
    "Ground Floor",
    "57",
    "AIPL Joy Street",
    "Main Road",
    "Sector - 66",
    "Gurgaon - 122018 Haryana"
   ],
   "phones": [
    "07838113555"
   ],
   "hrefs": [
    "tel:07838113555"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 24.426221,
   "lng": 73.987169,
   "x": 229.1,
   "y": 501.8,
   "map": "https://www.google.com/maps/search/?api=1&query=Ground+Floor%2C+57%2C+AIPL+Joy+Street%2C+Main+Road%2C+Sector+-+66%2C+Gurgaon+-+122018+Haryana"
  },
  {
   "city": "Gurugram",
   "label": "Airia Mall, Sohna Road Sector 68",
   "addr": [
    "4B",
    "1st Floor",
    "Airia Mall",
    "Sohna Road",
    "Sector-68",
    "Gurgaon-122103 Haryana"
   ],
   "phones": [
    "7428006602",
    "7428006601"
   ],
   "hrefs": [
    "tel:7428006602",
    "tel:7428006601"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.4595,
   "lng": 77.0266,
   "x": 328.7,
   "y": 354.0,
   "map": "https://www.google.com/maps/search/?api=1&query=4B%2C+1st+Floor%2C+Airia+Mall%2C+Sohna+Road%2C+Sector-68%2C+Gurgaon-122103+Haryana"
  },
  {
   "city": "Alwar",
   "label": "Lajpat Nagar, Ambedkar Circle",
   "addr": [
    "Looks Salon Alwar",
    "Plot no. 14",
    "First floor",
    "Lajpat nagar",
    "Ambedkar Circle",
    "Alwar - 301001"
   ],
   "phones": [
    "+91 144 452 4482",
    "+91 9982088808"
   ],
   "hrefs": [
    "tel:+911444524482",
    "tel:+919982088808"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 27.5701,
   "lng": 76.6182,
   "x": 315.4,
   "y": 387.1,
   "map": "https://www.google.com/maps/search/?api=1&query=Looks+Salon+Alwar%2C%0D%0APlot+no.+14%2C+First+floor%2C%0D%0ALajpat+nagar%2C+Ambedkar+Circle%2C%0D%0AAlwar+-+301001"
  },
  {
   "city": "Gurugram",
   "label": "Ambience Mall",
   "addr": [
    "S-201 2nd Floor",
    "Ambience Mall",
    "Gurugram-122001 Haryana"
   ],
   "phones": [
    "0124 4029140",
    "0124 4029141"
   ],
   "hrefs": [
    "tel:01244029140",
    "tel:01244029141"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.505373,
   "lng": 77.096412,
   "x": 331.0,
   "y": 352.3,
   "map": "https://www.google.com/maps/search/?api=1&query=S-201+2nd+Floor%2C+Ambience+Mall%2CGurugram-122001+Haryana%0D%0A%0D%0A"
  },
  {
   "city": "Gurugram",
   "label": "Ardee City Mall, Sector 52",
   "addr": [
    "2nd Floor",
    "Block B",
    "Ardee City Mall",
    "Ardee City",
    "Sector 52",
    "Gurugram - 122003 Haryana"
   ],
   "phones": [
    "0124-2806628",
    "0124-2806629"
   ],
   "hrefs": [
    "tel:01242806628",
    "tel:01242806629"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.44518,
   "lng": 77.08073,
   "x": 330.5,
   "y": 354.6,
   "map": "https://www.google.com/maps/search/?api=1&query=2nd+Floor%2C+Block+B%2C+Ardee+City+Mall%2C+Ardee+City%2C+Sector+52%2C+Gurugram+-+122003+Haryana"
  },
  {
   "city": "Haridwar",
   "label": "Aryanagar Chowk",
   "addr": [
    "Ground floor",
    "Sitaram house",
    "Aryanagar chowk",
    "Haridwar - 249407 Uttar Pradesh"
   ],
   "phones": [
    "+91 9634198794"
   ],
   "hrefs": [
    "tel:+919634198794"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 29.92604,
   "lng": 78.121158,
   "x": 364.6,
   "y": 298.9,
   "map": "https://www.google.com/maps/search/?api=1&query=Ground+floor%2C+Sitaram+house%2C+Aryanagar+chowk+%2C+Haridwar+-+249407+Uttar+Pradesh"
  },
  {
   "city": "Patna",
   "label": "Dev Shiv Complex, Ashiana–Digha Road",
   "addr": [
    "Ground Floor & First Floor",
    "Dev Shiv Complex",
    "Ashiana Digha Road",
    "Passport Office",
    "Patna",
    "Bihar-800014"
   ],
   "phones": [
    "9955262100"
   ],
   "hrefs": [
    "tel:9955262100"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 25.5941,
   "lng": 85.1376,
   "x": 594.7,
   "y": 459.5,
   "map": "https://www.google.com/maps/search/?api=1&query=Ground+Floor+%26+First+Floor%2C+Dev+Shiv+Complex%2C+%0D%0AAshiana+Digha+Road%2C+Passport+Office%2C%0D%0APatna%2C+Bihar-800014"
  },
  {
   "city": "New Delhi",
   "label": "Ashok Vihar Phase II",
   "addr": [
    "B-3/4",
    "Ashok Vihar",
    "Phase II",
    "New Delhi-110052"
   ],
   "phones": [
    "011 45038900",
    "011 45038903"
   ],
   "hrefs": [
    "tel:01145038900",
    "tel:01145038903"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.692625,
   "lng": 77.139184,
   "x": 332.4,
   "y": 345.3,
   "map": "https://www.google.com/maps/search/?api=1&query=B-3%2F4%2C+Ashok+Vihar%2C+Phase+II%2C+New+Delhi-110052"
  },
  {
   "city": "Patna",
   "label": "B.R. House, Patliputra Colony",
   "addr": [
    "B.R.House",
    "Plot no-145",
    "Opp-SBI Bank",
    "Patliputra Colony",
    "Patna-800013 Bihar"
   ],
   "phones": [
    "0612 2266300"
   ],
   "hrefs": [
    "tel:06122266300"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 25.628618,
   "lng": 85.107189,
   "x": 593.7,
   "y": 458.3,
   "map": "https://www.google.com/maps/search/?api=1&query=B.R.House%2C+Plot+no-145%2C+Opp-SBI+Bank%2C+Patliputra+Colony%2C+Patna-800013+Bihar"
  },
  {
   "city": "Goa",
   "label": "Anjuna Beach Road, Bardez",
   "addr": [
    "179/9",
    "Anjuna Beach road",
    "Anjune",
    "Bardez",
    "Goa - 403509"
   ],
   "phones": [
    "+91 9582998299"
   ],
   "hrefs": [
    "tel:+919582998299"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 15.58641,
   "lng": 73.744588,
   "x": 221.1,
   "y": 810.6,
   "map": "https://www.google.com/maps/search/?api=1&query=179%2F9%2C+Anjuna+Beach+road%2C+Anjune%2C+Bardez%2C+Goa+-+403509+"
  },
  {
   "city": "Mohali",
   "label": "Bestech Square Mall, Sector 66",
   "addr": [
    "2nd floor",
    "Unit No.- S-1 & 2",
    "Bestech square mall",
    "Sector-66",
    "Mohali - 160017 Punjab"
   ],
   "phones": [
    "095018-54111"
   ],
   "hrefs": [
    "tel:09501854111"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 30.6736,
   "lng": 76.736017,
   "x": 319.2,
   "y": 270.6,
   "map": "https://www.google.com/maps/search/?api=1&query=2nd+floor%2C+Unit+No.-+S-1+%26+2%2C+Bestech+square+mall%2C+Sector-66%2C+Mohali+-+160017+Punjab%0D%0A"
  },
  {
   "city": "Agra",
   "label": "Shanti City Centre, Khandari",
   "addr": [
    "Shop No-9 Shanti City Centre",
    "Bhagirathi Marg",
    "Khandari",
    "Agra- 282002"
   ],
   "phones": [
    "0562 4040888",
    "7457038883",
    "98975 90901"
   ],
   "hrefs": [
    "tel:05624040888",
    "tel:7457038883",
    "tel:9897590901"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 27.207198,
   "lng": 77.991954,
   "x": 360.4,
   "y": 400.5,
   "map": "https://www.google.com/maps/search/?api=1&query=Shop+No-9+Shanti+City+Centre%2C+Bhagirathi+Marg%2C+Khandari%2C+Agra-+282002%0D%0A%0D%0A"
  },
  {
   "city": "Noida",
   "label": "Bhutani City Centre, Sector 150",
   "addr": [
    "Ground Floor",
    "Tower-B",
    "Bhutani City Centre",
    "Unit no. GF22 26 37",
    "Sector 150",
    "Noida - 201306",
    "Uttar Pradesh"
   ],
   "phones": [
    "+91 83681 70383"
   ],
   "hrefs": [
    "tel:+918368170383"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.501058,
   "lng": 77.41097,
   "x": 341.3,
   "y": 352.5,
   "map": "https://www.google.com/maps/search/?api=1&query=Looks+Salon%2C%0D%0AGround+Floor%2C+Tower-B%2C+%0D%0ABhutani+City+Centre%2C+Unit+no.+GF22+26++37%2C+%0D%0ASector+150%2C+%0D%0ANoida+-+201306%0D%0AUttar+Pradesh"
  },
  {
   "city": "Noida",
   "label": "Binge Central, Candor Techspace Sector 62",
   "addr": [
    "Unit no.10",
    "Binge Central",
    "Candor Techspace",
    "Sector - 62",
    "Noida - 201301 Uttar Pradesh"
   ],
   "phones": [],
   "hrefs": [],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.5355,
   "lng": 77.391,
   "x": 340.7,
   "y": 351.2,
   "map": "https://www.google.com/maps/search/?api=1&query=Unit+no.10%2C+Binge+Central%2C+Candor+Techspace%2C+Sector+-+62%2C+Noida+-+201301+Uttar+Pradesh+"
  },
  {
   "city": "Mumbai",
   "label": "Brady House, Veer Nariman Road, Fort",
   "addr": [
    "Shop No.1",
    "Ground Floor 12/14 Veer Nariman Road",
    "Brady House",
    "Fort",
    "Mumbai - 400001 Maharastra"
   ],
   "phones": [
    "09643748988"
   ],
   "hrefs": [
    "tel:09643748988"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 18.932328,
   "lng": 72.83368,
   "x": 191.3,
   "y": 695.7,
   "map": "https://www.google.com/maps/search/?api=1&query=Shop+No.1%2CGround+Floor+12%2F14+Veer+Nariman+Road%2C+Brady+House%2C+Fort%2C+Mumbai+-+400001+Maharastra%0D%0A%0D%0A"
  },
  {
   "city": "Pune",
   "label": "Castle Royale",
   "addr": [
    "Castle Royale Pune - 411020 Maharashtra"
   ],
   "phones": [
    "9015 375 206"
   ],
   "hrefs": [
    "tel:9015375206"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 18.557222,
   "lng": 73.829228,
   "x": 223.9,
   "y": 708.7,
   "map": "https://www.google.com/maps/search/?api=1&query=Castle+Royale+Pune+-+411020+Maharashtra"
  },
  {
   "city": "Noida",
   "label": "Central Market, Sector 120",
   "addr": [
    "Shop no. AG 14",
    "15 & 16",
    "Central market",
    "Sector 120",
    "Noida - 201301 Uttar Pradesh"
   ],
   "phones": [
    "92208 71559"
   ],
   "hrefs": [
    "tel:9220871559"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.586658,
   "lng": 77.398301,
   "x": 340.9,
   "y": 349.3,
   "map": "https://www.google.com/maps/search/?api=1&query=Shop+no.+AG+14%2C+15+%26+16%2C+Central+market%2C+Sector+120%2C+Noida+-+201301+Uttar+Pradesh"
  },
  {
   "city": "New Delhi",
   "label": "Tikendrajit Marg, Chanakyapuri",
   "addr": [
    "13A-16D",
    "Tikendrajit Marg",
    "Chanakyapuri",
    "New Delhi",
    "Delhi 110021"
   ],
   "phones": [
    "01126110866",
    "01126110865"
   ],
   "hrefs": [
    "tel:01126110866",
    "tel:01126110865"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.585333,
   "lng": 77.190905,
   "x": 334.1,
   "y": 349.3,
   "map": "https://www.google.com/maps/search/?api=1&query=13A-16D%2C+Tikendrajit+Marg%2C+Chanakyapuri%2C+New+Delhi%2C+Delhi+110021"
  },
  {
   "city": "New Delhi",
   "label": "Omaxe Chowk Mall, Chandni Chowk",
   "addr": [
    "Shop no.025-32",
    "1st Floor",
    "Omaxe Chowk Mall",
    "H.C Sen Marg",
    "Gandhi Maidan",
    "Chandni Chowk",
    "Delhi - 110006"
   ],
   "phones": [
    "+91 1142231947"
   ],
   "hrefs": [
    "tel:+911142231947"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.657446,
   "lng": 77.231076,
   "x": 335.4,
   "y": 346.6,
   "map": "https://www.google.com/maps/search/?api=1&query=Shop+no.025-32%2C+1st+Floor%2C+Omaxe+Chowk+Mall%2C+H.C+Sen+Marg%2C+Gandhi+Maidan%2C+Chandni+Chowk%2C+Delhi+-+110006"
  },
  {
   "city": "Karnal",
   "label": "Dayal Tower, Kunjpura Road",
   "addr": [
    "Dayal Tower",
    "1st Floor",
    "Commercial Complex",
    "390",
    "Char Chaman",
    "Kunjpura Road",
    "Karnal - 132001 Haryana"
   ],
   "phones": [
    "0184-4051600",
    "1844051500"
   ],
   "hrefs": [
    "tel:01844051600",
    "tel:1844051500"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 29.68013,
   "lng": 77.0848,
   "x": 330.6,
   "y": 308.2,
   "map": "https://www.google.com/maps/search/?api=1&query=Dayal+Tower%2C1st+Floor%2C+Commercial+Complex%2C+390%2CChar+Chaman%2C+Kunjpura+Road%2C+Karnal+-+132001+Haryana"
  },
  {
   "city": "New Delhi",
   "label": "Chittaranjan Park",
   "addr": [
    "K-1/109",
    "Basement & Grd Floor",
    "Chittranjan Park",
    "New Delhi - 110019"
   ],
   "phones": [
    "+91 11 42765083",
    "42765084"
   ],
   "hrefs": [
    "tel:+911142765083",
    "tel:42765084"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.54067,
   "lng": 77.24819,
   "x": 336.0,
   "y": 351.0,
   "map": "https://www.google.com/maps/search/?api=1&query=K-1%2F109%2C+Basement+%26+Grd+Floor%2C%0D%0AChittranjan+Park%2C%0D%0ANew+Delhi+-+110019"
  },
  {
   "city": "Guwahati",
   "label": "City Centre Mall, G.S. Road",
   "addr": [
    "3rd floor",
    "City Centre Mall",
    "G S Road",
    "Guwahati - 781005 Assam"
   ],
   "phones": [
    "8812935810"
   ],
   "hrefs": [
    "tel:8812935810"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 26.14436,
   "lng": 91.79181,
   "x": 812.8,
   "y": 439.5,
   "map": "https://www.google.com/maps/search/?api=1&query=3rd+floor%2C+City+Centre+Mall%2C+G+S+Road%2C+Guwahati+-+781005+Assam"
  },
  {
   "city": "New Delhi",
   "label": "6 Alipur Road, Shamnath Marg",
   "addr": [
    "6 Alipur Road",
    "Shamnath Marg",
    "Civil Lines",
    "Delhi-110054"
   ],
   "phones": [
    "+91 9266410101"
   ],
   "hrefs": [
    "tel:+919266410101"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.673614,
   "lng": 77.225567,
   "x": 335.3,
   "y": 346.0,
   "map": "https://www.google.com/maps/search/?api=1&query=6+Alipur+Road%2C+Shamnath+Marg%2C+Civil+Lines%2C+Delhi-110054%0D%0A%0D%0A"
  },
  {
   "city": "Ludhiana",
   "label": "Rani Jhansi Road, Civil Lines",
   "addr": [
    "Ground Floor",
    "B-19/400-2",
    "Rani Jhansi Road",
    "Civil Lines",
    "Ludhiana - 141001 Punjab"
   ],
   "phones": [
    "9878196700",
    "9878126700",
    "0161-4080203",
    "+91 9289052421",
    "+91 1206582419"
   ],
   "hrefs": [
    "tel:9878196700",
    "tel:9878126700",
    "tel:01614080203",
    "tel:+919289052421",
    "tel:+911206582419"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.596859,
   "lng": 77.392477,
   "x": 340.7,
   "y": 348.9,
   "map": "https://www.google.com/maps/search/?api=1&query=Ground+Floor%2C+B-19%2F400-2%2C+Rani+Jhansi+Road%2C+Civil+Lines%2C+Ludhiana+-+141001+Punjab"
  },
  {
   "city": "New Delhi",
   "label": "Club Road, West Punjabi Bagh",
   "addr": [
    "13C",
    "Club Road",
    "West Punjabi Bagh",
    "New Delhi-110026"
   ],
   "phones": [
    "01140548761",
    "01147501948"
   ],
   "hrefs": [
    "tel:01140548761",
    "tel:01147501948"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.667131,
   "lng": 77.126001,
   "x": 332.0,
   "y": 346.3,
   "map": "https://www.google.com/maps/search/?api=1&query=13C%2C+Club+Road%2C+West+Punjabi+Bagh%2C+New+Delhi-110026"
  },
  {
   "city": "New Delhi",
   "label": "Inner Circle, Connaught Place",
   "addr": [
    "C - 33 First Floor",
    "Inner Circle Connaught Place",
    "Delhi-110001"
   ],
   "phones": [
    "011 4351 2929"
   ],
   "hrefs": [
    "tel:01143512929"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.634541,
   "lng": 77.22003,
   "x": 335.1,
   "y": 347.5,
   "map": "https://www.google.com/maps/search/?api=1&query=C+-+33+First+Floor%2CInner+Circle+Connaught+Place%2C+Delhi-110001%0D%0A%0D%0A"
  },
  {
   "city": "New Delhi",
   "label": "Regal Building, Connaught Place",
   "addr": [
    "44 Regal Building",
    "Near Madame Tussauds",
    "Connaught Place",
    "New Delhi - 110001"
   ],
   "phones": [
    "+91 98183 23559",
    "011-45586734"
   ],
   "hrefs": [
    "tel:+919818323559",
    "tel:01145586734"
   ],
   "hours": "10:00 AM – 9:00 PM",
   "lat": 28.63243,
   "lng": 77.21879,
   "x": 335.0,
   "y": 347.6,
   "map": "https://www.google.com/maps/search/?api=1&query=44+Regal+Building%2C+Near+Madame+Tussauds%2C+Connaught+Place%2C+New+Delhi+-+110001"
  }
 ]
};
