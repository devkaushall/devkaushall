/* ============================================================
   LOOKS SALON — CONCEPT DEMO · main.js
   Vanilla JS, no dependencies. All booking is simulated in-memory.
   ============================================================ */
(function () {
  'use strict';

  var D = window.LOOKS;
  if (!D) { console.error('LOOKS data missing'); return; }

  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
  var REDUCED = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var inr = function (n) { return '₹' + Math.round(n).toLocaleString('en-IN'); };
  var esc = function (s) { return String(s).replace(/[&<>"']/g, function (m) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[m]; }); };

  /* ---------- Demo strip ---------- */
  var strip = $('#demoStrip');
  $('#demoStripClose').addEventListener('click', function () { strip.classList.add('is-hidden'); });

  /* ---------- Header state + mobile menu ---------- */
  var head = $('#siteHead');
  var burger = $('#burger');
  var mobileMenu = $('#mobileMenu');
  var onScroll = function () { head.classList.toggle('is-stuck', window.scrollY > 12); };
  window.addEventListener('scroll', onScroll, { passive: true }); onScroll();

  var closeMenu = function () {
    mobileMenu.classList.remove('is-open');
    mobileMenu.setAttribute('aria-hidden', 'true');
    burger.classList.remove('is-open');
    burger.setAttribute('aria-expanded', 'false');
    burger.setAttribute('aria-label', 'Open menu');
    document.body.classList.remove('no-scroll');
  };
  burger.addEventListener('click', function () {
    var open = !mobileMenu.classList.contains('is-open');
    mobileMenu.classList.toggle('is-open', open);
    mobileMenu.setAttribute('aria-hidden', String(!open));
    burger.classList.toggle('is-open', open);
    burger.setAttribute('aria-expanded', String(open));
    burger.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    document.body.classList.toggle('no-scroll', open);
    if (open) { var f = mobileMenu.querySelector('a'); if (f) f.focus(); }
  });
  $$('#mobileMenu a').forEach(function (a) { a.addEventListener('click', closeMenu); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeMenu(); });

  /* ---------- Scrollspy ---------- */
  var spyLinks = $$('.main-nav a[data-spy]');
  var spyMap = {};
  spyLinks.forEach(function (a) { spyMap[a.getAttribute('data-spy')] = a; });
  if ('IntersectionObserver' in window) {
    var spy = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) {
          spyLinks.forEach(function (a) { a.classList.remove('is-active'); });
          var l = spyMap[en.target.id]; if (l) l.classList.add('is-active');
        }
      });
    }, { rootMargin: '-35% 0px -55% 0px' });
    ['services', 'transformations', 'gallery', 'loyalty', 'salons', 'story'].forEach(function (id) {
      var el = document.getElementById(id); if (el) spy.observe(el);
    });
  }

  /* ---------- Reveal on scroll ---------- */
  var revealEls = $$('.reveal');
  if (REDUCED || !('IntersectionObserver' in window)) {
    revealEls.forEach(function (el) { el.classList.add('in-view'); });
  } else {
    var ro = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('in-view'); ro.unobserve(en.target); }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });
    revealEls.forEach(function (el) { ro.observe(el); });
  }

  /* ---------- Brand marquee ---------- */
  (function () {
    var track = $('#brandTrack');
    var group = function () {
      return '<div class="mq-group">' + D.brands.map(function (b) {
        return '<span class="mq-item">' + esc(b) + '</span>';
      }).join('') + '</div>';
    };
    track.innerHTML = group() + group();
  })();

  /* ---------- Stats ---------- */
  (function () {
    var grid = $('#statsGrid');
    grid.innerHTML = D.stats.map(function (s) {
      return '<div class="stat reveal"><span class="stat-v" data-v="' + s.value + '" data-fmt="' + (s.fmt || '') + '">' +
        (s.fmt === 'year' ? s.value : '0') + (s.suffix || '') + '</span><span class="stat-l">' + esc(s.label) + '</span></div>';
    }).join('');
    var nums = $$('.stat-v', grid);
    var animate = function (el) {
      var target = parseInt(el.getAttribute('data-v'), 10);
      var suffix = target === 1989 ? '' : (D.stats[nums.indexOf(el)] || {}).suffix || '';
      if (el.getAttribute('data-fmt') === 'year') { el.textContent = String(target); return; }
      if (REDUCED) { el.textContent = target.toLocaleString('en-IN') + suffix; return; }
      var t0 = null, dur = 1500;
      var step = function (t) {
        if (!t0) t0 = t;
        var p = Math.min((t - t0) / dur, 1);
        var e = 1 - Math.pow(1 - p, 3);
        el.textContent = Math.round(target * e).toLocaleString('en-IN') + suffix;
        if (p < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    };
    if ('IntersectionObserver' in window) {
      var so = new IntersectionObserver(function (en) {
        en.forEach(function (e2) { if (e2.isIntersecting) { animate(e2.target); so.unobserve(e2.target); } });
      }, { threshold: 0.5 });
      nums.forEach(function (n) { so.observe(n); });
      $$('.stat', grid).forEach(function (el) { el.classList.add('in-view'); });
    } else nums.forEach(animate);
  })();

  /* ---------- Services explorer ---------- */
  var svcState = { gender: 'ladies', cat: 0, picked: null };
  var svcTabs = $('#svcTabs'), svcBody = $('#svcBody'), svcImg = $('#svcImgEl'),
      svcFig = $('#svcImg'), svcCap = $('#svcImgCap'), priceNote = $('#priceNote'),
      gSwitch = $('.gender-switch');

  priceNote.textContent = D.priceNote;

  function catList() { return D.services[svcState.gender]; }

  function renderTabs() {
    var cats = catList();
    svcTabs.innerHTML = cats.map(function (c, i) {
      return '<button type="button" role="tab" class="svc-tab" id="svctab-' + i + '" aria-selected="' + (i === svcState.cat) + '" aria-controls="svcpanel" data-i="' + i + '">' +
        '<span class="svc-tab-n">' + String(i + 1).padStart(2, '0') + '</span>' + esc(c.name) + '</button>';
    }).join('');
    $$('.svc-tab', svcTabs).forEach(function (btn) {
      btn.addEventListener('click', function () { setCat(parseInt(btn.dataset.i, 10)); });
      btn.addEventListener('keydown', function (e) {
        var n = cats.length, i = parseInt(btn.dataset.i, 10), t = null;
        if (e.key === 'ArrowDown' || e.key === 'ArrowRight') t = (i + 1) % n;
        if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') t = (i - 1 + n) % n;
        if (e.key === 'Home') t = 0;
        if (e.key === 'End') t = n - 1;
        if (t !== null) { e.preventDefault(); setCat(t); var el = $('#svctab-' + t, svcTabs); if (el) el.focus(); }
      });
    });
  }

  function renderBody() {
    var c = catList()[svcState.cat];
    var priceHtml = c.priceKind === 'indicative'
      ? '<span class="svc-price">' + esc(c.price) + '</span><span class="svc-price-flag flag-indicative">Indicative range</span>'
      : '<span class="svc-price">' + esc(c.price) + '</span><span class="svc-price-flag flag-consult">Ask in salon</span>';
    svcBody.innerHTML =
      '<div id="svcpanel" role="tabpanel" aria-labelledby="svctab-' + svcState.cat + '">' +
      '<p class="svc-blurb">' + esc(c.blurb) + '</p>' +
      '<div class="svc-price-row">' + priceHtml + '</div>' +
      '<div class="svc-items" role="group" aria-label="Services in ' + esc(c.name) + '">' +
      c.items.map(function (it) {
        return '<button type="button" class="svc-item' + (svcState.picked === it ? ' is-picked' : '') + '" data-item="' + esc(it) + '">' + esc(it) + '</button>';
      }).join('') + '</div>' +
      '<div class="svc-actions">' +
      '<button type="button" class="btn btn-gold" id="svcBook">Book ' + esc(c.name.toLowerCase()) + ' <span class="btn-demo-tag">demo</span></button>' +
      '<span class="svc-picked-note" id="svcPickedNote">' + (svcState.picked ? 'Selected: <strong>' + esc(svcState.picked) + '</strong>' : 'Tap a service to select it') + '</span>' +
      '</div></div>';

    $$('.svc-item', svcBody).forEach(function (b) {
      b.addEventListener('click', function () {
        svcState.picked = b.dataset.item;
        $$('.svc-item', svcBody).forEach(function (x) { x.classList.toggle('is-picked', x === b); });
        $('#svcPickedNote', svcBody).innerHTML = 'Selected: <strong>' + esc(svcState.picked) + '</strong>';
      });
    });
    $('#svcBook', svcBody).addEventListener('click', function () {
      Booking.open({
        gender: svcState.gender,
        category: c.name,
        service: svcState.picked || c.items[0]
      });
    });
  }

  function setCat(i) {
    svcState.cat = i;
    svcState.picked = null;
    renderTabs(); renderBody(); swapImage();
  }

  function swapImage() {
    var c = catList()[svcState.cat];
    svcFig.classList.add('is-swapping');
    window.setTimeout(function () {
      svcImg.src = 'assets/img/' + c.img;
      svcImg.alt = c.name + ' at Looks Salon (concept imagery)';
      svcCap.textContent = c.name;
      svcFig.classList.remove('is-swapping');
    }, REDUCED ? 0 : 260);
  }

  $$('.gs-btn', gSwitch).forEach(function (btn) {
    btn.addEventListener('click', function () {
      svcState.gender = btn.dataset.gender;
      svcState.cat = 0; svcState.picked = null;
      $$('.gs-btn', gSwitch).forEach(function (b) {
        var on = b === btn;
        b.classList.toggle('is-active', on);
        b.setAttribute('aria-checked', String(on));
      });
      gSwitch.setAttribute('data-gender', svcState.gender);
      renderTabs(); renderBody(); swapImage();
    });
  });
  gSwitch.setAttribute('data-gender', 'ladies');
  renderTabs(); renderBody();

  /* ---------- Before / After ---------- */
  var BA = {
    hair: { before: 'ba-hair-before.jpg', after: 'ba-hair-after.jpg', caption: 'A colour-gloss transformation story — from faded and dry to dimensional shine.' },
    skin: { before: 'ba-skin-before.jpg', after: 'ba-skin-after.jpg', caption: 'A glow-ritual story — from dull and tired to luminous, even-toned skin.' }
  };
  var slider = $('#baSlider'), clip = $('#baClip'), handle = $('#baHandle'),
      baBefore = $('#baBefore'), baAfter = $('#baAfter'), baCap = $('#baCaption'), baPanel = $('#ba-panel');

  function setPos(p) {
    p = Math.max(2, Math.min(98, p));
    slider.style.setProperty('--pos', p + '%');
    handle.setAttribute('aria-valuenow', Math.round(p));
  }
  setPos(50);

  var dragging = false;
  function posFromEvent(e) {
    var r = slider.getBoundingClientRect();
    var x = (e.touches ? e.touches[0].clientX : e.clientX) - r.left;
    return (x / r.width) * 100;
  }
  slider.addEventListener('pointerdown', function (e) {
    if (e.button !== undefined && e.button !== 0) return;
    dragging = true; setPos(posFromEvent(e));
    if (slider.setPointerCapture) { try { slider.setPointerCapture(e.pointerId); } catch (err) { /* noop */ } }
    e.preventDefault();
  });
  window.addEventListener('pointermove', function (e) { if (dragging) setPos(posFromEvent(e)); }, { passive: true });
  window.addEventListener('pointerup', function () { dragging = false; });
  slider.addEventListener('touchmove', function (e) { if (dragging) { setPos(posFromEvent(e)); } }, { passive: true });

  handle.addEventListener('keydown', function (e) {
    var cur = parseFloat(handle.getAttribute('aria-valuenow')) || 50;
    var d = { ArrowLeft: -4, ArrowRight: 4, ArrowDown: -4, ArrowUp: 4 }[e.key];
    if (d) { e.preventDefault(); setPos(cur + d); }
    if (e.key === 'Home') { e.preventDefault(); setPos(2); }
    if (e.key === 'End') { e.preventDefault(); setPos(98); }
  });

  $$('.ba-tab').forEach(function (tab) {
    tab.addEventListener('click', function () {
      var pair = BA[tab.dataset.pair];
      $$('.ba-tab').forEach(function (t) {
        var on = t === tab;
        t.classList.toggle('is-active', on);
        t.setAttribute('aria-selected', String(on));
      });
      baPanel.setAttribute('aria-labelledby', tab.id);
      baBefore.src = 'assets/img/' + pair.before;
      baAfter.src = 'assets/img/' + pair.after;
      baCap.textContent = pair.caption;
      setPos(50);
    });
  });

  /* ---------- Gallery ---------- */
  var galGrid = $('#galGrid'), galFilters = $('#galFilters');
  var galFilter = 'all';
  var galItems = D.gallery.map(function (g, i) {
    var size = (i === 0 || i === 4 || i === 8) ? ' wide' : (i === 2 || i === 6) ? ' tall' : '';
    return Object.assign({ size: size, idx: i }, g);
  });
  var galCats = ['all'].concat(D.gallery.map(function (g) { return g.cat; }).filter(function (v, i, a) { return a.indexOf(v) === i; }));
  var catLabel = { all: 'All', hair: 'Hair', colour: 'Colour', bridal: 'Bridal', gents: 'Gents', skin: 'Skin', nails: 'Nails', salon: 'Salon' };

  function visibleGal() { return galItems.filter(function (g) { return galFilter === 'all' || g.cat === galFilter; }); }

  galFilters.innerHTML = galCats.map(function (c) {
    var n = c === 'all' ? galItems.length : galItems.filter(function (g) { return g.cat === c; }).length;
    return '<button type="button" class="gal-filter' + (c === galFilter ? ' is-active' : '') + '" data-cat="' + c + '">' +
      (catLabel[c] || c) + '<span class="cnt">' + n + '</span></button>';
  }).join('');

  galGrid.innerHTML = galItems.map(function (g) {
    return '<button type="button" class="gal-item' + g.size + '" data-cat="' + g.cat + '" data-i="' + g.idx + '" aria-label="View: ' + esc(g.title) + '">' +
      '<img src="assets/img/' + g.src + '" alt="' + esc(g.alt) + '" loading="lazy" width="1200" height="800">' +
      '<span class="gal-cap"><span class="gal-cat">' + (catLabel[g.cat] || g.cat) + '</span>' + esc(g.title) + '</span></button>';
  }).join('');

  $$('.gal-filter', galFilters).forEach(function (b) {
    b.addEventListener('click', function () {
      galFilter = b.dataset.cat;
      $$('.gal-filter', galFilters).forEach(function (x) { x.classList.toggle('is-active', x === b); });
      $$('.gal-item', galGrid).forEach(function (it) {
        it.classList.toggle('is-hidden', !(galFilter === 'all' || it.dataset.cat === galFilter));
      });
    });
  });

  /* Lightbox */
  var lb = $('#lightbox'), lbImg = $('#lbImg'), lbCap = $('#lbCap');
  var lbList = [], lbIdx = 0, lbLastFocus = null;

  function lbOpen(i) {
    lbList = visibleGal();
    lbIdx = Math.max(0, Math.min(i, lbList.length - 1));
    var g = lbList[lbIdx];
    lbImg.src = 'assets/img/' + g.src;
    lbImg.alt = g.alt;
    lbCap.textContent = g.title + ' — ' + (catLabel[g.cat] || g.cat);
    lb.classList.add('is-open');
    lb.setAttribute('aria-hidden', 'false');
    document.body.classList.add('no-scroll');
    lbLastFocus = document.activeElement;
    $('#lbClose').focus();
  }
  function lbClose() {
    lb.classList.remove('is-open');
    lb.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('no-scroll');
    if (lbLastFocus) lbLastFocus.focus();
  }
  function lbStep(d) {
    lbIdx = (lbIdx + d + lbList.length) % lbList.length;
    var g = lbList[lbIdx];
    lbImg.style.opacity = 0;
    window.setTimeout(function () {
      lbImg.src = 'assets/img/' + g.src; lbImg.alt = g.alt;
      lbCap.textContent = g.title + ' — ' + (catLabel[g.cat] || g.cat);
      lbImg.style.opacity = 1;
    }, REDUCED ? 0 : 160);
  }
  $$('.gal-item', galGrid).forEach(function (it) {
    it.addEventListener('click', function () {
      var vis = visibleGal().map(function (g) { return g.idx; });
      lbOpen(vis.indexOf(parseInt(it.dataset.i, 10)));
    });
  });
  $('#lbClose').addEventListener('click', lbClose);
  $('#lbPrev').addEventListener('click', function () { lbStep(-1); });
  $('#lbNext').addEventListener('click', function () { lbStep(1); });
  lb.addEventListener('click', function (e) { if (e.target === lb) lbClose(); });
  document.addEventListener('keydown', function (e) {
    if (!lb.classList.contains('is-open')) return;
    if (e.key === 'Escape') lbClose();
    if (e.key === 'ArrowLeft') lbStep(-1);
    if (e.key === 'ArrowRight') lbStep(1);
    if (e.key === 'Tab') trapFocus(lb, e);
  });
  lbImg.style.transition = 'opacity .16s';

  /* ---------- Loyalty calculator ---------- */
  (function () {
    var spend = $('#calcSpend'), visits = $('#calcVisits');
    var fill = function (el) {
      var p = ((el.value - el.min) / (el.max - el.min)) * 100;
      el.style.setProperty('--fill', p + '%');
    };
    var calc = function () {
      var s = +spend.value, v = +visits.value;
      var per = Math.floor(s / 100) * 10;
      var total = per * v;
      var canRedeem = total >= 250;
      var maxOff = canRedeem ? Math.min(total, Math.floor(s / 2)) : 0;
      $('#calcSpendOut').textContent = inr(s);
      $('#calcVisitsOut').textContent = v + (v === 1 ? ' visit' : ' visits');
      $('#coPerVisit').textContent = per.toLocaleString('en-IN') + ' pts';
      $('#coTotal').textContent = total.toLocaleString('en-IN') + ' pts';
      $('#coValue').textContent = inr(total);
      $('#coRedeem').textContent = canRedeem ? inr(maxOff) : '—';
      $('#lcPoints').textContent = total.toLocaleString('en-IN') + ' pts';
      $('#calcFine').textContent = canRedeem
        ? 'Redemption capped at 50% of the visit bill (official rule). First redemption needs ≥ 250 points; points expire 1 year from issue.'
        : 'Below the 250-point minimum needed for a first redemption — official rule.';
      fill(spend); fill(visits);
    };
    spend.addEventListener('input', calc);
    visits.addEventListener('input', calc);
    calc();
  })();

  /* ---------- Salon finder ---------- */
  var branches = D.branches;
  var finderList = $('#finderList'), finderChips = $('#finderChips'), finderInput = $('#finderInput'),
      finderClear = $('#finderClear'), finderCount = $('#finderCount'), mapTip = $('#mapTip');
  var fCity = 'all', fQuery = '';
  var activeBranch = -1;

  $('#indiaPath').setAttribute('d', D.map.path);
  $('#branchCount').textContent = branches.length;

  var pinLayer = $('#pinLayer');
  var svgNS = 'http://www.w3.org/2000/svg';
  branches.forEach(function (b, i) {
    if (b.x == null || b.y == null) return;
    var g = document.createElementNS(svgNS, 'g');
    g.setAttribute('class', 'map-pin');
    g.setAttribute('data-i', i);
    g.setAttribute('transform', 'translate(' + b.x + ',' + b.y + ')');
    g.setAttribute('aria-hidden', 'true');
    g.innerHTML = '<circle class="pin-halo" r="17"></circle><circle class="pin-core" r="7"></circle>';
    pinLayer.appendChild(g);
  });

  function matches(b) {
    var cityOk = fCity === 'all' || b.city === fCity;
    if (!cityOk) return false;
    if (!fQuery) return true;
    var hay = (b.label + ' ' + b.city + ' ' + b.addr.join(' ') + ' ' + b.phones.join(' ')).toLowerCase();
    return fQuery.toLowerCase().split(/\s+/).every(function (w) { return hay.indexOf(w) !== -1; });
  }
  function filtered() { return branches.map(function (b, i) { return { b: b, i: i }; }).filter(function (o) { return matches(o.b); }); }

  function renderChips() {
    var counts = {};
    branches.forEach(function (b) { counts[b.city] = (counts[b.city] || 0) + 1; });
    var cities = Object.keys(counts).sort(function (a, c) { return counts[c] - counts[a] || a.localeCompare(c); });
    finderChips.innerHTML = '<button type="button" class="f-chip' + (fCity === 'all' ? ' is-active' : '') + '" data-city="all">All India<span class="cnt">' + branches.length + '</span></button>' +
      cities.map(function (c) {
        return '<button type="button" class="f-chip' + (fCity === c ? ' is-active' : '') + '" data-city="' + esc(c) + '">' + esc(c) + '<span class="cnt">' + counts[c] + '</span></button>';
      }).join('');
    $$('.f-chip', finderChips).forEach(function (ch) {
      ch.addEventListener('click', function () { fCity = ch.dataset.city; renderChips(); renderList(); });
    });
  }

  function phoneIcon() { return '<svg viewBox="0 0 24 24" class="ic" aria-hidden="true"><path d="M6.6 3h-2A1.6 1.6 0 0 0 3 4.7C3 12.6 11.4 21 19.3 21a1.6 1.6 0 0 0 1.7-1.6v-2a1.6 1.6 0 0 0-1.3-1.6l-2.4-.4a1.6 1.6 0 0 0-1.5.6l-.8 1a13.6 13.6 0 0 1-5.9-5.9l1-.8a1.6 1.6 0 0 0 .6-1.5l-.4-2.4A1.6 1.6 0 0 0 8.6 3h-2Z" fill="none" stroke="currentColor" stroke-width="1.7"/></svg>'; }
  function clockIcon() { return '<svg viewBox="0 0 24 24" class="ic" aria-hidden="true"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M12 7v5.2l3.2 2" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>'; }

  function renderList() {
    var res = filtered();
    finderCount.textContent = 'Showing ' + res.length + ' of ' + branches.length + ' listed salons';
    if (!res.length) {
      finderList.innerHTML = '<p class="f-empty">No salon matches that search. Try a city name like “Delhi”, “Mumbai” or a sector/mall name.</p>';
      syncPins([]); return;
    }
    finderList.innerHTML = res.map(function (o) {
      var b = o.b;
      var phones = b.phones.length
        ? b.phones.slice(0, 2).map(function (p, k) { return '<a class="f-phone" href="' + b.hrefs[k] + '">' + phoneIcon() + esc(p) + '</a>'; }).join('')
        : '<span class="f-hours">Call toll-free ' + esc(D.meta.tollFree) + '</span>';
      return '<article class="f-card' + (activeBranch === o.i ? ' is-active' : '') + '" data-i="' + o.i + '" role="listitem" tabindex="-1">' +
        '<div class="f-card-top"><h3>' + esc(b.label) + '</h3><span class="f-city">' + esc(b.city) + '</span></div>' +
        '<p class="f-addr">' + b.addr.map(esc).join(', ') + '</p>' +
        '<div class="f-meta">' + phones + '<span class="f-hours">' + clockIcon() + esc(b.hours) + '</span></div>' +
        '<div class="f-actions">' +
        (b.map ? '<a class="f-map-link" href="' + esc(b.map) + '" target="_blank" rel="noopener noreferrer">Open in Google Maps ↗</a>' : '') +
        '<button type="button" class="f-book" data-book-branch="' + o.i + '">Book here · demo</button>' +
        '</div></article>';
    }).join('');
    syncPins(res.map(function (o) { return o.i; }));

    $$('.f-card', finderList).forEach(function (card) {
      var i = parseInt(card.dataset.i, 10);
      card.addEventListener('mouseenter', function () { highlightPin(i, true); });
      card.addEventListener('mouseleave', function () { highlightPin(i, false); });
      card.addEventListener('click', function (e) {
        if (e.target.closest('a,button')) return;
        setActive(i);
      });
    });
    $$('[data-book-branch]', finderList).forEach(function (btn) {
      btn.addEventListener('click', function () { Booking.open({ branchIdx: parseInt(btn.dataset.bookBranch, 10) }); });
    });
  }

  function syncPins(visibleIdx) {
    $$('.map-pin', pinLayer).forEach(function (p) {
      var i = parseInt(p.dataset.i, 10);
      p.classList.toggle('is-dim', visibleIdx.indexOf(i) === -1);
    });
  }
  function highlightPin(i, on) {
    var p = $('.map-pin[data-i="' + i + '"]', pinLayer);
    if (p) p.classList.toggle('is-active', on);
  }
  function setActive(i) {
    activeBranch = i;
    $$('.f-card', finderList).forEach(function (c) { c.classList.toggle('is-active', parseInt(c.dataset.i, 10) === i); });
    $$('.map-pin', pinLayer).forEach(function (p) { p.classList.toggle('is-active', parseInt(p.dataset.i, 10) === i); });
    var b = branches[i];
    showTip(i, b.label + ' · ' + b.city, true);
  }

  function showTip(i, html, sticky) {
    var b = branches[i];
    var svg = $('#indiaMap'), cont = $('.finder-map');
    if (b.x == null || !svg || !cont) { mapTip.classList.remove('is-on'); return; }
    var sr = svg.getBoundingClientRect(), cr = cont.getBoundingClientRect();
    var vb = (svg.viewBox && svg.viewBox.baseVal && svg.viewBox.baseVal.width) ? svg.viewBox.baseVal : { width: 1000, height: 1115 };
    var px = sr.left - cr.left + (b.x / vb.width) * sr.width;
    var py = sr.top - cr.top + (b.y / vb.height) * sr.height;
    mapTip.innerHTML = '<strong>' + esc(b.label) + '</strong>' + esc(b.city) + ' · ' + esc(b.hours);
    mapTip.style.left = Math.max(90, Math.min(cr.width - 90, px)) + 'px';
    mapTip.style.top = Math.max(8, py - 64) + 'px';
    mapTip.classList.add('is-on');
    if (!sticky) mapTip.dataset.auto = '1';
  }

  $$('.map-pin', pinLayer).forEach(function (p) {
    var i = parseInt(p.dataset.i, 10);
    p.addEventListener('mouseenter', function () { showTip(i); highlightCard(i); });
    p.addEventListener('mouseleave', function () { mapTip.classList.remove('is-on'); highlightCard(-1); });
    p.addEventListener('click', function () {
      setActive(i); highlightCard(i);
      var card = $('.f-card[data-i="' + i + '"]', finderList);
      if (card) card.scrollIntoView({ block: 'nearest', behavior: REDUCED ? 'auto' : 'smooth' });
    });
  });
  function highlightCard(i) {
    $$('.f-card', finderList).forEach(function (c) { c.classList.toggle('is-active', parseInt(c.dataset.i, 10) === i); });
  }

  finderInput.addEventListener('input', function () {
    fQuery = finderInput.value.trim();
    finderClear.hidden = !fQuery;
    renderList();
  });
  finderClear.addEventListener('click', function () {
    finderInput.value = ''; fQuery = ''; finderClear.hidden = true; renderList(); finderInput.focus();
  });

  renderChips(); renderList();

  /* ---------- Story parallax ---------- */
  (function () {
    if (REDUCED || !window.matchMedia('(pointer:fine)').matches || window.innerWidth < 1020) return;
    var img = $('#storyImg'), wrapEl = $('#storyParallax');
    if (!img || !wrapEl) return;
    var ticking = false;
    var update = function () {
      var r = wrapEl.getBoundingClientRect();
      var vh = window.innerHeight;
      if (r.bottom > 0 && r.top < vh) {
        var prog = (r.top + r.height / 2 - vh / 2) / vh;
        img.style.transform = 'translateY(' + (-prog * 26).toFixed(1) + 'px)';
      }
      ticking = false;
    };
    window.addEventListener('scroll', function () {
      if (!ticking) { ticking = true; requestAnimationFrame(update); }
    }, { passive: true });
    update();
  })();

  /* ---------- Collections chips ---------- */
  $('#colList').innerHTML = D.collections.map(function (c) { return '<li class="col-chip">' + esc(c) + '</li>'; }).join('');

  /* ---------- Visit section data ---------- */
  $('#hqAddr').innerHTML = D.meta.hq.map(esc).join('<br>');
  $('#altPhones').innerHTML = 'Also published: ' + D.meta.phonesAlt.map(function (p) {
    return '<a href="tel:' + p.replace(/[^\d+]/g, '') + '" style="color:inherit">' + esc(p) + '</a>';
  }).join(' · ');
  $('#mailList').innerHTML = Object.keys(D.meta.emails).map(function (k) {
    return '<li><a href="mailto:' + D.meta.emails[k] + '"><span>' + esc(k) + '</span>' + esc(D.meta.emails[k]) + '</a></li>';
  }).join('');
  $('#socialList').innerHTML = Object.keys(D.meta.social).map(function (k) {
    return '<li><a href="' + D.meta.social[k] + '" target="_blank" rel="noopener noreferrer">' + esc(k) + '</a></li>';
  }).join('');
  $('#year').textContent = new Date().getFullYear();

  /* ---------- Focus trap helper ---------- */
  function trapFocus(container, e) {
    var f = $$('a[href],button:not([disabled]),input,select,textarea,[tabindex]:not([tabindex="-1"])', container)
      .filter(function (el) { return el.offsetParent !== null || el === document.activeElement; });
    if (!f.length) return;
    var first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }

  /* ============================================================
     BOOKING — simulated flow (no network, no storage)
     ============================================================ */
  var Booking = (function () {
    var drawer = $('#bookingDrawer'), form = $('#bkForm'), panels = $$('.bk-panel', form),
        steps = $$('#bkSteps li'), back = $('#bkBack'), next = $('#bkNext'), foot = $('#bkFoot'),
        catSel = $('#bkCategory'), citySel = $('#bkCity'), branchSel = $('#bkBranch'),
        svcChips = $('#bkServices'), slotsWrap = $('#bkSlots'), dateIn = $('#bkDate'),
        lastFocus = null, cur = 0;

    var st = { gender: 'ladies', category: '', service: '', city: '', branch: -1, date: '', slot: '', name: '', phone: '', email: '', notes: '' };

    var SLOTS = { AM: ['10:00 AM', '11:00 AM', '12:00 PM'], PM: ['01:30 PM', '03:00 PM', '04:30 PM', '06:00 PM', '07:30 PM'] };

    function iso(d) { return d.toISOString().split('T')[0]; }
    function setGender(g) {
      st.gender = g;
      $$('.seg-btn', form).forEach(function (b) {
        var on = b.dataset.gender === g;
        b.classList.toggle('is-active', on);
        b.setAttribute('aria-checked', String(on));
      });
      catSel.innerHTML = D.services[g].map(function (c) { return '<option value="' + esc(c.name) + '">' + esc(c.name) + '</option>'; }).join('');
      if (!D.services[g].some(function (c) { return c.name === st.category; })) st.category = D.services[g][0].name;
      catSel.value = st.category;
      renderServices();
    }
    function renderServices() {
      var cat = D.services[st.gender].filter(function (c) { return c.name === st.category; })[0] || D.services[st.gender][0];
      st.category = cat.name;
      if (!cat.items.some(function (i) { return i === st.service; })) st.service = '';
      svcChips.innerHTML = cat.items.map(function (it) {
        return '<button type="button" class="cs-chip" aria-pressed="' + (it === st.service) + '" data-svc="' + esc(it) + '">' + esc(it) + '</button>';
      }).join('');
      $$('.cs-chip', svcChips).forEach(function (b) {
        b.addEventListener('click', function () {
          st.service = b.dataset.svc;
          $$('.cs-chip', svcChips).forEach(function (x) {
            var on = x === b;
            x.classList.toggle('is-active', on);
            x.setAttribute('aria-pressed', String(on));
          });
          hideErr('service');
        });
      });
    }
    function renderCities() {
      var counts = {};
      branches.forEach(function (b) { counts[b.city] = (counts[b.city] || 0) + 1; });
      var cities = Object.keys(counts).sort();
      citySel.innerHTML = '<option value="">Select city…</option>' + cities.map(function (c) {
        return '<option value="' + esc(c) + '">' + esc(c) + ' (' + counts[c] + ')</option>';
      }).join('');
      if (st.city && cities.indexOf(st.city) !== -1) citySel.value = st.city;
    }
    function renderBranches() {
      var list = branches.map(function (b, i) { return { b: b, i: i }; }).filter(function (o) { return o.b.city === st.city; });
      branchSel.innerHTML = '<option value="">Select salon…</option>' + list.map(function (o) {
        return '<option value="' + o.i + '">' + esc(o.b.label) + '</option>';
      }).join('');
      branchSel.disabled = !list.length;
      if (st.branch > -1 && list.some(function (o) { return o.i === st.branch; })) { branchSel.value = String(st.branch); showBranchAddr(); }
      else { st.branch = -1; $('#bkBranchAddr').textContent = ''; }
    }
    function showBranchAddr() {
      var b = branches[st.branch];
      $('#bkBranchAddr').textContent = b ? b.addr.join(', ') + ' · ' + b.hours : '';
    }
    function renderSlots() {
      slotsWrap.innerHTML = ['AM', 'PM'].map(function (grp) {
        return '<p class="slot-group-label" style="width:100%">' + grp + '</p>' + SLOTS[grp].map(function (s) {
          return '<button type="button" role="radio" aria-checked="' + (s === st.slot) + '" class="cs-chip' + (s === st.slot ? ' is-active' : '') + '" data-slot="' + s + '">' + s + '</button>';
        }).join('');
      }).join('');
      $$('[data-slot]', slotsWrap).forEach(function (b) {
        b.addEventListener('click', function () {
          st.slot = b.dataset.slot;
          $$('[data-slot]', slotsWrap).forEach(function (x) {
            var on = x === b;
            x.classList.toggle('is-active', on);
            x.setAttribute('aria-checked', String(on));
          });
          hideErr('slot');
        });
      });
    }
    function initDates() {
      var t = new Date(), min = iso(t), max = iso(new Date(t.getTime() + 30 * 864e5));
      dateIn.min = min; dateIn.max = max;
      if (!st.date) { var tm = new Date(t.getTime() + 864e5); st.date = iso(tm); }
      dateIn.value = st.date;
    }
    function showErr(id) { var e = $('#err-' + id); if (e) e.hidden = false; var f = $('#' + ({ service: 'bkServices', slot: 'bkSlots', branch: 'bkBranch', date: 'bkDate', name: 'bkName', phone: 'bkPhone', email: 'bkEmail', consent: 'bkConsent' }[id])); if (f && f.setAttribute) f.setAttribute('aria-invalid', 'true'); }
    function hideErr(id) { var e = $('#err-' + id); if (e) e.hidden = true; var f = $('#' + ({ service: 'bkServices', slot: 'bkSlots', branch: 'bkBranch', date: 'bkDate', name: 'bkName', phone: 'bkPhone', email: 'bkEmail', consent: 'bkConsent' }[id])); if (f && f.removeAttribute) f.removeAttribute('aria-invalid'); }

    function validStep(i) {
      var ok = true;
      if (i === 0) {
        if (!st.service) { showErr('service'); ok = false; } else hideErr('service');
      }
      if (i === 1) {
        if (!st.city || st.branch < 0) { showErr('branch'); ok = false; } else hideErr('branch');
      }
      if (i === 2) {
        var d = dateIn.value;
        if (!d || d < dateIn.min || d > dateIn.max) { showErr('date'); ok = false; } else { hideErr('date'); st.date = d; }
        if (!st.slot) { showErr('slot'); ok = false; } else hideErr('slot');
      }
      if (i === 3) {
        st.name = $('#bkName').value.trim();
        st.phone = $('#bkPhone').value.trim();
        st.email = $('#bkEmail').value.trim();
        st.notes = $('#bkNotes').value.trim();
        if (st.name.length < 2) { showErr('name'); ok = false; } else hideErr('name');
        var digits = st.phone.replace(/[^\d]/g, '').replace(/^(\+?91|0)/, '');
        if (!/^[6-9]\d{9}$/.test(digits)) { showErr('phone'); ok = false; } else hideErr('phone');
        if (st.email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(st.email)) { showErr('email'); ok = false; } else hideErr('email');
        if (!$('#bkConsent').checked) { showErr('consent'); ok = false; } else hideErr('consent');
        if (ok) renderSummary();
      }
      return ok;
    }

    function renderSummary() {
      var b = branches[st.branch] || {};
      var dTxt = '';
      try { dTxt = new Date(st.date + 'T12:00:00').toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' }); } catch (e) { dTxt = st.date; }
      var rows = [
        ['Service', (st.gender === 'ladies' ? 'Ladies' : 'Gents') + ' · ' + st.category + ' · ' + st.service],
        ['Salon', (b.label || '') + (b.city ? ', ' + b.city : '')],
        ['When', dTxt + ' · ' + st.slot],
        ['Guest', st.name + ' · ' + st.phone]
      ];
      var html = '<p class="sum-title">Your demo request</p>' + rows.map(function (r) {
        return '<div class="sum-row"><span>' + r[0] + '</span><strong>' + esc(r[1]) + '</strong></div>';
      }).join('');
      $('#bkSummary').innerHTML = html;
      return html;
    }

    function go(i, skipValid) {
      if (i > cur && !skipValid && !validStep(cur)) return;
      cur = Math.max(0, Math.min(4, i));
      panels.forEach(function (p) {
        var on = parseInt(p.dataset.panel, 10) === cur;
        p.classList.toggle('is-active', on);
        p.hidden = !on;
      });
      steps.forEach(function (s, k) {
        s.classList.toggle('is-active', k === cur && cur < 4);
        s.classList.toggle('is-done', k < cur || cur === 4);
      });
      back.hidden = cur === 0 || cur === 4;
      foot.style.display = cur === 4 ? 'none' : '';
      next.textContent = cur === 3 ? 'Confirm demo request ✓' : 'Continue →';
      if (cur === 3) renderSummary();
      var focusTarget = panels[cur] ? panels[cur].querySelector('select,input,button,[tabindex]') : null;
      if (focusTarget && drawer.classList.contains('is-open')) { try { focusTarget.focus({ preventScroll: true }); } catch (e) { focusTarget.focus(); } }
    }

    function confirm() {
      var ref = 'LK-DEMO-' + Date.now().toString(36).slice(-4).toUpperCase() + '-' + String(Math.floor(Math.random() * 900) + 100);
      $('#bkRef').textContent = ref;
      $('#bkDoneSummary').innerHTML = renderSummary();
      go(4, true);
    }

    function resetState() {
      st.gender = 'ladies'; st.category = ''; st.service = ''; st.city = ''; st.branch = -1;
      st.date = ''; st.slot = ''; st.name = ''; st.phone = ''; st.email = ''; st.notes = '';
      try { form.reset(); } catch (e) { /* noop */ }
      ['service', 'branch', 'date', 'slot', 'name', 'phone', 'email', 'consent'].forEach(hideErr);
      $('#bkSummary').innerHTML = ''; $('#bkDoneSummary').innerHTML = '';
      $('#bkRef').textContent = '';
    }

    function open(prefill) {
      prefill = prefill || {};
      closeMenu();
      resetState();
      if (prefill.gender) st.gender = prefill.gender;
      if (prefill.category) st.category = prefill.category;
      if (prefill.service) st.service = prefill.service;
      if (typeof prefill.branchIdx === 'number') {
        st.branch = prefill.branchIdx;
        st.city = branches[prefill.branchIdx].city;
      }
      setGender(st.gender);
      if (st.category) catSel.value = st.category;
      renderServices();
      renderCities();
      if (st.city) citySel.value = st.city;
      renderBranches();
      initDates();
      renderSlots();
      cur = 4; go(0, true);
      lastFocus = document.activeElement;
      drawer.classList.add('is-open');
      drawer.setAttribute('aria-hidden', 'false');
      document.body.classList.add('no-scroll');
      window.setTimeout(function () { $('#bkClose').focus(); }, 60);
    }
    function close() {
      drawer.classList.remove('is-open');
      drawer.setAttribute('aria-hidden', 'true');
      document.body.classList.remove('no-scroll');
      if (lastFocus) lastFocus.focus();
    }
    function restart() {
      resetState();
      setGender('ladies'); renderCities(); renderBranches(); initDates(); renderSlots();
      go(0, true);
    }

    /* events */
    $$('.seg-btn', form).forEach(function (b) {
      b.addEventListener('click', function () { setGender(b.dataset.gender); });
    });
    catSel.addEventListener('change', function () { st.category = catSel.value; st.service = ''; renderServices(); });
    citySel.addEventListener('change', function () { st.city = citySel.value; st.branch = -1; renderBranches(); hideErr('branch'); });
    branchSel.addEventListener('change', function () { st.branch = parseInt(branchSel.value, 10); if (isNaN(st.branch)) st.branch = -1; showBranchAddr(); if (st.branch > -1) hideErr('branch'); });
    dateIn.addEventListener('change', function () { hideErr('date'); });
    next.addEventListener('click', function (e) { e.preventDefault(); if (cur < 3) go(cur + 1); else if (validStep(3)) confirm(); });
    back.addEventListener('click', function () { go(cur - 1, true); });
    form.addEventListener('submit', function (e) { e.preventDefault(); next.click(); });
    $('#bkClose').addEventListener('click', close);
    $('#bkScrim').addEventListener('click', close);
    $('#bkRestart').addEventListener('click', restart);
    steps.forEach(function (s) {
      s.addEventListener('click', function () {
        var t = parseInt(s.dataset.step, 10);
        if (cur === 4 || t < cur) go(t, true);
      });
      s.style.cursor = 'pointer';
    });
    document.addEventListener('keydown', function (e) {
      if (!drawer.classList.contains('is-open')) return;
      if (e.key === 'Escape') close();
      if (e.key === 'Tab') trapFocus(drawer, e);
    });
    $$('[data-book]').forEach(function (b) { b.addEventListener('click', function () { open(); }); });

    return { open: open, close: close };
  })();

  window.LooksBooking = Booking; /* handy for console demos */
})();
