# Looks Salon — Research Notes (verified sources)

Research date: 2026-10-11. Primary source: official website lookssalon.in (home, about, ladies services, gents services, contact, offers, loyalty card, salon finder, collection pages). Secondary: brand social profiles, business directories (used only for cross-checks).

## 1. Brand facts (OFFICIAL website)

- **Business:** Looks Salon — unisex (ladies + gents) salon chain, positioned as "Top Unisex Hair Salon Chain in India".
- **Established:** January 1989 (official About page).
- **Founder/Owner:** Mr. Sanjay Dutta (official About page; corroborated by Crunchbase).
- **Head office:** No 17A/22, Ajmal Khan Road, Karol Bagh, New Delhi – 110005 (official Contact page).
- **Scale claims (official):** "over 162 branches nationally and internationally"; "over 6000 employees"; growth path of 200 salons. NOTE: other pages on the same site still say 85+/90+/95+ (stale copy). Instagram bio (official) says "250+ Salons across 51 Cities". → Demo uses conservative "160+ salons" phrasing; flagged as brand claim sourced from official site.
- **International:** Dubai presence (site banners + "first branch up and running in Dubai" on Salon Finder page). No Dubai address/phone published on the finder → NOT invented in demo.
- **Positioning line (official):** "Utmost Luxury at Affordable Prices"; campaign lines: "Let's not wait for the Perfect Look", "Explore the Realm of Beauty", "#LoveYourLooks since 1989" (IG bio).
- **Ecosystem (official links):** e-Shop Looks Kart (lookskart.com), Academy (looksschool.com), Franchise programme (lookssalon.in/franchise.html), Loyalty Card (lookssalon.in/loyalty-card.html).

## 2. Contacts (OFFICIAL)

- Toll-free: **1800 212 56657** (site-wide booking CTA)
- Offers page numbers: **+91 9582715379**, **+91 11 45491111**
- Emails: careers@lookssalon.in, academy@lookssalon.in, customercare@lookssalon.in (feedback), franchise@lookssalon.in
- HQ hours note (contact page): "Open until 09:00 PM"; branch timings published: 10:00 AM – 9:00 PM.

## 3. Social media (verified)

- Instagram: @looksunisexsalon (106K followers at research time)
- Facebook: facebook.com/Looksunisexsalon (in official site structured data)
- Twitter/X: @looksindia (in official site structured data)
- YouTube: "Looks Salon" channel (~6.1K subscribers, linked from official About page)
- LinkedIn: linkedin.com/company/looks-unisex-salon (directory cross-check)

## 4. Services (OFFICIAL Ladies + Gents pages — exact menus)

### Ladies
- **Hair Styling:** Hair Cut, Ironing, Global Colouring, Blow Dry, Root Touch Up, Shampoo & Conditioning, Head Massage, Roller Setting, Oiling
- **Make Up:** Party Make Up, Engagement Make Up, Bridal & Reception Make Up, Base Make Up, Eye Make Up
- **Hair Texture:** Rebonding, Perming, Keratin, Colour Protection, Smoothening
- **Hair Treatments:** Spa Treatments, Volumizing, Advanced Hair Moisturising, Scalp Treatments
- **Facials & Rituals:** Bleach, Luxury Facials/Rituals, Clean Ups, Body Polishing/Rejuvenation, Threading
- **Hand & Feet:** Manicure, Spa Pedicure, Pedicure, Waxing, Spa Manicure
- **Nail Care:** Nail Paint, Nail Art, Nail Filling

### Gents
- **Hair Cut & Finish:** Cut and Hair Care, Shampoo & Conditioning, Head Massage, Beard Styling, Hair/Beard Colouring
- **Hair Colour:** Hair Colour (Ammonia & Ammonia Free), Hi-Lites, Beard Colour
- **Hair Texture:** Straightening, Smoothening, Rebonding, Perming
- **Hair Treatments:** Hair Spa, Advanced Moisturising, Scalp Treatments, Colour Protection
- **Skin Care:** Clean Ups, Facials, Organic Treatments, Manicure, Pedicure
- **Beard Grooming:** Beard Trim, Beard Colour, Beard Styling, Shave, Luxury Shave & Beard Spa

## 5. Pricing — NOT officially published

Official site publishes **no service price list**. Third-party aggregators (salonpricelisto.com 2026, sabsastaa.com 2024, LBB 2019) list indicative ranges, e.g. men's haircut ₹500–1500, women's ₹700+, global colour ₹1200–6000, facials ₹800–3500, waxing ₹200–2000. **Decision:** demo shows price ranges clearly labelled "Indicative — third-party data, verify at salon"; nothing presented as official Looks Salon pricing.

## 6. Loyalty programme (OFFICIAL Loyalty Card page — exact rules)

- Join by availing any service at any branch
- Earn: 10 points per ₹100 spent (on pre-tax service bill, in-salon only)
- Value: 1 point = ₹1
- Redeem: up to 50% of a visit's service total; minimum 250 points before first redemption
- Validity: 1 year from date of issue
→ Demo builds an interactive loyalty calculator strictly on these published rules.

## 7. Locations (OFFICIAL Salon Finder — scraped & verified)

- 48 branch records with address, phone(s), Google-Maps link; 40 carry exact lat/lng from the site, 8 use city-centroid approximations (flagged `coord_source` in `branches-source.json`).
- City spread in finder data: New Delhi 14, Gurugram 5, Noida 4, Mumbai 2, Bengaluru 2, Indore 2, Patna 2, + one each: Ahmedabad, Agra, Alwar, Bhagalpur, Dehradun, Goa, Greater Noida, Guwahati, Haridwar, Hissar, Karnal, Ludhiana, Meerut, Mohali, Pune, Ranchi, Roorkee.
- Booking-form city dropdown (official) lists 64 cities — used as the demo's "cities served" list.
- Sample landmark branches: Grand Hyatt Mumbai (Lobby Level), GMR Aerocity "The Square" Pavilion, Vega City Mall Bengaluru, Unity One Mall Rohini, Ahmedabad One Mall, Worldmark-1 Aerocity, Vista Square Sector-82A Gurugram, Ardee City Mall, Airia Mall Sohna Road, Bestech Square Mohali, Shanti City Centre Agra, 137 Metro Station Noida, Connaught Place (Regal Building & Inner Circle), West Punjabi Bagh, Chanakyapuri, Alipur Road, Ashok Vihar, Chittaranjan Park, Karkarduma, Anjuna Beach Road Goa, Castle Royale Pune.

## 8. Partner brands (OFFICIAL)

L'Oréal Professionnel, Kérastase, Moroccanoil, GK Hair, Dermalogica, Swati, René, Brasil Cacau, Balmain (Paris), Biotop, Wahl, Dyson, Wet Brush, American Crew, pH Plex, Myolift; Matrix mentioned in About text ("one of the largest market share holders of L'Oreal Professional").

## 9. Signature collections (OFFICIAL Collection page names)

Launch Pad · Collection 2011 · Rock N Folk · Bridal Collection · Collection 2012 · Andpersand Shoot.

## 10. Existing-site limitations (audit for design opportunity)

- Dated template look (jQuery-era), heavy banner-image carousel, mixed/stale stats (85+/90+/95+/162), long booking form with reCAPTCHA above the fold, no visible pricing guidance, salon finder depends on Google Maps JS + dropdown reloads, no storytelling/editorial content, weak mobile hierarchy, no before/after showcase, no gallery filtering, no loyalty engagement tool.
- Modern patterns to adopt: editorial hero, sticky service explorer, drag before/after, filterable gallery, map-based finder, multi-step booking drawer, loyalty calculator, brand marquee, motion with reduced-motion support.

## 11. Compliance decisions for the demo

- Original design/code/imagery — nothing copied from lookssalon.in (no logos, CSS, HTML, images or text reused).
- Only verified facts presented as brand claims; claims sourced from official site are attributed ("as published on lookssalon.in" in demo notes).
- Booking is a clearly-labelled **simulation** — confirmation screen states no real appointment is created, and provides the real toll-free number to book for real.
- Prices labelled indicative/third-party. Before/after images are AI-generated illustrations of a transformation concept, labelled as such.
- Unverifiable items (Dubai branch address, current offers) are NOT shown as facts.
