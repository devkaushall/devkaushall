# Oxford Institute — Badshahpur (Gurugram) — Research Notes

Compiled: 11 October 2026 (Asia/Kolkata)
Purpose: source-of-truth sheet for the demo website. **Everything here is a starting reference, not final truth.**
Anything marked ⚠️ MUST be confirmed with the institute before the site goes live.

---

## 1. Which business is this?

| Field | Value | Source | Confidence |
|---|---|---|---|
| Public name | Oxford School of Language & Computers (a.k.a. Oxford Institute) | Justdial listing, Badshahpur | High |
| Branch used for this site | **Badshahpur, Gurugram** | Justdial listing | High |
| Full address | 1st Floor, Opposite Police Station, Jaildar Market, Main Sohna Road, Badshahpur, Gurgaon – 122101, Haryana | Justdial (address block + schema.org markup) | High |
| PIN | 122101 (Badshahpur PO) | Justdial / onefivenine village data | High |
| Year of establishment (Badshahpur listing) | **2008** | Justdial "Year of Establishment: 2008" | Medium — ⚠️ |
| Year of establishment (group / main branch) | **2005** | oxfordedu.co.in About page (archived), Justdial main listing | Medium — ⚠️ |
| Sister / main centre | 572/2, 1st Floor, Adarsh Nagar, New Railway Road, near Auto Stand, Gopal Nagar, Sector 12, Gurugram – 122001 | oxfordedu.co.in (archived) + LinkedIn | High |
| Main-branch listing also states | "Also at: Badshahpur, Sohna, Manesar, Hailymandi" | Justdial (New Railway Road listing) | High — confirms Badshahpur is part of the same group |
| Mode of service | Offline / classroom (Badshahpur listing) | Justdial "Mode of Service: Offline" | High |
| Timings | Opens 7:00 am. Justdial hours schema for Badshahpur: Mon 07:00–19:00. Sulekha (main branch): Mon–Sun 7 am–9 pm. Justdial main listing: "Open until 9:00 pm". | Justdial, Sulekha | **LOW — conflicting** ⚠️ |

### Contact numbers / email
| Field | Value | Source | Note |
|---|---|---|---|
| Phone / WhatsApp | **9818112018** | oxfordedu.co.in Contact page (archived) + LinkedIn | Group contact. ⚠️ Confirm whether Badshahpur has its own number |
| Phone (second) | **8178197865** | oxfordedu.co.in Contact page (archived) | ⚠️ Confirm |
| Email | **oxfordinstituteggn@gmail.com** | oxfordedu.co.in Contact page (archived) | ⚠️ |
| Email (alternate, seen on Sulekha) | info@oxfordedu.co.in | Sulekha | ⚠️ Domain now hijacked (see §5) — do not publish this one |
| Badshahpur-specific phone | **Not found publicly** | Justdial hides it behind "Show Number" | ⚠️ Must be supplied by client |

### Social / web
| Channel | Handle / URL | Source |
|---|---|---|
| Facebook | https://www.facebook.com/OxfordSchoolOfLanguage/ | LinkedIn bio; page exists (1,123 likes seen) |
| Instagram | https://www.instagram.com/oxfordinstitute_english/ | LinkedIn bio. ⚠️ Not independently verified — handle may have changed |
| YouTube | https://www.youtube.com/@oxford_institute_ggn | LinkedIn bio. ⚠️ Not independently verified |
| Old website | https://oxfordedu.co.in/ | **HIJACKED** — see §5 |
| Group websites (different, larger brand) | oxfordinstitute.in (Oxford Software Institute, Delhi), oxfordaccounting.in, oxfordschoolofenglish.in | ⚠️ These are the wider Oxford group in Delhi/NCR. Content from them was **not** used as facts for the Badshahpur centre. |

---

## 2. Courses — what is actually documented

Primary source: archived `oxfordedu.co.in` (Wayback snapshot 13-Oct-2025), pages `/courses/` and individual course pages.

| Course | Fee (listed on old site) | Duration (old site) | Topics listed by the institute |
|---|---|---|---|
| Spoken English | ₹6,000 | 3 months | Modal verbs & tenses, conditional sentences, one-on-one conversations, mock interview skills; active listening, clear expression |
| Basic Computer | ₹5,000 | 3 months | Computer basics, hardware & software, Windows, file management, MS Word, MS Excel, MS PowerPoint, data entry & formatting, basic troubleshooting |
| Advanced Excel | ₹5,500 | not stated | Pivot table & pivot chart, relationships, advanced conditional formatting, dynamic advanced filter, drop-down list, attendance sheet, dynamic chart, INDEX-MATCH, financial functions |
| Tally | ₹6,000 | 3 months | Intro to Tally, accounting info, inventory masters, accounting vouchers, voucher entry, bill/invoice, point of sale, payroll masters, company logo, interest calculation, budget, purchase bill pending, multi-address |
| GST | ₹4,000 | not stated | Intro to GST, voucher entry, bill/invoice with GST, advance receipt, adjustment entry, TDS |
| DTP | ₹5,500 | not stated | Photoshop, CorelDRAW |
| Web Designing | ₹6,000 | 3 months | HTML, CSS, JavaScript (old home page also listed "DHTML") |
| C Language | ₹4,000 | not stated | Intro to C, fundamentals, operators & expressions, data types & I/O library functions, arrays & functions, strings & functions, structures & file handling |
| C++ Language | ₹4,500 | not stated | (No dedicated archived page found) |
| Python | ₹7,000 | 2 months | Intro, variables, multiple assignment, string methods & slicing, type casting, user input, math functions, if statements, logical operators, while / for / nested loops, break-continue-pass, lists, 2D lists, tuples, sets |
| Core Java | ₹7,000 | not stated | (No dedicated archived page found) |
| PHP | ₹7,000 | not stated | (No dedicated archived page found) |

Corroborated by the institute's own LinkedIn "Courses We Offer" list:
> Spoken English (Basic to Advanced), Basic Computer Skills, **Tally with GST**, Advanced Excel, Python Programming, Java Programming, Web Designing, "and many more career-oriented programs".

Corroborated by UrbanPro (Oxford Institute Gurgaon): DTP, Java, C++, C, Tally ERP 9, **MS Office software training**, basic & advanced computer courses, plus personality development / soft skills.

### Courses the client asked about but which are NOT verified for this centre
| Course | Status | Decision taken on the site |
|---|---|---|
| **MS Office** | Not a standalone course on the old fee list, but MS Office training IS listed on UrbanPro and Word/Excel/PowerPoint are inside the Basic Computer syllabus | Shown as a **module of Basic Computer**, not as a separate paid course. Not invented. |
| **Digital Marketing** | Only found on `oxfordinstitute.in` (the separate Delhi "Oxford Software Institute"), never on oxfordedu.co.in or the Badshahpur listing | **Not listed as an available course.** Put in an "Ask us about this" strip so the visitor can enquire, with explicit "confirm at the centre" wording. |
| Placement / job guarantee | No source found for any placement record, percentage, or guarantee | **Nothing claimed anywhere on the site.** |
| Batch size / lab size | One old UrbanPro review mentions "a big lab and so many systems" (2016, main branch) | Used only as a quoted review, never as an institute claim. |

⚠️ All fees above come from a website snapshot taken in Oct 2025 of a domain that is now hijacked. They are shown on the demo as **"listed ₹X (from the institute's previous website — confirm current fee on call)"** and the demo carries a visible notice. They must be re-confirmed before launch.

---

## 3. Ratings & reviews (public, dated)

Ratings differ per platform — the site therefore shows them **per platform with a source label**, never as one invented number.

| Platform | Rating seen | Count seen | Note |
|---|---|---|---|
| Justdial — Badshahpur listing | 4.7 / 5 | 127 ratings | Search-result view, 127 ratings, "18 years in business" |
| Justdial — Badshahpur listing (page body, same day) | 5.0 / 5 | 161 ratings | ⚠️ Conflicts with the search-result view above. Live figures drift. |
| Justdial — New Railway Road (main branch) | 4.5 / 5 | 207 ratings | "20 years in business", est. 2005 |
| UrbanPro — Oxford Institute Gurgaon | 4.5 / 5 | 11 reviews | Includes one strongly negative 2018 review about front-desk behaviour |
| Sulekha — main branch | 4.0 | — | "Sulekha score" |
| Google Business Profile | **Not retrievable** | — | ⚠️ No GBP rating could be verified. Do not print a Google rating. |

### Real review quotes used on the site (verbatim, with attribution)
1. "This is splendid platform to learn English and Computer Courses. I beefed up my English here. Teachers are very kind & friendly and their's study way is superb." — **Ankit**, Justdial, 31 May 2022
2. "Best English language classes in Gurgaon. If you want to speak fluent English must join." — **Hemant Kumar Jha**, Justdial, 30 Jan 2020
3. "Awesome study structure" — **Ashutosh**, Justdial, 5 Aug 2018
4. "Oxford institute is one of the best institute in Gurgaon for computer and spoken classes." — UrbanPro review
5. "Best institute for learning English Language in Gurgaon. Top class facilities and trainers. Classes are taken in a very peaceful and cool environment." — UrbanPro review
6. "English Spoken classes are really superb at Oxford institute. Good trainers." — UrbanPro review
7. **Constructive / honest:** "It is good institute for english speaking but … I take admission in last 6'clock batch, in this batch no one came, so my two months was very bad … I suggest you, if you take admission, don't take the last 6 o'clock batch." — Justdial reviewer, 25 Jun 2025, Badshahpur listing

Review #7 is kept on the site deliberately: it is real, it is specific to Badshahpur, and it turns into an honest FAQ answer about choosing a batch with enough students. Fabricated 5-star testimonials were **not** used.

---

## 4. Area / audience context (Badshahpur)

- Badshahpur sits on the Gurugram–Sohna road (NH-248A), ~7 km south of Gurugram district HQ; PIN 122101. Source: Wikipedia + onefivenine.
- Mixed residential + village + market area, close to Sector 47/48/67/68 residential belts, Sohna Road offices and retail. Source: 99acres locality overview.
- Nearby schools found in locality data: GBSSS Badshahpur (~0.6 km), ODM International School (Sohna Rd). Source: Sapient Realty locality page. ⚠️ Used only for general "who studies here" framing, no partnership claimed.
- Practical read for design/copy: audience is school & college students, job seekers, shopkeepers/accountants needing Tally-GST-Excel, and working adults who need evening batches. Language register should be simple, warm English with Hinglish-friendly phrasing; price sensitivity is real, so "affordable" and "confirm fee on call" beat premium-only framing.

---

## 5. Important finding: the old domain is hijacked

`oxfordedu.co.in` — still linked as the official website from the Justdial Badshahpur listing and from the LinkedIn bio — currently serves a **gambling/casino site** ("10cric India 2026").

Verified directly on 11 Oct 2026:
- `curl -sL https://oxfordedu.co.in/` → HTTP 200, `<title>10cric India 2026: Bonus & Payouts</title>`, `og:site_name = 10cric`, Cloudflare-served.
- Wayback snapshots of the genuine institute site exist from 2012 up to Jan 2026 (`/`, `/about/`, `/courses/`, `/contact-us/`, and 8 course pages).

Implications, and they are a strong pitch point:
1. Anyone searching the institute today lands on a casino page. Trust damage is immediate.
2. Google is likely indexing that gambling content against the institute's brand.
3. The domain needs to be recovered/secured, or a new domain issued, alongside the new website.

**Do not** copy the old site's design — it is a stock WordPress (Neve theme + Elementor) template with generic headings ("OUR POPULAR COURSES", "Join Our Course"). This demo uses an original visual identity built from scratch.

---

## 6. Open questions to confirm with the client (blocking for launch)

1. Badshahpur centre's own phone/WhatsApp number (currently only the group number 9818112018 / 8178197865 is public).
2. Exact opening days & hours for Badshahpur (sources conflict: 7–7 vs 7–9).
3. Current fee for every course (old site's figures are ~1 year stale, from a hijacked domain).
4. Exact batch timings per course + which batches currently have enough students.
5. Is Digital Marketing actually offered at Badshahpur? (Not evidenced.)
6. Is there a separate "MS Office" course, or is it only inside Basic Computer?
7. Certificate: issuing body, whether it is government/NSDC-linked, and its exact name. (Old pages say "certificate upon completion" with no authority named.)
8. Any real placement/assistance record that can be documented? (Nothing found — currently zero claims on the site.)
9. Preferred domain + confirmation of the oxfordedu.co.in recovery plan.
10. Real photos of the Badshahpur classroom/lab to replace placeholder art.
