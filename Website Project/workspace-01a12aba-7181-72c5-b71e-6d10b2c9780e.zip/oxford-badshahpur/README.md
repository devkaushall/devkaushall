# Oxford Institute — Badshahpur (Gurugram) · Demo Website

Client pitch ke liye banaya gaya **original, premium demo website**.
Koi framework/template nahi — hand-written HTML + CSS + vanilla JS, self-hosted fonts, zero build step.

## Run

```bash
python3 -m http.server 4173 --bind 0.0.0.0 --directory oxford-badshahpur
# ya koi bhi static server
```

Tests (real Chromium):

```bash
python3 tests/qa_site.py        # 228 checks — behaviour, a11y, perf, content-integrity
```

## Pages

| File | Kya hai |
|---|---|
| `index.html` | Hero (3D course deck + pointer parallax), ticker, verified stats, courses preview, course-finder quiz, pillars, real reviews, location + live open/closed clock (IST), FAQ preview, CTA |
| `courses.html` | Fee table (source-traced), 11 course cards + filters + compare tray + detail modals, “confirm nahi hue” enquiry strip, career paths |
| `about.html` | Story, 2 centres timeline, “jo hum nahi kehte” honesty section, sources, hijacked-domain warning |
| `faq.html` | 13 FAQs with category filter + live search + deep links |
| `contact.html` | Enquiry form (real validation, draft restore, honest submit → WhatsApp/mailto/copy), direct contacts, hours |

## Features jo actually kaam karte hain (sab Playwright-verified)

- **Course detail modals** — syllabus, duration, listed fee + “confirm on call” notice, WhatsApp/call/enquiry CTAs; keyboard accessible (Enter/Space, focus trap, Esc).
- **Compare** — max 3 courses side-by-side; tray localStorage mein persist hota hai.
- **Course-finder quiz** — 3 sawaal → suggestion + advice + prefilled WhatsApp message.
- **Command palette** — `Ctrl/⌘K` ya `/` se courses/pages/quick actions.
- **Form** — Indian mobile validation (6–9 start, 10–12 digits), optional email check, consent required,
  inline errors + `aria-invalid`, draft autosave/restore, `?course=` prefill.
  **Honest submit:** demo mode mein form fake success nahi dikhata — poora message WhatsApp/email/copy ke
  liye khulta hai aur screen par exactly yahi likha hota hai. `js/data.js` mein `formEndpoint` set karne par
  real POST + genuine success/error states chalte hain.
- **Live open/closed pill + hours** — Asia/Kolkata ke hisaab se compute hota hai; sources-conflict note ke saath.
- **Mobile** — full-screen drawer (staggered links, scroll-lock), sticky action bar (Call / WhatsApp / Enquiry), floating WhatsApp FAB.
- **A11y** — skip link, focus-visible rings, aria labels, reduced-motion support, keyboard-only operability.
- **Performance** — ~300 KB total transfer per page, 12–13 requests, DOMContentLoaded < 250 ms locally; fonts self-hosted (Fraunces/Manrope/JetBrains Mono woff2).

## Content-integrity rules is demo mein hard-coded

- Fees sirf “**listed**” mark ke saath (source: institute ki previous website ka Wayback snapshot, Oct 2025) + har jagah “confirm on call”.
- Reviews sirf **verbatim public** (Justdial/UrbanPro) naam+date ke saath; ek constructive review bhi jaan-boojh kar.
- Ratings platform-wise alag-alag, source-labeled. Google rating verify nahi hui → dikhayi hi nahi.
- Placement/guarantee/cert claims **zero** — ulta “hum kya nahi kehte” section hai.
- Digital Marketing / standalone MS Office / IELTS → sirf enquiry strip mein, “confirm nahi hua” likha kar.

## Sources

Pura breakdown `docs/RESEARCH-NOTES.md` mein hai. Highlights:
- Justdial (Badshahpur listing): address, est. 2008, categories, ratings, timings
- oxfordedu.co.in Wayback snapshot Oct 2025: 11 courses, fees, syllabus topics
- LinkedIn bio: phone 9818112018, email, social handles
- UrbanPro: MS Office/DTP/C/C++/Java/Tally confirmation + reviews

**Important:** `oxfordedu.co.in` ab hijack ho chuka hai (gambling site serve karta hai — 11 Oct 2026 ko verified).
Client ko batana: naya domain launch ke saath sabse pehle.

## Launch se pehle confirm karein (checklist)

`docs/RESEARCH-NOTES.md` §6 — 10 open questions (Badshahpur ka apna number, exact timings, current fees,
batch strength, Digital Marketing availability, certificate authority, real photos, domain recovery).

## Structure

```
oxford-badshahpur/
├── index.html courses.html about.html faq.html contact.html
├── css/ styles.css fonts.css
├── js/ data.js (sare facts ek jagah) icons.js app.js courses.js form.js faq.js
├── assets/fonts/ (self-hosted woff2)
└── docs/ RESEARCH-NOTES.md
tests/qa_site.py  ·  tests/results.json  ·  tests/shots/
```
