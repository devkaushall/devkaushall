/* =========================================================================
   Oxford Institute — Badshahpur | Central content + config
   -------------------------------------------------------------------------
   Every fact here is traced in docs/RESEARCH-NOTES.md.
   verify:"ok"     -> corroborated by 2+ public sources
   verify:"listed" -> from the institute's own previous website (archived),
                      needs re-confirmation (stale / domain hijacked)
   verify:"ask"    -> NOT confirmed as offered. Shown as "ask the centre".
   ========================================================================= */
window.OXFORD = (function () {
  'use strict';

  const CONFIG = {
    brand: {
      name: 'Oxford Institute',
      full: 'Oxford School of Language & Computer Education',
      branch: 'Badshahpur, Gurugram',
      tagline: 'Bolna seekho. Kaam karna seekho.',
      since: 2008,           // Justdial, Badshahpur listing (group started 2005)
      pin: '122101'
    },
    contact: {
      phoneDisplay: '98181 12018',
      phoneRaw: '919818112018',        // +91 98181 12018 — group number
      phone2Display: '81781 97865',
      phone2Raw: '918178197865',
      email: 'oxfordinstituteggn@gmail.com',
      address: '1st Floor, Opposite Police Station, Jaildar Market, Main Sohna Road, Badshahpur, Gurugram, Haryana 122101',
      addressShort: 'Main Sohna Road, Badshahpur, Gurugram 122101',
      landmark: 'Opposite Police Station, Jaildar Market',
      mapsQuery: 'Oxford School of Language & Computers, Main Sohna Road, Badshahpur, Gurugram 122101',
      hours: [
        { d: 'Monday',    o: '07:00', c: '19:00' },
        { d: 'Tuesday',   o: '07:00', c: '19:00' },
        { d: 'Wednesday', o: '07:00', c: '19:00' },
        { d: 'Thursday',  o: '07:00', c: '19:00' },
        { d: 'Friday',    o: '07:00', c: '19:00' },
        { d: 'Saturday',  o: '07:00', c: '19:00' },
        { d: 'Sunday',    o: null,    c: null }
      ],
      hoursNote: 'Timings public listings se liye gaye hain aur sources mein 7–7 pm / 7–9 pm dono dikhe hain — final timing centre par confirm karein.'
    },
    social: [
      { id: 'facebook',  label: 'Facebook',  url: 'https://www.facebook.com/OxfordSchoolOfLanguage/' },
      { id: 'instagram', label: 'Instagram', url: 'https://www.instagram.com/oxfordinstitute_english/' },
      { id: 'youtube',   label: 'YouTube',   url: 'https://www.youtube.com/@oxford_institute_ggn' }
    ],
    /* Set to your form endpoint (Formspree / Google Apps Script / your API).
       While it is empty the form opens WhatsApp / Mail with the filled data,
       so the demo never fakes a "message sent" toast. */
    formEndpoint: '',
    formEndpointName: 'WhatsApp'
  };

  /* ----------------------------- COURSES -------------------------------- */
  /* cat: language | office | design | code
     fee/duration = as listed on the institute's previous website (verify:"listed") */
  const COURSES = [
    {
      id: 'spoken-english',
      title: 'Spoken English',
      cat: 'language',
      catLabel: 'Language & Communication',
      duration: '3 months',
      durationVerify: 'listed',
      fee: 6000,
      feeVerify: 'listed',
      level: 'Beginner → Advanced',
      blurb: 'Hindi-soch se English-bolne tak. Grammar, pronunciation aur roz ki conversation — sab bol-bol kar practice hoti hai, sirf likh kar nahi.',
      goodFor: ['Students jo interview se pehle confident hona chahte hain', 'Job seekers aur freshers', 'Working adults jo meetings / customers se English mein baat karte hain'],
      syllabus: ['Modal verbs & tenses', 'Conditional sentences', 'Vocabulary aur daily-use phrases', 'Pronunciation & listening practice', 'One-on-one conversation practice', 'Mock interview skills'],
      outcome: 'Aap apni baat English mein bina atke rakh paayenge — introduction, interview aur daily conversation teeno mein.',
      tags: ['Most asked', 'Evening batches'],
      verify: 'ok'
    },
    {
      id: 'basic-computer',
      title: 'Basic Computer + MS Office',
      cat: 'office',
      catLabel: 'Office & Accounting',
      duration: '3 months',
      durationVerify: 'listed',
      fee: 5000,
      feeVerify: 'listed',
      level: 'Absolute beginner',
      blurb: 'Computer pehli baar chhune wale ke liye. On/off se lekar Word, Excel, PowerPoint, printing aur file management tak — practical, step-by-step.',
      goodFor: ['School / college students', 'Pehli baar computer seekhne wale', 'Shop aur office staff', 'Government form aur online kaam khud karne ke liye'],
      syllabus: ['Computer basics — hardware & software', 'Windows operating system chalana', 'File & folder management', 'MS Word — documents, formatting, printing', 'MS Excel — sheets, formulas, data entry', 'MS PowerPoint — presentations', 'Internet, email aur online forms', 'Basic troubleshooting'],
      outcome: 'Aap computer khud chala lenge — document banana, sheet maintain karna, presentation aur print nikalna.',
      tags: ['Foundation course', 'MS Office included'],
      note: 'MS Office is course ka hissa hai — alag se MS Office batch ki availability centre par confirm karein.',
      verify: 'ok'
    },
    {
      id: 'tally-gst',
      title: 'Tally with GST',
      cat: 'office',
      catLabel: 'Office & Accounting',
      duration: '3 months (Tally) · GST module alag bhi',
      durationVerify: 'listed',
      fee: 6000,
      feeModule: { label: 'GST module', fee: 4000 },
      feeVerify: 'listed',
      level: 'Beginner → Job ready',
      blurb: 'Accounting ka asli kaam — company banana se lekar billing, GST return entry, payroll aur reports tak. Har entry khud karke seekhenge.',
      goodFor: ['B.Com / commerce students', 'CA aur accountant offices mein job chahiye', 'Apni dukaan / business ka khata khud rakhne wale'],
      syllabus: ['Introduction to Tally & company creation', 'Accounting masters & inventory masters', 'Accounting vouchers aur voucher entry', 'Bill / invoice banana', 'GST — bill with GST, advance receipt, adjustment entry', 'TDS (Tax Deducted at Source)', 'Point of Sale (POS)', 'Payroll masters', 'Interest calculation & budget', 'Purchase bill pending, multi-address', 'Reports aur closing'],
      outcome: 'Aap ek company ka poora account Tally mein maintain kar sakenge — entry, GST, billing aur reports.',
      tags: ['High demand', 'Accounting jobs'],
      verify: 'ok'
    },
    {
      id: 'advanced-excel',
      title: 'Advanced Excel',
      cat: 'office',
      catLabel: 'Office & Accounting',
      duration: 'Centre par confirm karein',
      durationVerify: 'ask',
      fee: 5500,
      feeVerify: 'listed',
      level: 'Intermediate',
      blurb: 'Basic Excel aata hai? Ab formulas, pivot tables aur reports ka level. Data ko kaam ki report mein badalna seekhenge.',
      goodFor: ['Office / back-office jobs', 'Data entry se aage badhna hai', 'Reports aur MIS banane wale', 'Students jinka project data pe hai'],
      syllabus: ['Pivot Table & Pivot Chart', 'Pivot Table relationships', 'Advanced conditional formatting', 'Dynamic advanced filter', 'Searchable drop-down list', 'Attendance sheet banana', 'Dynamic advanced charts', 'INDEX–MATCH formula', 'Financial functions'],
      outcome: 'Aap bade data se saaf report aur dashboard bana sakenge — bina ghante lagaye.',
      tags: ['Career booster'],
      verify: 'ok'
    },
    {
      id: 'dtp',
      title: 'DTP (Photoshop + CorelDRAW)',
      cat: 'design',
      catLabel: 'Design & Creative',
      duration: 'Centre par confirm karein',
      durationVerify: 'ask',
      fee: 5500,
      feeVerify: 'listed',
      level: 'Beginner friendly',
      blurb: 'Poster, banner, card, logo, photo editing — jo kaam market mein roz hota hai, wahi software ke saath. Design ka kaam khud karke seekhenge.',
      goodFor: ['Creative kaam mein interest', 'Printing press / photo studio / shop branding', 'Freelance design kaam', 'Social media ke liye design banana'],
      syllabus: ['Adobe Photoshop — editing, retouching, layers', 'CorelDRAW — vector design, layout', 'Poster, banner & visiting card design', 'Logo aur branding basics', 'Print-ready file banana'],
      outcome: 'Aap print aur digital dono ke liye design files khud bana sakenge.',
      tags: ['Creative', 'Freelance friendly'],
      verify: 'ok'
    },
    {
      id: 'web-designing',
      title: 'Web Designing',
      cat: 'design',
      catLabel: 'Design & Creative',
      duration: '3 months',
      durationVerify: 'listed',
      fee: 6000,
      feeVerify: 'listed',
      level: 'Beginner',
      blurb: 'HTML, CSS aur JavaScript — apni pehli website khud banaiye. Coding ka dar nikalne ka sabse practical rasta.',
      goodFor: ['Students jo IT field mein jaana chahte hain', 'Freelance web kaam', 'Apne business ki website samajhne ke liye', 'Programming se pehle ka base'],
      syllabus: ['HTML — page structure', 'CSS — design, layout, responsive basics', 'JavaScript — interactivity', 'Ek complete practice website banana'],
      outcome: 'Aap ek working webpage design aur code kar sakenge — structure, style aur basic interaction ke saath.',
      tags: ['IT career start'],
      verify: 'ok'
    },
    {
      id: 'c-language',
      title: 'C Language',
      cat: 'code',
      catLabel: 'Programming',
      duration: 'Centre par confirm karein',
      durationVerify: 'ask',
      fee: 4000,
      feeVerify: 'listed',
      level: 'Beginner',
      blurb: 'Programming ka foundation. Logic banana seekhne ke liye C sabse solid shuruaat hai — college syllabus ke liye bhi.',
      goodFor: ['BCA / B.Tech / B.Sc CS students', 'Programming bilkul naya hai', 'College exam & practical ke liye'],
      syllabus: ['Introduction to C', 'C fundamentals', 'Operators & expressions', 'Data types aur input/output library functions', 'Arrays & functions', 'Strings & functions', 'Structures & file handling'],
      outcome: 'Aap programs ka logic samajh kar khud likh sakenge — college practical tak confidently.',
      tags: ['College students'],
      verify: 'ok'
    },
    {
      id: 'cpp',
      title: 'C++ Language',
      cat: 'code',
      catLabel: 'Programming',
      duration: 'Centre par confirm karein',
      durationVerify: 'ask',
      fee: 4500,
      feeVerify: 'listed',
      level: 'Beginner → Intermediate',
      blurb: 'C ke baad ka natural step — object oriented programming ka base, jo aage Java aur software courses mein kaam aata hai.',
      goodFor: ['School (11th–12th) computer science students', 'BCA / B.Tech students', 'Software field mein jaane ki planning'],
      syllabus: ['C++ basics aur syntax', 'Object oriented programming concepts', 'Classes & objects', 'Practice programs'],
      note: 'Detailed topic list institute ki previous website par available nahi thi — pura syllabus centre se lein.',
      outcome: 'Aap OOP ka base samajh kar programs likhna shuru kar denge.',
      tags: ['OOP base'],
      verify: 'ok'
    },
    {
      id: 'python',
      title: 'Python Programming',
      cat: 'code',
      catLabel: 'Programming',
      duration: '2 months',
      durationVerify: 'listed',
      fee: 7000,
      feeVerify: 'listed',
      level: 'Beginner',
      blurb: 'Aaj ki sabse practical language. Chhote programs se shuru karke loops, lists aur real logic tak — hands-on coding ke saath.',
      goodFor: ['IT career start karna hai', 'Data / automation field mein interest', 'College project ke liye', 'School students jo coding shuru karna chahte hain'],
      syllabus: ['Introduction to Python', 'Variables & multiple assignment', 'String methods aur slicing', 'Type casting aur user input', 'Math functions', 'if statements & logical operators', 'while, for aur nested loops', 'break / continue / pass', 'Lists, 2D lists, tuples, sets'],
      outcome: 'Aap Python mein apne programs likh sakenge — logic se lekar data handle karne tak.',
      tags: ['Popular', 'Future ready'],
      verify: 'ok'
    },
    {
      id: 'core-java',
      title: 'Core Java',
      cat: 'code',
      catLabel: 'Programming',
      duration: 'Centre par confirm karein',
      durationVerify: 'ask',
      fee: 7000,
      feeVerify: 'listed',
      level: 'Intermediate',
      blurb: 'Software development ki sabse chalti language. Object oriented programming properly samajhne ke liye.',
      goodFor: ['Software job ki taiyari', 'BCA / MCA / B.Tech students', 'C++ ke baad next level'],
      syllabus: ['Java fundamentals', 'Object oriented programming', 'Core Java concepts aur practice programs'],
      note: 'Detailed topic list institute ki previous website par available nahi thi — pura syllabus centre se lein.',
      outcome: 'Aap Java mein object oriented programs bana sakenge.',
      tags: ['Software jobs'],
      verify: 'ok'
    },
    {
      id: 'php',
      title: 'PHP',
      cat: 'code',
      catLabel: 'Programming',
      duration: 'Centre par confirm karein',
      durationVerify: 'ask',
      fee: 7000,
      feeVerify: 'listed',
      level: 'Intermediate',
      blurb: 'Web ke peeche ka kaam — forms, database aur dynamic pages. Web designing ke baad ka logical next step.',
      goodFor: ['Web development mein career', 'Freelance website projects', 'HTML/CSS/JS ke baad aage badhna'],
      syllabus: ['PHP basics', 'Forms aur server-side scripting', 'Database ke saath kaam karna'],
      note: 'Detailed topic list institute ki previous website par available nahi thi — pura syllabus centre se lein.',
      outcome: 'Aap dynamic web pages aur basic database-driven features bana sakenge.',
      tags: ['Web development'],
      verify: 'ok'
    }
  ];

  /* Not evidenced for this centre — shown as an enquiry prompt, never as an offer. */
  const ASK_COURSES = [
    { id: 'digital-marketing', title: 'Digital Marketing', note: 'Is centre par available hai ya nahi — confirm nahi ho paya.' },
    { id: 'ms-office-standalone', title: 'MS Office (alag batch)', note: 'Basic Computer course mein included hai; alag batch ki availability confirm karein.' },
    { id: 'ielts', title: 'IELTS / Personality Development', note: 'Group ke doosre centres par chalta hai — Badshahpur ke liye confirm karein.' }
  ];

  /* ---------------------------- RECOMMENDER ----------------------------- */
  const QUIZ = [
    {
      id: 'goal',
      q: 'Aap sabse pehle kya improve karna chahte hain?',
      options: [
        { k: 'english',  label: 'English bolna' },
        { k: 'job',      label: 'Job / office kaam' },
        { k: 'accounts', label: 'Accounting & billing' },
        { k: 'code',     label: 'Coding / IT field' },
        { k: 'design',   label: 'Design & creative' }
      ]
    },
    {
      id: 'time',
      q: 'Roz kitna time de sakte hain?',
      options: [
        { k: 'less', label: '1 ghanta ya kam' },
        { k: 'mid',  label: '1–2 ghante' },
        { k: 'more', label: '2 ghante se zyada' }
      ]
    },
    {
      id: 'base',
      q: 'Computer ka experience kaisa hai?',
      options: [
        { k: 'zero', label: 'Bilkul naya' },
        { k: 'some', label: 'Thoda bahut chala leta hoon' },
        { k: 'good', label: 'Achha chala leta hoon' }
      ]
    }
  ];

  function recommend(answers) {
    const g = answers.goal, base = answers.base, time = answers.time;
    const order = [];
    const push = (id) => { if (!order.includes(id)) order.push(id); };

    if (g === 'english') { push('spoken-english'); push(base === 'zero' ? 'basic-computer' : 'advanced-excel'); }
    if (g === 'job')     { push('basic-computer'); push('advanced-excel'); push('spoken-english'); }
    if (g === 'accounts'){ push('tally-gst'); push('advanced-excel'); push('basic-computer'); }
    if (g === 'code')    { push(base === 'zero' ? 'basic-computer' : 'python'); push(base === 'zero' ? 'c-language' : 'core-java'); push('web-designing'); }
    if (g === 'design')  { push('dtp'); push('web-designing'); push(base === 'zero' ? 'basic-computer' : 'advanced-excel'); }

    if (base === 'zero') { if (!order.includes('basic-computer')) order.splice(1, 0, 'basic-computer'); }
    if (time === 'less') { /* short daily time: keep course order, advice changes */ }

    return order.slice(0, 3).map(id => COURSES.find(c => c.id === id)).filter(Boolean);
  }

  function advice(answers) {
    const bits = [];
    if (answers.base === 'zero') bits.push('Computer bilkul naya hai to Basic Computer se shuruaat karein — baaki courses uske baad aasan ho jaayenge.');
    if (answers.time === 'less') bits.push('Roz 1 ghanta bhi kaafi hai, bas batch aisa chunein jismein students theek-thaak hon — poori batch mein akele rehne se progress slow hoti hai.');
    if (answers.time === 'more') bits.push('2 ghante se zyada time hai to ek technical course + Spoken English saath mein chala sakte hain.');
    if (answers.goal === 'job') bits.push('Job ke liye interview practice zaroori hai — Spoken English ka mock interview module isi ke liye hai.');
    if (answers.goal === 'accounts') bits.push('Tally aur Excel saath mein karne se accounting + reporting dono cover ho jaate hain — zyadatar accounting jobs mein dono maange jaate hain.');
    if (answers.goal === 'english') bits.push('Spoken English ke saath ek computer course bhi rakhein — English se interview clear hota hai, kaam computer se milta hai.');
    if (answers.goal === 'design') bits.push('DTP ke saath Web Designing bhi dekh lein — print aur digital dono kaam milne ke chances badh jaate hain.');
    if (!bits.length) bits.push('Abhi sirf ek course se shuruaat karein aur use poora karein — ek saath do course shuru karke dono adhoore reh jaate hain.');
    bits.push('Join karne se pehle current fees, duration aur batch timing centre par confirm kar lein — yahan dikhi fees institute ki previous website se listed hain.');
    return bits;
  }

  /* --------------------------- SOCIAL PROOF ----------------------------- */
  /* Verbatim public reviews with source + date. Nothing invented. */
  const REVIEWS = [
    { quote: 'This is splendid platform to learn English and Computer Courses. I beefed up my English here. Teachers are very kind & friendly and their study way is superb.', name: 'Ankit', meta: 'Justdial review · 31 May 2022', tone: 'positive' },
    { quote: 'Best English language classes in Gurgaon. If you want to speak fluent English must join.', name: 'Hemant Kumar Jha', meta: 'Justdial review · 30 Jan 2020', tone: 'positive' },
    { quote: 'Best institute for learning English Language in Gurgaon. Top class facilities and trainers. Classes are taken in a very peaceful and cool environment.', name: 'Greesha', meta: 'UrbanPro review', tone: 'positive' },
    { quote: 'Oxford institute is one of the best institute in Gurgaon for computer and spoken classes. They are providing a big lab and so many systems in the lab, and batch timings suit students.', name: 'Rajni Mahlawat', meta: 'UrbanPro review · 03 Mar 2016', tone: 'positive' },
    { quote: 'English Spoken classes are really superb at Oxford institute. Good trainers.', name: 'Neha', meta: 'UrbanPro review · 17 Jun 2016', tone: 'positive' },
    { quote: 'Awesome study structure.', name: 'Ashutosh', meta: 'Justdial review · 05 Aug 2018', tone: 'positive' },
    { quote: 'It is a good institute for English speaking, but I took admission in the last 6 o’clock batch and in that batch no one came, so my two months were not good. In summer I joined the first batch and it was good — so if you take admission, don’t take the last 6 o’clock batch.', name: 'A Justdial reviewer', meta: 'Badshahpur listing · 25 Jun 2025', tone: 'mixed' }
  ];

  const RATING_SOURCES = [
    { platform: 'Justdial — Badshahpur', score: '4.7', count: '127 ratings', note: 'Public listing', verify: 'listed' },
    { platform: 'Justdial — main branch', score: '4.5', count: '207 ratings', note: 'New Railway Road, Gurugram', verify: 'listed' },
    { platform: 'UrbanPro', score: '4.5', count: '11 reviews', note: 'Oxford Institute Gurgaon', verify: 'listed' }
  ];

  /* -------------------------------- FAQ --------------------------------- */
  const FAQS = [
    {
      cat: 'Admission',
      q: 'Admission ke liye kya karna hoga?',
      a: 'Sabse aasan rasta: WhatsApp ya call par course ka naam bata dijiye. Centre par batch timings aur current fees bata di jaayengi, phir aap institute aakar form bhar sakte hain. Address: 1st Floor, Opposite Police Station, Jaildar Market, Main Sohna Road, Badshahpur, Gurugram 122101.'
    },
    {
      cat: 'Admission',
      q: 'Kya demo ya trial class milti hai?',
      a: 'Iska jawab centre par depend karta hai — hum is website par jhootha "free demo guaranteed" nahi likh rahe. Call ya WhatsApp par pooch lijiye ki aapke batch mein ek baith kar class dekh sakte hain ya nahi; aksar institutes ye allow karti hain.'
    },
    {
      cat: 'Fees',
      q: 'Fees kitni hai?',
      a: 'Is demo par jo fees dikh rahi hain wo institute ki previous website (archived) se li gayi hain aur purani ho sakti hain — isliye har course card par "confirm on call" likha hai. Sahi current fee ke liye 98181 12018 par call karein. Koi bhi course lene se pehle fee, duration aur batch timing written mein confirm kar lein.'
    },
    {
      cat: 'Fees',
      q: 'Kya installment mein fees de sakte hain?',
      a: 'Ye publicly confirm nahi hai, isliye hum yahan koi promise nahi kar rahe. Direct centre par pooch lijiye — chhote institutes aksar 2 hisson mein fees lete hain.'
    },
    {
      cat: 'Batch',
      q: 'Kaun sa batch choose karein?',
      a: 'Ek honest baat: ek student ne Badshahpur listing par review likha tha ki unhone shaam 6 baje ki aakhri batch li aur us batch mein students nahi aaye, jisse unke 2 mahine kharab gaye. Isliye admission se pehle pooch lijiye ki us batch mein kitne students hain. Subah/pehli batch aur shaam ki main batch mein usually bheed rehti hai.'
    },
    {
      cat: 'Batch',
      q: 'Working professionals ke liye evening batch hai?',
      a: 'Institute subah 7 baje khulta hai aur shaam tak batches chalte hain (public listings mein 7–7 pm aur 7–9 pm dono timings dikhi hain). Apne time ke hisaab se exact evening batch centre se confirm karein.'
    },
    {
      cat: 'Course',
      q: 'Computer bilkul nahi aata — kahan se shuru karun?',
      a: 'Basic Computer + MS Office course se. Usme Windows chalana, file management, Word, Excel, PowerPoint, printing aur basic troubleshooting cover hota hai. Uske baad aap Advanced Excel, Tally, DTP ya Python mein ja sakte hain.'
    },
    {
      cat: 'Course',
      q: 'Tally aur Advanced Excel mein se kaun karun?',
      a: 'Accounting, CA office, billing ya khate ka kaam karna hai → Tally with GST. Office mein reports, MIS ya data ka kaam hai → Advanced Excel. Dono ek saath karne se accounting + reporting dono cover ho jaate hain.'
    },
    {
      cat: 'Course',
      q: 'Kya aap Digital Marketing sikhate hain?',
      a: 'Is centre par Digital Marketing available hai — ye publicly confirm nahi ho saka, isliye hum ise course list mein nahi dikha rahe. Aapko ye course chahiye to call/WhatsApp par pooch lijiye; institute ke group ke doosre centres par ye course chalta hai.'
    },
    {
      cat: 'Certificate',
      q: 'Course ke baad certificate milta hai?',
      a: 'Institute ki previous website par course completion certificate ka zikr hai. Lekin certificate kis authority se issued hai, wo publicly confirm nahi hai — isliye admission se pehle certificate ka naam aur issuing body zaroor pooch lein.'
    },
    {
      cat: 'Certificate',
      q: 'Kya placement ya job guarantee milti hai?',
      a: 'Nahi — aur hum yahan jhootha placement claim bhi nahi kar rahe. Is centre ke liye koi documented placement record publicly available nahi mila. Course se skill milti hai; job ke liye interview practice (Spoken English course ka hissa) aur apna kaam khud dikhana zaroori hai.'
    },
    {
      cat: 'General',
      q: 'Classes offline hain ya online?',
      a: 'Badshahpur listing ke mutabik yahan training offline / classroom mode mein hoti hai. Online class ki availability centre par confirm karein.'
    },
    {
      cat: 'General',
      q: 'Institute ka dusra centre bhi hai?',
      a: 'Haan. Isi group ka main centre 572/2, 1st Floor, Adarsh Nagar, New Railway Road, near Auto Stand, Sector 12, Gurugram 122001 par hai (2005 se). Badshahpur centre Main Sohna Road par hai.'
    }
  ];

  /* ----------------------------- WHY US --------------------------------- */
  const PILLARS = [
    {
      n: '01',
      title: 'Practice first, theory baad mein',
      body: 'Har course ka syllabus aisa bana hai jo khud karke seekha jaata hai — Tally mein entry aap bharenge, Excel mein sheet aap banayenge, Python mein program aap likhenge. Sirf dekhne se skill nahi banti.',
      proof: 'Institute ki own course pages par "hands-on training / learn by doing" consistently likha hai.'
    },
    {
      n: '02',
      title: 'Ek hi jagah, do zaroori skills',
      body: 'Gurugram ke is hisse mein English aur computer dono ek hi centre par milna badi baat hai. English confidence deta hai, computer kaam dilata hai — dono saath chalne se job-ready profile banti hai.',
      proof: 'Centre ka naam hi Oxford School of Language & Computer Education hai; dono streams 2005 se listed hain.'
    },
    {
      n: '03',
      title: 'Kaam aane wale courses, fancy nahi',
      body: 'Tally with GST, Advanced Excel, MS Office, DTP, Web Designing — ye wo courses hain jo local market, offices aur shops mein roz maange jaate hain. Course list market ke hisaab se hai, trend ke peeche bhaagne ke liye nahi.',
      proof: 'Fee list mein 11 courses hain; sabhi job-oriented ya school/college syllabus se jude hain.'
    },
    {
      n: '04',
      title: 'Sohna Road par, ghar ke paas',
      body: 'Main Sohna Road, Jaildar Market, Police Station ke saamne — Badshahpur, Sector 47/48/67/68 aur aas-paas ki societies se seedha pahunch. Roz aana jaana aasan ho to course complete hone ke chances badh jaate hain.',
      proof: 'Address public listing se verified: 1st Floor, Opp. Police Station, Jaildar Market, Main Sohna Road, Badshahpur 122101.'
    }
  ];

  const STATS = [
    { value: '2008', label: 'Badshahpur centre listed since', sub: 'Group 2005 se' },
    { value: '11', label: 'Courses publicly listed', sub: 'Language · Office · Design · Code' },
    { value: '122101', label: 'Main Sohna Road, Badshahpur', sub: 'Opp. Police Station, Jaildar Market' },
    { value: '4.7', label: 'Justdial rating (Badshahpur)', sub: '127 public ratings' }
  ];

  /* Utility used by pages */
  function courseById(id) { return COURSES.find(c => c.id === id) || null; }
  function byCat(cat) { return cat === 'all' ? COURSES : COURSES.filter(c => c.cat === cat); }
  function rupee(n) { return '₹' + n.toLocaleString('en-IN'); }

  function waLink(message) {
    return 'https://wa.me/' + CONFIG.contact.phoneRaw + '?text=' + encodeURIComponent(message);
  }

  return {
    CONFIG, COURSES, ASK_COURSES, QUIZ, recommend, advice,
    REVIEWS, RATING_SOURCES, FAQS, PILLARS, STATS,
    courseById, byCat, rupee, waLink
  };
})();
