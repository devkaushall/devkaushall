/* =========================================================================
   OXFORD INSTITUTE — BADSHAHPUR | faq.js
   Renders the FAQ from the shared data file with category filters, live
   search and #hash deep-linking. Single source of truth = js/data.js
   ========================================================================= */
(function () {
  'use strict';
  const { $, $$, esc } = OX_UI;
  const D = window.OXFORD;

  function boot() {
    const list = $('[data-faq-list]');
    const filters = $('[data-faq-filters]');
    if (!list) return;

    const cats = ['Sabhi'].concat(D.FAQS.map(f => f.cat).filter((c, i, a) => a.indexOf(c) === i));
    let activeCat = 'Sabhi';
    let query = '';

    if (filters) {
      filters.innerHTML = cats.map((c, i) =>
        '<input type="radio" name="faqcat" id="fq-' + i + '" value="' + esc(c) + '"' + (i === 0 ? ' checked' : '') + '>' +
        '<label for="fq-' + i + '">' + esc(c) + ' <span class="n">' +
          (c === 'Sabhi' ? D.FAQS.length : D.FAQS.filter(f => f.cat === c).length) + '</span></label>'
      ).join('');
      filters.addEventListener('change', e => { if (e.target.name === 'faqcat') { activeCat = e.target.value; paint(); } });
    }

    const search = $('#faq-search');
    if (search) {
      search.addEventListener('input', OX_UI.debounce(() => { query = search.value.trim().toLowerCase(); paint(); }, 130));
    }

    function paint() {
      const hit = D.FAQS.filter(f =>
        (activeCat === 'Sabhi' || f.cat === activeCat) &&
        (!query || (f.q + ' ' + f.a).toLowerCase().indexOf(query) > -1)
      );

      const cnt = $('[data-faq-count]');
      if (cnt) cnt.textContent = hit.length + ' / ' + D.FAQS.length;
      const empty = $('[data-faq-empty]');
      if (empty) empty.hidden = hit.length > 0;

      let html = '', lastCat = '';
      hit.forEach(f => {
        if (f.cat !== lastCat) { html += '<h2 class="faq__cat">' + esc(f.cat) + '</h2>'; lastCat = f.cat; }
        const id = 'q-' + f.q.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40);
        html += '<details class="qa" id="' + id + '" data-cat="' + esc(f.cat) + '">' +
                  '<summary>' + esc(f.q) + '</summary>' +
                  '<div class="qa__a">' + esc(f.a) + '</div>' +
                '</details>';
      });
      list.innerHTML = html;

      /* open the deep-linked one */
      if (location.hash) {
        const t = document.querySelector(location.hash);
        if (t && t.tagName === 'DETAILS') {
          t.open = true;
          t.scrollIntoView({ behavior: OX_UI.reduceMotion() ? 'auto' : 'smooth', block: 'center' });
        }
      }
    }

    paint();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
