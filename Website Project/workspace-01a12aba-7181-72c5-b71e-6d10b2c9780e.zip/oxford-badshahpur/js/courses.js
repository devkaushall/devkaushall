/* =========================================================================
   OXFORD INSTITUTE — BADSHAHPUR | courses.js
   Renders the course grid (filters + expandable cards + compare) and the
   3-step "course finder" recommender. Used by index.html and courses.html.
   ========================================================================= */
(function () {
  'use strict';
  const { $, $$, ico, esc } = OX_UI;
  const D = window.OXFORD;

  const CATS = [
    { k: 'all',      label: 'Saare courses' },
    { k: 'language', label: 'Language' },
    { k: 'office',   label: 'Office & Accounts' },
    { k: 'design',   label: 'Design & Creative' },
    { k: 'code',     label: 'Programming' }
  ];

  const VAR = { language: ['--c-lang', '--c-lang-w'], office: ['--c-off', '--c-off-w'], design: ['--c-des', '--c-des-w'], code: ['--c-code', '--c-code-w'] };

  /* ---------------------------- CARD MARKUP ---------------------------- */
  function cardHTML(c, opts) {
    const o = opts || {};
    const [cc, cw] = VAR[c.cat];
    const fee = c.fee ? '₹' + c.fee.toLocaleString('en-IN') : 'On call';
    const feeSub = c.fee ? (c.feeVerify === 'listed' ? 'listed fee · confirm karein' : 'confirm on call') : 'centre par poochein';
    const tags = (c.tags || []).slice(0, 2).map(t => '<span class="tag">' + esc(t) + '</span>').join('');

    return '' +
    '<article class="cc" data-cc="' + c.id + '" data-cat="' + c.cat + '" style="--ccc:var(' + cc + ');--ccw:var(' + cw + ')" id="' + c.id + '" tabindex="0" role="button" aria-label="' + esc(c.title) + ' course ka detail kholein">' +
      '<div class="cc__top">' +
        '<span class="cc__glyph">' + ico(OX_UI.glyphFor(c.id)) + '</span>' +
        '<span class="cc__tags">' + tags + '</span>' +
      '</div>' +
      '<div>' +
        '<div class="cc__cat">' + esc(c.catLabel) + '</div>' +
        '<h3>' + esc(c.title) + '</h3>' +
      '</div>' +
      '<p class="cc__blurb">' + esc(c.blurb) + '</p>' +
      '<div class="cc__meta">' +
        '<span class="chip">' + ico('clock') + esc(c.duration) + '</span>' +
        '<span class="chip">' + ico('target') + esc(c.level) + '</span>' +
      '</div>' +
      (c.note ? '<p class="cc__note">' + esc(c.note) + '</p>' : '') +
      '<ul class="cc__syl" id="syl-' + c.id + '">' +
        c.syllabus.map(s => '<li>' + ico('check') + '<span>' + esc(s) + '</span></li>').join('') +
      '</ul>' +
      '<div class="cc__foot">' +
        '<span class="cc__fee"><b>' + fee + '</b><small>' + esc(feeSub) + '</small></span>' +
        '<span class="cc__acts">' +
          '<button class="iconbtn" type="button" data-compare="' + c.id + '" aria-pressed="false" aria-label="Compare mein jodein: ' + esc(c.title) + '" title="Compare">' + ico('scale') + '</button>' +
          '<a class="iconbtn iconbtn--wa" href="' + D.waLink('Namaste! Mujhe "' + c.title + '" course ki details chahiye — fees, batch timing aur next batch.') + '" target="_blank" rel="noopener" aria-label="WhatsApp par ' + esc(c.title) + ' ke baare mein poochein" title="WhatsApp">' + ico('whatsapp') + '</a>' +
          '<button class="btn btn--sm" type="button" data-open-course="' + c.id + '">' + (o.compact ? 'Details' : 'Details') + ico('arrowR') + '</button>' +
        '</span>' +
      '</div>' +
    '</article>';
  }

  /* ------------------------------ GRID --------------------------------- */
  function renderGrid() {
    const grid = $('[data-course-grid]');
    if (!grid) return;
    const limit = parseInt(grid.dataset.limit || '0', 10);
    const list = limit ? D.COURSES.slice(0, limit) : D.COURSES;
    grid.innerHTML = list.map(c => cardHTML(c)).join('');

    if (limit) {
      const more = document.createElement('div');
      more.className = 'sec__more';
      more.style.cssText = 'grid-column:1/-1;display:flex;justify-content:center;margin-top:8px';
      more.innerHTML = '<a class="btn btn--ghost" href="courses.html">Saare ' + D.COURSES.length + ' courses dekhein ' + ico('arrowR') + '</a>';
      grid.appendChild(more);
    }

    /* re-run reveals for the freshly injected cards */
    $$('.cc', grid).forEach((n, i) => { n.setAttribute('data-rv', ''); n.dataset.rvDelay = String((i % 4) * 80); });
    if (window.OX_APP && OX_APP.paintClocks) OX_APP.paintClocks();
    const io = ('IntersectionObserver' in window) ? new IntersectionObserver(es => {
      es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
    }, { threshold: .1, rootMargin: '0px 0px -6% 0px' }) : null;
    $$('.cc', grid).forEach(n => { if (io) io.observe(n); else n.classList.add('in'); });
    if (window.OX_APP) OX_APP.syncCompareUI();

    /* keyboard: Enter/Space on a card opens its detail modal */
    grid.addEventListener('keydown', e => {
      if (e.key !== 'Enter' && e.key !== ' ') return;
      const card = e.target.closest ? e.target.closest('.cc') : null;
      if (!card) return;
      if (e.target.closest('button, a, input, select')) return;   /* let inner controls work */
      e.preventDefault();
      window.OX_APP.courseModal(card.dataset.cc);
    });

    /* deep link: courses.html#tally-gst */
    if (location.hash) {
      const t = document.querySelector(location.hash);
      if (t) setTimeout(() => {
        t.scrollIntoView({ behavior: OX_UI.reduceMotion() ? 'auto' : 'smooth', block: 'center' });
        t.style.transition = 'box-shadow .4s'; t.style.boxShadow = 'inset 0 0 0 2px var(--copper), var(--sh-3)';
        setTimeout(() => { t.style.boxShadow = ''; }, 1800);
      }, 420);
    }
  }

  /* ---------------------------- FILTERS -------------------------------- */
  function initFilters() {
    const box = $('[data-filters]');
    if (!box) return;
    box.innerHTML = CATS.map((c, i) => {
      const n = c.k === 'all' ? D.COURSES.length : D.COURSES.filter(x => x.cat === c.k).length;
      return '<input type="radio" name="cat" id="cat-' + c.k + '" value="' + c.k + '"' + (i === 0 ? ' checked' : '') + '>' +
             '<label for="cat-' + c.k + '">' + esc(c.label) + ' <span class="n">' + n + '</span></label>';
    }).join('');

    const grid = $('[data-course-grid]');
    const count = $('[data-result-count]');
    box.addEventListener('change', e => {
      if (e.target.name !== 'cat') return;
      const v = e.target.value;
      let shown = 0;
      $$('.cc', grid).forEach(card => {
        const hit = v === 'all' || card.dataset.cat === v;
        card.classList.toggle('is-out', !hit);
        if (hit) {
          shown++;
          card.classList.remove('in');
          requestAnimationFrame(() => requestAnimationFrame(() => card.classList.add('in')));
        }
      });
      if (count) count.textContent = shown + (shown === 1 ? ' course' : ' courses') +
        (v === 'all' ? '' : ' · ' + (CATS.find(c => c.k === v) || {}).label);
    });
    if (count) count.textContent = D.COURSES.length + ' courses';
  }

  /* ------------------------ "ASK US" STRIP ----------------------------- */
  function initAsk() {
    const box = $('[data-ask]');
    if (!box) return;
    box.innerHTML = D.ASK_COURSES.map(a =>
      '<div>' + ico('info') + '<span><b>' + esc(a.title) + '</b> — <small>' + esc(a.note) + '</small></span>' +
      '<a class="tlink" style="margin-left:auto" href="' + D.waLink('Namaste! Kya aap "' + a.title + '" course Badshahpur centre par karate hain? Please details bhej dein.') + '" target="_blank" rel="noopener">Poochein ' + ico('arrowR') + '</a></div>'
    ).join('');
  }

  /* -------------------------- RECOMMENDER ------------------------------ */
  function initQuiz() {
    const box = $('[data-quiz]');
    if (!box) return;
    const Q = D.QUIZ;
    const answers = {};
    let step = 0;

    box.innerHTML =
      '<div class="quiz__bar">' +
        Q.map((_, i) => '<i data-bar="' + i + '"></i>').join('') +
        '<span class="quiz__count" data-count-txt>1 / ' + Q.length + '</span>' +
      '</div>' +
      '<div data-steps></div>' +
      '<div data-result hidden></div>';

    const stepsEl = box.querySelector('[data-steps]');
    const resEl = box.querySelector('[data-result]');
    const barEls = $$('[data-bar]', box);
    const countEl = box.querySelector('[data-count-txt]');

    stepsEl.innerHTML = Q.map((q, qi) =>
      '<div class="quiz__step' + (qi === 0 ? ' is-on' : '') + '" data-step="' + qi + '">' +
        '<div class="kicker kicker--light">Step ' + (qi + 1) + '</div>' +
        '<h3 class="quiz__q" style="margin-top:10px">' + esc(q.q) + '</h3>' +
        '<div class="quiz__opts" role="group" aria-label="' + esc(q.q) + '">' +
          q.options.map(o => '<button class="quiz__opt" type="button" data-k="' + o.k + '" aria-pressed="false">' + esc(o.label) + '</button>').join('') +
        '</div>' +
      '</div>'
    ).join('');

    function paint() {
      $$('.quiz__step', box).forEach(s => s.classList.toggle('is-on', +s.dataset.step === step));
      barEls.forEach((b, i) => b.style.setProperty('--p', i < step ? '1' : (i === step ? '.5' : '0')));
      countEl.textContent = Math.min(step + 1, Q.length) + ' / ' + Q.length;
    }

    box.addEventListener('click', e => {
      const opt = e.target.closest('.quiz__opt');
      if (!opt) {
        const again = e.target.closest('[data-again]');
        if (again) { Object.keys(answers).forEach(k => delete answers[k]); step = 0; resEl.hidden = true; stepsEl.hidden = false; paint(); }
        const wa = e.target.closest('[data-quiz-wa]');
        return;
      }
      $$('.quiz__opt', opt.parentElement).forEach(b => b.setAttribute('aria-pressed', String(b === opt)));
      answers[Q[step].id] = opt.dataset.k;
      if (step < Q.length - 1) { step++; paint(); }
      else showResult();
    });

    function showResult() {
      const picks = D.recommend(answers);
      const adv = D.advice(answers);
      const summary = picks.map((c, i) => (i + 1) + '. ' + c.title).join(', ');

      resEl.hidden = false;
      stepsEl.hidden = true;
      barEls.forEach(b => b.style.setProperty('--p', '1'));
      countEl.textContent = 'Result';

      resEl.innerHTML =
        '<div class="kicker kicker--light">Aapke liye</div>' +
        '<h3 class="quiz__q" style="margin-top:10px">Ye courses aapke liye sahi rahenge</h3>' +
        '<div class="quiz__res">' +
          picks.map((c, i) =>
            '<div class="quiz__pick">' +
              '<span class="rn">' + (i + 1) + '</span>' +
              '<span style="flex:1"><b>' + esc(c.title) + '</b><small>' + esc(c.duration) + (c.fee ? ' · ₹' + c.fee.toLocaleString('en-IN') + ' (listed)' : '') + '</small></span>' +
              '<button class="btn btn--sm btn--light" type="button" data-open-course="' + c.id + '">Details ' + ico('arrowR') + '</button>' +
            '</div>'
          ).join('') +
        '</div>' +
        (adv.length ? '<div class="quiz__advice">' + adv.map(a => '<p>' + ico('spark') + '<span>' + esc(a) + '</span></p>').join('') + '</div>' : '') +
        '<div class="row" style="margin-top:22px;gap:10px">' +
          '<a class="btn btn--copper" data-quiz-wa href="' + D.waLink('Namaste! Maine aapki website par course finder use kiya. Mera suggestion aaya: ' + summary + '. Please in courses ki fees aur batch timings bata dein.') + '" target="_blank" rel="noopener">' + ico('whatsapp') + 'Ye suggestion WhatsApp par bhejein</a>' +
          '<a class="btn btn--light" href="contact.html?course=' + picks[0].id + '">' + ico('mail') + 'Enquiry form</a>' +
          '<button class="btn btn--ghost" style="--fg:var(--paper);box-shadow:inset 0 0 0 1.5px var(--line-ink)" type="button" data-again>Phir se karein</button>' +
        '</div>' +
        '<p style="margin-top:16px;font-size:.8rem;color:rgba(246,241,230,.55)">Ye ek basic suggestion tool hai — final decision centre par baat karke hi lein. Fees listed hain, confirm karna zaroori hai.</p>';

      resEl.scrollIntoView({ behavior: OX_UI.reduceMotion() ? 'auto' : 'smooth', block: 'nearest' });
    }

    paint();
  }

  function boot() {
    renderGrid();
    initFilters();
    initAsk();
    initQuiz();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
