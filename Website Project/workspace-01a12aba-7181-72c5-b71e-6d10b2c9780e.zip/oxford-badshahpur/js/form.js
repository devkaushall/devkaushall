/* =========================================================================
   OXFORD INSTITUTE — BADSHAHPUR | form.js
   Enquiry form: real client-side validation, draft saving, and an HONEST
   submit path.

   • If OXFORD.CONFIG.formEndpoint is set  -> POST JSON to that endpoint and
     show a real success/error state.
   • If it is empty (default, demo state) -> the form does NOT pretend to
     send. It composes the filled enquiry and opens WhatsApp / the mail app,
     and says exactly that on screen.
   No fake "message sent" toast anywhere.
   ========================================================================= */
(function () {
  'use strict';
  const { $, $$, ico, esc } = OX_UI;
  const D = window.OXFORD;
  const C = D.CONFIG;
  const DRAFT = 'ox_enquiry_draft';

  const FIELDS = [
    { n: 'name',    req: true,  label: 'Naam' },
    { n: 'phone',   req: true,  label: 'Mobile number' },
    { n: 'email',   req: false, label: 'Email (optional)' },
    { n: 'course',  req: true,  label: 'Course' },
    { n: 'batch',   req: false, label: 'Preferred time' },
    { n: 'msg',     req: false, label: 'Message' }
  ];

  /* --------------------------- validation ------------------------------ */
  const V = {
    name(v) {
      if (!v.trim()) return 'Naam likhna zaroori hai.';
      if (v.trim().length < 2) return 'Naam thoda poora likhein.';
      if (!/^[\p{L}\s.'-]+$/u.test(v.trim())) return 'Naam mein sirf akshar likhein (number ya symbol nahi).';
      return '';
    },
    phone(v) {
      const d = v.replace(/[\s-]/g, '');
      if (!d) return 'Mobile number zaroori hai — batch aur fees isi par bataayenge.';
      if (!/^\+?\d[\d\s-]{7,15}$/.test(d)) return 'Sahi mobile number likhein (10 digit).';
      const digits = d.replace(/\D/g, '');
      if (digits.length < 10 || digits.length > 12) return 'Number 10 digit ka hona chahiye.';
      const last10 = digits.slice(-10);
      if (!/^[6-9]/.test(last10)) return 'Indian mobile number 6, 7, 8 ya 9 se shuru hota hai.';
      return '';
    },
    email(v) {
      if (!v.trim()) return '';
      if (!/^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/.test(v.trim())) return 'Email address sahi nahi lag raha.';
      return '';
    },
    course(v) { return v ? '' : 'Kaun sa course chahiye — select karein.'; },
    batch() { return ''; },
    msg(v) { return v.length > 900 ? 'Message thoda chhota rakhein (900 akshar tak).' : ''; }
  };

  function setErr(field, message) {
    const wrap = field.closest('.field');
    const err = wrap.querySelector('.err span') || wrap.querySelector('.err');
    wrap.classList.toggle('has-err', !!message);
    wrap.classList.toggle('ok', !message && field.value.trim() !== '');
    if (err) err.textContent = message || '';
    field.setAttribute('aria-invalid', message ? 'true' : 'false');
    const desc = wrap.querySelector('.err');
    if (desc) {
      const id = 'err-' + field.name;
      desc.id = id;
      field.setAttribute('aria-describedby', message ? id : (field.dataset.hintId || ''));
    }
  }

  function validateField(field, silent) {
    const fn = V[field.name];
    if (!fn) return true;
    const msg = fn(field.value);
    if (!silent) setErr(field, msg);
    return !msg;
  }

  /* ----------------------------- render -------------------------------- */
  function render() {
    const form = $('[data-enquiry-form]');
    if (!form) return;

    /* course options straight from the real course list */
    const sel = form.querySelector('[name="course"]');
    if (sel) {
      const groups = {};
      D.COURSES.forEach(c => { (groups[c.catLabel] = groups[c.catLabel] || []).push(c); });
      sel.innerHTML = '<option value="">— Course chunein —</option>' +
        Object.keys(groups).map(g =>
          '<optgroup label="' + esc(g) + '">' +
          groups[g].map(c => '<option value="' + c.id + '">' + esc(c.title) + (c.fee ? ' · ₹' + c.fee.toLocaleString('en-IN') : '') + '</option>').join('') +
          '</optgroup>'
        ).join('') +
        '<optgroup label="Pakka nahi?">' +
          '<option value="not-sure">Pakka nahi — guide karein</option>' +
          D.ASK_COURSES.map(a => '<option value="ask-' + a.id + '">' + esc(a.title) + ' (availability poochni hai)</option>').join('') +
        '</optgroup>';
    }

    /* prefill: ?course=  then last viewed course */
    const qs = new URLSearchParams(location.search).get('course');
    const remembered = (() => { try { return localStorage.getItem('ox_last_course'); } catch (e) { return null; } })();
    const wanted = qs || remembered;
    if (wanted && sel) {
      const hit = Array.prototype.some.call(sel.options, o => o.value === wanted);
      if (hit) { sel.value = wanted; sel.closest('.field').classList.add('ok'); }
    }
    if (qs) {
      const c = D.courseById(qs);
      const note = $('[data-form-note]');
      if (c && note) {
        note.hidden = false; note.style.display = 'flex';
        note.innerHTML = ico('info') + '<span><b>' + esc(c.title) + '</b> select ho gaya hai. Fees aur batch timing WhatsApp par turant mil jaayegi — <a href="' + D.waLink('Namaste! Mujhe "' + c.title + '" course ki fees aur batch timings chahiye.') + '" target="_blank" rel="noopener">yahan click karein</a>.</span>';
      }
    }

    /* restore draft */
    try {
      const draft = JSON.parse(localStorage.getItem(DRAFT) || '{}');
      Object.keys(draft).forEach(k => {
        const f = form.querySelector('[name="' + k + '"]');
        if (f && !f.value && k !== 'consent') f.value = draft[k];
      });
      if (Object.keys(draft).length) {
        const s = $('[data-draft-note]');
        if (s) { s.hidden = false; }
      }
    } catch (e) {}

    /* live validation */
    FIELDS.forEach(f => {
      const field = form.querySelector('[name="' + f.n + '"]');
      if (!field) return;
      field.addEventListener('blur', () => { if (field.value.trim()) validateField(field); });
      field.addEventListener('input', OX_UI.debounce(() => {
        if (field.closest('.field').classList.contains('has-err')) validateField(field);
        saveDraft();
      }, 260));
      field.addEventListener('change', saveDraft);
    });

    const consent = form.querySelector('[name="consent"]');
    if (consent) consent.addEventListener('change', () => {
      const wrap = consent.closest('.field');
      if (consent.checked) { wrap.classList.remove('has-err'); consent.setAttribute('aria-invalid', 'false'); }
    });

    form.addEventListener('submit', e => { e.preventDefault(); onSubmit(form); });
    form.addEventListener('reset', () => {
      try { localStorage.removeItem(DRAFT); } catch (err) {}
      $$('.field', form).forEach(w => w.classList.remove('has-err', 'ok'));
      status(form, '', '');
      const dn = $('[data-draft-note]'); if (dn) dn.hidden = true;
    });
  }

  function saveDraft() {
    const form = $('[data-enquiry-form]');
    if (!form) return;
    const o = {};
    FIELDS.forEach(f => {
      const el = form.querySelector('[name="' + f.n + '"]');
      if (el && el.value) o[f.n] = el.value;
    });
    try { localStorage.setItem(DRAFT, JSON.stringify(o)); } catch (e) {}
  }

  function status(form, kind, html) {
    const s = $('[data-form-status]');
    if (!s) return;
    s.className = 'form__status' + (kind ? ' on form__status--' + kind : '');
    s.innerHTML = html || '';
    s.setAttribute('role', kind === 'err' ? 'alert' : 'status');
  }

  function courseLabel(id) {
    const c = D.courseById(id);
    if (c) return c.title;
    if (id === 'not-sure') return 'Pakka nahi — guide karein';
    const a = D.ASK_COURSES.find(x => 'ask-' + x.id === id);
    if (a) return a.title + ' (availability poochni hai)';
    return id;
  }

  function compose(data) {
    const L = [];
    L.push('Namaste Oxford Institute Badshahpur,');
    L.push('');
    L.push('Naam: ' + data.name);
    L.push('Mobile: ' + data.phone);
    if (data.email) L.push('Email: ' + data.email);
    L.push('Course: ' + courseLabel(data.course));
    if (data.batch) L.push('Preferred time: ' + data.batch);
    if (data.msg) { L.push(''); L.push('Message: ' + data.msg); }
    L.push('');
    L.push('(Ye enquiry website ke enquiry form se bheji gayi hai.)');
    return L.join('\n');
  }

  function onSubmit(form) {
    /* 1. validate everything */
    let bad = null;
    FIELDS.forEach(f => {
      const field = form.querySelector('[name="' + f.n + '"]');
      if (!field) return;
      const ok = validateField(field);
      if (!ok && !bad) bad = field;
    });
    const consent = form.querySelector('[name="consent"]');
    if (consent && !consent.checked) {
      consent.closest('.field').classList.add('has-err');
      consent.setAttribute('aria-invalid', 'true');
      const e = consent.closest('.field').querySelector('.err span');
      if (e) e.textContent = 'Aage badhne ke liye ye chunna zaroori hai.';
      if (!bad) bad = consent;
    }

    if (bad) {
      status(form, 'err', ico('alert') + '<span>Kuch details adhoori hain — neeche laal rang mein dikha diya gaya hai. Sahi karke dobara bhejein.</span>');
      bad.focus();
      bad.scrollIntoView({ behavior: OX_UI.reduceMotion() ? 'auto' : 'smooth', block: 'center' });
      return;
    }

    const data = {};
    FIELDS.forEach(f => { const el = form.querySelector('[name="' + f.n + '"]'); data[f.n] = el ? el.value.trim() : ''; });
    const body = compose(data);

    /* 2. real endpoint, if configured */
    if (C.formEndpoint) {
      const btn = form.querySelector('[type="submit"]');
      btn.disabled = true;
      const old = btn.innerHTML;
      btn.innerHTML = 'Bhej rahe hain…';
      status(form, 'info', ico('clock') + '<span>Enquiry bhej rahe hain…</span>');
      fetch(C.formEndpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ source: 'website-enquiry', branch: 'Badshahpur', at: new Date().toISOString(), data: data })
      }).then(r => {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        try { localStorage.removeItem(DRAFT); } catch (e) {}
        status(form, 'ok', ico('checkC') + '<span><b>Enquiry chali gayi.</b> Institute ki team aapko ' + esc(data.phone) + ' par contact karegi. Turant jawab chahiye to <a href="tel:+91' + C.contact.phoneRaw.slice(2) + '">' + C.contact.phoneDisplay + '</a> par call karein.</span>');
        form.reset();
      }).catch(err => {
        status(form, 'err', ico('alert') + '<span>Enquiry send nahi ho payi (' + esc(err.message) + '). Direct <a href="' + D.waLink(body) + '" target="_blank" rel="noopener">WhatsApp</a> ya <a href="tel:+91' + C.contact.phoneRaw.slice(2) + '">call</a> kar lein.</span>');
      }).then(() => { btn.disabled = false; btn.innerHTML = old; });
      return;
    }

    /* 3. demo path — open WhatsApp with the exact text, and say so honestly */
    const wa = D.waLink(body);
    const mail = 'mailto:' + C.contact.email +
      '?subject=' + encodeURIComponent('Course enquiry — ' + courseLabel(data.course) + ' (' + data.name + ')') +
      '&body=' + encodeURIComponent(body);

    status(form, 'info',
      ico('whatsapp') +
      '<span><b>Details tayyar hain.</b> Ye demo website hai, isliye enquiry seedha server par nahi jaati — neeche button se aapka poora message WhatsApp ya email mein khul jaayega, bas send dabana hai.' +
      '<span class="row" style="margin-top:12px">' +
        '<a class="btn btn--sm" style="--bg:#1FA855;--fg:#fff" href="' + wa + '" target="_blank" rel="noopener">' + ico('whatsapp') + 'WhatsApp mein kholein</a>' +
        '<a class="btn btn--sm btn--ghost" href="' + mail + '">' + ico('mail') + 'Email mein kholein</a>' +
        '<button class="btn btn--sm btn--ghost" type="button" data-copy>Bhi copy karein</button>' +
      '</span>' +
      '<span style="display:block;margin-top:10px;font-size:.82rem;opacity:.8">Live site par ye form seedha institute ke inbox / WhatsApp Business API par jaayega.</span></span>'
    );

    const copyBtn = $('[data-copy]');
    if (copyBtn) copyBtn.addEventListener('click', () => {
      const done = () => { copyBtn.textContent = 'Copy ho gaya ✓'; setTimeout(() => { copyBtn.innerHTML = 'Message copy karein'; }, 2200); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(body).then(done, done);
      else {
        const ta = document.createElement('textarea');
        ta.value = body; document.body.appendChild(ta); ta.select();
        try { document.execCommand('copy'); } catch (e) {}
        ta.remove(); done();
      }
    });

    /* keep the draft until they actually send it elsewhere */
    const first = $('[data-form-status] a');
    if (first) first.focus({ preventScroll: true });
  }

  function boot() { render(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
