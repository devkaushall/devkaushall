/* =========================================================================
   OXFORD INSTITUTE — icons + tiny DOM helpers (no dependencies)
   All icons are hand-drawn 24x24 stroke SVG, currentColor.
   ========================================================================= */
window.OX_UI = (function () {
  'use strict';

  const P = { fill: 'none', stroke: 'currentColor', 'stroke-width': '1.9', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' };

  const PATHS = {
    /* brand monogram: O + ascending step (learning that goes up) */
    logo: {
      viewBox: '0 0 24 24', raw:
        '<circle cx="12" cy="12" r="8.6" fill="none" stroke="#E9A96A" stroke-width="2"/>' +
        '<path d="M7.4 14.4l3.1-3.3 2.4 2.2 3.7-4.4" fill="none" stroke="#F6F1E6" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"/>' +
        '<path d="M14.1 8.9h2.6v2.6" fill="none" stroke="#F6F1E6" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"/>'
    },
    /* navigation + ui */
    arrowR: '<path d="M4 12h15"/><path d="m13 6 6 6-6 6"/>',
    arrowU: '<path d="M12 20V5"/><path d="m6 11 6-6 6 6"/>',
    arrowDR: '<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>',
    chevD: '<path d="m6 9 6 6 6-6"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/>',
    check: '<path d="m4.5 12.5 5 5 10-11"/>',
    checkC: '<circle cx="12" cy="12" r="9"/><path d="m8 12.4 2.7 2.7L16.2 9"/>',
    alert: '<path d="M12 3.6 2.6 20h18.8L12 3.6Z"/><path d="M12 10v4.2"/><circle cx="12" cy="17.4" r=".9" fill="currentColor" stroke="none"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5.4"/><circle cx="12" cy="7.9" r=".95" fill="currentColor" stroke="none"/>',
    star: '<path d="m12 3.4 2.7 5.6 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1L3.2 9.9l6.1-.9L12 3.4Z"/>',
    spark: '<path d="M12 3v4.2M12 16.8V21M3 12h4.2M16.8 12H21M6.2 6.2l2.9 2.9M14.9 14.9l2.9 2.9M17.8 6.2l-2.9 2.9M9.1 14.9l-2.9 2.9"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    sliders: '<path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2.1"/><circle cx="10" cy="17" r="2.1"/>',
    scale: '<path d="M12 4v16M7 8h10"/><path d="M4.5 15.5 7 8l2.5 7.5a2.6 2.6 0 0 1-5 0Z"/><path d="M14.5 15.5 17 8l2.5 7.5a2.6 2.6 0 0 1-5 0Z"/>',
    target: '<circle cx="12" cy="12" r="8.4"/><circle cx="12" cy="12" r="4.4"/><circle cx="12" cy="12" r="1" fill="currentColor" stroke="none"/>',
    route: '<circle cx="6" cy="18" r="2.6"/><circle cx="18" cy="6" r="2.6"/><path d="M15.4 6H10a4 4 0 0 0 0 8h4a4 4 0 0 1 0 8H8.6"/>',
    quote: '<path d="M9.6 6.4C6.7 7.6 5 10 5 13.1c0 2.6 1.5 4.4 3.6 4.4 1.9 0 3.3-1.4 3.3-3.2 0-1.8-1.3-3.1-3-3.1-.3 0-.6 0-.9.1.3-1.6 1.5-3 3.2-3.8l-1.6-1.1Z"/><path d="M19.1 6.4c-2.9 1.2-4.6 3.6-4.6 6.7 0 2.6 1.5 4.4 3.6 4.4 1.9 0 3.3-1.4 3.3-3.2 0-1.8-1.3-3.1-3-3.1-.3 0-.6 0-.9.1.3-1.6 1.5-3 3.2-3.8l-1.6-1.1Z"/>',

    /* contact */
    phone: '<path d="M6.4 3.5h3l1.5 3.8-2 1.4a12.5 12.5 0 0 0 5.4 5.4l1.4-2 3.8 1.5v3a2 2 0 0 1-2.2 2A16.6 16.6 0 0 1 4.4 5.7a2 2 0 0 1 2-2.2Z"/>',
    mail: '<rect x="3" y="5.2" width="18" height="13.6" rx="2.4"/><path d="m3.8 7 7.1 5.2a2 2 0 0 0 2.2 0L20.2 7"/>',
    pin: '<path d="M12 21.2s7-5.5 7-11a7 7 0 1 0-14 0c0 5.5 7 11 7 11Z"/><circle cx="12" cy="10" r="2.7"/>',
    clock: '<circle cx="12" cy="12" r="8.6"/><path d="M12 7.2V12l3.2 2"/>',
    whatsapp: '<path d="M3.4 20.6 4.8 16A8.4 8.4 0 1 1 8 19.2l-4.6 1.4Z"/><path d="M9 8.4c.3-.7.6-.7 1-.7h.7c.2 0 .5 0 .7.6l.8 1.9c.1.3 0 .5-.1.7l-.5.6c-.2.2-.2.4 0 .7a6.6 6.6 0 0 0 3 2.6c.3.1.5.1.7-.1l.6-.7c.2-.2.4-.2.6-.1l1.8.9c.3.1.4.3.4.5v.7c0 .5-.5 1.4-1.6 1.6-1 .2-2.4-.1-4.6-1.4a10.4 10.4 0 0 1-3.8-3.9c-.6-1.2-.8-2.3-.7-3.1.1-.7.6-1.4 1-1.5Z"/>',
    share: '<circle cx="18" cy="5.4" r="2.6"/><circle cx="6" cy="12" r="2.6"/><circle cx="18" cy="18.6" r="2.6"/><path d="m8.3 10.8 7.4-4M8.3 13.2l7.4 4"/>',

    /* social */
    facebook: '<path d="M14.6 8.4h2.2V5.3h-2.5c-2.2 0-3.6 1.5-3.6 3.7v1.6H8.5v3.1h2.2v7h3.2v-7h2.3l.4-3.1h-2.7V9.4c0-.7.3-1 .7-1Z"/>',
    instagram: '<rect x="3.4" y="3.4" width="17.2" height="17.2" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17" cy="7" r="1.1" fill="currentColor" stroke="none"/>',
    youtube: '<rect x="2.6" y="5.4" width="18.8" height="13.2" rx="4"/><path d="m10.3 9.4 5 2.6-5 2.6V9.4Z"/>',
    linkedin: '<rect x="3.4" y="3.4" width="17.2" height="17.2" rx="4"/><path d="M7.6 10.4v6.4M7.6 7.4v.1"/><path d="M11.6 16.8v-6.4M11.6 13.1c0-1.5.9-2.4 2.2-2.4s2.2.9 2.2 2.5v3.6"/>',

    /* course glyphs */
    gLang: '<path d="M4 6.4h7.4M7.7 4.4v2"/><path d="M9.4 6.4c0 3.2-2.3 5.7-5.2 6.6"/><path d="M5.6 10.3c1 2 2.8 3.4 5 3.9"/><path d="m12.6 20 3.7-9 3.7 9"/><path d="M14 17h4.6"/>',
    gOffice: '<rect x="3.2" y="4.6" width="17.6" height="12.6" rx="2.2"/><path d="M3.2 8.6h17.6"/><path d="M9.4 8.6v8.6"/><path d="M6.6 19.4h10.8"/>',
    gSheet: '<rect x="3.4" y="4.4" width="17.2" height="15.2" rx="2.2"/><path d="M3.4 9.4h17.2M3.4 14.6h17.2M9.6 9.4v10.2M15 9.4v10.2"/><path d="M3.4 4.4h17.2"/>',
    gTally: '<path d="M5.6 4.6h12.8a1.8 1.8 0 0 1 1.8 1.8v11.2a1.8 1.8 0 0 1-1.8 1.8H5.6a1.8 1.8 0 0 1-1.8-1.8V6.4a1.8 1.8 0 0 1 1.8-1.8Z"/><path d="M3.8 9.6h16.4"/><path d="M8 13.4h3.2M8 16.4h5.6"/><circle cx="16.4" cy="14.9" r="1.7"/>',
    gDesign: '<path d="M12 3.2a8.8 8.8 0 0 0 0 17.6c1.4 0 2-.9 2-1.8 0-1.4-1.2-1.8-1.2-2.9 0-.8.7-1.5 1.7-1.5h1.6A4.7 4.7 0 0 0 20.8 10c0-3.8-3.9-6.8-8.8-6.8Z"/><circle cx="7.8" cy="10.4" r="1.1" fill="currentColor" stroke="none"/><circle cx="11.4" cy="7.4" r="1.1" fill="currentColor" stroke="none"/><circle cx="15.6" cy="8.6" r="1.1" fill="currentColor" stroke="none"/>',
    gCode: '<path d="m8.4 8.4-4 3.6 4 3.6"/><path d="m15.6 8.4 4 3.6-4 3.6"/><path d="m13.4 5.6-2.8 12.8"/>',
    gWeb: '<circle cx="12" cy="12" r="8.6"/><path d="M3.4 12h17.2"/><path d="M12 3.4a13 13 0 0 1 0 17.2 13 13 0 0 1 0-17.2Z"/>',
    gPython: '<path d="M12 3.6c-3 0-4.4 1.2-4.4 3v2h4.6v.9H6.2c-1.9 0-3 1.4-3 3.5s1.1 3.6 3 3.6h1.2v-2.4c0-1.8 1.4-3 3.2-3h3.6c1.6 0 2.8-1.1 2.8-2.6V6.6c0-1.8-1.6-3-5-3Z"/><circle cx="9.7" cy="6.3" r=".9" fill="currentColor" stroke="none"/><path d="M12 20.4c3 0 4.4-1.2 4.4-3v-2h-4.6v-.9h6c1.9 0 3-1.4 3-3.5s-1.1-3.6-3-3.6h-1.2v2.4c0 1.8-1.4 3-3.2 3H9.8c-1.6 0-2.8 1.1-2.8 2.6v3c0 1.8 1.6 3 5 3Z"/><circle cx="14.3" cy="17.7" r=".9" fill="currentColor" stroke="none"/>',
    gJava: '<path d="M9.4 4.6c2.6 1.4 3.6 3.2 2.4 4.8-1 1.4-2.6 1.8-2.6 3 0 .8.7 1.5 1.8 1.9"/><path d="M14.2 4.2c1.8 1.8 2.4 3.8 1.4 5.6"/><path d="M6.6 15.4c-1.6.8-2.2 1.8-1.4 2.8 1.2 1.5 4 2.2 6.8 2.2s5.6-.7 6.8-2.2c.8-1 .2-2-1.4-2.8"/><path d="M7.6 12.6c-1.2.4-1.8 1-1.6 1.8"/><path d="M16.4 12.6c1.2.4 1.8 1 1.6 1.8"/>',
    gExcel: '<rect x="3.4" y="4.4" width="17.2" height="15.2" rx="2.2"/><path d="m8.4 9.4 4.4 5.4M12.8 9.4l-4.4 5.4"/><path d="M16 9.4v5.4"/>',
    gUsers: '<circle cx="9.4" cy="8.4" r="3.4"/><path d="M3.4 19.4c0-3.1 2.7-5.2 6-5.2s6 2.1 6 5.2"/><path d="M16.2 6.4a3.2 3.2 0 0 1 0 6.2"/><path d="M17.4 14.6c2 .6 3.2 2.1 3.2 4.2"/>',
    gCap: '<path d="m12 4.4 9 4.2-9 4.2-9-4.2 9-4.2Z"/><path d="M6.6 10.6v4.6c0 1.6 2.4 2.8 5.4 2.8s5.4-1.2 5.4-2.8v-4.6"/><path d="M20.4 8.8v5"/>',
    gBadge: '<circle cx="12" cy="9.6" r="5.6"/><path d="m8.4 14.4-1.4 6 5-2.6 5 2.6-1.4-6"/>',
    gRupee: '<path d="M7.4 5.4h9M7.4 9.4h9M14.6 5.4c0 2.8-1.9 4-4.6 4h-.6l6.4 9.2"/>',
    gBook: '<path d="M4.4 5.2c2.6-1 5-1 7.6.6 2.6-1.6 5-1.6 7.6-.6v13c-2.6-1-5-1-7.6.6-2.6-1.6-5-1.6-7.6-.6v-13Z"/><path d="M12 5.8v13"/>',
    gClock: '<circle cx="12" cy="12" r="8.6"/><path d="M12 7.2V12l3.2 2"/>',
    gBolt: '<path d="M13.4 3.4 5.6 13.6h5.2l-.8 7 7.8-10.2h-5.2l.8-7Z"/>',
    gShield: '<path d="M12 3.4 4.6 6.2v5.4c0 4.4 3 7.6 7.4 9 4.4-1.4 7.4-4.6 7.4-9V6.2L12 3.4Z"/><path d="m8.8 12 2.2 2.2 4.2-4.4"/>',
    gMap: '<path d="m3.4 6.6 5.8-2.2 5.6 2.2 5.8-2.2v13l-5.8 2.2-5.6-2.2-5.8 2.2v-13Z"/><path d="M9.2 4.4v13M14.8 6.6v13"/>',
    gFilter: '<path d="M4 6.4h16M7 12h10M10 17.6h4"/>',
    gLayers: '<path d="m12 3.4 8.6 4.4L12 12.2 3.4 7.8 12 3.4Z"/><path d="m3.4 12.2 8.6 4.4 8.6-4.4"/><path d="m3.4 16.4 8.6 4.4 8.6-4.4"/>',
    gLight: '<path d="M9.4 17.4h5.2"/><path d="M10 20.4h4"/><path d="M12 3.4a5.8 5.8 0 0 0-3.4 10.5c.6.5.9 1 .9 1.7h5c0-.7.3-1.2.9-1.7A5.8 5.8 0 0 0 12 3.4Z"/>'
  };

  const GLYPH = {
    'spoken-english': 'gLang', 'basic-computer': 'gOffice', 'tally-gst': 'gTally',
    'advanced-excel': 'gExcel', 'dtp': 'gDesign', 'web-designing': 'gWeb',
    'c-language': 'gCode', 'cpp': 'gCode', 'python': 'gPython',
    'core-java': 'gJava', 'php': 'gCode'
  };

  /* Build an <svg> element */
  function svg(name, opts) {
    const o = opts || {};
    const p = PATHS[name];
    if (!p) return null;
    const cls = o.cls ? ' class="' + o.cls + '"' : '';
    const size = o.size ? ' width="' + o.size + '" height="' + o.size + '"' : '';
    const aria = o.label ? ' role="img" aria-label="' + o.label + '"' : ' aria-hidden="true"';
    let inner;
    if (p.raw) {
      inner = p.raw;
    } else {
      const attrs = Object.keys(P).map(k => k + '="' + P[k] + '"').join(' ');
      inner = '<g ' + attrs + '>' + p + '</g>';
    }
    const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    s.setAttribute('viewBox', p.viewBox || '0 0 24 24');
    s.setAttribute('fill', 'none');
    s.innerHTML = inner;
    // re-create with attributes via outerHTML trick for reliability
    const holder = document.createElement('div');
    holder.innerHTML = '<svg viewBox="' + (p.viewBox || '0 0 24 24') + '" fill="none"' + cls + size + aria + '>' + inner + '</svg>';
    return holder.firstElementChild;
  }

  /* HTML string version, for template building */
  function ico(name, cls, label) {
    const p = PATHS[name]; if (!p) return '';
    const aria = label ? ' role="img" aria-label="' + label + '"' : ' aria-hidden="true"';
    const inner = p.raw ? p.raw
      : '<g fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">' + p + '</g>';
    return '<svg viewBox="' + (p.viewBox || '0 0 24 24') + '" fill="none"' + (cls ? ' class="' + cls + '"' : '') + aria + '>' + inner + '</svg>';
  }

  function glyphFor(courseId) { return GLYPH[courseId] || 'gBook'; }

  /* DOM helpers */
  const $  = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.prototype.slice.call((r || document).querySelectorAll(s));
  function el(tag, attrs, html) {
    const n = document.createElement(tag);
    if (attrs) Object.keys(attrs).forEach(k => { if (attrs[k] != null) n.setAttribute(k, attrs[k]); });
    if (html != null) n.innerHTML = html;
    return n;
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, c =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }
  function debounce(fn, ms) { let t; return function () { const a = arguments, c = this; clearTimeout(t); t = setTimeout(() => fn.apply(c, a), ms || 120); }; }
  function reduceMotion() { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; }

  return { svg, ico, glyphFor, $, $$, el, esc, debounce, reduceMotion, GLYPH };
})();
