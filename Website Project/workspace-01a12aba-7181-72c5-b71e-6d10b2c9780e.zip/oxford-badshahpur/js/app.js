/* =========================================================================
   OXFORD INSTITUTE — BADSHAHPUR | app.js
   Shared UI engine: header, drawer, footer, scroll FX, reveals, command
   palette, course modal, compare tray, live open/closed clock, floating
   actions.  Zero dependencies, no build step.
   ========================================================================= */
(function () {
  'use strict';
  const { $, $$, ico, esc, debounce, reduceMotion } = OX_UI;
  const D = window.OXFORD;
  const C = D.CONFIG;

  /* =====================================================================
     0.  PAGE REGISTRY
     ================================================================== */
  const PAGES = [
    { href: 'index.html',   label: 'Home' },
    { href: 'courses.html', label: 'Courses' },
    { href: 'about.html',   label: 'About' },
    { href: 'faq.html',     label: 'FAQ' },
    { href: 'contact.html', label: 'Contact' }
  ];

  function pageKey() {
    const p = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
    return p === '' ? 'index.html' : p;
  }

  /* =====================================================================
     1.  HEADER
     ================================================================== */
  function buildHeader() {
    const here = pageKey();
    const nav = PAGES.map((p, i) =>
      '<a href="' + p.href + '"' + (p.href === here ? ' aria-current="page"' : '') + '>' + esc(p.label) + '</a>'
    ).join('');

    const head = document.createElement('header');
    head.className = 'head';
    head.setAttribute('data-header', '');
    head.innerHTML =
      '<div class="wrap head__in">' +
        '<a class="brand" href="index.html" aria-label="Oxford Institute Badshahpur — home">' +
          '<span class="brand__mark">' + ico('logo') + '</span>' +
          '<span class="brand__txt">' +
            '<span class="brand__name">Oxford</span>' +
            '<span class="brand__sub">Badshahpur</span>' +
          '</span>' +
        '</a>' +
        '<nav class="nav" aria-label="Main navigation">' + nav + '</nav>' +
        '<div class="head__cta">' +
          '<button class="searchbtn" type="button" data-cmdk aria-label="Search courses and pages">' +
            ico('search') + '<span>Search</span><kbd>⌘K</kbd>' +
          '</button>' +
          '<a class="btn btn--copper btn--sm" href="' + D.waLink('Namaste! Mujhe Oxford Institute Badshahpur ke courses ke baare mein jaankari chahiye.') + '" target="_blank" rel="noopener">' +
            ico('whatsapp') + '<span>WhatsApp</span>' +
          '</a>' +
        '</div>' +
        '<button class="burger" type="button" data-burger aria-label="Open menu" aria-expanded="false" aria-controls="drawer">' +
          '<i></i>' +
        '</button>' +
      '</div>';
    document.body.prepend(head);

    /* drawer */
    const drawer = document.createElement('div');
    drawer.className = 'drawer';
    drawer.id = 'drawer';
    drawer.setAttribute('aria-hidden', 'true');
    drawer.innerHTML =
      '<nav class="drawer__links" aria-label="Mobile navigation">' +
        PAGES.map((p, i) =>
          '<a href="' + p.href + '"' + (p.href === here ? ' aria-current="page"' : '') +
          ' style="transition-delay:' + (60 + i * 45) + 'ms"><span>0' + (i + 1) + '</span>' + esc(p.label) + '</a>'
        ).join('') +
      '</nav>' +
      '<div class="drawer__foot">' +
        '<div class="mono">Direct baat karein</div>' +
        '<div class="row">' +
          '<a class="btn btn--copper btn--sm" href="tel:+91' + C.contact.phoneRaw.slice(2) + '">' + ico('phone') + C.contact.phoneDisplay + '</a>' +
          '<a class="btn btn--light btn--sm" href="' + D.waLink('Namaste! Course ke baare mein baat karni hai.') + '" target="_blank" rel="noopener">' + ico('whatsapp') + 'WhatsApp</a>' +
        '</div>' +
        '<p style="font-size:.86rem;color:rgba(246,241,230,.65);margin-top:6px">' + esc(C.contact.addressShort) + '</p>' +
      '</div>';
    document.body.appendChild(drawer);

    /* burger toggle */
    const burger = $('[data-burger]');
    burger.addEventListener('click', () => toggleNav());
    drawer.addEventListener('click', e => { if (e.target.tagName === 'A') toggleNav(false); });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && document.body.classList.contains('nav-open')) toggleNav(false);
    });
    window.addEventListener('resize', debounce(() => {
      if (window.innerWidth > 900 && document.body.classList.contains('nav-open')) toggleNav(false);
    }, 140));

    /* scroll behaviour: sticky bg + hide on scroll down */
    let last = window.scrollY;
    const onScroll = () => {
      const y = window.scrollY;
      head.classList.toggle('is-stuck', y > 12);
      if (y > 420 && y > last + 6 && !document.body.classList.contains('nav-open')) head.classList.add('is-hidden');
      else if (y < last - 4 || y < 200) head.classList.remove('is-hidden');
      last = y;
      const bar = $('.progress i');
      if (bar) {
        const h = document.documentElement.scrollHeight - window.innerHeight;
        bar.style.transform = 'scaleX(' + (h > 0 ? Math.min(1, y / h) : 0) + ')';
      }
      const tt = $('.totop'); if (tt) tt.classList.toggle('on', y > 700);
      const mb = $('.mbar');  if (mb) mb.classList.toggle('on', y > 340);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  function toggleNav(force) {
    const open = force == null ? !document.body.classList.contains('nav-open') : !!force;
    document.body.classList.toggle('nav-open', open);
    const b = $('[data-burger]'), d = $('#drawer');
    if (b) { b.setAttribute('aria-expanded', String(open)); b.setAttribute('aria-label', open ? 'Close menu' : 'Open menu'); }
    if (d) d.setAttribute('aria-hidden', String(!open));
    document.body.style.overflow = open ? 'hidden' : '';
    if (open) { const f = $('#drawer a'); if (f) setTimeout(() => f.focus(), 260); }
  }

  /* =====================================================================
     2.  FOOTER
     ================================================================== */
  function buildFooter() {
    const f = document.createElement('footer');
    f.className = 'foot';
    const courseLinks = D.COURSES.slice(0, 7).map(c =>
      '<li><a href="courses.html#' + c.id + '" data-open-course="' + c.id + '">' + esc(c.title) + '</a></li>'
    ).join('');

    f.innerHTML =
      '<div class="wrap">' +
        '<div class="notice">' +
          '<b>Demo website — client pitch ke liye banaya gaya.</b> Courses, fees aur timings institute ki public listings aur unki previous website (archived) se liye gaye hain, isliye final confirm centre par hi karein. Placement ya result ka koi claim is site par nahi kiya gaya hai.' +
        '</div>' +
        '<div class="foot__top">' +
          '<div>' +
            '<div class="foot__brand">' +
              '<span class="brand__mark">' + ico('logo') + '</span>' +
              '<span class="brand__txt"><span class="brand__name">Oxford</span><span class="brand__sub">Badshahpur</span></span>' +
            '</div>' +
            '<p>' + esc(C.brand.full) + ' — Spoken English aur computer courses, ' + C.brand.since + ' se Badshahpur, Gurugram mein.</p>' +
            '<div class="foot__social">' +
              C.social.map(s =>
                '<a href="' + s.url + '" target="_blank" rel="noopener" aria-label="' + s.label + '">' + ico(s.id) + '</a>'
              ).join('') +
            '</div>' +
          '</div>' +
          '<div><h4>Pages</h4><ul>' +
            PAGES.map(p => '<li><a href="' + p.href + '">' + esc(p.label) + '</a></li>').join('') +
            '<li><a href="index.html#recommender">Course finder</a></li>' +
          '</ul></div>' +
          '<div><h4>Courses</h4><ul>' + courseLinks +
            '<li><a href="courses.html">Saare courses →</a></li>' +
          '</ul></div>' +
          '<div><h4>Contact</h4><ul>' +
            '<li><a href="tel:+91' + C.contact.phoneRaw.slice(2) + '">' + C.contact.phoneDisplay + '</a></li>' +
            '<li><a href="tel:+91' + C.contact.phone2Raw.slice(2) + '">' + C.contact.phone2Display + '</a></li>' +
            '<li><a href="mailto:' + C.contact.email + '">' + C.contact.email + '</a></li>' +
            '<li><a href="' + mapsUrl() + '" target="_blank" rel="noopener">Directions (Google Maps)</a></li>' +
          '</ul>' +
          '<p style="margin-top:14px;font-size:.85rem">' + esc(C.contact.address) + '</p>' +
          '<p style="margin-top:10px;font-size:.85rem"><span data-clock>Timings check ho rahi hain…</span></p>' +
          '</div>' +
        '</div>' +
        '<div class="foot__bottom">' +
          '<span>© ' + new Date().getFullYear() + ' ' + esc(C.brand.full) + ' · Badshahpur, Gurugram ' + C.brand.pin + '</span>' +
          '<span>Concept &amp; design demo · Not the live institute website</span>' +
        '</div>' +
      '</div>';
    document.body.appendChild(f);
    paintClocks();
  }

  function mapsUrl() { return 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(C.contact.mapsQuery); }

  /* =====================================================================
     3.  FLOATING ACTIONS
     ================================================================== */
  function buildFloating() {
    const fab = document.createElement('div');
    fab.className = 'fab';
    fab.innerHTML =
      '<button class="totop" type="button" data-totop aria-label="Back to top">' + ico('arrowU') + '</button>' +
      '<a class="fab__btn" href="' + D.waLink('Namaste! Main Oxford Institute Badshahpur ki website se aa raha/rahi hoon. Course ke baare mein jaankari chahiye.') + '" target="_blank" rel="noopener" aria-label="WhatsApp par baat karein">' +
        ico('whatsapp') + '<span>WhatsApp par poochein</span>' +
      '</a>';
    document.body.appendChild(fab);
    $('[data-totop]').addEventListener('click', () =>
      window.scrollTo({ top: 0, behavior: reduceMotion() ? 'auto' : 'smooth' }));

    const bar = document.createElement('div');
    bar.className = 'mbar';
    bar.innerHTML =
      '<a class="btn btn--ghost btn--sm" href="tel:+91' + C.contact.phoneRaw.slice(2) + '">' + ico('phone') + 'Call</a>' +
      '<a class="btn btn--sm" style="--bg:#1FA855;--fg:#fff" href="' + D.waLink('Namaste! Course enquiry — Oxford Institute Badshahpur.') + '" target="_blank" rel="noopener">' + ico('whatsapp') + 'WhatsApp</a>' +
      '<a class="btn btn--copper btn--sm" href="contact.html">Enquiry</a>';
    document.body.appendChild(bar);
  }

  /* =====================================================================
     4.  OPEN / CLOSED CLOCK  (IST-aware, no library)
     ================================================================== */
  function istNow() {
    const s = new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata', hour12: false });
    const d = new Date(s.replace(' ', 'T'));
    if (isNaN(d)) return new Date();
    return d;
  }
  function paintClocks() {
    const now = istNow();
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const today = days[now.getDay()];
    const mins = now.getHours() * 60 + now.getMinutes();
    const row = C.contact.hours.find(h => h.d === today);
    let open = false, txt = '';
    if (row && row.o) {
      const [oh, om] = row.o.split(':').map(Number), [ch, cm] = row.c.split(':').map(Number);
      const o = oh * 60 + om, c = ch * 60 + cm;
      open = mins >= o && mins < c;
      txt = open
        ? 'Abhi khula hai · ' + fmt(row.o) + '–' + fmt(row.c) + ' IST'
        : (mins < o ? 'Abhi band · aaj ' + fmt(row.o) + ' baje khulega' : 'Aaj ke liye band · kal ' + fmt(row.o) + ' baje khulega');
    } else {
      txt = 'Aaj (Sunday) band · kal ' + fmt('07:00') + ' baje khulega';
    }
    $$('[data-clock]').forEach(n => {
      n.textContent = txt;
      n.title = C.contact.hoursNote;
    });
    $$('[data-open-pill]').forEach(n => {
      n.textContent = open ? 'Abhi khula hai' : 'Abhi band';
      n.classList.toggle('chip--live', open);
      n.title = txt + ' — ' + C.contact.hoursNote;
    });
    $$('[data-hours]').forEach(list => {
      list.innerHTML = C.contact.hours.map(h =>
        '<li' + (h.d === today ? ' class="today"' : '') + '><span>' + h.d + '</span><span>' +
        (h.o ? fmt(h.o) + ' – ' + fmt(h.c) : 'Band') + '</span></li>'
      ).join('');
    });
  }
  function fmt(hhmm) {
    const [h, m] = hhmm.split(':').map(Number);
    const ap = h >= 12 ? 'pm' : 'am';
    const hh = h % 12 === 0 ? 12 : h % 12;
    return hh + (m ? ':' + String(m).padStart(2, '0') : '') + ' ' + ap;
  }

  /* =====================================================================
     5.  SCROLL REVEALS
     ================================================================== */
  function initReveals() {
    const items = $$('[data-rv]');
    if (!items.length) return;
    if (reduceMotion() || !('IntersectionObserver' in window)) { items.forEach(n => n.classList.add('in')); return; }
    const io = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (!e.isIntersecting) return;
        const n = e.target;
        const delay = parseInt(n.dataset.rvDelay || '0', 10);
        setTimeout(() => n.classList.add('in'), delay);
        io.unobserve(n);
      });
    }, { threshold: 0.14, rootMargin: '0px 0px -8% 0px' });
    items.forEach(n => io.observe(n));
  }

  /* stagger children marked with data-stagger */
  function initStagger() {
    $$('[data-stagger]').forEach(group => {
      const kids = Array.prototype.slice.call(group.children);
      kids.forEach((k, i) => {
        if (k.dataset.rv == null) k.setAttribute('data-rv', '');
        k.dataset.rvDelay = String(i * 70);
      });
    });
    initReveals();
  }

  /* count-up */
  function initCounters() {
    const ns = $$('[data-count]');
    if (!ns.length) return;
    if (reduceMotion()) { ns.forEach(n => n.textContent = n.dataset.count); return; }
    const io = new IntersectionObserver(es => {
      es.forEach(e => {
        if (!e.isIntersecting) return;
        const n = e.target, target = parseFloat(n.dataset.count);
        const dur = 1100, t0 = performance.now();
        const dec = (n.dataset.dec | 0);
        (function step(t) {
          const p = Math.min(1, (t - t0) / dur);
          const e2 = 1 - Math.pow(1 - p, 3);
          n.textContent = (target * e2).toFixed(dec);
          if (p < 1) requestAnimationFrame(step); else n.textContent = target.toFixed(dec);
        })(t0);
        io.unobserve(n);
      });
    }, { threshold: .5 });
    ns.forEach(n => io.observe(n));
  }

  /* =====================================================================
     6.  MODAL SYSTEM  (course detail + compare)
     ================================================================== */
  let lastFocus = null;

  function openOverlay(node) {
    lastFocus = document.activeElement;
    document.body.appendChild(node);
    requestAnimationFrame(() => node.classList.add('on'));
    document.body.style.overflow = 'hidden';
    node.addEventListener('keydown', trap);
    const f = node.querySelector('[data-autofocus], a, button');
    if (f) setTimeout(() => f.focus(), 320);
    node.addEventListener('click', e => { if (e.target === node) closeOverlay(node); });
  }
  function closeOverlay(node) {
    node.classList.remove('on');
    node.removeEventListener('keydown', trap);
    document.body.style.overflow = '';
    setTimeout(() => node.remove(), 380);
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }
  function trap(e) {
    if (e.key !== 'Tab') { if (e.key === 'Escape') closeOverlay(e.currentTarget); return; }
    const f = $$('a[href], button:not([disabled]), input, select, textarea, [tabindex]:not([tabindex="-1"])', e.currentTarget)
      .filter(n => n.offsetParent !== null);
    if (!f.length) return;
    const first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }

  /* ---------- course detail modal ---------- */
  function courseModal(id) {
    const c = D.courseById(id);
    if (!c) return;
    rememberCourse(id);

    const feeTxt = c.fee ? '₹' + c.fee.toLocaleString('en-IN') : '—';
    const feeNote = c.feeVerify === 'listed' ? 'previous website se listed — confirm karein' : 'centre par confirm karein';

    const ov = OX_UI.el('div', { class: 'ovl', role: 'dialog', 'aria-modal': 'true', 'aria-label': c.title + ' course details' });
    ov.innerHTML =
      '<div class="modal">' +
        '<div class="modal__hd">' +
          '<div>' +
            '<div class="cc__cat" style="--ccc:var(--c-' + c.cat + ');">' + esc(c.catLabel) + '</div>' +
            '<h2 class="h-md" style="margin-top:6px">' + esc(c.title) + '</h2>' +
          '</div>' +
          '<button class="modal__x" type="button" data-close aria-label="Close">' + ico('close') + '</button>' +
        '</div>' +
        '<div class="modal__body">' +
          '<div class="mgrid">' +
            '<div class="mcell"><small>Duration</small><b>' + esc(c.duration) + '</b></div>' +
            '<div class="mcell"><small>Fee</small><b>' + feeTxt + (c.feeModule ? ' <span style="font-size:.8rem;font-weight:600;color:var(--ink-faint)">+ ' + esc(c.feeModule.label) + ' ₹' + c.feeModule.fee.toLocaleString('en-IN') + '</span>' : '') + '</b></div>' +
            '<div class="mcell"><small>Level</small><b>' + esc(c.level) + '</b></div>' +
            '<div class="mcell"><small>Mode</small><b>Classroom (offline)</b></div>' +
          '</div>' +
          '<div class="cc__note" style="margin-top:-6px">' + ico('info') + ' <span>' + esc(feeNote) + '. Sahi current fee, batch timing aur seat ke liye <a href="tel:+91' + C.contact.phoneRaw.slice(2) + '" style="font-weight:800">' + C.contact.phoneDisplay + '</a> par call karein.</span></div>' +
          '<div><h3 class="h-sm">Ye course kiske liye sahi hai</h3>' +
            '<ul class="mlist" style="margin-top:11px">' +
              c.goodFor.map(g => '<li>' + ico('check') + '<span>' + esc(g) + '</span></li>').join('') +
            '</ul></div>' +
          '<div><h3 class="h-sm">Syllabus / course highlights</h3>' +
            '<ul class="mlist" style="margin-top:11px">' +
              c.syllabus.map(s => '<li>' + ico('checkC') + '<span>' + esc(s) + '</span></li>').join('') +
            '</ul></div>' +
          (c.note ? '<div class="cc__note">' + ico('info') + '<span>' + esc(c.note) + '</span></div>' : '') +
          '<div class="card" style="padding:18px 20px;background:var(--moss-wash);box-shadow:inset 0 0 0 1px rgba(44,122,91,.2)">' +
            '<div class="mono" style="color:#1D5B41">Course ke baad</div>' +
            '<p style="margin-top:7px;font-size:.95rem;color:#1C4A38">' + esc(c.outcome) + '</p>' +
          '</div>' +
          '<div>' +
            '<h3 class="h-sm">Is course ke liye enquiry karein</h3>' +
            '<div class="macts" style="margin-top:13px">' +
              '<a class="btn btn--copper" data-autofocus href="' + D.waLink(waCourseMsg(c)) + '" target="_blank" rel="noopener">' + ico('whatsapp') + 'WhatsApp par poochein</a>' +
              '<a class="btn btn--ghost" href="tel:+91' + C.contact.phoneRaw.slice(2) + '">' + ico('phone') + C.contact.phoneDisplay + '</a>' +
              '<a class="btn btn--ghost" href="contact.html?course=' + c.id + '">' + ico('mail') + 'Enquiry form bharein</a>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>';

    ov.querySelector('[data-close]').addEventListener('click', () => closeOverlay(ov));
    openOverlay(ov);
  }

  function waCourseMsg(c) {
    return 'Namaste! Mujhe "' + c.title + '" course ke baare mein poochna hai (Oxford Institute Badshahpur).\n' +
           'Please ye bata dijiye:\n1. Current fees\n2. Batch timings\n3. Kab se nayi batch shuru ho rahi hai';
  }

  /* ---------- compare modal ---------- */
  const compare = {
    key: 'ox_compare',
    get() { try { return JSON.parse(localStorage.getItem(this.key) || '[]'); } catch (e) { return []; } },
    set(v) { try { localStorage.setItem(this.key, JSON.stringify(v.slice(0, 3))); } catch (e) {} },
    has(id) { return this.get().indexOf(id) > -1; },
    toggle(id) {
      let v = this.get();
      v = v.indexOf(id) > -1 ? v.filter(x => x !== id) : (v.length < 3 ? v.concat([id]) : v);
      this.set(v); syncCompareUI(); return v;
    },
    clear() { this.set([]); syncCompareUI(); }
  };

  function syncCompareUI() {
    const list = compare.get();
    $$('[data-compare]').forEach(b => {
      const on = list.indexOf(b.dataset.compare) > -1;
      b.setAttribute('aria-pressed', String(on));
      b.setAttribute('aria-label', (on ? 'Compare se hatayein: ' : 'Compare mein jodein: ') + b.dataset.compare);
    });
    const tray = $('[data-compare-tray]');
    if (!tray) return;
    if (!list.length) {
      tray.hidden = true; tray.innerHTML = '';
      document.body.classList.remove('has-tray');
      return;
    }
    tray.hidden = false;
    document.body.classList.add('has-tray');
    tray.innerHTML =
      '<div class="card" style="padding:14px 18px;display:flex;flex-wrap:wrap;align-items:center;gap:12px">' +
        ico('scale') +
        '<b style="font-size:.92rem">' + list.length + ' course' + (list.length > 1 ? 's' : '') + ' compare ke liye chune gaye</b>' +
        '<span class="faint" style="font-size:.83rem">' + list.map(id => esc(D.courseById(id).title)).join(' · ') + '</span>' +
        '<button class="btn btn--sm btn--copper" data-cmp-open style="margin-left:auto">Compare karein</button>' +
        '<button class="btn btn--sm btn--ghost" data-cmp-clear>Clear</button>' +
      '</div>';
    tray.querySelector('[data-cmp-open]').addEventListener('click', openCompare);
    tray.querySelector('[data-cmp-clear]').addEventListener('click', () => compare.clear());
  }

  function openCompare() {
    const list = compare.get().map(D.courseById).filter(Boolean);
    if (!list.length) return;
    const ov = OX_UI.el('div', { class: 'ovl', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Course comparison' });
    const head = ['', 'Duration', 'Fee', 'Level', 'Focus'].map(h => '<th>' + esc(h) + '</th>').join('');
    const rows = [
      ['Duration', c => c.duration],
      ['Fee', c => c.fee ? '₹' + c.fee.toLocaleString('en-IN') + (c.feeModule ? ' + ' + c.feeModule.label + ' ₹' + c.feeModule.fee.toLocaleString('en-IN') : '') : '—'],
      ['Level', c => c.level],
      ['Focus', c => c.syllabus.slice(0, 3).join(', ')]
    ];
    ov.innerHTML =
      '<div class="modal">' +
        '<div class="modal__hd"><div><div class="kicker">Side by side</div><h2 class="h-md" style="margin-top:8px">Courses compare karein</h2></div>' +
        '<button class="modal__x" type="button" data-close aria-label="Close">' + ico('close') + '</button></div>' +
        '<div class="modal__body">' +
          '<div class="cmp-wrap"><table class="cmp"><thead><tr>' + head + '</tr></thead><tbody>' +
            rows.map(r => '<tr><th>' + esc(r[0]) + '</th>' + list.map(c => '<td>' + esc(r[1](c)) + '</td>').join('') + '</tr>').join('') +
            '<tr><th></th>' + list.map(c =>
              '<td><a class="btn btn--sm btn--copper btn--block" href="' + D.waLink(waCourseMsg(c)) + '" target="_blank" rel="noopener">Enquiry</a></td>'
            ).join('') + '</tr>' +
          '</tbody></table></div>' +
          '<p class="faint" style="font-size:.83rem">Fees institute ki previous website se listed hain — current fee call par confirm karein. Placement ya guarantee ka koi claim nahi.</p>' +
        '</div>' +
      '</div>';
    ov.querySelector('[data-close]').addEventListener('click', () => closeOverlay(ov));
    openOverlay(ov);
  }

  /* ---------- "remember last course" so contact form pre-fills ---------- */
  function rememberCourse(id) { try { localStorage.setItem('ox_last_course', id); } catch (e) {} }

  /* =====================================================================
     7.  COMMAND PALETTE  (⌘K / Ctrl K)
     ================================================================== */
  function buildPalette() {
    const ov = OX_UI.el('div', { class: 'ovl cmdk', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Search' });
    ov.innerHTML =
      '<div class="cmdk__box">' +
        '<div class="cmdk__in">' + ico('search') +
          '<input type="search" placeholder="Course, page ya topic search karein…" aria-label="Search" autocomplete="off">' +
          '<button class="modal__x" type="button" data-close aria-label="Close search" style="box-shadow:none">' + ico('close') + '</button>' +
        '</div>' +
        '<div class="cmdk__list" role="listbox" aria-label="Search results"></div>' +
        '<div class="cmdk__foot">' +
          '<span><kbd>↑↓</kbd> navigate</span><span><kbd>Enter</kbd> open</span><span><kbd>Esc</kbd> close</span>' +
        '</div>' +
      '</div>';

    const input = ov.querySelector('input');
    const list = ov.querySelector('.cmdk__list');
    let items = [], idx = 0;

    function all() {
      const out = [];
      D.COURSES.forEach(c => out.push({
        t: c.title, s: c.catLabel + ' · ' + (c.fee ? '₹' + c.fee.toLocaleString('en-IN') : 'fee on call'),
        g: 'Courses', run: () => { closeOverlay(ov); setTimeout(() => courseModal(c.id), 200); }
      }));
      PAGES.forEach(p => out.push({
        t: p.label, s: 'Page', g: 'Pages', run: () => { location.href = p.href; }
      }));
      [
        { t: 'WhatsApp par baat karein', s: C.contact.phoneDisplay, run: () => window.open(D.waLink('Namaste! Course enquiry — Oxford Institute Badshahpur.'), '_blank', 'noopener') },
        { t: 'Call karein', s: C.contact.phoneDisplay, run: () => location.href = 'tel:+91' + C.contact.phoneRaw.slice(2) },
        { t: 'Directions (Google Maps)', s: 'Main Sohna Road, Badshahpur', run: () => window.open(mapsUrl(), '_blank', 'noopener') },
        { t: 'Course finder (quiz)', s: 'Kaun sa course mere liye sahi hai', run: () => { location.href = 'index.html#recommender'; } },
        { t: 'Fees ke baare mein', s: 'FAQ', run: () => { location.href = 'faq.html#fees'; } }
      ].forEach(a => out.push(Object.assign({ g: 'Quick actions', s: '' }, a)));
      return out;
    }

    function render(q) {
      const query = (q || '').trim().toLowerCase();
      items = all().filter(i => !query || (i.t + ' ' + i.s).toLowerCase().indexOf(query) > -1).slice(0, 12);
      idx = 0;
      if (!items.length) {
        list.innerHTML = '<div class="cmdk__empty">Kuch nahi mila. Course ka naam try karein — jaise "tally", "excel", "python".</div>';
        return;
      }
      let html = '', lastG = '';
      items.forEach((i, n) => {
        if (i.g !== lastG) { html += '<div class="cmdk__grp">' + esc(i.g) + '</div>'; lastG = i.g; }
        html += '<button class="cmdk__it" role="option" data-i="' + n + '" aria-selected="' + (n === 0) + '">' +
                  ico(i.g === 'Courses' ? 'gBook' : i.g === 'Pages' ? 'route' : 'arrowR') +
                  '<span>' + esc(i.t) + (i.s ? ' <small style="display:inline;margin:0 0 0 6px;font-family:var(--f-body);color:var(--ink-faint);font-size:.78rem">' + esc(i.s) + '</small>' : '') + '</span>' +
                '</button>';
      });
      list.innerHTML = html;
      $$('.cmdk__it', list).forEach(b => {
        b.addEventListener('click', () => items[+b.dataset.i].run());
        b.addEventListener('mousemove', () => select(+b.dataset.i));
      });
    }
    function select(n) {
      idx = Math.max(0, Math.min(items.length - 1, n));
      $$('.cmdk__it', list).forEach((b, i) => b.setAttribute('aria-selected', String(i === idx)));
      const cur = list.querySelector('.cmdk__it[aria-selected="true"]');
      if (cur) cur.scrollIntoView({ block: 'nearest' });
    }
    function open() {
      input.value = ''; render('');
      openOverlay(ov);
      setTimeout(() => input.focus(), 300);
    }
    input.addEventListener('input', () => render(input.value));
    ov.querySelector('[data-close]').addEventListener('click', () => closeOverlay(ov));
    ov.addEventListener('keydown', e => {
      if (e.key === 'ArrowDown') { e.preventDefault(); select(idx + 1); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); select(idx - 1); }
      else if (e.key === 'Enter') { e.preventDefault(); if (items[idx]) items[idx].run(); }
    });

    document.addEventListener('keydown', e => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); open(); }
      if (e.key === '/' && !/input|textarea|select/i.test((document.activeElement || {}).tagName || '')) { e.preventDefault(); open(); }
    });
    $$('[data-cmdk]').forEach(b => b.addEventListener('click', open));
  }

  /* =====================================================================
     8.  GLOBAL CLICK DELEGATION
     ================================================================== */
  function initDelegation() {
    document.addEventListener('click', e => {
      const opener = e.target.closest('[data-open-course]');
      if (opener) { e.preventDefault(); courseModal(opener.dataset.openCourse); return; }
      const cmp = e.target.closest('[data-compare]');
      if (cmp) { e.preventDefault(); compare.toggle(cmp.dataset.compare); return; }
    });
  }

  /* =====================================================================
     9.  HERO DECK (3D card stack)
     ================================================================== */
  function initDeck() {
    const stage = $('[data-deck-stage]');
    if (!stage) return;
    const cards = Array.prototype.slice.call(stage.children);
    const dots = $$('[data-deck-dot]');
    let i = 0, timer = null;

    function paint() {
      cards.forEach((c, n) => {
        const p = (n - i + cards.length) % cards.length;
        c.dataset.pos = String(Math.min(p, 3));
        c.setAttribute('aria-hidden', p === 0 ? 'false' : 'true');
        c.tabIndex = p === 0 ? 0 : -1;
      });
      dots.forEach((d, n) => d.setAttribute('aria-selected', String(n === i)));
    }
    function go(n) { i = (n + cards.length) % cards.length; paint(); }
    function next() { go(i + 1); }

    cards.forEach((c, n) => {
      c.addEventListener('click', () => { if (n === i) courseModal(c.dataset.course); else go(n); });
      c.addEventListener('keydown', ev => {
        if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); courseModal(c.dataset.course); }
        if (ev.key === 'ArrowRight') { ev.preventDefault(); next(); restart(); }
        if (ev.key === 'ArrowLeft')  { ev.preventDefault(); go(i - 1); restart(); }
      });
    });
    dots.forEach((d, n) => d.addEventListener('click', () => { go(n); restart(); }));

    function restart() { clearInterval(timer); if (!reduceMotion()) timer = setInterval(next, 5200); }

    paint(); restart();

    /* pointer parallax tilt — CSS 3D only, no library */
    const deck = $('[data-deck]');
    if (deck && !reduceMotion() && window.matchMedia('(pointer:fine)').matches) {
      let raf = null;
      deck.addEventListener('pointermove', ev => {
        if (raf) return;
        raf = requestAnimationFrame(() => {
          raf = null;
          const r = deck.getBoundingClientRect();
          const x = (ev.clientX - r.left) / r.width - .5;
          const y = (ev.clientY - r.top) / r.height - .5;
          stage.style.transform = 'rotateY(' + (x * 13).toFixed(2) + 'deg) rotateX(' + (-y * 11).toFixed(2) + 'deg) translateZ(0)';
        });
      });
      deck.addEventListener('pointerleave', () => { stage.style.transform = ''; });
    }
  }

  /* =====================================================================
     10. BOOT
     ================================================================== */
  function boot() {
    buildHeader();
    buildFooter();
    buildFloating();
    buildPalette();
    initDelegation();
    initStagger();
    initReveals();
    initCounters();
    initDeck();
    syncCompareUI();
    paintClocks();
    setInterval(paintClocks, 60000);
    requestAnimationFrame(() => document.body.classList.add('is-ready'));

    /* expose for page modules */
    window.OX_APP = {
      courseModal, openOverlay, closeOverlay, compare, syncCompareUI,
      toggleNav, mapsUrl, rememberCourse, paintClocks, COURSES: D.COURSES
    };
    document.dispatchEvent(new CustomEvent('ox:ready'));
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
