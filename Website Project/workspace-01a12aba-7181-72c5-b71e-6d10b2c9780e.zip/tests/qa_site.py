#!/usr/bin/env python3
"""
Oxford Institute — Badshahpur | automated site QA
Runs a real Chromium over the built site and asserts on behaviour.

Covers: console/page errors, resource loading, internal links, responsive
layout, navigation + drawer, scroll reveals, course cards & filters, course
modal, compare tray, course-finder quiz, FAQ search/filter, enquiry-form
validation & honest submit path, command palette, live clock, a11y basics,
and page-weight budget.
"""
import re, sys, json, pathlib
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

BASE = "http://127.0.0.1:4173"
ROOT = pathlib.Path("/home/user/oxford-badshahpur")
SHOTS = pathlib.Path("/home/user/tests/shots")
SHOTS.mkdir(parents=True, exist_ok=True)
PAGES = ["index.html", "courses.html", "about.html", "faq.html", "contact.html"]

results = []
def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("  PASS  " if ok else "  FAIL  ") + name + (("  → " + str(detail)[:220]) if detail else ""))

VIEWPORTS = {
    "mobile":  {"width": 390,  "height": 844, "isMobile": True,  "hasTouch": True,  "deviceScaleFactor": 2},
    "tablet":  {"width": 834,  "height": 1112,"isMobile": True,  "hasTouch": True,  "deviceScaleFactor": 2},
    "desktop": {"width": 1440, "height": 960, "isMobile": False, "hasTouch": False, "deviceScaleFactor": 1},
}

def new_page(browser, vp, errors, failed_reqs):
    ctx = browser.new_context(viewport={k: vp[k] for k in ("width", "height")},
                              is_mobile=vp["isMobile"], has_touch=vp["hasTouch"],
                              device_scale_factor=vp["deviceScaleFactor"], locale="en-IN")
    pg = ctx.new_page()
    pg.on("console", lambda m: errors.append(f"[{m.type}] {m.text}") if m.type in ("error", "warning") else None)
    pg.on("pageerror", lambda e: errors.append(f"[pageerror] {e}"))
    pg.on("requestfailed", lambda r: failed_reqs.append(f"{r.url} :: {r.failure}"))
    return ctx, pg

def run():
    with sync_playwright() as p:
        browser = p.chromium.launch(args=["--no-sandbox", "--font-render-hinting=none"])

        # ================= 1. load every page, capture errors =============
        print("\n=== 1. Page load, console errors, resource failures ===")
        all_errors, all_failed = {}, {}
        for page in PAGES:
            errs, fails = [], []
            ctx, pg = new_page(browser, VIEWPORTS["desktop"], errs, fails)
            r = pg.goto(f"{BASE}/{page}", wait_until="networkidle")
            pg.wait_for_timeout(700)
            title = pg.title()
            h1 = pg.eval_on_selector_all("h1", "ns => ns.map(n => n.innerText.trim())")
            check(f"{page} → HTTP 200", r and r.status == 200, r.status if r else "no response")
            check(f"{page} → <title> present", bool(title.strip()), title[:70])
            check(f"{page} → exactly one <h1>", len(h1) == 1, h1)
            check(f"{page} → header injected by app.js", pg.locator(".head .brand").count() >= 1)
            check(f"{page} → footer injected by app.js", pg.locator(".foot").count() == 1)
            check(f"{page} → floating WhatsApp present", pg.locator(".fab__btn").count() >= 1)
            check(f"{page} → no console errors", len(errs) == 0, errs[:6])
            check(f"{page} → no failed requests", len(fails) == 0, fails[:6])
            all_errors[page], all_failed[page] = errs, fails
            ctx.close()

        # ================= 2. internal link audit =========================
        print("\n=== 2. Internal link + asset audit (all pages) ===")
        ctx, pg = new_page(browser, VIEWPORTS["desktop"], [], [])
        seen, broken = set(), []
        for page in PAGES:
            pg.goto(f"{BASE}/{page}", wait_until="networkidle")
            pg.wait_for_timeout(350)
            hrefs = pg.eval_on_selector_all(
                "a[href]",
                "ns => ns.map(n => n.getAttribute('href'))")
            for h in hrefs:
                if not h or h.startswith(("#", "mailto:", "tel:", "javascript:")):
                    continue
                if h.startswith(("http://", "https://")):
                    if "127.0.0.1:4173" not in h:
                        continue  # external (wa.me, maps, social) — not fetched
                    h = h.split("4173", 1)[1]
                if h in seen:
                    continue
                seen.add(h)
                path = h.split("#")[0].split("?")[0] or "index.html"
                try:
                    resp = pg.request.get(f"{BASE}/{path}")
                    if resp.status >= 400:
                        broken.append(f"{page} → {h} ({resp.status})")
                except Exception as e:
                    broken.append(f"{page} → {h} ({e})")
        check("all internal links resolve", not broken, broken[:10])
        check("at least 10 internal links audited", len(seen) >= 10, f"{len(seen)} unique")

        # ================= 3. responsive / no overflow ====================
        print("\n=== 3. Responsive layout (no horizontal scroll) ===")
        for name, vp in VIEWPORTS.items():
            ctx2, pg2 = new_page(browser, vp, [], [])
            for page in PAGES:
                pg2.goto(f"{BASE}/{page}", wait_until="networkidle")
                pg2.wait_for_timeout(450)
                info = pg2.evaluate("""() => {
                    // measure with the vertical scrollbar removed so its own width
                    // is not mistaken for content overflow
                    const de = document.documentElement, prev = de.style.overflow;
                    de.style.overflow = 'hidden';
                    const sw = de.scrollWidth, cw = de.clientWidth;
                    de.style.overflow = prev;
                    const off = [...document.querySelectorAll('body *')].filter(n => {
                        const cs = getComputedStyle(n);
                        if (cs.position === 'fixed' || cs.visibility === 'hidden' || cs.display === 'none') return false;
                        const r = n.getBoundingClientRect();
                        return (r.right > cw + 2 || r.left < -2) && r.width > 0;
                    }).slice(0, 6).map(n => n.tagName + '.' + (n.className.baseVal ?? n.className).toString().split(' ')[0]);
                    return { sw, cw, off };
                }""")
                over = info["sw"] - info["cw"]
                check(f"{name} / {page} → no horizontal overflow", over <= 1,
                      f"overflow {over}px (scrollWidth {info['sw']} vs clientWidth {info['cw']}) {info['off']}")
            # mobile chrome
            if name == "mobile":
                pg2.goto(f"{BASE}/index.html", wait_until="networkidle"); pg2.wait_for_timeout(400)
                check("mobile → burger visible", pg2.locator(".burger").is_visible())
                check("mobile → desktop nav hidden", not pg2.locator(".nav").first.is_visible())
                check("mobile → action bar in DOM", pg2.locator(".mbar").count() == 1)
                pg2.evaluate("window.scrollTo(0, 900)"); pg2.wait_for_timeout(500)
                check("mobile → action bar slides in on scroll", pg2.locator(".mbar").evaluate("n => n.classList.contains('on')"))
            elif name == "tablet":
                check("tablet → burger visible (<=900px breakpoint)", pg2.locator(".burger").is_visible())
            else:
                check("desktop → burger hidden", not pg2.locator(".burger").first.is_visible())
            ctx2.close()
        ctx.close()

        # ================= 4. mobile drawer ===============================
        print("\n=== 4. Mobile navigation drawer ===")
        ctx, pg = new_page(browser, VIEWPORTS["mobile"], [], [])
        pg.goto(f"{BASE}/index.html", wait_until="networkidle"); pg.wait_for_timeout(400)
        pg.click(".burger"); pg.wait_for_timeout(600)
        check("drawer opens", pg.evaluate("document.body.classList.contains('nav-open')"))
        check("drawer aria-hidden=false", pg.get_attribute("#drawer", "aria-hidden") == "false")
        check("burger aria-expanded=true", pg.get_attribute(".burger", "aria-expanded") == "true")
        check("drawer links staggered in", pg.evaluate("[...document.querySelectorAll('#drawer a')].every(a => getComputedStyle(a).opacity > .9)"))
        check("body scroll locked", pg.evaluate("getComputedStyle(document.body).overflow") == "hidden")
        pg.keyboard.press("Escape"); pg.wait_for_timeout(500)
        check("Escape closes drawer", not pg.evaluate("document.body.classList.contains('nav-open')"))
        pg.click(".burger"); pg.wait_for_timeout(500)
        pg.click("#drawer a[href='courses.html']"); pg.wait_for_load_state("networkidle")
        check("drawer link navigates", "courses.html" in pg.url, pg.url)
        ctx.close()

        # ================= 5. scroll reveals + hero animation =============
        print("\n=== 5. Scroll reveals, hero, deck ===")
        ctx, pg = new_page(browser, VIEWPORTS["desktop"], [], [])
        pg.goto(f"{BASE}/index.html", wait_until="networkidle"); pg.wait_for_timeout(900)
        check("hero headline mask revealed", pg.evaluate(
            "getComputedStyle(document.querySelector('.hero h1 .ln > span')).transform") in ("none", "matrix(1, 0, 0, 1, 0, 0)"))
        pg.evaluate("window.scrollTo(0, 1400)"); pg.wait_for_timeout(1100)
        rev = pg.evaluate("""() => {
            const ns=[...document.querySelectorAll('[data-rv]')];
            return {total: ns.length, shown: ns.filter(n=>n.classList.contains('in')).length};
        }""")
        check("reveal elements exist", rev["total"] > 8, rev)
        check("some reveals fired after scroll", rev["shown"] > 0, rev)
        pg.evaluate("window.scrollTo(0, document.body.scrollHeight)"); pg.wait_for_timeout(1600)
        rev2 = pg.evaluate("[...document.querySelectorAll('[data-rv]')].filter(n=>!n.classList.contains('in')).length")
        check("all reveals fire after full scroll", rev2 == 0, f"{rev2} still hidden")
        check("back-to-top visible after scroll", pg.locator(".totop").evaluate("n => n.classList.contains('on')"))
        # deck — bring the hero back into the viewport first
        pg.evaluate("window.scrollTo(0, 0)"); pg.wait_for_timeout(700)
        pg.locator("[data-deck]").scroll_into_view_if_needed(); pg.wait_for_timeout(400)
        deck = pg.evaluate("""() => {
            const c=[...document.querySelectorAll('.deck__card')];
            return {n:c.length, front: c.filter(x=>x.dataset.pos==='0').length,
                    transform: getComputedStyle(document.querySelector('.deck__stage')).transform};
        }""")
        check("deck has 4 cards, exactly 1 front", deck["n"] == 4 and deck["front"] == 1, deck)
        base_tilt = pg.evaluate("getComputedStyle(document.querySelector('.deck__stage')).transform")
        check("deck stage starts untilted", base_tilt == "none", base_tilt)
        box = pg.locator(".deck").bounding_box()
        pg.mouse.move(box["x"] + box["width"] * 0.72, box["y"] + box["height"] * 0.35, steps=10)
        pg.wait_for_timeout(600)
        tilt = pg.evaluate("getComputedStyle(document.querySelector('.deck__stage')).transform")
        check("deck stage gets 3D tilt on pointer move",
              tilt not in ("none", "matrix(1, 0, 0, 1, 0, 0)") and "matrix3d" in tilt, tilt)
        pg.mouse.move(2, 2, steps=6); pg.wait_for_timeout(800)
        check("deck tilt resets on pointer leave",
              pg.evaluate("getComputedStyle(document.querySelector('.deck__stage')).transform") == "none")
        front = pg.locator(".deck__card[data-pos='0']")
        front_title = front.locator(".deck__title").inner_text()
        front.click(); pg.wait_for_timeout(650)
        check("front deck card opens course modal", pg.locator(".ovl.on .modal").count() == 1)
        modal_title = pg.locator(".ovl.on .modal h2").first.inner_text()
        check("modal title matches card", front_title.strip() in modal_title, f"{front_title} / {modal_title}")
        pg.keyboard.press("Escape"); pg.wait_for_timeout(600)
        check("Escape closes modal", pg.locator(".ovl.on").count() == 0)
        # dots
        cur = pg.locator(".deck__card[data-pos='0'] .deck__title").inner_text().strip()
        nxt = (pg.locator(".deck__dot").count() - 1)
        pg.locator(".deck__dot").nth(nxt).click(); pg.wait_for_timeout(800)
        new_front = pg.locator(".deck__card[data-pos='0'] .deck__title").inner_text().strip()
        check("deck dot switches front card", new_front != cur, f"'{cur}' → '{new_front}'")
        check("clicked dot marked selected",
              pg.locator(".deck__dot").nth(nxt).get_attribute("aria-selected") == "true")
        ctx.close()

        # ================= 6. courses page: grid + filters ================
        print("\n=== 6. Course grid, filters, compare ===")
        ctx, pg = new_page(browser, VIEWPORTS["desktop"], [], [])
        pg.goto(f"{BASE}/courses.html", wait_until="networkidle"); pg.wait_for_timeout(800)
        pg.evaluate("localStorage.clear()"); pg.reload(wait_until="networkidle"); pg.wait_for_timeout(800)
        n_cards = pg.locator(".cc").count()
        n_expected = pg.evaluate("OXFORD.COURSES.length")
        check("all courses rendered", n_cards == n_expected, f"{n_cards} rendered / {n_expected} in data")
        check("compare tray starts empty", pg.evaluate("JSON.parse(localStorage.getItem('ox_compare')||'[]').length") == 0)
        check("filter pills rendered", pg.locator(".filters label").count() == 5)
        check("fee table rows == courses", pg.locator(".cmp tbody tr").count() == n_expected,
              pg.locator(".cmp tbody tr").count())
        pg.click("label[for='cat-code']"); pg.wait_for_timeout(650)
        vis = pg.locator(".cc:not(.is-out)").count()
        code_n = pg.evaluate("OXFORD.COURSES.filter(c=>c.cat==='code').length")
        check("filter=code shows only code courses", vis == code_n, f"{vis} visible / {code_n} expected")
        check("filter count label updates", "programming" in pg.locator("[data-result-count]").inner_text().lower(),
              pg.locator("[data-result-count]").inner_text())
        # non-code cards hidden
        hidden_ok = pg.evaluate("""() => [...document.querySelectorAll('.cc')]
             .filter(c => c.dataset.cat !== 'code')
             .every(c => c.classList.contains('is-out'))""")
        check("non-matching cards hidden", hidden_ok)
        pg.click("label[for='cat-all']"); pg.wait_for_timeout(500)
        check("filter=all restores all", pg.locator(".cc:not(.is-out)").count() == n_expected)

        # compare tray
        pg.locator("[data-compare]").nth(0).scroll_into_view_if_needed(); pg.wait_for_timeout(250)
        pg.locator("[data-compare]").nth(0).click(); pg.wait_for_timeout(300)
        pg.locator("[data-compare]").nth(1).scroll_into_view_if_needed(); pg.wait_for_timeout(250)
        pg.locator("[data-compare]").nth(1).click(); pg.wait_for_timeout(400)
        check("compare tray appears", pg.locator("[data-compare-tray]").is_visible())
        check("tray adds bottom room so content is not covered",
              pg.evaluate("document.body.classList.contains('has-tray')"))
        check("compare aria-pressed set", pg.locator("[data-compare]").nth(0).get_attribute("aria-pressed") == "true")
        pg.locator("[data-cmp-open]").click(); pg.wait_for_timeout(650)
        sel = pg.evaluate("JSON.parse(localStorage.getItem('ox_compare')||'[]')")
        data_cols = pg.locator(".ovl.on .cmp tbody tr").first.locator("td").count()
        check("compare modal shows one column per selected course",
              data_cols == len(sel) == 2, f"{data_cols} data cols / {len(sel)} selected")
        names = pg.locator(".ovl.on .cmp tbody").inner_text()
        check("compare modal shows course enquiry actions",
              pg.locator(".ovl.on .cmp a[href^='https://wa.me/']").count() == len(sel))
        pg.keyboard.press("Escape"); pg.wait_for_timeout(500)
        pg.locator("[data-cmp-clear]").click(); pg.wait_for_timeout(300)
        check("compare clear hides tray", not pg.locator("[data-compare-tray]").is_visible())

        # deep link
        pg.goto(f"{BASE}/courses.html#tally-gst", wait_until="networkidle"); pg.wait_for_timeout(1400)
        check("hash deep-link highlights card",
              pg.evaluate("!!document.querySelector('#tally-gst')") and
              pg.evaluate("document.querySelector('#tally-gst').getBoundingClientRect().top < window.innerHeight"))
        # ask-strip
        check("'ask us' strip rendered", pg.locator("[data-ask] > div").count() == 3,
              pg.locator("[data-ask] > div").count())
        ctx.close()

        # ================= 7. course modal content ========================
        print("\n=== 7. Course detail modal ===")
        ctx, pg = new_page(browser, VIEWPORTS["desktop"], [], [])
        pg.goto(f"{BASE}/courses.html", wait_until="networkidle"); pg.wait_for_timeout(700)
        pg.locator("[data-open-course='tally-gst']").first.click(); pg.wait_for_timeout(700)
        m = pg.locator(".ovl.on")
        check("modal has role=dialog", m.get_attribute("role") == "dialog")
        check("modal has aria-modal", m.get_attribute("aria-modal") == "true")
        txt = m.inner_text()
        for need in ["Tally with GST", "Syllabus", "voucher", "WhatsApp", "₹6,000"]:
            check(f"modal contains '{need}'", need.lower() in txt.lower())
        wa = m.locator("a[href^='https://wa.me/']").first.get_attribute("href")
        check("modal WhatsApp link carries course name", "Tally" in wa and wa.startswith("https://wa.me/919818112018"), wa[:90])
        check("modal has phone tel: link", m.locator("a[href^='tel:']").count() >= 1)
        check("modal has enquiry form link with ?course=", "contact.html?course=tally-gst" in m.inner_html())
        # focus trap
        pg.keyboard.press("Tab")
        inside = pg.evaluate("!!document.activeElement.closest('.ovl')")
        check("focus stays trapped in modal", inside)
        pg.keyboard.press("Escape"); pg.wait_for_timeout(600)
        check("modal closed", pg.locator(".ovl.on").count() == 0)
        check("focus returned to trigger", pg.evaluate("document.activeElement && document.activeElement.dataset.openCourse") == "tally-gst")
        # remembered course prefill
        pg.goto(f"{BASE}/contact.html", wait_until="networkidle"); pg.wait_for_timeout(600)
        check("contact form pre-fills last viewed course",
              pg.input_value("#f-course") == "tally-gst", pg.input_value("#f-course"))
        ctx.close()

        # ================= 8. course finder quiz ==========================
        print("\n=== 8. Course finder (recommender) ===")
        ctx, pg = new_page(browser, VIEWPORTS["desktop"], [], [])
        pg.goto(f"{BASE}/index.html#recommender", wait_until="networkidle"); pg.wait_for_timeout(800)
        pg.locator("[data-quiz]").scroll_into_view_if_needed(); pg.wait_for_timeout(500)
        check("quiz renders 3 steps", pg.locator(".quiz__step").count() == 3)
        check("only step 1 visible", pg.locator(".quiz__step.is-on").count() == 1)
        pg.locator(".quiz__step.is-on .quiz__opt", has_text="Accounting & billing").click(); pg.wait_for_timeout(450)
        check("step 2 active", pg.locator(".quiz__step.is-on [data-k='less'], .quiz__step.is-on [data-k='mid'], .quiz__step.is-on [data-k='more']").count() == 3)
        pg.locator(".quiz__step.is-on .quiz__opt", has_text="1–2 ghante").click(); pg.wait_for_timeout(450)
        pg.locator(".quiz__step.is-on .quiz__opt", has_text="Thoda bahut").click(); pg.wait_for_timeout(700)
        res = pg.locator("[data-result]")
        check("result panel shown", res.is_visible())
        picks = pg.locator(".quiz__pick").count()
        check("3 course suggestions", picks == 3, picks)
        first_pick = pg.locator(".quiz__pick b").first.inner_text()
        check("Tally suggested for accounting goal", "Tally" in first_pick, first_pick)
        check("advice list rendered", pg.locator(".quiz__advice p").count() >= 1)
        qwa = pg.locator("[data-quiz-wa]").get_attribute("href")
        check("result WhatsApp message lists suggestions", "Tally" in qwa, qwa[:110])
        pg.locator("[data-again]").click(); pg.wait_for_timeout(500)
        check("reset returns to step 1", pg.locator("[data-result]").evaluate("n => n.hidden") and
              pg.locator(".quiz__step.is-on").count() == 1)
        ctx.close()

        # ================= 9. FAQ page ====================================
        print("\n=== 9. FAQ search + filters ===")
        ctx, pg = new_page(browser, VIEWPORTS["desktop"], [], [])
        pg.goto(f"{BASE}/faq.html", wait_until="networkidle"); pg.wait_for_timeout(700)
        total = pg.locator("details.qa").count()
        data_n = pg.evaluate("OXFORD.FAQS.length")
        check("all FAQs rendered", total == data_n, f"{total} / {data_n}")
        check("category pills rendered", pg.locator("[data-faq-filters] label").count() >= 4)
        pg.fill("#faq-search", "placement"); pg.wait_for_timeout(450)
        check("search filters FAQs", 0 < pg.locator("details.qa").count() < total,
              pg.locator("details.qa").count())
        pg.fill("#faq-search", "zzzznothing"); pg.wait_for_timeout(450)
        check("empty state shown for no match", pg.locator("[data-faq-empty]").is_visible() and
              pg.locator("details.qa").count() == 0)
        pg.fill("#faq-search", ""); pg.wait_for_timeout(400)
        pg.click("label[for='fq-1']"); pg.wait_for_timeout(450)
        cat = pg.get_attribute("#fq-1", "value")
        only = pg.evaluate("[...document.querySelectorAll('details.qa')].map(d=>d.dataset.cat)")
        check("category filter narrows list", len(only) < total and all(c == cat for c in only), f"{cat}: {len(only)}")
        # accordion behaviour
        pg.click("label[for='fq-0']"); pg.wait_for_timeout(300)
        pg.locator("details.qa summary").first.click(); pg.wait_for_timeout(400)
        check("accordion opens", pg.locator("details.qa").first.evaluate("d => d.open"))
        check("no fabricated placement claim in answers",
              pg.evaluate("OXFORD.FAQS.filter(f=>/100%|guarantee|guaranteed job/i.test(f.a) && !/nahi|not|no claim/i.test(f.a)).length") == 0)
        ctx.close()

        # ================= 10. form validation ============================
        print("\n=== 10. Enquiry form — validation & honest submit ===")
        ctx, pg = new_page(browser, VIEWPORTS["desktop"], [], [])
        pg.goto(f"{BASE}/contact.html", wait_until="networkidle"); pg.wait_for_timeout(700)
        pg.evaluate("localStorage.clear()")
        pg.reload(wait_until="networkidle"); pg.wait_for_timeout(600)
        check("course select populated from data",
              pg.locator("#f-course option").count() == pg.evaluate("OXFORD.COURSES.length") + 1 + 1 + 3,
              pg.locator("#f-course option").count())
        # empty submit
        pg.click("button[type='submit']"); pg.wait_for_timeout(500)
        errs = pg.locator(".field.has-err").count()
        check("empty submit blocks + marks required fields", errs == 4, f"{errs} fields flagged")
        check("error summary shown", pg.locator("[data-form-status].form__status--err").is_visible())
        check("NO fake success toast on invalid submit",
              pg.locator("[data-form-status].form__status--ok").count() == 0)
        # bad phone
        pg.fill("#f-name", "Rahul Kumar")
        pg.fill("#f-phone", "12345")
        pg.click("button[type='submit']"); pg.wait_for_timeout(400)
        check("invalid phone rejected", pg.locator("#f-phone").evaluate("n => n.closest('.field').classList.contains('has-err')"))
        pg.fill("#f-phone", "5123456789")
        pg.click("button[type='submit']"); pg.wait_for_timeout(400)
        check("phone not starting 6-9 rejected", pg.locator("#f-phone").evaluate("n => n.closest('.field').classList.contains('has-err')"))
        # bad email
        pg.fill("#f-phone", "9876543210"); pg.fill("#f-email", "not-an-email")
        pg.click("button[type='submit']"); pg.wait_for_timeout(400)
        check("invalid email rejected", pg.locator("#f-email").evaluate("n => n.closest('.field').classList.contains('has-err')"))
        # consent required
        pg.fill("#f-email", "rahul@example.com")
        pg.select_option("#f-course", "tally-gst")
        pg.click("button[type='submit']"); pg.wait_for_timeout(400)
        check("consent checkbox required", pg.locator("#f-consent").evaluate("n => n.getAttribute('aria-invalid')") == "true")
        # valid submit → honest demo path
        pg.check("#f-consent"); pg.fill("#f-msg", "Evening batch chahiye, fees kitni hogi?")
        pg.click("button[type='submit']"); pg.wait_for_timeout(700)
        check("valid submit shows info state (not fake success)",
              pg.locator("[data-form-status].form__status--info").is_visible())
        check("valid submit does NOT show fake 'sent' state",
              pg.locator("[data-form-status].form__status--ok").count() == 0)
        wa_href = pg.locator("[data-form-status] a[href^='https://wa.me/']").get_attribute("href")
        import urllib.parse as up
        decoded = up.unquote_plus(wa_href.split("text=", 1)[1])
        for need in ["Rahul Kumar", "9876543210", "Tally with GST", "Evening batch chahiye"]:
            check(f"WhatsApp payload contains '{need}'", need in decoded)
        mail_href = pg.locator("[data-form-status] a[href^='mailto:']").get_attribute("href")
        check("mailto fallback built with subject", "Course%20enquiry" in mail_href or "Course enquiry" in up.unquote(mail_href), mail_href[:80])
        check("copy button offered", pg.locator("[data-copy]").count() == 1)
        # validation state clears
        check("valid fields marked ok", pg.locator("#f-name").evaluate("n => n.closest('.field').classList.contains('ok')"))
        # draft persistence
        draft = pg.evaluate("localStorage.getItem('ox_enquiry_draft')")
        check("draft saved to localStorage", draft and "Rahul" in draft, (draft or "")[:70])
        pg.reload(wait_until="networkidle"); pg.wait_for_timeout(700)
        check("draft restored after reload", pg.input_value("#f-name") == "Rahul Kumar")
        check("draft note shown", pg.locator("[data-draft-note]").is_visible())
        pg.click("button[type='reset']"); pg.wait_for_timeout(400)
        check("reset clears draft", pg.evaluate("localStorage.getItem('ox_enquiry_draft')") is None)
        # ?course= prefill
        pg.goto(f"{BASE}/contact.html?course=python", wait_until="networkidle"); pg.wait_for_timeout(700)
        check("?course= prefill works", pg.input_value("#f-course") == "python")
        check("prefill notice shown", pg.locator("[data-form-note]").is_visible())
        ctx.close()

        # ================= 11. command palette ============================
        print("\n=== 11. Command palette (Ctrl+K) ===")
        ctx, pg = new_page(browser, VIEWPORTS["desktop"], [], [])
        pg.goto(f"{BASE}/index.html", wait_until="networkidle"); pg.wait_for_timeout(600)
        pg.keyboard.press("Control+k"); pg.wait_for_timeout(600)
        check("palette opens", pg.locator(".cmdk.on").count() == 1)
        n0 = pg.locator(".cmdk__it").count()
        check("palette lists items", n0 > 5, n0)
        pg.fill(".cmdk input", "tally"); pg.wait_for_timeout(400)
        items = pg.locator(".cmdk__it").all_inner_texts()
        check("search narrows to Tally", any("Tally" in i for i in items) and not any("Python" in i for i in items), items[:4])
        pg.keyboard.press("ArrowDown"); pg.keyboard.press("Enter"); pg.wait_for_timeout(900)
        check("Enter opens course modal", pg.locator(".ovl.on .modal h2").count() >= 1)
        pg.keyboard.press("Escape"); pg.wait_for_timeout(500)
        pg.keyboard.press("Control+k"); pg.wait_for_timeout(400)
        pg.fill(".cmdk input", "zzzzz"); pg.wait_for_timeout(350)
        check("palette empty state", pg.locator(".cmdk__empty").is_visible())
        pg.keyboard.press("Escape"); pg.wait_for_timeout(400)
        check("palette closes", pg.locator(".cmdk.on").count() == 0)
        ctx.close()

        # ================= 12. live clock / hours =========================
        print("\n=== 12. Live open/closed clock ===")
        ctx, pg = new_page(browser, VIEWPORTS["desktop"], [], [])
        pg.goto(f"{BASE}/index.html", wait_until="networkidle"); pg.wait_for_timeout(700)
        pill = pg.locator("[data-open-pill]").inner_text()
        foot = pg.locator(".foot [data-clock]").inner_text()
        hours = pg.locator("[data-hours] li").count()
        check("open/closed pill has text", pill.strip() in ("Abhi khula hai", "Abhi band"), pill)
        check("footer clock computed", "IST" in foot or "khulega" in foot or "band" in foot, foot)
        check("hours list has 7 days", hours == 7, hours)
        check("today's row marked", pg.locator("[data-hours] li.today").count() == 1)
        ctx.close()

        # ================= 13. a11y basics ================================
        print("\n=== 13. Accessibility basics ===")
        ctx, pg = new_page(browser, VIEWPORTS["desktop"], [], [])
        for page in PAGES:
            pg.goto(f"{BASE}/{page}", wait_until="networkidle"); pg.wait_for_timeout(500)
            bad_imgs = pg.evaluate("""() => [...document.querySelectorAll('img')].filter(i => !i.alt && !i.getAttribute('aria-label')).length""")
            check(f"{page} → all <img> have alt", bad_imgs == 0, bad_imgs)
            no_label = pg.evaluate("""() => [...document.querySelectorAll('button')].filter(b => {
                    const t=(b.innerText||'').trim();
                    return !t && !b.getAttribute('aria-label') && !b.querySelector('[aria-label]');
                }).length""")
            check(f"{page} → all buttons labelled", no_label == 0, no_label)
            dupes = pg.evaluate("""() => { const ids=[...document.querySelectorAll('[id]')].map(n=>n.id);
                    return ids.filter((v,i)=>ids.indexOf(v)!==i); }""")
            check(f"{page} → no duplicate ids", len(set(dupes)) == 0, list(set(dupes))[:6])
            check(f"{page} → skip link present", pg.locator(".skip").count() == 1)
            check(f"{page} → lang attribute set", pg.get_attribute("html", "lang") in ("hi", "en", "hi-IN"))
            check(f"{page} → viewport meta", pg.locator("meta[name='viewport']").count() == 1)
            check(f"{page} → meta description", bool((pg.get_attribute("meta[name='description']", "content") or "").strip()))
        # keyboard nav on course cards
        pg.goto(f"{BASE}/courses.html", wait_until="networkidle"); pg.wait_for_timeout(700)
        pg.locator(".cc").first.focus()
        check("course card is focusable", pg.evaluate("document.activeElement.classList.contains('cc')"))
        check("course card exposes button role + label",
              pg.evaluate("document.activeElement.getAttribute('role')") == "button" and
              bool(pg.evaluate("document.activeElement.getAttribute('aria-label')")))
        pg.keyboard.press("Enter"); pg.wait_for_timeout(800)
        check("Enter on card opens its modal", pg.locator(".ovl.on .modal h2").count() == 1)
        pg.keyboard.press("Escape"); pg.wait_for_timeout(600)
        pg.locator(".cc").first.focus(); pg.keyboard.press(" "); pg.wait_for_timeout(800)
        check("Space on card opens its modal", pg.locator(".ovl.on .modal h2").count() == 1)
        pg.keyboard.press("Escape"); pg.wait_for_timeout(500)
        # reduced motion
        ctx.close()
        ctx3 = browser.new_context(viewport={"width": 1280, "height": 900}, reduced_motion="reduce")
        pg3 = ctx3.new_page()
        pg3.goto(f"{BASE}/index.html", wait_until="networkidle"); pg3.wait_for_timeout(700)
        check("reduced-motion → reveals visible immediately",
              pg3.evaluate("[...document.querySelectorAll('[data-rv]')].every(n => getComputedStyle(n).opacity === '1')"))
        check("reduced-motion → hero headline visible",
              pg3.evaluate("getComputedStyle(document.querySelector('.hero h1 .ln > span')).transform") in ("none", "matrix(1, 0, 0, 1, 0, 0)"))
        check("reduced-motion → ticker animation off",
              pg3.evaluate("getComputedStyle(document.querySelector('.ticker__track')).animationName") == "none")
        ctx3.close()

        # ================= 14. content-integrity guards ===================
        print("\n=== 14. Content integrity (no invented claims) ===")
        ctx, pg = new_page(browser, VIEWPORTS["desktop"], [], [])
        banned = ["100% placement", "guaranteed job", "job guarantee", "placement guarantee",
                  "best institute in india", "govt certified", "government certified",
                  "iso certified", "5000+ students", "10,000 students", "free demo class guaranteed"]
        # the site deliberately *denies* these claims; only flag an occurrence
        # that is NOT inside a denial.
        NEG = ["nahi", "not", "no claim", "koi claim", "jhootha", "nahin", "?"]
        hits = []
        for page in PAGES:
            pg.goto(f"{BASE}/{page}", wait_until="networkidle"); pg.wait_for_timeout(400)
            body = pg.inner_text("body").lower()
            for b in banned:
                start = body.find(b)
                while start != -1:
                    window = body[max(0, start - 160): start + 180]
                    if not any(n in window for n in NEG):
                        hits.append(f"{page}: '{b}' → …{window.strip()[:130]}…")
                    start = body.find(b, start + len(b))
        check("no fabricated placement / guarantee / cert claims", not hits, hits[:4])
        # and the denials must actually be there
        for page, phrase in [("index.html", "placement"), ("faq.html", "job guarantee")]:
            pg.goto(f"{BASE}/{page}", wait_until="networkidle"); pg.wait_for_timeout(300)
            check(f"{page} states placement is NOT guaranteed",
                  "nahi" in pg.inner_text("body").lower())
        pg.goto(f"{BASE}/index.html", wait_until="networkidle"); pg.wait_for_timeout(400)
        body = pg.inner_text("body")
        for need in ["98181 12018", "122101", "Main Sohna Road", "Badshahpur", "2008"]:
            check(f"homepage shows verified fact '{need}'", need in body)
        check("fee disclaimer visible on homepage", "listed" in body.lower() and "confirm" in body.lower())
        check("demo disclaimer in footer", "Demo website" in pg.inner_text(".foot"))
        # external links safe
        unsafe = pg.evaluate("""() => [...document.querySelectorAll('a[target=_blank]')]
              .filter(a => !/noopener/.test(a.rel||'')).map(a=>a.href)""")
        check("all target=_blank links have rel=noopener", not unsafe, unsafe[:4])
        ctx.close()

        # ================= 15. performance budget =========================
        print("\n=== 15. Page weight & load performance ===")
        ctx, pg = new_page(browser, VIEWPORTS["desktop"], [], [])
        for page in ["index.html", "courses.html", "contact.html"]:
            pg.goto(f"{BASE}/{page}", wait_until="networkidle"); pg.wait_for_timeout(500)
            m = pg.evaluate("""() => {
                const rs = performance.getEntriesByType('resource');
                const bytes = rs.reduce((s,r)=>s+(r.transferSize||r.encodedBodySize||0),0);
                const nav = performance.getEntriesByType('navigation')[0] || {};
                return {bytes, reqs: rs.length,
                        domContentLoaded: Math.round(nav.domContentLoadedEventEnd||0),
                        loaded: Math.round(nav.loadEventEnd||0)};
            }""")
            kb = m["bytes"] / 1024
            check(f"{page} → total transfer < 900 KB", kb < 900, f"{kb:.0f} KB / {m['reqs']} requests")
            check(f"{page} → < 40 requests", m["reqs"] < 40, m["reqs"])
            check(f"{page} → DOMContentLoaded < 2.5s", m["domContentLoaded"] < 2500, f"{m['domContentLoaded']}ms")
            check(f"{page} → load < 4s", m["loaded"] < 4000, f"{m['loaded']}ms")
        ctx.close()

        # ================= 16. screenshots ================================
        print("\n=== 16. Screenshots ===")
        for name, vp in VIEWPORTS.items():
            ctx, pg = new_page(browser, vp, [], [])
            pg.goto(f"{BASE}/index.html", wait_until="networkidle"); pg.wait_for_timeout(1400)
            pg.mouse.move(vp["width"] * 0.62, vp["height"] * 0.42)
            pg.wait_for_timeout(700)
            pg.screenshot(path=str(SHOTS / f"01-home-hero-{name}.png"))
            pg.evaluate("window.scrollTo(0, 1250)"); pg.wait_for_timeout(1200)
            pg.screenshot(path=str(SHOTS / f"02-home-courses-{name}.png"))
            pg.evaluate("document.querySelector('#recommender').scrollIntoView()"); pg.wait_for_timeout(1200)
            pg.screenshot(path=str(SHOTS / f"03-home-quiz-{name}.png"))
            pg.goto(f"{BASE}/courses.html", wait_until="networkidle"); pg.wait_for_timeout(1300)
            pg.screenshot(path=str(SHOTS / f"04-courses-{name}.png"), full_page=(name == "desktop"))
            pg.goto(f"{BASE}/contact.html", wait_until="networkidle"); pg.wait_for_timeout(1000)
            pg.screenshot(path=str(SHOTS / f"05-contact-{name}.png"))
            pg.goto(f"{BASE}/about.html", wait_until="networkidle"); pg.wait_for_timeout(1000)
            pg.screenshot(path=str(SHOTS / f"06-about-{name}.png"))
            pg.goto(f"{BASE}/faq.html", wait_until="networkidle"); pg.wait_for_timeout(1000)
            pg.screenshot(path=str(SHOTS / f"07-faq-{name}.png"))
            if name == "mobile":
                pg.goto(f"{BASE}/index.html", wait_until="networkidle"); pg.wait_for_timeout(700)
                pg.click(".burger"); pg.wait_for_timeout(800)
                pg.screenshot(path=str(SHOTS / "08-mobile-drawer.png"))
                pg.keyboard.press("Escape"); pg.wait_for_timeout(600)
                pg.locator("[data-open-course='spoken-english']").first.click(); pg.wait_for_timeout(800)
                pg.screenshot(path=str(SHOTS / "09-mobile-modal.png"))
            if name == "desktop":
                pg.goto(f"{BASE}/courses.html", wait_until="networkidle"); pg.wait_for_timeout(900)
                pg.keyboard.press("Control+k"); pg.wait_for_timeout(600)
                pg.fill(".cmdk input", "excel"); pg.wait_for_timeout(400)
                pg.screenshot(path=str(SHOTS / "10-palette.png"))
                pg.keyboard.press("Escape"); pg.wait_for_timeout(500)
                pg.locator("[data-open-course='python']").first.click(); pg.wait_for_timeout(800)
                pg.screenshot(path=str(SHOTS / "11-modal-course.png"))
            print(f"  shots saved for {name}")
            ctx.close()

        browser.close()

    # ---------------- summary ----------------
    total = len(results)
    passed = sum(1 for _, ok, _ in results if ok)
    failed = [(n, d) for n, ok, d in results if not ok]
    print("\n" + "=" * 68)
    print(f"  {passed}/{total} checks passed" + (f" — {len(failed)} FAILED" if failed else " — all green"))
    print("=" * 68)
    for n, d in failed:
        print("  ✗ " + n + "  →  " + str(d)[:200])
    (ROOT.parent / "tests" / "results.json").write_text(
        json.dumps({"total": total, "passed": passed, "failed": [n for n, _ in failed],
                    "detail": [{"name": n, "ok": ok, "detail": str(d)} for n, ok, d in results]},
                   indent=2, ensure_ascii=False))
    return 1 if failed else 0

if __name__ == "__main__":
    sys.exit(run())
