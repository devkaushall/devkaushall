# Apple's Pizza, Etawah — concept website demo

A premium, self-contained, static website concept for **Apple's Pizza, Etawah** — built as a pitch demo.
No framework, no build step, no backend, no external requests.

> **Status: concept demo.** Every business fact on the page is compiled from public listings and is
> labelled with its source. Nothing here has been confirmed by the outlet yet. See
> `../research/RESEARCH-FINDINGS.md` for the evidence trail and the open questions.

---

## Run it

```bash
# any static server works
python3 -m http.server 8080 --directory site
# → http://localhost:8080
```

Or just open `site/index.html` directly. Everything works from `file://` too — the only
difference is that browsers block local `woff2` loading over `file://` (a browser security rule),
so the page falls back to system serif/sans. On any real host, the fonts load normally.

## Deploy it

Copy the `site/` folder to any static host (Netlify, Cloudflare Pages, GitHub Pages, Hostinger,
cPanel). There is nothing to compile and nothing to configure. The folder is **4.1 MB** (it holds
every image variant), but a visitor only downloads **≈430 KB on desktop / ≈590 KB on mobile**,
because `srcset` picks one size per image.

---

## Files

```
site/
├─ index.html              # the whole page (semantic, one h1, labelled sections)
└─ assets/
   ├─ css/style.css        # design system: tokens, layout, components, responsive, motion
   ├─ js/main.js           # all interactions (vanilla, ~500 lines, no dependencies)
   ├─ fonts/               # Fraunces + Manrope, self-hosted woff2 (SIL OFL)
   └─ img/                 # 6 demo photographs (jpg + webp) + archived wordmark for reference
```

---

## What the concept does differently to the old site

The previous site (`applespizza.in`) was an ordering-app shell: no readable menu, no prices,
no address, no photography, and its last archived state said *"No slot available right now."*
This concept inverts that priority:

| Old site | This concept |
|---|---|
| Order flow first, content unreadable | Content first: menu, prices, location, hours all on one page |
| Nothing for search engines | Semantic HTML + `Restaurant` JSON-LD |
| No menu a visitor can read | All 21 verified pizzas, searchable, filterable, sortable |
| No photography | Original demo photography with honest "Demo visual" labels |
| No local information | Address, coordinates, three phone numbers, directory hours with conflicts shown |
| Broken (`HTTP 500`) | Static files, zero runtime dependencies, works offline |

**What it deliberately does not do:** take orders, take payment, or claim to. Ordering is handed
off to the phone/WhatsApp/Zomato routes the outlet already uses.

---

## Interactions (all functional — nothing decorative)

| Control | What it actually does |
|---|---|
| Scroll progress bar | Tracks real document scroll |
| Sticky header + active link | Highlights the section you're in via IntersectionObserver |
| Hamburger drawer | Opens/closes, closes on link tap, locks page scroll |
| Hero lazy-susan + parallax | Rotating pizza disc, layered parallax on scroll, disabled under `prefers-reduced-motion` |
| Signature card tilt | Pointer-tracked 3D tilt (fine pointers only) |
| Marquee | Verified-only phrases, pauses on hover, static under reduced motion |
| Menu search | Live text filter across name, toppings and description |
| Menu chips | Filters: All / ₹100 / ₹160 / ₹180 / Spicy / House special |
| Menu sort | Menu order, price ascending/descending, A–Z |
| Item drawer | Opens per pizza, ESC to close, focus trapped, background made `inert`, "Next pizza" cycles, 3 pairing suggestions |
| Enquiry list | Add/remove items, +/− quantity, live subtotal, saved in `localStorage`, **builds a real prefilled WhatsApp message**, copy-to-clipboard |
| Topping studio | 10 real menu toppings painted onto an SVG pizza, "Surprise me", "Clear the pie" |
| Hours table | Four directory sources side by side, conflicts stated openly |
| FAQ accordion | 7 questions answered strictly from verified data |
| Concept note dialog | The owner-facing rationale, opened from 4 places |
| Demo ribbon | Dismissible, remembers the choice for the session |
| Sticky mobile bar | Menu / Call / WhatsApp / Directions |
| Toast | Confirms every add, copy, clear and reset |

---

## Verification (evidence, not claims)

Two automated Playwright suites drive a real Chromium browser:

```bash
npm i -D playwright jsdom html-validate && npx playwright install chromium
node tests/quality.js     # 22 checks
node tests/audit.js       # 92 checks
npx html-validate site/index.html
```

| Suite | What it covers | Result |
|---|---|---|
| `tests/audit.js` | 6 viewports (320→1920), all interactions, console, overflow | **92 / 92** |
| `tests/quality.js` | fonts, WCAG-AA contrast, tap targets, a11y, motion, `file://` | **22 / 22** |
| `tests/a11y.js` | **axe-core** on the page at 2 widths + drawer, enquiry sheet, concept dialog | **5 / 5 clean** |
| `tests/crossbrowser.js` | identical interaction run in **Chromium and Firefox** + 15 feature-support probes | **32 / 32** |
| `tests/perf.js` | LCP, FCP, CLS, request count, payload, srcset resolution | **8 / 8** |
| `tests/hero-reveal.js` | hero text visible after deep-scroll return (reveal-transform regression guard) | pass |
| `html-validate` (recommended preset) | markup correctness | **0 problems** |
| Console errors / failed requests / external requests | across every run | **0 / 0 / 0** |

**Measured performance** (Chromium, localhost — measures render + payload cost, not real network latency):

| | FCP | LCP | CLS | Asset bytes | Requests |
|---|---|---|---|---|---|
| Desktop 1440 | 310 ms | 1314 ms | **0** | 427 KB *(baseline 1439 KB → −70%)* | 12 |
| Mobile 390 | 199 ms | 1130 ms | **0** | 591 KB | 12 |

Images ship in **6 sizes × WebP/JPEG** via `srcset`, so a phone pulls ~50 KB where a desktop pulls ~90 KB.

**Browser coverage — be precise about this:** verified end-to-end in **Chromium 129** and **Firefox 130**
(both engines: same results, zero console errors). **WebKit/Safari could not be executed** in this
environment — its build needs `libicu 66` / `libwebp.so.6`, which Debian 13 no longer ships. What I did
instead: all `backdrop-filter` declarations are `-webkit-` prefixed with the standard property kept,
`appearance` is prefixed, and the design uses no `dvh`, subgrid, `:has()` or similar bleeding-edge
features. **Safari/iOS should still be checked on a real device before launch** — this is the one
honest gap left in the verification.

Screenshots from every run are in `tests/shots/`.

Bugs found and fixed during verification, for the record:

1. `renderList()` crash from a stray variable reference — broke the enquiry sheet *and* the WhatsApp link.
2. "Copy list" handler attached before the button existed in the DOM.
3. Five colour-contrast failures (muted text, hero eyebrow on charcoal, "House special" tag).
4. Tap targets under 36 px in the ribbon and footer.
5. `display:none` on mobile button labels removed their accessible names.
6. `<section>` elements used inside a dialog (not landmarks there).
7. 28 `aria-label` misuses on non-interactive elements.
8. Schematic-map road paths rendering as solid black (missing `fill="none"`).
9. **Self-inflicted, caught by instrumentation:** the responsive `srcset` I added pointed the 4th
   signature card at hero variants I hadn't generated — a broken image on mobile. Fixed, and the perf
   suite now asserts every displayed image resolves.
10. axe-core: brand links had `aria-label`s that dropped their visible text
    (`label-content-name-mismatch`), and the mobile action bar wasn't a landmark.
11. The item drawer's "Add" button didn't refresh its label after adding (no live feedback).

---

## Before this goes live — replace these

1. **Photography** — all six images are original demo visuals, not the outlet's food.
2. **Wordmark** — the mark is a placeholder (a reference copy of the real blue wordmark is at
   `assets/img/logo-archived-2025.jpg`); swap in the real logo file.
3. **Hours** — currently four disagreeing directory values, shown as such. Needs one real answer.
4. **Trading status & outlets** — see the research file; a second Ashok Nagar listing exists and
   Restaurant Guru flags the business as possibly closed.
5. **Ordering links** — confirm whether the Zomato / Swiggy / magicpin listings are still live
   before linking to them (currently linked to Zomato only, with its rating shown).
6. **Menu gaps** — garlic bread, desserts and beverages appear only in directory photo tags, with
   no verified items or prices, so they are shown as "awaiting confirmation".
7. **Remove the demo framing** (the ribbon, "Demo visual" tags and the concept dialog) once the
   content is owner-approved.
8. **Domain** — `applespizza.in` currently returns a server error; hosting/DNS needs attention.
