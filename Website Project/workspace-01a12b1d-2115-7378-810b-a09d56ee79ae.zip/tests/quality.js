/* Deep quality audit: fonts, contrast, tap targets, a11y, external requests */
const { chromium } = require('playwright');
const fs = require('fs');

const URL = process.env.URL || 'http://localhost:8080/';
const results = [];
const log = (ok, name, detail = '') => {
  results.push({ ok, name, detail });
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
};

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await ctx.newPage();

  const external = [];
  page.on('request', r => {
    const u = r.url();
    if (!u.startsWith('http://localhost') && !u.startsWith('data:') && !u.startsWith('blob:')) external.push(u);
  });

  await page.goto(URL, { waitUntil: 'load' });
  await page.waitForTimeout(600);
  await page.evaluate(() => document.fonts.ready);

  /* ---------- fonts ---------- */
  const fonts = await page.evaluate(() => {
    const g = s => { const el = document.querySelector(s); return el ? getComputedStyle(el).fontFamily : null; };
    return {
      h1: g('#hero-h'), h2: g('#menu-h'), h3: g('.item__name'), brand: g('.brand__name'),
      body: g('body'), chip: g('.chip-btn'),
      loadedFraunces: document.fonts.check('600 2rem Fraunces'),
      loadedFrauncesItalic: document.fonts.check('italic 600 1rem Fraunces'),
      loadedManrope: document.fonts.check('500 1rem Manrope')
    };
  });
  log(/Fraunces/.test(fonts.h1) && fonts.loadedFraunces, 'Fraunces loaded for display type', fonts.h1);
  log(/Fraunces/.test(fonts.h3) && fonts.loadedFraunces, 'Fraunces applied to menu item names', fonts.h3);
  log(/Manrope/.test(fonts.body) && fonts.loadedManrope, 'Manrope applied to body', fonts.body);
  log(fonts.loadedFrauncesItalic, 'Fraunces italic axis available');
  log(external.length === 0, 'zero external network requests', external.slice(0, 4).join(', ') || 'self-contained');

  /* ---------- anchors ---------- */
  const anchors = await page.evaluate(() => {
    const bad = [];
    document.querySelectorAll('a[href^="#"]').forEach(a => {
      const id = a.getAttribute('href').slice(1);
      if (id && !document.getElementById(id)) bad.push(a.getAttribute('href') + ' → ' + (a.textContent || '').trim().slice(0, 24));
    });
    return bad;
  });
  log(anchors.length === 0, 'every in-page link resolves to a real section', anchors.join(' , '));

  /* ---------- duplicate ids + labels + alt ---------- */
  const a11y = await page.evaluate(() => {
    const ids = {}, dupes = [];
    document.querySelectorAll('[id]').forEach(el => { if (ids[el.id]) dupes.push(el.id); ids[el.id] = 1; });
    const noAlt = [...document.querySelectorAll('img')].filter(i => i.getAttribute('alt') === null).length;
    const emptyAlt = [...document.querySelectorAll('img')].filter(i => i.getAttribute('alt') === '').length;
    const ctrls = [...document.querySelectorAll('input,select,button')];
    const unlabelled = ctrls.filter(c => {
      if (c.tagName === 'BUTTON') return !(c.textContent.trim() || c.getAttribute('aria-label'));
      const id = c.id;
      return !(id && document.querySelector(`label[for="${id}"]`)) && !c.getAttribute('aria-label');
    }).map(c => c.tagName + '#' + (c.id || c.className));
    const btnsNoName = [...document.querySelectorAll('button')].filter(b => !b.textContent.trim() && !b.getAttribute('aria-label')).length;
    return { dupes, noAlt, emptyAlt, unlabelled, btnsNoName, imgs: document.querySelectorAll('img').length };
  });
  log(a11y.dupes.length === 0, 'no duplicate element ids', a11y.dupes.join(','));
  log(a11y.noAlt === 0, 'all images carry an alt attribute', `${a11y.imgs} imgs, ${a11y.emptyAlt} decorative (empty alt)`);
  log(a11y.unlabelled.length === 0, 'all inputs/selects/buttons have accessible names', a11y.unlabelled.join(' , '));
  log(a11y.btnsNoName === 0, 'no unnamed buttons', String(a11y.btnsNoName));

  /* ---------- landmarks & headings ---------- */
  const struct = await page.evaluate(() => {
    const hs = [...document.querySelectorAll('h1,h2,h3')].map(h => Number(h.tagName[1]));
    let jumps = 0;
    for (let i = 1; i < hs.length; i++) if (hs[i] - hs[i - 1] > 1) jumps++;
    return {
      h1: document.querySelectorAll('h1').length, jumps,
      landmarks: { header: !!document.querySelector('header'), main: !!document.querySelector('main'), footer: !!document.querySelector('footer'), nav: document.querySelectorAll('nav').length },
      sectionsWithLabel: [...document.querySelectorAll('main > section, header + section')].filter(s => s.hasAttribute('aria-labelledby') || s.hasAttribute('aria-label')).length,
      sections: document.querySelectorAll('main > section').length,
      nestedSections: document.querySelectorAll('section section').length
    };
  });
  log(struct.h1 === 1, 'exactly one h1', String(struct.h1));
  log(struct.jumps === 0, 'no heading-level jumps', String(struct.jumps));
  log(struct.landmarks.header && struct.landmarks.main && struct.landmarks.footer, 'header/main/footer landmarks present');
  log(struct.sectionsWithLabel === struct.sections && struct.nestedSections === 0, `every <section> is labelled (${struct.sectionsWithLabel}/${struct.sections}, nested ${struct.nestedSections})`);

  /* ---------- contrast ---------- */
  const contrast = await page.evaluate(() => {
    const lum = c => {
      const [r, g, b] = c.map(v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); });
      return 0.2126 * r + 0.7152 * g + 0.0722 * b;
    };
    const parse = s => { const m = s.match(/[\d.]+/g); return m ? m.slice(0, 3).map(Number) : null; };
    const bgOf = el => {
      let n = el;
      while (n) {
        const cs = getComputedStyle(n);
        const bg = cs.backgroundColor;
        if (bg && bg !== 'transparent' && !/rgba\(0, 0, 0, 0\)/.test(bg)) {
          const p = parse(bg);
          const a = (bg.match(/[\d.]+/g) || [])[3];
          if (a === undefined || Number(a) > 0.85) return p;
        }
        n = n.parentElement;
      }
      return [251, 241, 222];
    };
    const ratio = (f, b) => { const l1 = lum(f), l2 = lum(b); return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05); };
    const out = [];
    const sel = 'p, h1, h2, h3, li, a, span, strong, em, td, th, figcaption, blockquote, button, dt, dd, label, summary';
    document.querySelectorAll(sel).forEach(el => {
      if (!el.textContent.trim()) return;
      const r = el.getBoundingClientRect();
      if (!r.width || !r.height) return;
      if (el.closest('[hidden]') || el.closest('.sheet[hidden]')) return;
      const cs = getComputedStyle(el);
      if (cs.visibility === 'hidden' || Number(cs.opacity) < 0.6) return;
      const fg = parse(cs.color); if (!fg) return;
      const size = parseFloat(cs.fontSize);
      const bold = Number(cs.fontWeight) >= 700;
      const large = size >= 24 || (size >= 18.66 && bold);
      const need = large ? 3 : 4.5;
      const cr = ratio(fg, bgOf(el));
      if (cr < need) out.push({
        sel: el.tagName.toLowerCase() + '.' + String(el.className).split(' ')[0],
        txt: el.textContent.trim().slice(0, 26), cr: cr.toFixed(2), need, size: Math.round(size)
      });
    });
    return out;
  });
  const worst = contrast.slice(0, 8);
  log(contrast.length === 0, 'text contrast meets WCAG AA', worst.map(c => `${c.sel}(${c.txt}) ${c.cr}<${c.need}`).join(' | '));

  /* ---------- tap targets on mobile ---------- */
  const mctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true });
  const mp = await mctx.newPage();
  await mp.goto(URL, { waitUntil: 'load' });
  await mp.waitForTimeout(500);
  const targets = await mp.evaluate(() => {
    const bad = [];
    document.querySelectorAll('a,button,summary,input,select').forEach(el => {
      if (el.closest('[hidden]') || el.closest('.sheet[hidden]')) return;
      const r = el.getBoundingClientRect();
      if (!r.width || !r.height) return;
      if (el.classList.contains('skip-link')) return;
      // WCAG 2.5.8 exempts targets inline within a sentence
      const inline = el.matches('a') && el.closest('p, li, figcaption, dd');
      if (inline) return;
      if (r.height < 36 || r.width < 30) bad.push(`${el.tagName.toLowerCase()}.${String(el.className).split(' ')[0]} ${Math.round(r.width)}×${Math.round(r.height)}`);
    });
    return bad;
  });
  log(targets.length === 0, 'mobile tap targets ≥ 36px', targets.slice(0, 6).join(' , '));

  /* ---------- image weight & formats ---------- */
  // force-load deferred images instead of scrolling (the hero disc never stops moving)
  await mp.evaluate(() => document.querySelectorAll('img').forEach(i => { i.loading = 'eager'; }));
  await mp.waitForTimeout(1500);
  await mp.evaluate(() => Promise.all([...document.querySelectorAll('img')].map(i => i.decode().catch(() => null))));
  const imgs = await mp.evaluate(async () => {
    const out = [];
    for (const i of document.querySelectorAll('img')) {
      out.push({ src: i.currentSrc.split('/').pop(), w: i.naturalWidth, h: i.naturalHeight, fmt: i.currentSrc.split('.').pop() });
    }
    return out;
  });
  const allLoaded = imgs.every(i => i.w > 0);
  log(allLoaded, 'all images decoded successfully (after scroll)', imgs.map(i => `${i.src}(${i.w}×${i.h})`).join(' '));

  /* ---------- accessible names at mobile width ---------- */
  const mobileNames = await mp.evaluate(() => {
    const out = [];
    document.querySelectorAll('button, a[href]').forEach(el => {
      const r = el.getBoundingClientRect();
      if (!r.width || !r.height) return;
      const name = (el.getAttribute('aria-label') || el.textContent || '').trim() ||
        (el.querySelector('img') ? (el.querySelector('img').getAttribute('alt') || '') : '');
      if (!name) out.push(el.tagName.toLowerCase() + '.' + String(el.className).split(' ')[0]);
    });
    return out;
  });
  log(mobileNames.length === 0, 'no unnamed controls at 390px', mobileNames.join(', ') || 'all named');

  /* ---------- static file:// smoke test (hosting without a server) ---------- */
  const fctx = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const fp = await fctx.newPage();
  const ferr = [];
  fp.on('pageerror', e => ferr.push(e.message));
  fp.on('requestfailed', r => ferr.push('failed: ' + r.url().split('/').pop()));
  await fp.goto('file:///home/user/site/index.html', { waitUntil: 'load' });
  await fp.waitForTimeout(700);
  const fstate = await fp.evaluate(() => ({
    cards: document.querySelectorAll('.item').length,
    font: getComputedStyle(document.querySelector('#hero-h')).fontFamily.indexOf('Fraunces') > -1,
    css: getComputedStyle(document.querySelector('.hero')).backgroundColor,
    logo: !!document.querySelector('.brand__mark svg')
  }));
  const fontErrOnly = ferr.every(e => /woff2/.test(e));
  log(fstate.cards === 21 && fstate.css === 'rgb(21, 16, 14)' && fstate.logo && fontErrOnly,
    'opens from file:// with graceful system-font fallback',
    JSON.stringify(fstate) + ' | blocked on file://: ' + ferr.join(',') + ' (browser security rule; any static host serves them)');
  log(imgs.some(i => i.fmt === 'webp'), 'webp delivered where the browser supports it', imgs.map(i => i.fmt).join(','));

  /* ---------- reduced motion sanity ---------- */
  const rctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, reducedMotion: 'reduce' });
  const rp = await rctx.newPage();
  await rp.goto(URL, { waitUntil: 'load' });
  await rp.waitForTimeout(400);
  const rm = await rp.evaluate(() => {
    const hidden = [...document.querySelectorAll('[data-reveal]')].filter(n => getComputedStyle(n).opacity === '0').length;
    const discAnim = getComputedStyle(document.querySelector('#heroDisc img')).animationDuration;
    return { hidden, discAnim, total: document.querySelectorAll('[data-reveal]').length };
  });
  log(rm.hidden === 0, 'reduced motion: no content left invisible', `${rm.total} reveal nodes, ${rm.hidden} hidden`);
  log(parseFloat(rm.discAnim) < 0.01, 'reduced motion: hero rotation disabled', rm.discAnim);

  await browser.close();
  const failed = results.filter(r => !r.ok).length;
  fs.writeFileSync('/home/user/tests/quality-results.json', JSON.stringify(results, null, 2));
  console.log(`\n==== ${results.length - failed}/${results.length} quality checks passed ====`);
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(2); });
