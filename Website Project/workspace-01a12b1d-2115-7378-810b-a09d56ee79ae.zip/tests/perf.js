/* Real-metrics performance audit: LCP, CLS, FCP, payload, request count.
   NOTE: runs against localhost, so this measures render + payload cost, not real network latency. */
const { chromium } = require('playwright');
const fs = require('fs');

const URL = process.env.URL || 'http://localhost:8080/';
const label = process.env.LABEL || 'current';
const results = [];
const log = (ok, name, detail = '') => {
  results.push({ ok, name, detail });
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
};

async function measure(browserType, device, label2) {
  const b = await browserType.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const ctxOpts = device === 'mobile'
    ? { viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, userAgent: 'Mozilla/5.0 (Linux; Android 13; Pixel 6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122 Mobile Safari/537.36' }
    : { viewport: { width: 1440, height: 900 } };
  const ctx = await b.newContext(ctxOpts);

  // observe LCP + CLS before any page script runs
  const metrics = {};
  await ctx.addInitScript(() => {
    window.__perf = { lcp: 0, cls: 0, lcpEl: '' };
    try {
      new PerformanceObserver(l => { for (const e of l.getEntries()) { window.__perf.lcp = e.startTime; window.__perf.lcpEl = (e.element && (e.element.tagName + (e.element.className ? '.' + String(e.element.className).split(' ')[0] : ''))) || e.url || '?'; } }).observe({ type: 'largest-contentful-paint', buffered: true });
      new PerformanceObserver(l => { for (const e of l.getEntries()) if (!e.hadRecentInput) window.__perf.cls += e.value; }).observe({ type: 'layout-shift', buffered: true });
    } catch (e) { /* older engines */ }
  });

  const requests = [];
  const page = await ctx.newPage();
  page.on('response', async r => {
    try {
      const h = r.headers();
      requests.push({ url: r.url().split('/').pop() || r.url(), type: h['content-type'] || '', len: Number(h['content-length'] || 0) });
    } catch (e) {}
  });

  const t0 = Date.now();
  await page.goto(URL, { waitUntil: 'load' });
  const loadMs = Date.now() - t0;
  await page.waitForTimeout(1200);                 // let LCP + CLS settle
  await page.evaluate(() => document.fonts.ready);

  const data = await page.evaluate(() => {
    const nav = performance.getEntriesByType('navigation')[0] || {};
    const paint = performance.getEntriesByType('paint').reduce((a, p) => (a[p.name] = Math.round(p.startTime), a), {});
    const res = performance.getEntriesByType('resource');
    const byType = {};
    let total = 0;
    res.forEach(r => {
      const ext = (r.name.split('.').pop() || '').split('?')[0];
      byType[ext] = byType[ext] || { n: 0, bytes: 0 };
      byType[ext].n++; byType[ext].bytes += (r.transferSize || r.encodedBodySize || 0);
      total += (r.transferSize || r.encodedBodySize || 0);
    });
    return {
      fcp: paint['first-contentful-paint'] || 0,
      lcp: Math.round(window.__perf.lcp),
      lcpEl: window.__perf.lcpEl,
      cls: Number(window.__perf.cls.toFixed(4)),
      domContentLoaded: Math.round(nav.domContentLoadedEventEnd || 0),
      load: Math.round(nav.loadEventEnd || 0),
      resources: res.length,
      assetBytes: total,
      byType,
      imagesLoaded: [...document.querySelectorAll('img')].map(i => ({ f: i.currentSrc.split('/').pop(), w: Math.round(i.getBoundingClientRect().width), nw: i.naturalWidth }))
    };
  });
  // second pass: force-load every image so we can verify srcset picks actually resolve
  await page.evaluate(() => document.querySelectorAll('img').forEach(i => { i.loading = 'eager'; }));
  await page.waitForTimeout(1500);
  const imgHealth = await page.evaluate(() => [...document.querySelectorAll('img')].map(i => ({
    f: i.currentSrc.split('/').pop() || '(none)', nw: i.naturalWidth, css: Math.round(i.getBoundingClientRect().width)
  })));
  await b.close();
  return { ...data, loadMs, device, requests: requests.length, imgHealth };
}

(async () => {
  const out = {};
  for (const [dev, dtype] of [['desktop', 'desktop'], ['mobile', 'mobile']]) {
    const m = await measure(chromium, dtype, dev);
    out[dev] = m;
    console.log(`\n── ${dev} (${label}) ─────────────────────────`);
    console.log(`   FCP ${m.fcp}ms · LCP ${m.lcp}ms (${m.lcpEl}) · CLS ${m.cls} · DCL ${m.domContentLoaded}ms · load ${m.load}ms`);
    console.log(`   requests ${m.requests} · asset bytes ${(m.assetBytes / 1024).toFixed(0)} KB`);
    console.log(`   images: ` + m.imagesLoaded.map(i => `${i.f}→${i.w}px(css, ${i.nw}px src)`).join(' | '));
    log(m.lcp > 0 && m.lcp < 2500, `[${dev}/${label}] LCP under 2.5s`, m.lcp + 'ms');
    log(m.cls < 0.1, `[${dev}/${label}] CLS under 0.1`, String(m.cls));
    log(m.fcp > 0 && m.fcp < 1800, `[${dev}/${label}] FCP under 1.8s`, m.fcp + 'ms');
    const broken = m.imgHealth.filter(i => i.nw === 0);
    log(broken.length === 0, `[${dev}/${label}] every image resolves (after eager pass)`,
      broken.length ? broken.map(b => b.f + ' BROKEN').join(', ') : m.imgHealth.map(i => i.f.replace(/^(hero-pizza|paneer-corn|farmhouse|margherita|outlet-vibe)/, '$1')).join(', '));
  }
  fs.writeFileSync(`/home/user/tests/perf-${label}.json`, JSON.stringify(out, null, 2));
  const failed = results.filter(r => !r.ok).length;
  console.log(`\n==== perf [${label}]: ${results.length - failed}/${results.length} passed ====`);
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(2); });
