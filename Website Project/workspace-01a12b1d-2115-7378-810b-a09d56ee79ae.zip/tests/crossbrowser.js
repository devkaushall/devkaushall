/* Cross-engine parity: identical interaction run in Chromium and Firefox,
   plus explicit feature-support checks for the CSS/JS the concept relies on. */
const pw = require('playwright');
const fs = require('fs');

const URL = process.env.URL || 'http://localhost:8080/';
const OUT = '/home/user/tests/shots';
const results = [];
const log = (ok, name, detail = '') => {
  results.push({ ok, name, detail });
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
};

async function run(browserName, launchOpts, label) {
  let browser;
  try { browser = await pw[browserName].launch(launchOpts); }
  catch (e) { log(false, `[${label}] browser launches`, String(e.message).split('\n')[0].slice(0, 90)); return; }

  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await ctx.newPage();
  const errors = [], failed = [];
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('requestfailed', r => failed.push(r.url().split('/').pop()));
  page.on('response', r => { if (r.status() >= 400) failed.push(r.status() + ' ' + r.url().split('/').pop()); });

  const resp = await page.goto(URL, { waitUntil: 'load' });
  await page.waitForTimeout(900);
  log(resp && resp.status() === 200, `[${label}] page loads`, 'HTTP ' + (resp && resp.status()));
  log(errors.length === 0, `[${label}] no console errors`, errors.slice(0, 2).join(' | ') || 'clean');
  log(failed.length === 0, `[${label}] no failed requests`, failed.slice(0, 3).join(', ') || 'clean');

  /* feature support this design depends on */
  const feat = await page.evaluate(() => {
    const s = p => CSS.supports(p);
    return {
      sticky: s('position: sticky'),
      aspect: s('aspect-ratio: 1/1'),
      backdrop: s('backdrop-filter: blur(4px)') || s('-webkit-backdrop-filter: blur(4px)'),
      conic: s('background: repeating-conic-gradient(from 0deg, red 0 10deg, blue 10deg 20deg)'),
      mask: s('mask: radial-gradient(#000, transparent)') || s('-webkit-mask: radial-gradient(#000, transparent)'),
      grid: s('display: grid'),
      clamp: s('font-size: clamp(1rem, 2vw, 2rem)'),
      inert: 'inert' in HTMLElement.prototype,
      io: 'IntersectionObserver' in window,
      details: 'open' in document.createElement('details'),
      fonts: document.fonts.check('600 2rem Fraunces'),
      scrollBehavior: s('scroll-behavior: smooth'),
      lcp: 'PerformanceObserver' in window && PerformanceObserver.supportedEntryTypes.includes('largest-contentful-paint'),
      dvh: false,
      gapFlex: s('gap: 1rem')
    };
  });
  const unsupported = Object.entries(feat).filter(([k, v]) => (k === 'dvh' ? false : String(v) === 'false'));
  log(unsupported.length === 0, `[${label}] all required CSS/JS features supported`,
    unsupported.length ? unsupported.map(([k]) => k).join(', ') : Object.keys(feat).length + ' features ok');
  log(feat.inert, `[${label}] inert attribute supported (dialog background lockout)`, String(feat.inert));
  log(feat.fonts, `[${label}] self-hosted Fraunces loads`, String(feat.fonts));

  /* interactions */
  await page.click('[data-filter="t160"]');
  await page.waitForTimeout(250);
  log((await page.$$eval('.item:not(.is-dim)', e => e.length)) === 7, `[${label}] filter ₹160 → 7 items`);
  await page.click('[data-filter="all"]');
  await page.fill('#menuSearch', 'jalapeno');
  await page.waitForTimeout(300);
  const searchN = await page.$$eval('.item:not(.is-dim)', e => e.length);
  log(searchN === 7, `[${label}] search "jalapeno" → 7 items (verified count)`, String(searchN));
  await page.fill('#menuSearch', '');
  await page.selectOption('#sortSelect', 'price-asc');
  await page.waitForTimeout(250);
  log((await page.$eval('.item:not(.is-dim)', e => e.dataset.price)) === '100', `[${label}] sort price-asc puts ₹100 first`);
  await page.selectOption('#sortSelect', 'default');

  await page.click('[data-view="apples-pizza"]');
  await page.waitForTimeout(400);
  const drawer = await page.isVisible('#dialogItem');
  log(drawer, `[${label}] item drawer opens`);
  const drawerLabelBefore = await page.textContent('#drawerAdd');
  await page.click('#drawerAdd');
  await page.waitForTimeout(300);
  const drawerLabelAfter = await page.textContent('#drawerAdd');
  log(/Added/.test(drawerLabelAfter) && drawerLabelBefore !== drawerLabelAfter,
    `[${label}] drawer Add button updates its label`, `${drawerLabelBefore.trim()} → ${drawerLabelAfter.trim()}`);
  await page.keyboard.press('Escape');
  await page.waitForTimeout(300);
  const restored = await page.$eval('main', el => !el.hasAttribute('inert'));
  log(restored && !(await page.isVisible('#dialogItem')), `[${label}] Escape closes drawer and restores the page`);

  await page.click('#enquiryBtn');
  await page.waitForTimeout(400);
  const total = await page.textContent('#enqTotal');
  const wa = await page.getAttribute('#enqWa', 'href');
  log(total === '₹180' && wa.startsWith('https://wa.me/917252009090?text='),
    `[${label}] enquiry total + WhatsApp handoff`, `${total} · ${wa.slice(0, 46)}…`);
  await page.screenshot({ path: `${OUT}/cross-${label}-enquiry.png` });
  await page.click('#enqClear');
  await page.keyboard.press('Escape');
  await page.waitForTimeout(300);

  await page.click('.topping[data-topping="corn"]');
  await page.click('.topping[data-topping="onion"]');
  await page.waitForTimeout(300);
  const shapes = await page.$$eval('#toppingLayer ellipse, #toppingLayer path, #toppingLayer rect, #toppingLayer circle', e => e.length);
  log(shapes >= 20, `[${label}] topping studio paints shapes`, shapes + ' shapes');

  await page.evaluate(() => document.querySelector('#outlet').scrollIntoView());
  await page.waitForTimeout(500);
  await page.screenshot({ path: `${OUT}/cross-${label}-outlet.png` });
  await page.evaluate(() => window.scrollTo(0, 0));
  await page.waitForTimeout(400);
  await page.screenshot({ path: `${OUT}/cross-${label}-hero.png` });

  await ctx.close();

  /* mobile pass */
  const mctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: false });
  const mp = await mctx.newPage();
  await mp.goto(URL, { waitUntil: 'load' });
  await mp.waitForTimeout(600);
  await mp.click('#navToggle');
  await mp.waitForTimeout(350);
  const navOpen = await mp.isVisible('#navDrawer');
  await mp.click('#navDrawer a[href="#menu"]');
  await mp.waitForTimeout(700);
  const scrolled = await mp.evaluate(() => window.scrollY);
  log(navOpen && scrolled > 400 && !(await mp.isVisible('#navDrawer')),
    `[${label}] mobile nav opens, navigates, closes`, 'scrollY ' + Math.round(scrolled));
  const bar = await mp.evaluate(() => {
    const el = document.querySelector('#mobileBar');
    return { display: getComputedStyle(el).display, links: el.querySelectorAll('a').length, tag: el.tagName };
  });
  log(bar.display === 'flex' && bar.links === 4, `[${label}] mobile action bar visible with 4 actions`, JSON.stringify(bar));
  await mp.screenshot({ path: `${OUT}/cross-${label}-mobile.png` });
  await mctx.close();
  await browser.close();
}

(async () => {
  await run('chromium', { args: ['--no-sandbox', '--disable-dev-shm-usage'] }, 'chromium');
  console.log('');
  await run('firefox', {}, 'firefox');
  const failed = results.filter(r => !r.ok).length;
  fs.writeFileSync('/home/user/tests/crossbrowser-results.json', JSON.stringify(results, null, 2));
  console.log(`\n==== cross-engine: ${results.length - failed}/${results.length} checks passed ====`);
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(2); });
