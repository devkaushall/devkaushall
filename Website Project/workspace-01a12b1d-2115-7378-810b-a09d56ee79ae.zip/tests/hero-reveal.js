const pw = require('playwright');
(async () => {
  for (const n of ['chromium', 'firefox']) {
    const b = await pw[n].launch({ args: n === 'chromium' ? ['--no-sandbox','--disable-dev-shm-usage'] : [] });
    const p = await (await b.newContext({ viewport: { width: 1440, height: 900 } })).newPage();
    await p.goto('http://localhost:8080/', { waitUntil: 'load' });
    await p.waitForTimeout(800);
    // simulate arriving from a deep scroll, like the previous screenshot did
    await p.evaluate(() => document.querySelector('#outlet').scrollIntoView());
    await p.waitForTimeout(600);
    await p.addStyleTag({ content: 'html{scroll-behavior:auto !important}' });
    await p.evaluate(() => window.scrollTo(0, 0));
    await p.waitForTimeout(1500);
    const s = await p.evaluate(() => {
      const h1 = document.querySelector('#hero-h'), copy = document.querySelector('.hero__copy');
      const cs = getComputedStyle(h1), cc = getComputedStyle(copy);
      const r = h1.getBoundingClientRect();
      return {
        h1Opacity: cs.opacity, h1Color: cs.color, h1Top: Math.round(r.top), h1H: Math.round(r.height),
        copyTransform: cc.transform, copyOpacity: cc.opacity,
        heroBg: getComputedStyle(document.querySelector('.hero')).backgroundColor,
        revealClass: h1.classList.contains('is-in'), scrollY: window.scrollY
      };
    });
    console.log(n, JSON.stringify(s));
    await p.screenshot({ path: `/home/user/tests/shots/final-${n}-top.png` });
    await b.close();
  }
})();
