const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox','--disable-dev-shm-usage'] });
  const targets = [
    ['story', '#story'], ['numbers', '#numbers'], ['outlet', '#outlet'],
    ['order', '#order'], ['faq', '#faq'], ['menu-notes', '.menu-notes'], ['signatures', '#signatures']
  ];
  for (const [w, tag] of [[1440, 'd'], [390, 'm']]) {
    const ctx = await b.newContext({ viewport: { width: w, height: 900 } });
    const p = await ctx.newPage();
    await p.goto('http://localhost:8080/', { waitUntil: 'load' });
    await p.addStyleTag({ content: '[data-reveal]{opacity:1 !important;transform:none !important} .disc img{animation:none !important}' });
    await p.waitForTimeout(600);
    for (const [name, sel] of targets) {
      const el = await p.$(sel);
      if (!el) { console.log('MISSING', sel); continue; }
      await el.scrollIntoViewIfNeeded();
      await p.waitForTimeout(350);
      await el.screenshot({ path: `/home/user/tests/shots/${tag}-${name}.png` });
    }
    await ctx.close();
  }
  await b.close();
  console.log('section shots done');
})();
