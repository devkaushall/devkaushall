/* Concept-site audit: console errors, overflow, missing assets, interactions, screenshots */
const { chromium } = require('playwright');
const fs = require('fs');

const URL = process.env.URL || 'http://localhost:8080/';
const OUT = '/home/user/tests/shots';
fs.mkdirSync(OUT, { recursive: true });

const VIEWPORTS = [
  { name: 'mobile-320', width: 320, height: 720 },
  { name: 'mobile-390', width: 390, height: 844 },
  { name: 'tablet-768', width: 768, height: 1024 },
  { name: 'laptop-1024', width: 1024, height: 768 },
  { name: 'desktop-1440', width: 1440, height: 900 },
  { name: 'wide-1920', width: 1920, height: 1080 }
];

const results = [];
const log = (ok, name, detail = '') => {
  results.push({ ok, name, detail });
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
};

(async () => {
  const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });

  for (const vp of VIEWPORTS) {
    const ctx = await browser.newContext({ viewport: { width: vp.width, height: vp.height }, deviceScaleFactor: 1 });
    const page = await ctx.newPage();
    const errors = [], failed = [];
    page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
    page.on('pageerror', e => errors.push('pageerror: ' + e.message));
    page.on('requestfailed', r => failed.push(r.url() + ' :: ' + (r.failure() || {}).errorText));
    page.on('response', r => { if (r.status() >= 400) failed.push(r.status() + ' ' + r.url()); });

    const resp = await page.goto(URL, { waitUntil: 'load' });
    await page.waitForTimeout(500);
    log(resp.status() === 200, `[${vp.name}] page loads`, `HTTP ${resp.status()}`);
    log(errors.length === 0, `[${vp.name}] no console errors`, errors.slice(0, 3).join(' | '));
    log(failed.length === 0, `[${vp.name}] no failed requests`, failed.slice(0, 3).join(' | '));

    // horizontal overflow — real test: can the page actually scroll sideways?
    const overflow = await page.evaluate(() => {
      const de = document.documentElement;
      const before = window.scrollX;
      window.scrollTo(9999, 0);
      const after = window.scrollX;
      window.scrollTo(before, window.scrollY);
      const clipped = (el) => {
        let n = el.parentElement;
        while (n && n !== document.body) {
          const cs = getComputedStyle(n);
          if (cs.overflowX === 'hidden' || cs.overflowX === 'clip') return true;
          n = n.parentElement;
        }
        return false;
      };
      const vw = de.clientWidth, bad = [];
      document.querySelectorAll('body *').forEach(el => {
        const r = el.getBoundingClientRect();
        if (!r.width || r.height < 3) return;
        if (r.right > vw + 1 && !clipped(el) && getComputedStyle(el).position !== 'fixed')
          bad.push(el.tagName.toLowerCase() + '.' + String(el.className).split(' ')[0] + ' right=' + Math.round(r.right));
      });
      return { canScrollX: after > 0, bad: bad.slice(0, 5) };
    });
    log(!overflow.canScrollX && overflow.bad.length === 0, `[${vp.name}] no horizontal overflow`,
      overflow.canScrollX ? 'PAGE SCROLLS SIDEWAYS' : (overflow.bad.join(' , ') || 'clean'));

    // key elements visible & sized
    const geom = await page.evaluate(() => {
      const pick = s => { const el = document.querySelector(s); if (!el) return null; const r = el.getBoundingClientRect();
        return { w: Math.round(r.width), h: Math.round(r.height), vis: getComputedStyle(el).visibility }; };
      return {
        hero: pick('.hero'), h1: pick('#hero-h'), disc: pick('#heroDisc'), menuGrid: pick('#menuGrid'),
        firstCard: pick('.item'), footer: pick('.footer'), mobilebar: pick('.mobilebar'),
        header: pick('.header'), studio: pick('.pizza'), map: pick('.map'),
        cards: document.querySelectorAll('.item').length,
        sigs: document.querySelectorAll('.sig').length,
        toppings: document.querySelectorAll('.topping').length,
        faqs: document.querySelectorAll('.faq__item').length
      };
    });
    log(geom.cards === 21, `[${vp.name}] 21 menu cards rendered`, String(geom.cards));
    log(geom.sigs === 4, `[${vp.name}] 4 signature cards`, String(geom.sigs));
    log(geom.toppings === 10, `[${vp.name}] 10 topping buttons`, String(geom.toppings));
    log(geom.faqs === 7, `[${vp.name}] 7 FAQ items`, String(geom.faqs));
    log(geom.h1 && geom.h1.w > 100 && geom.h1.h > 40, `[${vp.name}] hero heading laid out`, JSON.stringify(geom.h1));
    log(geom.menuGrid && geom.menuGrid.w > 260, `[${vp.name}] menu grid width`, JSON.stringify(geom.menuGrid));
    const barVisible = vp.width <= 760;
    log(barVisible ? geom.mobilebar.vis !== 'hidden' && geom.mobilebar.w > 0 : true,
      `[${vp.name}] mobile bar ${barVisible ? 'present' : 'hidden by design'}`);

    await page.screenshot({ path: `${OUT}/${vp.name}-hero.png` });
    await page.evaluate(() => document.querySelector('#menu').scrollIntoView());
    await page.waitForTimeout(700);
    await page.screenshot({ path: `${OUT}/${vp.name}-menu.png` });
    await page.evaluate(() => document.querySelector('#footer').scrollIntoView());
    await page.waitForTimeout(700);
    await page.screenshot({ path: `${OUT}/${vp.name}-footer.png` });
    await ctx.close();
  }

  /* ---------- interaction suite on desktop ---------- */
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  await page.goto(URL, { waitUntil: 'load' });
  await page.waitForTimeout(400);

  // 1. chips filter
  await page.click('[data-filter="t100"]');
  await page.waitForTimeout(250);
  let vis = await page.$$eval('.item:not(.is-dim)', els => els.length);
  log(vis === 6, 'filter ₹100 shows 6 items', 'visible ' + vis);
  await page.click('[data-filter="t180"]');
  vis = await page.$$eval('.item:not(.is-dim)', els => els.length);
  log(vis === 8, 'filter ₹180 shows 8 items', 'visible ' + vis);
  await page.click('[data-filter="spicy"]');
  vis = await page.$$eval('.item:not(.is-dim)', els => els.length);
  log(vis === 3, 'filter Spicy shows 3 items', 'visible ' + vis);
  await page.click('[data-filter="all"]');

  // 2. search
  await page.fill('#menuSearch', 'paneer');
  await page.waitForTimeout(300);
  vis = await page.$$eval('.item:not(.is-dim)', els => els.length);
  const counted = await page.textContent('#menuCount');
  log(vis >= 4, 'search "paneer" filters results', vis + ' → ' + counted.trim());
  await page.fill('#menuSearch', 'zzzz');
  await page.waitForTimeout(300);
  const emptyShown = await page.isVisible('#noResults');
  log(emptyShown, 'empty state appears for nonsense query');
  await page.fill('#menuSearch', '');
  await page.click('#sortSelect');
  await page.selectOption('#sortSelect', 'price-desc');
  await page.waitForTimeout(300);
  const firstPrice = await page.$eval('.item:not(.is-dim)', el => el.dataset.price);
  log(firstPrice === '180', 'sort price-desc puts ₹180 first', 'first=' + firstPrice);
  await page.selectOption('#sortSelect', 'default');

  // 3. item drawer
  await page.click('[data-view="farmhouse"]');
  await page.waitForTimeout(400);
  const drawerOk = await page.isVisible('#dialogItem') && (await page.textContent('#drawerName')).includes('Farmhouse');
  log(drawerOk, 'item drawer opens with correct item');
  const pairs = await page.$$eval('#drawerPairsList .chip-btn', els => els.length);
  log(pairs === 3, 'drawer shows 3 pairing suggestions', String(pairs));
  await page.screenshot({ path: `${OUT}/interaction-drawer.png` });
  await page.keyboard.press('Escape');
  await page.waitForTimeout(300);
  log(!(await page.isVisible('#dialogItem')), 'drawer closes on Escape');

  // 4. enquiry list
  await page.click('[data-add="apples-pizza"]');
  await page.click('[data-add="farmhouse"]');
  await page.click('[data-add="farmhouse"]'); // toggle remove via card
  await page.waitForTimeout(200);
  let count = await page.textContent('#enquiryCount');
  log(count === '1', 'add + toggle-off leaves 1 item', 'count=' + count);
  // add via card button then bump qty in the sheet
  await page.click('[data-add="double-cheese-margherita"]');
  await page.click('#enquiryBtn');
  await page.waitForTimeout(400);
  await page.click('[data-inc="apples-pizza"]');
  await page.waitForTimeout(200);
  const total = await page.textContent('#enqTotal');
  const lines = await page.$$eval('#enqList li', els => els.length);
  log(total === '₹520' && lines === 2, 'enquiry totals: ₹180×2 + ₹160 = ₹520', `${lines} lines, total ${total}`);
  const waHref = await page.getAttribute('#enqWa', 'href');
  const waOk = waHref.startsWith('https://wa.me/917252009090?text=') && decodeURIComponent(waHref).includes('Apples Pizza');
  log(waOk, 'WhatsApp handoff builds a real prefilled message', waHref.slice(0, 82) + '…');
  await page.screenshot({ path: `${OUT}/interaction-enquiry.png` });
  await page.click('#enqClear');
  await page.waitForTimeout(200);
  const cleared = await page.$eval('#enqTotal', el => el.textContent);
  log(cleared === '₹0', 'clear empties the list', cleared);
  await page.click('#dialogEnquiry [data-close]');
  await page.waitForTimeout(300);

  // 5. topping studio
  await page.click('.topping[data-topping="corn"]');
  await page.click('.topping[data-topping="paneer"]');
  await page.click('.topping[data-topping="capsicum"]');
  await page.waitForTimeout(300);
  const drawn = await page.$$eval('#toppingLayer > g', g => g.length);
  const cnt = await page.textContent('#studioCount');
  log(drawn === 3 && cnt === '3', 'studio draws 3 topping groups', `${drawn} groups, count ${cnt}`);
  const pieces = await page.$$eval('#toppingLayer ellipse, #toppingLayer rect, #toppingLayer circle, #toppingLayer path', e => e.length);
  log(pieces > 25, 'studio renders topping shapes', pieces + ' shapes');
  await page.screenshot({ path: `${OUT}/interaction-studio.png` });
  await page.click('#btnStudioSurprise');
  await page.waitForTimeout(300);
  const cnt2 = await page.textContent('#studioCount');
  log(cnt2 === '4', 'surprise me picks 4 toppings', cnt2);
  await page.click('#btnStudioReset');
  await page.waitForTimeout(200);
  log((await page.textContent('#studioCount')) === '0', 'reset clears the pie');

  // 6. faq + concept dialog
  const faqOpen = await page.$eval('.faq__item[open] summary', el => el.textContent.trim().slice(0, 24));
  log(!!faqOpen, 'FAQ accordion renders', faqOpen);
  await page.click('#btnConceptFoot');
  await page.waitForTimeout(400);
  log(await page.isVisible('#dialogConcept'), 'concept note dialog opens');
  await page.screenshot({ path: `${OUT}/interaction-concept.png` });
  await page.keyboard.press('Escape');
  await page.waitForTimeout(300);
  log(!(await page.isVisible('#dialogConcept')), 'concept dialog closes on Escape');
  const inertCleared = await page.$eval('main', el => !el.hasAttribute('inert'));
  log(inertCleared, 'background interactivity restored after close');

  // 7. mobile nav (tablet/mobile context)
  const mctx = await browser.newContext({ viewport: { width: 390, height: 844 } });
  const mp = await mctx.newPage();
  await mp.goto(URL, { waitUntil: 'load' });
  await mp.click('#navToggle');
  await mp.waitForTimeout(350);
  log(await mp.isVisible('#navDrawer'), 'mobile nav drawer opens');
  await mp.screenshot({ path: `${OUT}/interaction-mobilenav.png` });
  await mp.click('#navDrawer a[href="#menu"]');
  await mp.waitForTimeout(700);
  log(!(await mp.isVisible('#navDrawer')), 'mobile nav closes after choosing a link');
  const scrolled = await mp.evaluate(() => window.scrollY);
  log(scrolled > 500, 'mobile nav link scrolls to the menu section', 'scrollY ' + Math.round(scrolled));

  // 8. ribbon dismiss
  await mp.reload({ waitUntil: 'load' });
  const ribbonBefore = await mp.isVisible('#demoRibbon');
  await mp.click('#ribbonDismiss');
  await mp.waitForTimeout(200);
  const ribbonAfter = await mp.isVisible('#demoRibbon');
  log(ribbonBefore && !ribbonAfter, 'demo ribbon dismisses');

  log(errors.length === 0, 'interaction run: no console errors', errors.slice(0, 3).join(' | '));

  await browser.close();

  const failedCount = results.filter(r => !r.ok).length;
  fs.writeFileSync('/home/user/tests/results.json', JSON.stringify(results, null, 2));
  console.log(`\n==== ${results.length - failedCount}/${results.length} checks passed ====`);
  process.exit(failedCount ? 1 : 0);
})().catch(e => { console.error('AUDIT CRASH', e); process.exit(2); });
