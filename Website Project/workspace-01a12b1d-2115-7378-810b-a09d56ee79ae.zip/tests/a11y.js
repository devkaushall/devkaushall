/* axe-core accessibility audit — page, item drawer, enquiry sheet, at two widths */
const { chromium } = require('playwright');
const fs = require('fs');

const URL = process.env.URL || 'http://localhost:8080/';
const AXE = require.resolve('axe-core/axe.min.js');
const results = [];
const log = (ok, name, detail = '') => {
  results.push({ ok, name, detail });
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
};

async function runAxe(page, ctxName) {
  await page.addScriptTag({ path: AXE });
  const res = await page.evaluate(async () => {
    return await window.axe.run(document, {
      resultTypes: ['violations'],
      runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'best-practice'] }
    });
  });
  const v = res.violations;
  const serious = v.filter(x => x.impact === 'critical' || x.impact === 'serious');
  const detail = v.map(x => `${x.id}(${x.impact})×${x.nodes.length}`).join(', ');
  log(serious.length === 0, `[${ctxName}] axe: no critical/serious violations`, detail || 'clean');
  if (v.length) {
    console.log(`      all axe findings for ${ctxName}:`);
    v.forEach(x => {
      console.log(`      • ${x.id} [${x.impact}] ×${x.nodes.length} — ${x.help}`);
      x.nodes.slice(0, 3).forEach(n => console.log(`          ${n.target.join(' ')} :: ${String(n.failureSummary || '').split('\n').slice(1, 3).join(' ').trim().slice(0, 150)}`));
    });
  }
  return v;
}

(async () => {
  const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const summary = {};

  for (const [w, h, name] of [[1440, 900, 'desktop 1440'], [390, 844, 'mobile 390']]) {
    const ctx = await browser.newContext({ viewport: { width: w, height: h } });
    const page = await ctx.newPage();
    await page.goto(URL, { waitUntil: 'load' });
    await page.waitForTimeout(800);
    summary[name] = await runAxe(page, name);
    await ctx.close();
  }

  /* dialogs are separate contexts for axe — open each and re-run */
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await ctx.newPage();
  await page.goto(URL, { waitUntil: 'load' });
  await page.waitForTimeout(600);

  await page.click('[data-view="farmhouse"]');
  await page.waitForTimeout(400);
  summary['item drawer'] = await runAxe(page, 'item drawer open');
  await page.keyboard.press('Escape');
  await page.waitForTimeout(300);

  await page.click('[data-add="apples-pizza"]');
  await page.click('#enquiryBtn');
  await page.waitForTimeout(400);
  summary['enquiry sheet'] = await runAxe(page, 'enquiry sheet open');
  await page.keyboard.press('Escape');
  await page.waitForTimeout(300);

  await page.click('#btnConceptFoot');
  await page.waitForTimeout(400);
  summary['concept note'] = await runAxe(page, 'concept note open');

  await browser.close();
  fs.writeFileSync('/home/user/tests/a11y-results.json', JSON.stringify(summary, null, 2));
  const failed = results.filter(r => !r.ok).length;
  console.log(`\n==== axe: ${results.length - failed}/${results.length} contexts clean ====`);
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(2); });
