# Apple's Pizza — Concept Website: Design Direction & Implementation Plan

## 1. What the research dictates

The old site (`applespizza.in`, HTTP 500) was an order-app shell: no readable menu, no brand story, no address, no photography, and its last archived state said *"No slot available right now."* The concept must fix exactly those gaps **without pretending to take orders**.

Verified raw material to build on:
- Real 21-item pizza menu with three clear price tiers (₹100 / ₹160 / ₹180) from Zomato + Justdial + magicpin.
- Real coordinates, address, three listed phone numbers, establishment year 2016.
- Brand's own position: **100% pure veg**. Confirmed by the fact that every item on all three published menus is vegetarian.
- Real, high-volume reputation signals (Zomato 4.4 delivery / 553 ratings; Justdial 3.8 / 320 and 4.9 / 555; Google 4.1 / 113).
- Genuine FSSAI licence number, UPI/card/cash acceptance, own delivery up to 5 km.

## 2. Big idea

**"Etawah's pure-veg pizza, taken seriously."**
A warm, editorial pizzeria site — charcoal and tomato-red, cream paper, one enormous rotating pizza as the hero, real prices on real cards, and a menu you can actually browse.

Three rules I set for myself:
1. **Nothing decorative-only.** Every button calls, opens maps, filters, copies, or opens a panel.
2. **Nothing unverified in a confident voice.** Ratings carry their platform and denominator; hours carry an "as listed" note; the four items without confirmed descriptions say so out loud.
3. **No fake commerce.** No "Add to cart → checkout". A local **Enquiry List** builds a prefilled WhatsApp message instead — labelled as a demo behaviour, functional on a real phone.

## 3. Visual system

| Token | Value | Use |
|---|---|---|
| `--char` | `#15100E` | hero, footer, dark sections |
| `--char-2` | `#241A15` | cards on dark, grain |
| `--cream` | `#FBF1DE` | page background |
| `--tomato` | `#D22B1E` | primary brand red (echoes the old blue wordmark's replacement role) |
| `--amber` | `#F0973A` | highlights, cheese warmth |
| `--basil` | `#4E7A3A` | pure-veg mark, fresh accents |

- **Type:** Fraunces (variable serif, display, optical sizing, italic for emphasis) + Manrope (UI/body). Self-hosted `.woff2`, no CDN.
- **Texture:** very light SVG-noise paper overlay, 2px dotted "menu card" rules, small-caps section eyebrows — the vocabulary of a printed menu, not a SaaS template.
- **Imagery:** original demo photography, all from verified menu territory (corn/paprika/onion/capsicum/paneer/corn). Each photo carries a small "Demo visual" caption.
- **Brand mark:** original, clearly replaceable wordmark — apple silhouette whose leaf is a pizza slice, plus "Apple's Pizza / ETAWAH" lockup. The archived real wordmark is kept in the repo as reference only (`logo-archived-2025.jpg`) and is **not** used.

## 4. Sections (in order)

1. **Demo ribbon** — honest "concept demo, not the live site" strip with dismiss + "About this concept" dialog (the owner-facing rationale, ratings, what we fixed, placeholders to replace).
2. **Hero** — rotating pizza disc (a top-down lazy-susan), parallax layers, cream "pure veg · since 2016" ticket, three CTAs: browse menu / call / directions. Live "open–closed" chip is deliberately **not** shown as fact.
3. **Marquee** — verified-only phrases, pauses on hover, disabled for reduced-motion.
4. **Signature four** — photo-led feature rows with subtle pointer tilt, real prices, real topping lists.
5. **Menu browser** — 21 verified items, live search, tier/category filters, sort, spicy + house-special tags, item drawer with verified description + "pairs with", Enquiry List with WhatsApp handoff. Plus an honest side-panel: garlic bread / beverages / desserts exist in directory *photos and blurbs only* → shown as "awaiting confirmation", no prices.
6. **Size ladder card** — 7" Regular / 10" Medium, ₹100 / ₹245, attributed to the Swiggy listing, marked unconfirmed.
7. **Topping studio** — interactive SVG pizza where toggling toppings repaints the pie. Visual only, explicitly "prices to be confirmed" — gives the owner something memorable without inventing a customiser.
8. **Pure veg + numbers** — the brand claim, establishment year, ratings with platform + denominator, service modes.
9. **Outlet & hours** — one outlet (Friends Colony / MKD Super Mart), coordinates, schematic inline SVG locality map (no external tile network), opening-hours table shown as directory listings with a visible conflict note, tap-to-call/directions/WhatsApp, accessibility/service notes.
10. **FAQ** — accordion, answers strictly from verified data, each noting its source.
11. **CTA + footer** — call/WhatsApp/directions, full disclaimer, credits, asset ledger, `Restaurant` JSON-LD guarded as a concept.

## 5. Interactivity inventory (must all be functional)

Nav drawer · scroll progress · active-section highlight · scroll reveal · hero parallax + lazy-susan rotation · pointer tilt · marquee pause · menu search + filters + sort + clear · item drawer (focus-trapped, Esc, arrows between items) · enquiry list add/remove/qty · WhatsApp message build · copy-to-clipboard with toast · topping studio toggles + reset + random · hours "today" highlight (client-side only, labelled) · FAQ accordion · mobile sticky action bar · concept dialog · reduced-motion fallbacks.

## 6. Files

```
site/
  index.html
  assets/css/style.css
  assets/js/main.js
  assets/fonts/   (Fraunces + Manrope woff2, SIL OFL)
  assets/img/     (6 demo photos in jpg+webp, archived wordmark for reference)
```
Static, framework-free, no build step, works from `file://` and from a static host.

## 7. External dependencies: none

No map tiles, no CDN, no analytics, no backend, no payment, no API keys. Google Maps is reached by **link out**, not by embedding a keyed map. Ordering is a WhatsApp handoff. Every dependency that a production launch would need (real photos, live hours, ordering integration, domain/hosting) is listed as owner input.

## 8. Verification plan

- Playwright/Chromium: 6 viewports (320, 375, 768, 1024, 1440, 1920) × screenshots, console-error capture, horizontal-overflow detection, per-element geometry assertions.
- Interaction tests: nav, filters, search, drawer, enquiry list total, WhatsApp link, toast, FAQ, topping studio, dialog, mobile bar.
- Automated: HTML validation (`html-validate`), duplicate-ID/label/alt audit, colour-contrast script, image weight report, `file://` smoke test.
