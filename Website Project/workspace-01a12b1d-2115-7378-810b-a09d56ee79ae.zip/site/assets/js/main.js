/* ============================================================
   Apple's Pizza, Etawah — concept demo · interaction layer
   Vanilla JS, no dependencies. Every control does something real.
   ============================================================ */
(function () {
  'use strict';

  var $  = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var finePointer  = window.matchMedia('(hover: hover) and (pointer: fine)').matches;

  /* ---------------------------------------------------------
     0. toast
  --------------------------------------------------------- */
  var toastEl = $('#toast'), toastTimer;
  function toast(msg) {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.hidden = false;
    requestAnimationFrame(function () { toastEl.classList.add('is-on'); });
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      toastEl.classList.remove('is-on');
      setTimeout(function () { toastEl.hidden = true; }, 320);
    }, 2600);
  }

  /* ---------------------------------------------------------
     1. ribbon + concept dialog
  --------------------------------------------------------- */
  var ribbon = $('#demoRibbon');
  if (ribbon) {
    try { if (sessionStorage.getItem('apz-ribbon') === 'off') ribbon.classList.add('is-hidden'); } catch (e) {}
    $('#ribbonDismiss').addEventListener('click', function () {
      ribbon.classList.add('is-hidden');
      try { sessionStorage.setItem('apz-ribbon', 'off'); } catch (e) {}
    });
  }

  var lastFocus = null;
  function openSheet(el) {
    if (!el) return;
    lastFocus = document.activeElement;
    el.hidden = false;
    document.body.classList.add('is-locked');
    $$('.header, main, footer, .mobilebar, .ribbon').forEach(function (n) { n.setAttribute('inert', ''); });
    var focusable = el.querySelector('.sheet__x, a[href], button, input, select');
    if (focusable) focusable.focus();
  }
  function closeSheet(el) {
    if (!el) return;
    el.hidden = true;
    document.body.classList.remove('is-locked');
    $$('.header, main, footer, .mobilebar, .ribbon').forEach(function (n) { n.removeAttribute('inert'); });
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }
  $$('.sheet').forEach(function (sheet) {
    sheet.addEventListener('click', function (e) {
      if (e.target.closest('[data-close]')) closeSheet(sheet);
    });
    sheet.addEventListener('keydown', function (e) {
      if (e.key !== 'Tab') return;
      var f = $$('a[href], button:not([disabled]), input, select, [tabindex]:not([tabindex="-1"])', sheet)
        .filter(function (n) { return n.offsetParent !== null; });
      if (!f.length) return;
      var first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    });
  });
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    var open = $$('.sheet').filter(function (s) { return !s.hidden; }).pop();
    if (open) closeSheet(open);
  });

  var conceptDialog = $('#dialogConcept');
  ['#btnConceptTop', '#btnConceptNav2', '#btnConceptFoot', '#btnConceptFaq'].forEach(function (sel) {
    var b = $(sel);
    if (b) b.addEventListener('click', function () { openSheet(conceptDialog); });
  });

  /* ---------------------------------------------------------
     2. header, progress, mobile nav
  --------------------------------------------------------- */
  var header = $('#header'), bar = $('#progressBar');
  var navToggle = $('#navToggle'), navDrawer = $('#navDrawer');

  function onScroll() {
    var y = window.scrollY || document.documentElement.scrollTop;
    header.classList.toggle('is-stuck', y > 8);
    var h = document.documentElement.scrollHeight - window.innerHeight;
    bar.style.width = (h > 0 ? Math.min(100, (y / h) * 100) : 0) + '%';
    parallax(y);
  }
  window.addEventListener('scroll', function () { requestAnimationFrame(onScroll); }, { passive: true });

  if (navToggle) {
    navToggle.addEventListener('click', function () {
      var open = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!open));
      navDrawer.hidden = open;
      document.body.classList.toggle('is-locked', !open);
    });
    $$('a', navDrawer).forEach(function (a) {
      a.addEventListener('click', function () {
        navToggle.setAttribute('aria-expanded', 'false');
        navDrawer.hidden = true;
        document.body.classList.remove('is-locked');
      });
    });
    window.addEventListener('resize', function () {
      if (window.innerWidth > 900 && !navDrawer.hidden) {
        navToggle.setAttribute('aria-expanded', 'false');
        navDrawer.hidden = true;
        document.body.classList.remove('is-locked');
      }
    });
  }

  /* active section link */
  var navLinks = $$('.nav a[href^="#"]');
  var sections = navLinks.map(function (a) { return $(a.getAttribute('href')); }).filter(Boolean);
  if ('IntersectionObserver' in window && sections.length) {
    var navObs = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        navLinks.forEach(function (a) {
          a.classList.toggle('is-active', a.getAttribute('href') === '#' + en.target.id);
        });
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    sections.forEach(function (s) { navObs.observe(s); });
  }

  /* ---------------------------------------------------------
     3. scroll reveal
  --------------------------------------------------------- */
  var revealables = $$('[data-reveal]');
  if ('IntersectionObserver' in window && !reduceMotion) {
    var revObs = new IntersectionObserver(function (entries, obs) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('is-in'); obs.unobserve(en.target); }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: .12 });
    revealables.forEach(function (n) { revObs.observe(n); });
  } else {
    revealables.forEach(function (n) { n.classList.add('is-in'); });
  }
  var scores = $$('.score');
  if ('IntersectionObserver' in window) {
    var scObs = new IntersectionObserver(function (entries, obs) {
      entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('is-in'); obs.unobserve(en.target); } });
    }, { threshold: .4 });
    scores.forEach(function (n) { scObs.observe(n); });
  } else {
    scores.forEach(function (n) { n.classList.add('is-in'); });
  }

  /* ---------------------------------------------------------
     4. hero parallax + tilt
  --------------------------------------------------------- */
  var disc = $('#heroDisc'), heroCopy = $('.hero__copy');
  function parallax(y) {
    if (reduceMotion || !disc || y > 900) return;
    if (y < 0) return;
    disc.style.transform = 'translateY(' + (y * 0.09).toFixed(2) + 'px)';
    if (heroCopy) heroCopy.style.transform = 'translateY(' + (y * -0.03).toFixed(2) + 'px)';
  }

  if (finePointer && !reduceMotion) {
    $$('[data-tilt]').forEach(function (card) {
      card.addEventListener('pointermove', function (e) {
        var r = card.getBoundingClientRect();
        var px = (e.clientX - r.left) / r.width - .5;
        var py = (e.clientY - r.top) / r.height - .5;
        card.style.transform = 'perspective(900px) rotateY(' + (px * 5).toFixed(2) + 'deg) rotateX(' + (-py * 5).toFixed(2) + 'deg) translateY(-4px)';
      });
      card.addEventListener('pointerleave', function () { card.style.transform = ''; });
    });
  }

  /* ---------------------------------------------------------
     5. menu: search, filter, sort
  --------------------------------------------------------- */
  var grid = $('#menuGrid');
  var cards = grid ? $$('.item', grid) : [];
  var chips = $$('.chip-btn');
  var searchInput = $('#menuSearch');
  var sortSelect = $('#sortSelect');
  var countEl = $('#menuCount');
  var emptyEl = $('#noResults');
  var activeFilter = 'all';

  function hay(card) {
    return (card.dataset.name + ' ' + card.dataset.desc + ' ' + $('.item__toppings', card).textContent).toLowerCase();
  }
  function apply() {
    var q = (searchInput.value || '').trim().toLowerCase();
    var shown = 0;
    cards.forEach(function (card) {
      var okFilter = activeFilter === 'all' ||
        (activeFilter === 'spicy' ? card.dataset.tags.indexOf('spicy') > -1 :
         activeFilter === 'house' ? card.dataset.tags.indexOf('house') > -1 :
         card.dataset.tier === activeFilter);
      var okQuery = !q || hay(card).indexOf(q) > -1;
      var ok = okFilter && okQuery;
      card.classList.toggle('is-dim', !ok);
      if (ok) shown++;
    });
    countEl.textContent = 'Showing ' + shown + ' of ' + cards.length + ' items' + (q ? ' for \u201c' + q + '\u201d' : '');
    emptyEl.hidden = shown !== 0;
  }
  function sortCards() {
    var v = sortSelect.value;
    var sorted = cards.slice();
    if (v === 'price-asc')  sorted.sort(function (a, b) { return a.dataset.price - b.dataset.price || a.dataset.index - b.dataset.index; });
    if (v === 'price-desc') sorted.sort(function (a, b) { return b.dataset.price - a.dataset.price || a.dataset.index - b.dataset.index; });
    if (v === 'name')       sorted.sort(function (a, b) { return a.dataset.name.localeCompare(b.dataset.name); });
    if (v === 'default')    sorted.sort(function (a, b) { return a.dataset.index - b.dataset.index; });
    sorted.forEach(function (c) { grid.appendChild(c); });
  }
  chips.forEach(function (c) {
    c.addEventListener('click', function () {
      activeFilter = c.dataset.filter;
      chips.forEach(function (o) {
        var on = o === c;
        o.classList.toggle('is-active', on);
        o.setAttribute('aria-pressed', String(on));
      });
      apply();
    });
  });
  if (grid) {
    searchInput.addEventListener('input', apply);
    sortSelect.addEventListener('change', function () { sortCards(); apply(); });
    apply();
  }

  /* ---------------------------------------------------------
     6. enquiry list (local, honest — not a cart)
  --------------------------------------------------------- */
  var store = {};
  try { store = JSON.parse(localStorage.getItem('apz-list') || '{}') || {}; } catch (e) { store = {}; }

  var enqListEl = $('#enqList'), enqEmpty = $('#enqEmpty'), enqSum = $('#enqSum');
  var enqTotal = $('#enqTotal'), enqCount = $('#enquiryCount'), enqCountSr = $('#enquiryCountSr');
  var enqSheet = $('#dialogEnquiry'), waBtn = $('#enqWa');

  function itemData(id) {
    var card = cards.filter(function (c) { return c.dataset.id === id; })[0];
    if (!card) return null;
    return {
      id: id,
      name: card.dataset.name,
      price: Number(card.dataset.price),
      desc: card.dataset.desc,
      pending: card.dataset.pending === 'true',
      index: Number(card.dataset.index),
      tier: card.dataset.tier
    };
  }
  function save() { try { localStorage.setItem('apz-list', JSON.stringify(store)); } catch (e) {} }
  function totalItems() { return Object.keys(store).reduce(function (n, k) { return n + store[k]; }, 0); }
  function totalPrice() { return Object.keys(store).reduce(function (n, k) { var d = itemData(k); return n + (d ? d.price * store[k] : 0); }, 0); }

  function syncAddButtons() {
    $$('[data-add]').forEach(function (b) {
      var on = !!store[b.dataset.add];
      b.classList.toggle('is-added', on);
      b.setAttribute('aria-pressed', String(on));
      // buttons inside the item drawer carry a labelled span; menu chips use a bare text node
      var label = b.querySelector('.js-addlabel');
      if (label) label.textContent = on ? 'Added \u2014 tap to remove' : 'Add to enquiry list';
      else if (b.classList.contains('btn--xs')) b.lastChild.textContent = on ? 'Added' : 'Add';
    });
    var t = totalItems();
    enqCount.textContent = t;
    if (enqCountSr) enqCountSr.textContent = t + (t === 1 ? ' item' : ' items') + ' in enquiry list';
  }

  function renderList() {
    var keys = Object.keys(store);
    enqListEl.innerHTML = '';
    keys.forEach(function (id) {
      var d = itemData(id); if (!d) return;
      var li = document.createElement('li');
      li.innerHTML =
        '<div><p class="enq__name"></p><p class="enq__price">₹' + d.price + ' each · listed</p></div>' +
        '<div class="qty">' +
          '<button type="button" data-dec="' + id + '" aria-label="One less ' + d.name + '"><svg class="ico" aria-hidden="true"><use href="#i-minus"/></svg></button>' +
          '<span aria-hidden="true">' + store[id] + '</span>' +
          '<button type="button" data-inc="' + id + '" aria-label="One more ' + d.name + '"><svg class="ico" aria-hidden="true"><use href="#i-plus"/></svg></button>' +
        '</div>';
      $('.enq__name', li).textContent = d.name;
      enqListEl.appendChild(li);
    });
    enqEmpty.hidden = keys.length > 0;
    enqSum.hidden = keys.length === 0;
    enqTotal.textContent = '₹' + totalPrice();

    var lines = keys.map(function (id) {
      var d = itemData(id);
      return '• ' + d.name + ' — ₹' + d.price + ' × ' + store[id] + ' = ₹' + (d.price * store[id]);
    });
    var msg = 'Hi! Could you please check availability and price for the following from Apple\'s Pizza?\n\n' +
      lines.join('\n') + '\n\nListed subtotal: \u20B9' + totalPrice() +
      '\n\n(Sent from the concept demo site \u2014 please confirm current rates, packing and delivery.)';
    waBtn.href = 'https://wa.me/917252009090' + (keys.length ? '?text=' + encodeURIComponent(msg) : '');
    syncAddButtons();
    save();
  }

  function addItem(id, silent) {
    store[id] = (store[id] || 0) + 1;
    renderList();
    if (!silent) {
      var d = itemData(id);
      toast((d ? d.name : 'Pizza') + ' added — ' + totalItems() + ' in your enquiry list');
    }
  }
  function removeItem(id) {
    delete store[id];
    renderList();
  }

  document.addEventListener('click', function (e) {
    var add = e.target.closest('[data-add]');
    if (add) {
      e.preventDefault();
      var id = add.dataset.add;
      if (store[id]) { removeItem(id); toast('Removed from the enquiry list'); }
      else addItem(id);
      return;
    }
    var inc = e.target.closest('[data-inc]');
    if (inc) { addItem(inc.dataset.inc, true); return; }
    var dec = e.target.closest('[data-dec]');
    if (dec) {
      var did = dec.dataset.dec;
      store[did] -= 1;
      if (store[did] <= 0) delete store[did];
      renderList();
      return;
    }
    var view = e.target.closest('[data-view]');
    if (view) { openItem(view.dataset.view); }
  });

  $('#enquiryBtn').addEventListener('click', function () { renderList(); openSheet(enqSheet); });
  $('#enqCopy').addEventListener('click', function () {
    var keys = Object.keys(store);
    if (!keys.length) { toast('Nothing to copy yet — add a pizza first'); return; }
    var txt = keys.map(function (id) { var d = itemData(id); return d.name + ' (₹' + d.price + ') × ' + store[id]; }).join('\n') +
      '\nListed subtotal: ₹' + totalPrice();
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(txt).then(
        function () { toast('List copied — paste it anywhere'); },
        function () { toast('Copy failed — long-press to select instead'); }
      );
    } else { toast('Clipboard not available in this browser'); }
  });
  $('#enqClear').addEventListener('click', function () {
    if (!Object.keys(store).length) { toast('The list is already empty'); return; }
    store = {}; renderList(); toast('Enquiry list cleared');
  });

  /* ---------------------------------------------------------
     7. item drawer
  --------------------------------------------------------- */
  var drawer = $('#dialogItem');
  var drawerId = null;
  function openItem(id) {
    var d = itemData(id); if (!d) return;
    drawerId = id;
    var card = cards.filter(function (c) { return c.dataset.id === id; })[0];
    $('#drawerName').textContent = d.name;
    $('#drawerPrice').textContent = '₹' + d.price;
    $('#drawerTier').textContent = d.tier === 't100' ? '₹100 range · 7″ regular' : d.tier === 't160' ? '₹160 range' : '₹180 range · premium';
    $('#drawerDesc').textContent = d.pending
      ? 'The full topping list for this pizza is truncated on every public menu we could find. Rather than guess, we’ve left it blank — the owner can confirm it in one message.'
      : (d.desc || '—');
    var meta = ['Vegetarian', 'Listed on Zomato & Justdial'];
    if (card.dataset.tags.indexOf('spicy') > -1) meta.push('Spicy');
    if (card.dataset.tags.indexOf('house') > -1) meta.push('House special');
    if (d.pending) meta.push('Details to confirm');
    $('#drawerMeta').innerHTML = meta.map(function (m) { return '<span class="meta">' + m + '</span>'; }).join('');

    var pairs = cards
      .filter(function (c) { return c.dataset.id !== id; })
      .sort(function (a, b) { return Math.abs(a.dataset.index - d.index) - Math.abs(b.dataset.index - d.index); })
      .slice(0, 3);
    $('#drawerPairsList').innerHTML = pairs.map(function (p) {
      return '<button type="button" class="chip-btn" data-view="' + p.dataset.id + '">' + p.dataset.name.replace(' Pizza', '') + ' <span>₹' + p.dataset.price + '</span></button>';
    }).join('');

    var addBtn = $('#drawerAdd');
    addBtn.dataset.add = id;
    addBtn.innerHTML = '<svg class="ico" aria-hidden="true"><use href="#i-plus"/></svg><span class="js-addlabel">' +
      (store[id] ? 'Added \u2014 tap to remove' : 'Add to enquiry list') + '</span>';
    addBtn.classList.toggle('is-added', !!store[id]);
    openSheet(drawer);
  }
  $('#drawerNavNext').addEventListener('click', function () {
    var i = cards.map(function (c) { return c.dataset.id; }).indexOf(drawerId);
    var next = cards[(i + 1) % cards.length].dataset.id;
    openItem(next);
  });

  /* ---------------------------------------------------------
     8. topping studio
  --------------------------------------------------------- */
  var TOPPINGS = [
    { id: 'corn',     label: 'Golden corn',  color: '#F2C219' },
    { id: 'paneer',   label: 'Paneer',       color: '#FBF1DE' },
    { id: 'capsicum', label: 'Capsicum',     color: '#4E7A3A' },
    { id: 'tomato',   label: 'Tomato',       color: '#D8452F' },
    { id: 'olive',    label: 'Black olive',  color: '#2C1B12' },
    { id: 'jalapeno', label: 'Jalapeno',     color: '#6E9B52' },
    { id: 'paprika',  label: 'Red paprika',  color: '#A81E13' },
    { id: 'mushroom', label: 'Mushroom',     color: '#A87A55' },
    { id: 'onion',    label: 'Onion',        color: '#8E5C86' },
    { id: 'cheese',   label: 'Extra cheese', color: '#FFC978' }
  ];
  var toppingRow = $('#toppingRow'), toppingLayer = $('#toppingLayer');
  var studioCount = $('#studioCount'), studioNames = $('#studioNames');
  var chosen = [];
  var PRNG = function (seed) { return function () { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; }; };

  function pointsFor(seed, n, rMin, rMax) {
    var rnd = PRNG(seed), pts = [], guard = 0;
    while (pts.length < n && guard++ < 600) {
      var a = rnd() * Math.PI * 2, r = Math.sqrt(rnd()) * (rMax - rMin) + rMin;
      var x = 200 + Math.cos(a) * r, y = 200 + Math.sin(a) * r;
      var clash = pts.some(function (p) { return Math.hypot(p[0] - x, p[1] - y) < 24; });
      if (!clash) pts.push([x, y, rnd() * 360]);
    }
    return pts;
  }
  function shapeFor(id, x, y, rot, color) {
    var t = 'transform="rotate(' + rot.toFixed(0) + ' ' + x.toFixed(1) + ' ' + y.toFixed(1) + ')"';
    switch (id) {
      case 'corn':     return '<ellipse cx="' + x + '" cy="' + y + '" rx="6" ry="4.6" fill="' + color + '" ' + t + '/>';
      case 'paneer':   return '<rect x="' + (x - 8) + '" y="' + (y - 8) + '" width="16" height="16" rx="3" fill="' + color + '" stroke="#E0C89A" ' + t + '/>';
      case 'capsicum': return '<circle cx="' + x + '" cy="' + y + '" r="11" fill="none" stroke="' + color + '" stroke-width="5" ' + t + '/>';
      case 'tomato':   return '<circle cx="' + x + '" cy="' + y + '" r="9" fill="' + color + '"/><circle cx="' + x + '" cy="' + y + '" r="4.5" fill="#E8705C"/>';
      case 'olive':    return '<circle cx="' + x + '" cy="' + y + '" r="7.5" fill="none" stroke="' + color + '" stroke-width="5"/>';
      case 'jalapeno': return '<ellipse cx="' + x + '" cy="' + y + '" rx="10" ry="5" fill="' + color + '" ' + t + '/><ellipse cx="' + x + '" cy="' + y + '" rx="6" ry="2.2" fill="#B9D69C" ' + t + '/>';
      case 'paprika':  return '<rect x="' + (x - 10) + '" y="' + (y - 3.4) + '" width="20" height="6.8" rx="3" fill="' + color + '" ' + t + '/>';
      case 'mushroom': return '<path d="M' + (x - 8) + ' ' + (y + 3) + 'a8 8 0 0 1 16 0z" fill="' + color + '" ' + t + '/><rect x="' + (x - 2.6) + '" y="' + (y + 3) + '" width="5.2" height="7" rx="1.6" fill="#E3D2B5" ' + t + '/>';
      case 'onion':    return '<path d="M' + (x - 12) + ' ' + y + 'a12 12 0 0 1 24 0" fill="none" stroke="' + color + '" stroke-width="3.6" stroke-linecap="round" ' + t + '/>';
      case 'cheese':   return '<ellipse cx="' + x + '" cy="' + y + '" rx="15" ry="11" fill="' + color + '" opacity=".92" ' + t + '/>';
      default:         return '';
    }
  }
  function drawStudio() {
    var html = '', seed = 7;
    chosen.forEach(function (id) {
      var tp = TOPPINGS.filter(function (t) { return t.id === id; })[0];
      if (!tp) return;
      var n = id === 'cheese' ? 8 : id === 'paneer' ? 9 : 12;
      var rMin = id === 'cheese' ? 10 : 26, rMax = id === 'cheese' ? 130 : 118;
      var pts = pointsFor(seed += 37, n, rMin, rMax);
      html += '<g class="topping-pop">' + pts.map(function (p) {
        return shapeFor(id, p[0], p[1], p[2], tp.color);
      }).join('') + '</g>';
    });
    toppingLayer.innerHTML = html;
    studioCount.textContent = chosen.length;
    studioNames.textContent = chosen.length
      ? chosen.map(function (id) { return TOPPINGS.filter(function (t) { return t.id === id; })[0].label; }).join(', ')
      : 'nothing yet — start tapping';
  }
  if (toppingRow) {
    toppingRow.innerHTML = TOPPINGS.map(function (t) {
      return '<button type="button" class="topping" data-topping="' + t.id + '" aria-pressed="false">' +
        '<i style="--swatch:' + t.color + '"></i>' + t.label + '</button>';
    }).join('');
    toppingRow.addEventListener('click', function (e) {
      var b = e.target.closest('[data-topping]'); if (!b) return;
      var id = b.dataset.topping, i = chosen.indexOf(id);
      if (i > -1) { chosen.splice(i, 1); b.setAttribute('aria-pressed', 'false'); }
      else { chosen.push(id); b.setAttribute('aria-pressed', 'true'); }
      drawStudio();
    });
    $('#btnStudioReset').addEventListener('click', function () {
      chosen = [];
      $$('[data-topping]', toppingRow).forEach(function (b) { b.setAttribute('aria-pressed', 'false'); });
      drawStudio(); toast('Pie cleared');
    });
    $('#btnStudioSurprise').addEventListener('click', function () {
      var pool = TOPPINGS.map(function (t) { return t.id; });
      var pick = [];
      while (pick.length < 4) {
        var c = pool[Math.floor(Math.random() * pool.length)];
        if (pick.indexOf(c) === -1) pick.push(c);
      }
      chosen = pick;
      $$('[data-topping]', toppingRow).forEach(function (b) {
        b.setAttribute('aria-pressed', String(chosen.indexOf(b.dataset.topping) > -1));
      });
      drawStudio();
      toast('Random pie: ' + chosen.map(function (id) { return TOPPINGS.filter(function (t) { return t.id === id; })[0].label; }).join(', '));
    });
    drawStudio();
  }

  /* ---------------------------------------------------------
     9. misc
  --------------------------------------------------------- */
  var yearEl = $('#year');
  if (yearEl) yearEl.textContent = String(new Date().getFullYear());

  syncAddButtons();
  renderList();
  onScroll();
})();
