# Apple's Pizza, Etawah — Research Findings

**Research date:** 11 October 2026
**Purpose:** Evidence base for an *alternative concept* demo website. Nothing in this file is invented; every claim is tied to a source and a confidence level.

---

## 1. Business identity (verified, high confidence)

| Field | Value | Sources |
|---|---|---|
| Trading name | Apple's Pizza (also written "Apples Pizza" / "APPLE'SPIZZA") | Zomato, Justdial, Facebook, archived site |
| Category | Pizza / Italian / Fast Food — Quick-bite, casual dining | Justdial, magicpin, Zomato |
| Primary outlet | 166/c, 1st Floor, MKD Super Mart, Friends Colony, Etawah 206001, U.P. | Justdial (claimed listing), magicpin, Restaurant Guru |
| Coordinates | ≈ 26.7890, 79.0247 (Friends Colony / MKD Super Mart) | magicpin map link, Zomato directions link, Restaurant Guru |
| Landmark | MKD Super Mart, near Friends Colony / Indian Oil petrol pump | Justdial full address |
| Phone (Friends Colony) | +91 72520 09090 (also listed: +91 89380 09090, +91 84689 74638) | Zomato, magicpin, Facebook, Restaurant Guru, Justdial |
| Email | appizza7252@gmail.com | Facebook page contact block |
| Year of establishment | 2016 | Justdial "Year of Establishment" |
| Marketing claim | "APPLE'SPIZZA makes 100% pure veg pizza" | Facebook page intro (brand's own words) |
| Price point | ₹300 for two (Justdial), ₹500 for two (magicpin), ₹1–200 per person (Restaurant Guru) | **Conflicting — see §6** |
| Service modes | Dine-in, Takeaway, Home Delivery (own delivery service; "free delivery up to 5 km" per Justdial) | Justdial, Facebook, Restaurant Guru |

## 2. Operating status — **UNRESOLVED / DISPUTED**

This is the single most important open question, and it is contradictory across platforms:

| Source | Status shown | Date signal |
|---|---|---|
| Restaurant Guru (Apple's Pizza, Etawah) | **"May be permanently closed"** | "Updated 1 month ago" |
| Restaurant Guru (a second Etawah entry, "Veg Pizza", Naurangabad Rd) | "Permanently closed" | — |
| Swiggy (Ramnagar, Etawah listing) | "Currently closed for delivery… not accepting orders at the moment" | listing live |
| Zomato | Order-online page **live and fully populated** (21 items with prices), delivery rating 4.4 (553 ratings), FSSAI licence displayed | live at research time |
| Justdial (Friends Colony, claimed) | "Open until 9:00 pm", "11 Years in Business", phone + WhatsApp CTA, "Order Online" | live at research time |
| Justdial (Ashok Nagar, claimed) | "Open until 10:00 pm", 4.9 / 555 ratings | live at research time |
| magicpin (Friends Colony, verified listing) | **"Open now · 10:00 AM – 10:00 PM"** | page footer: "October, 2026" |
| Facebook page (@Applespizzaetw) | "Open now" + Delivery/Takeout/Dine-in | cached result; page itself returned HTTP 403 to us |
| Own website applespizza.in | **DOWN** — HTTP 500. Last Wayback capture 27 Feb 2025 showed the order page live but already reporting **"No slot available right now."** | Wayback CDX |

**Conclusion:** the "permanently closed" flag originates from third-party aggregation (Restaurant Guru) and possibly a Google Business Profile state. Directory listings (Justdial ×2, magicpin, Zomato) and the brand's own Facebook page still publish live "open" hours, and Zomato still shows a full orderable menu. **We could not independently confirm the doors are open today** — Google Maps / Google Business Profile status was not directly accessible from this environment, and the phone numbers were not called. Therefore this demo is explicitly labelled a **concept / design demo**, and no "open now" claim is published as fact.

**Two-listings caveat:** Justdial shows two claimed Apple's Pizza entries in Etawah — **Friends Colony / MKD Super Mart** (3.8★, 320 ratings, est. 2016) and **Ashok Nagar / near KKDC 1st Gate, Pakka Talab** (4.9★, 555 ratings). Whether the business has one outlet, moved, or runs two outlets is **not verified**. A third, looser address ("Vijay Nagar", Taste of City) and a "Naurangabad Rd / Veg Pizza" entry also exist. The demo therefore presents **one** outlet card (Friends Colony) and flags the second as needing owner confirmation.

## 3. Reputation signals (verified figures, varied sources)

| Platform | Rating | Volume |
|---|---|---|
| Zomato | 3.7 dining / **4.4 delivery** | 7 dining / 553 delivery ratings |
| Justdial – Friends Colony | 3.8 | 320 ratings |
| Justdial – Ashok Nagar | 4.9 | 555 ratings |
| Google (via Restaurant Guru) | 4.1 | 113 reviews |
| magicpin | 4.9 (2 reviews, 2020) | tiny sample |

Review sentiment: "good quality", "fresh food", "Awesome pizza", "best pizza in Etawah" (Zomato/Facebook). One recent negative review (Google, ~3 months before research) rates food/service/atmosphere 1/5 and says parking is difficult. Older Yappe/Google snippets praise seating and variety.

**Important:** Zomato's own embedded schema for this outlet also exposes `"aggregateRating": 3.7 / 7` — i.e. the 4.4 figure is a delivery-only rating. Charts must state the denominator, not just the star.

## 4. Menu — verified items, prices and sources

Prices below appear **identically on two or more** sources: Zomato order page (21 pizza items), Justdial menu (20 items), magicpin popular items. All items shown are flagged **Veg**; there is no verified non-veg pizza in any of the three menus. (Justdial's category tags include a generic "Serves: Non Veg" service tag that contradicts the menu and the brand's "100% pure veg" self-description — flagged, not used.)

### ₹100 tier (7" regular, per Swiggy menu naming)
Cheese and Golden Corn · Cheese and Paneer · Cheese and Capsicum · Cheese and Black Olive · Cheese and Jalapeno · Cheese and Mushroom · Single Cheese Topping (Swiggy)

### ₹160 tier
Spicy Triple Tango (golden corn, jalapeno, red paprika) · Double Cheese Margherita · Country Special (onion, capsicum, tomato) · Farmhouse (onion, capsicum, tomato, mushroom) · Double Spicy (red paprika, capsicum, jalapeno) · Veggie Hawaiian (capsicum, golden corn, jalapeno) · Golden Farm (black olive, golden corn, jalapeno)

### ₹180 tier
**Apples Pizza** — house special: onion, capsicum, golden corn, paneer · 4 Pepper (onion, capsicum, red paprika, jalapeno) · Peppy Paneer (capsicum, red paprika, paneer) · Mexican Green Wave (onion, capsicum, tomato, jalapeno) · 5 Pepper · Veggie Paradise · Deluxe Veggie · Veggie Farm

### Size ladder (Swiggy listing only)
7" Regular ₹100 · 10" Medium ₹245 (same four base toppings)

### Other categories — **not verified**
Restaurant Guru photo tags mention **garlic bread**, **cake** and interior shots; magicpin's generic blurb mentions "pastas, salads, desserts"; Justdial's photo tabs show one **drink** photo. No verified item names or prices exist for sides, desserts or beverages → **excluded from the demo menu**, listed only as "confirm with owner".

### Add-ons & customisation
Zomato shows a "customizable" flag and copy mentioning pizza sauce, mozzarella, parmesan, cheddar, oregano, chilli flakes — consistent with the chain-style crust/topping customiser for which Swiggy lists sizes. Full topping/extra-cheese price list: **not verified**.

## 5. Offers, ordering & payments

| Item | Verified? | Source |
|---|---|---|
| magicpin voucher: "Save 5%", "not valid for takeaway and home delivery", valid all open days, prior reservation recommended | Yes (platform-run, third-party) | magicpin |
| Zomato in-app offers | Referenced generically ("Save more with offers when you order on the app") — **no specific values published** | Zomato |
| Free delivery up to 5 km, own delivery fleet | Yes (directory-listed) | Justdial delivery details |
| Payments: UPI, Visa/Mastercard/Rupay, Cash | Yes (directory-listed) | Justdial schema |
| FSSAI licence 22721867000023 | Yes (displayed on Zomato) | Zomato |
| Owner-run website ordering | **Not available** — applespizza.in is down (HTTP 500) and the last archive snapshot of its ordering flow showed "No slot available right now" | live fetch + Wayback |
| Home-delivery platforms | Zomato page live; Swiggy listing exists but shows "not accepting orders"; no verified District/Magicpin ordering | Zomato, Swiggy |

## 6. Contradictions & unverified items (must be flagged to the owner)

1. **Current operating status** — "may be permanently closed" (Restaurant Guru) vs "open" (Justdial ×2, magicpin, Facebook, live Zomato menu). Unresolved.
2. **Number of outlets** — Friends Colony vs Ashok Nagar vs "Vijay Nagar" vs "Naurangabad Rd". Unresolved.
3. **Note on Google Business Profile:** the listing status we could not read directly — worth checking with the owner. There is also a widespread, documented issue of businesses being wrongly flagged "permanently closed" by map providers when hours are missing/conflicting ([dacgroup.com](https://www.dacgroup.com/insights/local-search-news/apple-maps-forcibly-closing-listings-over-missing-business-hours-and-conflicting-information/), [Apple community threads](https://discussions.apple.com/thread/255207154)), so a stale flag is plausible but unproven here.
4. **Opening hours** — 10 AM–7 PM (Restaurant Guru), 10 AM–9 PM (Justdial FC), 10 AM–10 PM (Justdial AN, magicpin, Yappe). The demo shows hours as *"as listed on directories"* with a "confirm" note rather than a single authoritative value.
5. **Price for two** — ₹300 (Justdial) vs ₹500 (magicpin) vs ₹1–200/person (Restaurant Guru). The demo uses only **item-level prices** (consistent across Zomato/Directory/magicpin) and avoids a "for two" claim.
6. **Rating denominators differ wildly** (7 vs 320 vs 555 vs 113). Demo labels each figure with its platform and count.
7. **Menus for sides/desserts/drinks** — referenced but unverified; excluded.
8. **Facebook page** returned HTTP 403 to our fetcher; its content is reported only from search-engine snippets of the page, not a direct read.

## 7. The existing website (facts only — no design reuse)

- `applespizza.in` → **HTTP 500 on 11 Oct 2026**; the domain resolves but the app is broken.
- Wayback: 9 captures, 27 Dec 2024 – 27 Feb 2025. Last capture shows an order-first landing screen: a "Search Your Delivery Location" flow, store picker (Etawah), **Pickup / Home Delivery** toggle, "Order Now" CTA, and the message **"No slot available right now."**
- Tech stack evidenced by archived asset list: Bootstrap, MDB, jQuery, Swiper, Popper (`/css/bootstrap.min.css`, `/js/jquery-*.js`, `/css/swiper-bundle.min.css`) — a standard third-party order-app template, plus custom `style.css` / `style-new.css`.
- Its only brand asset was an 800×383 JPEG wordmark: **"Apple's Pizza" in white bold sans-serif on a flat royal-blue field** — i.e. a plain text mark, not a designed logo. No logo file, no designed identity, no photography was found in the archive.
- No menu JSON, no prices, no hours, no address text and no crawlable content were exposed by the archived page (JavaScript-gated order app), so nothing here was taken from the old site's layout, code, or components.

**Implication for the concept:** the old site's weakness is clear — an order-app shell that failed, with no brand storytelling, no menu a visitor can read, no local-business information, and no photography. The concept therefore leads with appetite appeal + readable menu + trust/local info, and does **not** pretend to take orders.

## 8. Asset ledger

| Asset | Origin | Status |
|---|---|---|
| 6 food/interior photographs | **Original AI-generated demo photography** created for this concept | Stand-in only — owner must supply real photos |
| Wordmark "Apple's Pizza · Etawah" | **Original demo wordmark**, Fraunces + hand-drawn apple/pizza mark | Clearly labelled "concept" and swappable |
| `/assets/img/logo-archived-2025.jpg` | Old site's blue wordmark, via Wayback | Archived for reference only, not used in the design |
| Fonts | Fraunces + Manrope, self-hosted (SIL Open Font Licence) | Safe for the demo |

## 9. Source list

1. Zomato — https://www.zomato.com/etawah/apples-pizza-etawah-locality/order (menu, prices, ratings, FSSAI)
2. Zomato reviews — https://www.zomato.com/etawah/apples-pizza-etawah-locality/reviews
3. Justdial (Friends Colony) — https://www.justdial.com/Etawah/Apples-Pizza-Near-Friends-Colony-Friends-Colony/9999P5688-5688-170603004757-J3C6_BZDET
4. Justdial (Ashok Nagar) — https://www.justdial.com/Etawah/Apples-Pizza-Near-KKDC-1st-Gate-Pakka-Talab-Ashok-Nagar/9999P5688-5688-200316194116-B3B4_BZDET
5. magicpin — https://magicpin.in/Etawah/Friends-Colony/Restaurant/Apples-Pizza/store/386024/
6. Restaurant Guru — https://restaurant-guru.in/Apples-pizza-Etawah
7. Swiggy listing — https://www.swiggy.com/restaurants/apples-pizza-ramnagar-etawah-198893 (page now 404 for us; menu/prices seen via search index)
8. yappe.in — https://yappe.in/uttar-pradesh/etawah/apple-s-pizza/193420 (hours, address, 4.2/62)
9. Facebook — https://www.facebook.com/Applespizzaetw/ (403 to fetcher; snippet content only)
10. Wayback Machine — http://web.archive.org/web/20250227000759/https://www.applespizza.in/
11. Live check of https://applespizza.in/ — HTTP 500 on 11 Oct 2026

## 10. Questions the owner must answer before launch

1. Is the outlet trading, and which address(es) are live today?
2. Exact current opening hours + weekly off/holiday policy.
3. Confirm menu + prices as of today (and whether sides/desserts/drinks exist).
4. Is the Zomato/Swiggy/magicpin/District presence still active? Add or remove delivery CTA links accordingly.
5. Confirm all three phone numbers, plus WhatsApp ordering number.
6. 100% pure veg — confirm; and confirm no non-veg items are served.
7. FSSAI licence number still valid?
8. Written permission to use real photography, logo, reviews or a Google Business Profile snippet.
9. Any genuine current owner offers (the demo shows only the directory-listed magicpin 5% voucher, clearly attributed).
10. Decide the domain/launch route (`applespizza.in` is currently erroring — DNS/hosting action needed).

---

## 11. Verification method & limits (what was checked, and how)

**Checked directly (live fetches on 11 Oct 2026):** `applespizza.in` → HTTP 500 · Zomato outlet page
& reviews page · Justdial Friends Colony listing (overview, quick info, menu, photos) · Justdial
Ashok Nagar listing · magicpin outlet page · Restaurant Guru profile · Wayback Machine CDX index for
`applespizza.in` (9 captures, 27 Dec 2024 – 27 Feb 2025) and its archived landing page and logo asset.

**Checked indirectly (search-engine snapshots only, page itself blocked or gone):** Facebook page
(intro text, contact block, "Open now" flag — the page returned HTTP 403 to our fetcher) · Swiggy
listing (page now 404s for us; menu items and the "not accepting orders" state came from the
indexed snapshot) · yappe.in · tasteofcity.com.

**Not verifiable from here — do not treat as fact:** Google Maps / Google Business Profile operating
status (not readable in this environment) · whether the doors are open today · whether the phone
numbers still connect (no calls were placed) · District/Zomato app-only offers · the real
"cost for two" · current menu prices on the day of reading · ownership of the second Justdial
listing.

**Consequence:** the deliverable is labelled a **concept demo**, not a live site. No "open now"
badge, no orders, no payments, no invented offers, and no review text was written by us — the three
quotes used are verbatim from Zomato/Google reviews with the platform and date shown.
