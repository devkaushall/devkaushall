/* ============================================================
   ÉLAN — Events & Décor Atelier · interactions
   Vanilla JS · no dependencies
   ============================================================ */
(function () {
  'use strict';

  var docEl = document.documentElement;
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- Footer year ---------- */
  document.querySelectorAll('[data-year]').forEach(function (el) {
    el.textContent = String(new Date().getFullYear());
  });

  /* ---------- Scroll progress bar ---------- */
  var progress = document.querySelector('.progress span');

  /* ---------- Header state (scrolled + hide on scroll down) ---------- */
  var header = document.querySelector('.site-header');
  var lastY = window.scrollY;
  var ticking = false;

  function onScroll() {
    var y = window.scrollY;
    if (header) {
      header.classList.toggle('scrolled', y > 24);
      if (!mobileNavOpen) {
        if (y > lastY && y > 420) header.classList.add('hidden-up');
        else header.classList.remove('hidden-up');
      }
    }
    if (progress) {
      var h = docEl.scrollHeight - window.innerHeight;
      progress.style.width = (h > 0 ? (y / h) * 100 : 0) + '%';
    }
    floatersTop(y);
    parallaxTick();
    lastY = y;
    ticking = false;
  }
  window.addEventListener('scroll', function () {
    if (!ticking) { ticking = true; requestAnimationFrame(onScroll); }
  }, { passive: true });

  /* ---------- Mobile navigation ---------- */
  var navToggle = document.querySelector('.nav-toggle');
  var mobileNav = document.querySelector('.mobile-nav');
  var mobileNavOpen = false;

  function setMobileNav(open) {
    mobileNavOpen = open;
    if (!mobileNav || !navToggle) return;
    mobileNav.classList.toggle('open', open);
    navToggle.setAttribute('aria-expanded', String(open));
    navToggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    document.body.style.overflow = open ? 'hidden' : '';
    if (open) {
      mobileNav.querySelectorAll('a').forEach(function (a, i) {
        a.style.transitionDelay = (0.06 + i * 0.06) + 's';
      });
    }
  }
  if (navToggle && mobileNav) {
    navToggle.addEventListener('click', function () { setMobileNav(!mobileNavOpen); });
    mobileNav.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () { setMobileNav(false); });
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && mobileNavOpen) setMobileNav(false);
    });
  }

  /* ---------- Reveal on scroll ---------- */
  var revealEls = document.querySelectorAll('.rv, .rv-clip');
  if ('IntersectionObserver' in window && !reduceMotion) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
      });
    }, { threshold: 0.14, rootMargin: '0px 0px -6% 0px' });
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add('in'); });
  }

  /* ---------- Gentle parallax (rAF-batched) ---------- */
  var pxEls = [];
  if (!reduceMotion) {
    document.querySelectorAll('[data-parallax]').forEach(function (el) {
      pxEls.push({ el: el, speed: parseFloat(el.getAttribute('data-parallax')) || 0.1 });
    });
  }
  function parallaxTick() {
    if (!pxEls.length) return;
    var vh = window.innerHeight;
    pxEls.forEach(function (p) {
      var r = p.el.getBoundingClientRect();
      if (r.bottom < -80 || r.top > vh + 80) return;
      var offset = (r.top + r.height / 2 - vh / 2) * p.speed;
      p.el.style.transform = 'translate3d(0,' + offset.toFixed(1) + 'px,0)';
    });
  }

  /* ---------- Floating "back to top" ---------- */
  var topBtn = document.querySelector('.floater.top');
  function floatersTop(y) {
    if (topBtn) topBtn.classList.toggle('show', y > 700);
  }
  if (topBtn) {
    topBtn.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' });
    });
  }

  /* ============================================================
     PORTFOLIO — filters + lightbox
     ============================================================ */
  var workGrid = document.querySelector('.work-grid');
  if (workGrid) {
    var items = Array.prototype.slice.call(workGrid.querySelectorAll('.work-item'));
    var filterBtns = document.querySelectorAll('.filter-btn');
    var emptyNote = workGrid.querySelector('.work-empty');

    function applyFilter(cat) {
      var shown = 0;
      items.forEach(function (it) {
        var match = cat === 'all' || it.getAttribute('data-cat') === cat;
        if (match) {
          it.classList.remove('hide-item');
          shown++;
        } else {
          it.classList.add('hide-item');
        }
      });
      if (emptyNote) emptyNote.style.display = shown ? 'none' : 'block';
    }

    filterBtns.forEach(function (btn) {
      btn.addEventListener('click', function () {
        filterBtns.forEach(function (b) {
          b.classList.toggle('active', b === btn);
          b.setAttribute('aria-pressed', String(b === btn));
        });
        applyFilter(btn.getAttribute('data-filter'));
      });
    });

    /* Deep link: portfolio.html?cat=weddings */
    var params = new URLSearchParams(location.search);
    var cat = params.get('cat');
    if (cat) {
      var target = document.querySelector('.filter-btn[data-filter="' + cat + '"]');
      if (target) target.click();
    }

    /* ---------- Lightbox ---------- */
    var lightbox = document.getElementById('lightbox');
    if (lightbox) {
      var lbImg = lightbox.querySelector('.lb-media img');
      var lbTitle = lightbox.querySelector('.lb-title');
      var lbTag = lightbox.querySelector('.lb-tag');
      var lbCount = lightbox.querySelector('.lb-count');
      var visibleItems = function () {
        return items.filter(function (i) { return !i.classList.contains('hide-item'); });
      };
      var current = 0;
      var lastFocus = null;

      function renderLb() {
        var list = visibleItems();
        var item = list[current];
        if (!item) return;
        var img = item.querySelector('img');
        lbImg.src = img.getAttribute('data-full') || img.src;
        lbImg.alt = img.alt;
        lbTitle.textContent = item.getAttribute('data-title') || '';
        lbTag.textContent = item.getAttribute('data-catlabel') || '';
        lbCount.textContent = (current + 1) + ' / ' + list.length;
      }
      function openLb(idx) {
        lastFocus = document.activeElement;
        current = idx;
        renderLb();
        lightbox.classList.add('open');
        document.body.style.overflow = 'hidden';
        lightbox.querySelector('.lb-close').focus();
      }
      function closeLb() {
        lightbox.classList.remove('open');
        document.body.style.overflow = '';
        if (lastFocus) lastFocus.focus();
      }
      function stepLb(dir) {
        var list = visibleItems();
        current = (current + dir + list.length) % list.length;
        renderLb();
      }

      items.forEach(function (it) {
        it.addEventListener('click', function () {
          openLb(visibleItems().indexOf(it));
        });
      });
      lightbox.querySelector('.lb-close').addEventListener('click', closeLb);
      lightbox.querySelector('.lb-prev').addEventListener('click', function () { stepLb(-1); });
      lightbox.querySelector('.lb-next').addEventListener('click', function () { stepLb(1); });
      lightbox.addEventListener('click', function (e) {
        if (e.target === lightbox) closeLb();
      });
      document.addEventListener('keydown', function (e) {
        if (!lightbox.classList.contains('open')) return;
        if (e.key === 'Escape') closeLb();
        if (e.key === 'ArrowLeft') stepLb(-1);
        if (e.key === 'ArrowRight') stepLb(1);
      });
      /* swipe */
      var tsX = null;
      lightbox.addEventListener('touchstart', function (e) { tsX = e.touches[0].clientX; }, { passive: true });
      lightbox.addEventListener('touchend', function (e) {
        if (tsX === null) return;
        var dx = e.changedTouches[0].clientX - tsX;
        if (Math.abs(dx) > 48) stepLb(dx > 0 ? -1 : 1);
        tsX = null;
      }, { passive: true });
    }
  }

  /* ============================================================
     FAQ accordion
     ============================================================ */
  document.querySelectorAll('.faq').forEach(function (faq) {
    var q = faq.querySelector('.faq-q');
    if (!q) return;
    q.addEventListener('click', function () {
      var isOpen = faq.classList.contains('open');
      document.querySelectorAll('.faq.open').forEach(function (f) {
        f.classList.remove('open');
        f.querySelector('.faq-q').setAttribute('aria-expanded', 'false');
      });
      if (!isOpen) {
        faq.classList.add('open');
        q.setAttribute('aria-expanded', 'true');
      }
    });
  });

  /* ============================================================
     ENQUIRY FORM — validation + WhatsApp / Email compose
     NOTE: replace the placeholder number below with the real
     business WhatsApp number before going live.
     ============================================================ */
  var WA_NUMBER = '919876543210'; // placeholder — replace before launch
  var form = document.getElementById('enquiry-form');

  if (form) {
    var success = document.getElementById('form-success');
    var fsText = document.getElementById('fs-text');
    var fsWaLink = document.getElementById('fs-wa-link');
    var fsMailLink = document.getElementById('fs-mail-link');

    function getField(id) { return form.querySelector('#' + id); }

    /* Deep link from packages page: contact.html?f-package=signature */
    var pkgParam = new URLSearchParams(location.search).get('f-package');
    if (pkgParam) {
      var pkgNames = { intimate: 'The Intimate', signature: 'The Signature', grand: 'The Grand Atelier' };
      var pkgName = pkgNames[pkgParam];
      if (pkgName) {
        var msgField = getField('f-msg');
        if (msgField && !msgField.value) {
          msgField.value = 'I’m interested in the ' + pkgName + ' package — please share a tailored quotation.';
        }
      }
    }

    function validateField(field) {
      var wrap = field.closest('.field');
      var val = (field.value || '').trim();
      var ok = true;
      if (field.hasAttribute('required') && !val) ok = false;
      if (ok && field.type === 'tel' && val) {
        ok = /^[+]?[\d\s\-()]{8,16}$/.test(val);
      }
      if (ok && field.type === 'email' && val) {
        ok = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(val);
      }
      if (wrap) wrap.classList.toggle('invalid', !ok);
      return ok;
    }

    form.querySelectorAll('input, select, textarea').forEach(function (f) {
      f.addEventListener('blur', function () { validateField(f); });
      f.addEventListener('input', function () {
        var wrap = f.closest('.field');
        if (wrap && wrap.classList.contains('invalid')) validateField(f);
      });
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var fields = ['f-name', 'f-phone', 'f-email', 'f-type', 'f-date', 'f-city', 'f-guests', 'f-budget', 'f-msg'];
      var valid = true;
      var firstInvalid = null;
      fields.forEach(function (id) {
        var f = getField(id);
        if (!f) return;
        if (!validateField(f)) { valid = false; firstInvalid = firstInvalid || f; }
      });
      if (!valid) {
        if (firstInvalid) firstInvalid.focus();
        return;
      }

      var lines = [
        'Hello ÉLAN! I would like to plan an event.',
        '',
        'Name: ' + getField('f-name').value.trim(),
        'Phone: ' + getField('f-phone').value.trim(),
        'Email: ' + (getField('f-email').value.trim() || '—'),
        'Event type: ' + getField('f-type').value,
        'Event date: ' + (getField('f-date').value || 'Not decided'),
        'City / venue: ' + (getField('f-city').value.trim() || '—'),
        'Guests: ' + getField('f-guests').value,
        'Budget: ' + getField('f-budget').value,
        ''
      ];
      var msg = getField('f-msg').value.trim();
      if (msg) lines.push('Details: ' + msg);

      var waText = encodeURIComponent(lines.join('\n'));
      var waUrl = 'https://wa.me/' + WA_NUMBER + '?text=' + waText;
      var mailUrl = 'mailto:hello@elanevents.in?subject=' +
        encodeURIComponent('Event enquiry — ' + getField('f-type').value) +
        '&body=' + encodeURIComponent(lines.join('\n'));

      if (fsText) {
        fsText.textContent = 'Aapka message ready hai. "Send on WhatsApp" dabate hi WhatsApp khulega aur message pre-filled milega — bas send karna hai.';
      }
      if (fsWaLink) fsWaLink.setAttribute('href', waUrl);
      if (fsMailLink) fsMailLink.setAttribute('href', mailUrl);
      if (success) success.classList.add('show');

      var waBtn = document.getElementById('fs-wa-link');
      if (waBtn) {
        waBtn.addEventListener('click', function () { setTimeout(function () { form.reset(); success.classList.remove('show'); }, 1200); }, { once: true });
      }
    });

    var successClose = document.getElementById('fs-close');
    if (successClose) {
      successClose.addEventListener('click', function () {
        success.classList.remove('show');
        form.reset();
        var first = getField('f-name');
        if (first) first.focus();
      });
    }
  }

  /* ---------- First paint ---------- */
  onScroll();
})();
