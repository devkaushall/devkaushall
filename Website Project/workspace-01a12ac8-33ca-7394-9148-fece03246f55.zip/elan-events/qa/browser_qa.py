#!/usr/bin/env python3
"""Functional + visual QA for the ÉLAN demo site using headless Chromium."""
import json
import sys
from playwright.sync_api import sync_playwright

BASE = "http://localhost:8000"
SHOTS = "/home/user/elan-events/qa/shots"
results = []
failures = []


def check(name, cond, detail=""):
    results.append((name, bool(cond), detail))
    if not cond:
        failures.append(f"{name} {(': ' + detail) if detail else ''}")



def reveal_all(page):
    """Scroll through the page so IntersectionObserver reveals fire (like a real user)."""
    page.evaluate("""async () => {
        const d = document.documentElement;
        d.style.scrollBehavior = 'auto';
        const step = Math.round(window.innerHeight * 0.7);
        for (let y = 0; y <= d.scrollHeight; y += step) {
            window.scrollTo(0, y);
            await new Promise(r => setTimeout(r, 120));
        }
        window.scrollTo(0, 0);
        d.style.scrollBehavior = '';
    }""")
    page.wait_for_timeout(700)

def run():
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        ctx = browser.new_context(viewport={"width": 1440, "height": 900}, device_scale_factor=1)
        page = ctx.new_page()
        console_errors = []
        failed_req = []
        page.on("console", lambda m: console_errors.append(m.text) if m.type == "error" else None)
        page.on("requestfailed", lambda r: failed_req.append(r.url))

        # ---------- HOME (desktop) ----------
        page.goto(BASE + "/", wait_until="networkidle")
        check("home: title", "ÉLAN" in page.title())
        check("home: no console errors", not console_errors, "; ".join(console_errors[:3]))
        check("home: no failed requests", not failed_req, "; ".join(failed_req[:3]))
        check("home: hero visible", page.locator(".hero .display").is_visible())
        page.screenshot(path=f"{SHOTS}/home-desktop-hero.png")

        # header scroll state
        page.mouse.wheel(0, 900)
        page.wait_for_timeout(400)
        check("home: header gains .scrolled", "scrolled" in (page.get_attribute(".site-header", "class") or ""))

        # reveal animations applied
        revealed = page.eval_on_selector_all(".rv", "els => els.filter(e => e.classList.contains('in')).length")
        total_rv = page.eval_on_selector_all(".rv", "els => els.length")
        check("home: reveal-on-scroll working", revealed > 3, f"{revealed}/{total_rv} revealed after scroll")

        # services hover
        page.hover(".service-card >> nth=0")
        page.wait_for_timeout(700)
        page.screenshot(path=f"{SHOTS}/home-desktop-services.png")

        # no horizontal overflow
        ovf = page.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
        check("home: no horizontal overflow (1440)", ovf <= 0, f"overflow={ovf}px")

        # full page shot
        page.goto(BASE + "/", wait_until="networkidle")
        reveal_all(page)
        page.screenshot(path=f"{SHOTS}/home-desktop-full.png", full_page=True)

        # ---------- PORTFOLIO ----------
        page.goto(BASE + "/portfolio.html", wait_until="networkidle")
        all_count = page.locator(".work-item:not(.hide-item)").count()
        check("portfolio: 10 items initially", all_count == 10, f"got {all_count}")
        page.locator(".filter-btn", has_text="Weddings").first.click()
        page.wait_for_timeout(600)
        w_count = page.locator(".work-item:not(.hide-item)").count()
        check("portfolio: weddings filter shows 4", w_count == 4, f"got {w_count}")

        # deep link test
        page.goto(BASE + "/portfolio.html?cat=birthdays", wait_until="networkidle")
        page.wait_for_timeout(500)
        b_count = page.locator(".work-item:not(.hide-item)").count()
        active = page.locator(".filter-btn.active").get_attribute("data-filter")
        check("portfolio: deep-link ?cat=birthdays", b_count == 2 and active == "birthdays", f"count={b_count}, active={active}")

        # lightbox
        page.locator(".work-item:not(.hide-item)").first.click()
        page.wait_for_timeout(700)
        check("lightbox: opens", "open" in (page.get_attribute("#lightbox", "class") or ""))
        check("lightbox: image populated", (page.get_attribute(".lb-media img", "src") or "") != "")
        t1 = page.text_content(".lb-title")
        page.keyboard.press("ArrowRight")
        page.wait_for_timeout(400)
        t2 = page.text_content(".lb-title")
        check("lightbox: arrow key changes slide", t1 != t2, f"'{t1}' -> '{t2}'")
        page.screenshot(path=f"{SHOTS}/portfolio-lightbox.png")
        page.keyboard.press("Escape")
        page.wait_for_timeout(500)
        check("lightbox: Esc closes", "open" not in (page.get_attribute("#lightbox", "class") or ""))
        reveal_all(page)
        page.screenshot(path=f"{SHOTS}/portfolio-desktop.png", full_page=True)

        # ---------- PACKAGES ----------
        page.goto(BASE + "/packages.html", wait_until="networkidle")
        first_faq = page.locator(".faq").first
        first_faq.locator(".faq-q").click()
        page.wait_for_timeout(700)
        check("packages: FAQ opens", "open" in (first_faq.get_attribute("class") or ""))
        reveal_all(page)
        page.screenshot(path=f"{SHOTS}/packages-desktop-full.png", full_page=True)

        # ---------- CONTACT ----------
        page.goto(BASE + "/contact.html", wait_until="networkidle")

        # package deep link prefill
        page.goto(BASE + "/contact.html?f-package=signature", wait_until="networkidle")
        msg = page.input_value("#f-msg")
        check("contact: ?f-package prefill", "The Signature" in msg, msg[:60])

        # empty submit -> validation errors
        page.locator("#enquiry-form button[type=submit]").click()
        page.wait_for_timeout(400)
        invalid = page.locator(".field.invalid").count()
        check("contact: validation blocks empty submit", invalid >= 4, f"{invalid} invalid fields flagged")
        check("contact: success hidden before valid submit", "show" not in (page.get_attribute("#form-success", "class") or ""))

        # valid submit -> success + wa link
        page.fill("#f-name", "Test User")
        page.fill("#f-phone", "+91 98765 00000")
        page.fill("#f-email", "test@example.com")
        page.select_option("#f-type", label="Wedding")
        page.fill("#f-date", "2026-02-14")
        page.fill("#f-city", "Delhi")
        page.select_option("#f-guests", label="100 – 300")
        page.select_option("#f-budget", label="₹3.5 – 10 Lakh")
        page.fill("#f-msg", "Theme: ivory & gold, sangeet + reception.")
        page.locator("#enquiry-form button[type=submit]").click()
        page.wait_for_timeout(700)
        check("contact: success panel shows", "show" in (page.get_attribute("#form-success", "class") or ""))
        wa_href = page.get_attribute("#fs-wa-link", "href") or ""
        check("contact: wa.me link composed", wa_href.startswith("https://wa.me/919876543210?text=") and "Wedding" in wa_href, wa_href[:70])
        mail_href = page.get_attribute("#fs-mail-link", "href") or ""
        check("contact: mailto fallback composed", mail_href.startswith("mailto:hello@elanevents.in"), mail_href[:50])
        page.screenshot(path=f"{SHOTS}/contact-success.png")

        # ---------- MOBILE 390 ----------
        mob = browser.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True, has_touch=True)
        mp = mob.new_page()
        mconsole = []
        mp.on("console", lambda m: mconsole.append(m.text) if m.type == "error" else None)
        mp.goto(BASE + "/", wait_until="networkidle")
        check("mobile: no console errors", not mconsole, "; ".join(mconsole[:3]))
        movf = mp.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
        check("mobile: no horizontal overflow (390)", movf <= 0, f"overflow={movf}px")
        mp.screenshot(path=f"{SHOTS}/home-mobile-hero.png")

        # mobile nav
        mp.locator(".nav-toggle").click()
        mp.wait_for_timeout(600)
        check("mobile: nav opens", "open" in (mp.get_attribute(".mobile-nav", "class") or ""))
        mp.screenshot(path=f"{SHOTS}/home-mobile-nav.png")
        mp.locator(".mobile-nav a", has_text="Portfolio").click()
        mp.wait_for_timeout(800)
        check("mobile: nav link navigates", "portfolio.html" in mp.url)
        check("mobile: nav closes after click", "open" not in (mp.get_attribute(".mobile-nav", "class") or ""))

        # portfolio on mobile + lightbox swipe target exists
        mp.wait_for_timeout(400)
        mw_ovf = mp.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
        check("mobile portfolio: no overflow", mw_ovf <= 0, f"overflow={mw_ovf}px")
        reveal_all(mp)
        mp.screenshot(path=f"{SHOTS}/portfolio-mobile.png", full_page=True)

        # contact on mobile
        mp.goto(BASE + "/contact.html", wait_until="networkidle")
        mc_ovf = mp.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
        check("mobile contact: no overflow", mc_ovf <= 0, f"overflow={mc_ovf}px")
        reveal_all(mp)
        mp.screenshot(path=f"{SHOTS}/contact-mobile.png", full_page=True)

        # ---------- TABLET 768 ----------
        tab = browser.new_context(viewport={"width": 768, "height": 1024}, device_scale_factor=1)
        tp = tab.new_page()
        tp.goto(BASE + "/", wait_until="networkidle")
        tovf = tp.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
        check("tablet: no horizontal overflow (768)", tovf <= 0, f"overflow={tovf}px")
        reveal_all(tp)
        tp.screenshot(path=f"{SHOTS}/home-tablet.png", full_page=True)


        # ---------- NO-JS FALLBACK ----------
        nojs_ctx = browser.new_context(viewport={"width": 1440, "height": 900}, java_script_enabled=False)
        nj = nojs_ctx.new_page()
        nj.goto(BASE + "/", wait_until="load")
        nj_h = nj.locator(".hero .display")
        check("no-js: hero content visible", nj_h.is_visible())
        rv_vis = nj.eval_on_selector_all(".rv", "els => els.filter(e => getComputedStyle(e).opacity === '1').length")
        rv_all = nj.eval_on_selector_all(".rv", "els => els.length")
        check("no-js: all .rv content visible", rv_vis == rv_all, f"{rv_vis}/{rv_all}")
        nojs_ctx.close()

        # ---------- PERFORMANCE snapshot ----------
        page.goto(BASE + "/", wait_until="networkidle")
        n_req = page.evaluate("performance.getEntriesByType('resource').length")
        transfer = page.evaluate("performance.getEntriesByType('resource').reduce((a,r)=>a+(r.transferSize||0),0)/1024")
        check("home: reasonable request count", n_req <= 40, f"{n_req} requests, {transfer:.0f} KB transferred")

        browser.close()

    print("\n===== QA RESULTS =====")
    for name, okn, detail in results:
        print(("PASS  " if okn else "FAIL  ") + name + (f"   [{detail}]" if detail and not okn else ""))
    print(f"\n{sum(1 for _, o, _ in results if o)}/{len(results)} passed")
    sys.exit(1 if failures else 0)


run()
