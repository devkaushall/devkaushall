# ÉLAN — Events & Décor Atelier (Demo Website)

Premium event planning & decoration business ke liye luxury editorial style demo website.
Pitch-ready: 4 pages, interactive portfolio, packages, WhatsApp enquiry system — fully responsive.

## Pages

| Page | File | Features |
|---|---|---|
| Home | `index.html` | Cinematic hero, services grid, portfolio mosaic, 4-step process, quote band, CTA |
| Portfolio | `portfolio.html` | Category filters (deep-linkable `?cat=`), full-screen lightbox (keyboard + swipe) |
| Packages | `packages.html` | 3 packages with indicative pricing, 8 add-ons, FAQ accordion |
| Contact | `contact.html` | Validated enquiry form → pre-filled WhatsApp message (+ mailto fallback) |

## Tech

- **Zero dependencies** — vanilla HTML/CSS/JS, koi framework/library nahi
- Self-hosted fonts (Cormorant Garamond + Jost, `assets/fonts/`)
- AI-generated original photography (`assets/img/`) — koi copyright issue nahi
- `prefers-reduced-motion` respect, semantic HTML, aria labels, no-JS fallback
- Total ~3 MB images; har page ~30–35 requests (fast load)

## Rebrand checklist (client finalize hone par)

1. **WhatsApp number**: `assets/js/main.js` mein `WA_NUMBER` replace karo
   (`919876543210`), aur HTML files mein `wa.me/919876543210` + `tel:+919876543210` links.
   Quick way:
   ```bash
   grep -rl "919876543210" *.html assets/js | xargs sed -i 's/919876543210/<NEW_NUMBER_WITH_COUNTRY_CODE>/g'
   ```
2. **Email**: `hello@elanevents.in` replace karo (contact cards + `main.js` ka mailto).
3. **Brand name / logo**: "ÉLAN" text logo CSS class `.brand-name` mein hai — replace & adjust.
4. **Photography**: `assets/img/` mein apni event photos daal do (same filenames = no code change).
5. **City / address**: footer + contact page mein "New Delhi" updates.
6. **Packages & pricing**: `packages.html` mein indicative rates edit karo.

> Note: Form backend nahi hai — enquiry WhatsApp deep-link bana deta hai (demo ke liye
> by design, production mein Formspree/Netlify Forms/own API add ho sakta hai).

## Run locally

```bash
python3 -m http.server 8000
# http://localhost:8000
```

## QA

`qa/browser_qa.py` (Playwright) — **32/32 checks passing**:
links, filters, lightbox, form validation, WhatsApp/mail compose, mobile nav,
3-viewport overflow tests, console/request errors, no-JS visibility, perf snapshot.
Screenshots: `qa/shots/`.
