# Looks Salon — research & creative direction

**Research checked:** 11 October 2026  
**Reference site:** [lookssalon.in](https://www.lookssalon.in/)  
**Purpose:** an original interactive concept for client presentation—not a reproduction of the live site and not an official booking channel.

## Understand — verified brand facts

### Brand identity
- The official About page gives January 1989 as the establishment date; the company LinkedIn page identifies the first salon as Karol Bagh, New Delhi. The prototype uses that origin story, not a salon-count claim.
- The official home page links to the brand Instagram. The official social destinations surfaced on the site / official channel are Instagram `@looksunisexsalon`, Facebook `Looksunisexsalon`, X/Twitter `@looksindia`, and YouTube `@lookssalonofficial`. No follower counts are reproduced.
- The official site uses the descriptor “premium” and describes services for men and women. The concept stays within those categories, but its art direction, copy, layout, mark, interactions and code are original.

### Services (verified on official category pages)
- **Hair styling / finish:** hair cut, blow dry, ironing, global colour, root touch-up, shampoo/conditioning, head massage, roller setting and oiling.
- **Colour / texture / treatment:** colour (including ammonia and ammonia-free options on the gents page), highlights, straightening, smoothening, rebonding, perming, keratin, hair spa, scalp treatments and colour protection.
- **Skin / beauty:** facials, clean-ups, organic treatments, bleach, threading, body polishing / rejuvenation, waxing, manicure and pedicure.
- **Makeup:** party, engagement, bridal/reception, base and eye makeup.
- **Grooming:** beard trim, colour, styling, shave and luxury shave / beard spa.

The prototype asks visitors to confirm service availability locally and does not imply that every item is available at every outlet.

### Selected New Delhi branches shown in the finder
These four records were checked against the official [Central Delhi locator](https://www.lookssalon.in/locate-salon/new-delhi/central-delhi). The on-page finder calls them a **selected set**, not a complete network list.

| Branch | Official listing address | Phone used in concept | Published hours |
| --- | --- | --- | --- |
| Connaught Place | C-33, First Floor, Inner Circle, Connaught Place, Delhi 110001 | 011 4351 2929 | 10:00 AM–9:00 PM |
| Khan Market | 72, Khan Market, New Delhi 110003 | 011 4175 7233 (the listing also shows 011 4175 7244) | 10:00 AM–8:30 PM |
| Karol Bagh | 17A/22, WEA Ajmal Khan Road, Karol Bagh, New Delhi 110005 | +91 99535 33412 | 10:00 AM–7:30 PM |
| Chandni Chowk | Shop 025–32, first floor, Omaxe Chowk Mall, H.C. Sen Marg, Gandhi Maidan, Chandni Chowk, Delhi 110006 | 911142231947 | 10:00 AM–8:00 PM |

The live directory can change; each card links to a map and the page links back to the official finder. Confirm before relying on hours or branch contact details.

### Pricing, offers and booking
- No single current, branch-wide service price list was found on the supplied official `.in` site’s service pages. Third-party price lists conflict and are **not** used.
- The official E-Shop page surfaced prepaid cards (Blue ₹6,000 for ₹7,500 service value; Silver ₹15,000 for ₹20,000; Gold ₹50,000 for ₹75,000), with different validity / exclusions. These are not service-menu prices and may change, so they are not promoted in the concept.
- The official Offers page describes periodic offers but did not provide a specific live offer in the retrieved content. No discount or campaign is invented or displayed.
- The official appointment page describes an **enquiry with follow-up**, not an instant confirmed slot: online booking enquiries operate 10 AM–6 PM; it says the team calls back within an hour during that window, or after 10 AM if submitted outside it. The page lists `1800 212 56657` as the central number.
- No booking API, live schedule or integration credentials were available. The concept form is therefore local-only, has no network submission and always discloses that it **does not book**. A separate link takes users to the official booking page.

### Claims intentionally omitted
Branch-count claims differ across the official home/About pages, older service copy and current social descriptions. This demo omits network totals. It also avoids unverified prices, current offers, awards, testimonials, star ratings, guaranteed outcomes, branch-level service availability and any assertion that generated images are Looks clients.

## Review — observed website limitations (research notes, not a judgement on the business)
- The supplied official site is content-rich but legacy-shaped: service information is separated into Ladies/Gents pages and repeated booking prompts; the user has to cross between service, locator and booking paths.
- Booking is presented as a callback request. No live appointment slots, confirmation state or real-time branch availability was visible in the retrieved page content.
- The locator contains many locations, but the regional narrative/count copy is not perfectly consistent with the live branch cards; the demo uses a small, explicitly labelled selection and links to the source directory.
- The official Offers page is informational, not a browsable live deal catalogue. The E-Shop has prepaid-card values, not a uniform service menu.
- Public pages provide useful service categories and branch details, but not one clearly verified, current service-rate card for all locations.

## Plan — original direction
**“The modern atelier”:** a fashion-editorial, Delhi-rooted concept with parchment, ink-aubergine and restrained clay; expressive serif typography paired with a quiet sans; arched portrait crop, asymmetric editorial grids, generous breathing room and original AI-generated campaign imagery. The look deliberately does not reuse the reference site’s layout, banners, assets, CSS or implementation.

**Patterns translated into this concept:** a clear booking CTA; mobile-first, short progressive booking; branch-aware contact/map links; browsable service categories; filterable visual inspiration; a keyboard-operable reveal slider; responsive cards; readable disclosure around uncertain prices / simulated booking. These are common experience patterns, not copied interface components.

**Build choices:** the workspace was empty, so the prototype uses plain HTML, CSS and JavaScript with no added packages, external fonts, remote image dependencies, trackers or network form submission. This keeps the preview portable and lightweight. Motion is restrained and respects `prefers-reduced-motion`.

## Sources

### Official Looks Salon pages
- [Home](https://www.lookssalon.in/) — identity, booking prompt, social links and partners.
- [About / history](https://www.lookssalon.in/aboutus.html) — origin story and January 1989 date. The [Looks Salon LinkedIn page](https://in.linkedin.com/company/looks-unisex-salon) identifies the first salon in Karol Bagh.
- [Ladies services](https://www.lookssalon.in/ladies-salon-services.html) — hair, makeup, texture, skin, hand/feet and nail categories.
- [Gents services](https://www.lookssalon.in/gents-salon-services.html) — hair, colour, texture, skin and beard grooming categories.
- [Appointment page](https://www.lookssalon.in/salon-book-appointment.html) — call-back process / operating window / central phone.
- [Central Delhi locator](https://www.lookssalon.in/locate-salon/new-delhi/central-delhi) — selected addresses, phones and hours.
- [Offers](https://www.lookssalon.in/offers.html) — offer-page content at retrieval.
- [E-Shop / prepaid cards](https://www.lookssalon.in/salon-beauty-products-eshop.html) — published card values and conditions.
- [Contact](https://www.lookssalon.in/contact.html) — head-office number and official feedback contacts.
- [Instagram](https://www.instagram.com/looksunisexsalon/), [Facebook](https://www.facebook.com/Looksunisexsalon/), [X/Twitter](https://twitter.com/looksindia), [YouTube](https://www.youtube.com/@lookssalonofficial).

### Interaction / accessibility references
- [Square: How to build a salon website](https://squareup.com/us/en/the-bottom-line/starting-your-business/salon-website) — portfolio imagery, simple booking, clear services, mobile and brand-consistent design patterns.
- [W3C WAI: WCAG 2.2 target size minimum](https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum.html) — touch target guidance.
- [W3C WAI: WCAG 2.2 focus visible](https://www.w3.org/WAI/WCAG22/Understanding/focus-visible.html) — visible keyboard focus.

## Prototype image provenance
All six images in `images/` were generated specifically for this concept. They are local assets; there are no hotlinked stock photos. The slider uses two generated editorial portraits and is labelled as a concept visualization, **not** an actual client before/after.
