(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const serviceInfo = {
    hair: {
      title: 'Hair & finish',
      bookingService: 'Hair & styling',
      description: 'A considered starting point for cuts, everyday styling and hair care.',
      items: ['Hair cut & finish', 'Blow dry & ironing', 'Shampoo & conditioning', 'Hair spa treatments', 'Scalp treatments', 'Colour protection']
    },
    colour: {
      title: 'Colour & texture',
      bookingService: 'Hair colour & texture',
      description: 'Explore colour and texture services from the official Looks Salon service list.',
      items: ['Global colour', 'Root touch-up', 'Highlights / hi-lites', 'Straightening & smoothening', 'Keratin', 'Perming & rebonding']
    },
    skin: {
      title: 'Skin & rituals',
      bookingService: 'Skin & facials',
      description: 'Beauty and skin options listed across the official ladies’ and gents’ service pages.',
      items: ['Facials & luxury rituals', 'Clean-ups', 'Organic treatments', 'Bleach & threading', 'Body polishing', 'Skin care']
    },
    makeup: {
      title: 'Makeup & occasion',
      bookingService: 'Makeup & occasion',
      description: 'For an occasion look, discuss the brief and service details directly with your salon.',
      items: ['Party makeup', 'Engagement makeup', 'Bridal & reception makeup', 'Base makeup', 'Eye makeup', 'Hair styling']
    },
    grooming: {
      title: 'Grooming & more',
      bookingService: 'Grooming, hands & feet',
      description: 'A broader grooming edit, with selected hand, foot and nail care also listed officially.',
      items: ['Beard trim & styling', 'Shave & beard colour', 'Manicure & pedicure', 'Nail paint & nail art', 'Waxing', 'Hair / scalp care']
    }
  };

  const branchNames = {
    'cp-inner-circle': 'Connaught Place · C-33 Inner Circle',
    'khan-market-72': 'Khan Market · 72 Khan Market',
    'karol-bagh': 'Karol Bagh · Ajmal Khan Road',
    'chandni-chowk': 'Chandni Chowk · Omaxe Chowk Mall'
  };

  // Mobile navigation
  const menuToggle = $('.menu-toggle');
  const mobileNav = $('#mobile-nav');
  if (menuToggle && mobileNav) {
    menuToggle.addEventListener('click', () => {
      const isOpen = menuToggle.getAttribute('aria-expanded') === 'true';
      menuToggle.setAttribute('aria-expanded', String(!isOpen));
      menuToggle.setAttribute('aria-label', isOpen ? 'Open navigation' : 'Close navigation');
      mobileNav.hidden = isOpen;
    });

    $$('a, button', mobileNav).forEach((item) => {
      item.addEventListener('click', () => {
        mobileNav.hidden = true;
        menuToggle.setAttribute('aria-expanded', 'false');
        menuToggle.setAttribute('aria-label', 'Open navigation');
      });
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && !mobileNav.hidden) {
        mobileNav.hidden = true;
        menuToggle.setAttribute('aria-expanded', 'false');
        menuToggle.setAttribute('aria-label', 'Open navigation');
        menuToggle.focus();
      }
    });
  }

  // Service cards reveal only the services confirmed on the official menu pages.
  const detailPanel = $('#service-detail');
  const detailTitle = $('#service-detail-title');
  const detailDescription = $('#service-detail-description');
  const detailList = $('#service-detail-list');
  const detailBook = $('#service-detail-book');
  let selectedServiceId = '';

  function showService(id) {
    const info = serviceInfo[id];
    if (!info || !detailPanel) return;

    if (selectedServiceId === id && !detailPanel.hidden) {
      detailPanel.hidden = true;
      selectedServiceId = '';
      $$('[data-service]').forEach((card) => card.setAttribute('aria-expanded', 'false'));
      return;
    }

    selectedServiceId = id;
    detailTitle.textContent = info.title;
    detailDescription.textContent = info.description;
    detailList.replaceChildren();
    info.items.forEach((item) => {
      const li = document.createElement('li');
      li.textContent = item;
      detailList.append(li);
    });
    $$('[data-service]').forEach((card) => {
      card.setAttribute('aria-expanded', String(card.dataset.service === id));
    });
    detailPanel.hidden = false;
    if (window.innerWidth <= 620) {
      detailPanel.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'nearest' });
    }
  }

  $$('[data-service]').forEach((card) => {
    card.addEventListener('click', () => showService(card.dataset.service));
  });

  if (detailBook) {
    detailBook.addEventListener('click', () => {
      const info = serviceInfo[selectedServiceId];
      openBooking('', info ? info.bookingService : '');
    });
  }

  // Filterable inspiration gallery and accessible image lightbox.
  const galleryFilters = $$('[data-gallery-filter]');
  const galleryItems = $$('[data-gallery-item]');
  const galleryStatus = $('#gallery-status');

  function setGalleryFilter(category) {
    let visible = 0;
    galleryItems.forEach((item) => {
      const matches = category === 'all' || item.dataset.category === category;
      item.hidden = !matches;
      if (matches) visible += 1;
    });
    galleryFilters.forEach((button) => {
      const active = button.dataset.galleryFilter === category;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    if (galleryStatus) {
      const readable = category === 'all' ? 'all categories' : `${category} category`;
      galleryStatus.textContent = `${String(visible).padStart(2, '0')} image${visible === 1 ? '' : 's'} · ${readable}`;
    }
  }

  galleryFilters.forEach((button) => {
    button.addEventListener('click', () => setGalleryFilter(button.dataset.galleryFilter));
  });

  const lightbox = $('#lightbox-dialog');
  const lightboxImage = $('#lightbox-image');
  const lightboxCaption = $('#lightbox-caption');
  $$('[data-gallery-item]').forEach((item) => {
    item.addEventListener('click', () => {
      if (!lightbox || !lightboxImage || typeof lightbox.showModal !== 'function') return;
      const image = $('img', item);
      lightboxImage.src = item.dataset.full;
      lightboxImage.alt = image ? image.alt || item.getAttribute('aria-label') : '';
      lightboxCaption.textContent = item.dataset.caption || '';
      lightbox.showModal();
      $('[data-lightbox-close]', lightbox).focus();
    });
  });
  $$('[data-lightbox-close]').forEach((button) => button.addEventListener('click', () => lightbox?.close()));
  if (lightbox) {
    lightbox.addEventListener('click', (event) => {
      if (event.target === lightbox) lightbox.close();
    });
    lightbox.addEventListener('close', () => {
      if (lightboxImage) lightboxImage.removeAttribute('src');
      if (lightboxCaption) lightboxCaption.textContent = '';
    });
  }

  // Before/after-style visual comparison is disclosed as generated concept art.
  const revealRange = $('#reveal-range');
  const afterLayer = $('#after-layer');
  const revealDivider = $('#reveal-divider');
  if (revealRange && afterLayer && revealDivider) {
    const updateReveal = () => {
      const value = Number(revealRange.value);
      afterLayer.style.setProperty('--reveal', `${value}%`);
      revealDivider.style.left = `${value}%`;
      revealRange.setAttribute('aria-valuetext', `${value} percent styled image revealed`);
    };
    revealRange.addEventListener('input', updateReveal);
    updateReveal();
  }

  // Searchable, locally verified sample of Delhi branches (not the full network).
  const locationSearch = $('#location-search');
  const areaFilter = $('#area-filter');
  const locationCards = $$('[data-location-card]');
  const locationStatus = $('#location-status');
  const locationEmpty = $('#location-empty');

  function filterLocations() {
    const query = (locationSearch?.value || '').trim().toLowerCase();
    const area = areaFilter?.value || 'all';
    let visible = 0;
    locationCards.forEach((card) => {
      const areaMatches = area === 'all' || card.dataset.area === area;
      const textMatches = !query || card.dataset.search.toLowerCase().includes(query);
      const matches = areaMatches && textMatches;
      card.hidden = !matches;
      if (matches) visible += 1;
    });
    if (locationStatus) {
      locationStatus.textContent = `${visible} selected location${visible === 1 ? '' : 's'}${visible === 0 ? ' · try another search' : ''}`;
    }
    if (locationEmpty) locationEmpty.hidden = visible !== 0;
  }
  locationSearch?.addEventListener('input', filterLocations);
  areaFilter?.addEventListener('change', filterLocations);

  // A local-only, multi-step booking request preview.
  const bookingDialog = $('#booking-dialog');
  const bookingForm = $('#booking-form');
  const bookingStepOne = $('#booking-step-one');
  const bookingStepTwo = $('#booking-step-two');
  const bookingProgress = $('#booking-progress');
  const bookingSuccess = $('#booking-success');
  const bookingService = $('#booking-service');
  const bookingBranch = $('#booking-branch');
  const bookingDate = $('#booking-date');
  const bookingTime = $('#booking-time');
  const bookingName = $('#booking-name');
  const bookingPhone = $('#booking-phone');
  const stepOneError = $('#step-one-error');
  const requestSummary = $('#request-summary');
  const stepContext = $('#step-context');
  let returnFocusTo = null;

  function getBranchName(id) {
    return branchNames[id] || 'a selected Delhi salon';
  }

  function setDateMinimum() {
    if (!bookingDate) return;
    const today = new Date();
    const localDate = [today.getFullYear(), String(today.getMonth() + 1).padStart(2, '0'), String(today.getDate()).padStart(2, '0')].join('-');
    bookingDate.min = localDate;
  }
  setDateMinimum();

  function resetBooking() {
    bookingForm?.reset();
    if (bookingStepOne) bookingStepOne.hidden = false;
    if (bookingStepTwo) bookingStepTwo.hidden = true;
    if (bookingProgress) {
      bookingProgress.hidden = false;
      bookingProgress.innerHTML = '<span class="progress-current">01</span><span class="progress-line"></span><span>02</span><span class="progress-label">Service &amp; salon</span>';
    }
    if (bookingSuccess) bookingSuccess.hidden = true;
    if (bookingForm) bookingForm.hidden = false;
    if (stepOneError) stepOneError.hidden = true;
    if (requestSummary) requestSummary.textContent = '';
    if (bookingPhone) bookingPhone.setCustomValidity('');
    if (bookingName) bookingName.setCustomValidity('');
    setDateMinimum();
  }

  function openBooking(branchId = '', serviceName = '') {
    if (!bookingDialog || typeof bookingDialog.showModal !== 'function') return;
    resetBooking();
    returnFocusTo = document.activeElement;
    if (mobileNav && returnFocusTo && mobileNav.contains(returnFocusTo)) returnFocusTo = menuToggle;
    if (branchId && bookingBranch) bookingBranch.value = branchId;
    if (serviceName && bookingService) bookingService.value = serviceName;
    bookingDialog.showModal();
    window.setTimeout(() => {
      const firstMissing = [bookingService, bookingBranch].find((field) => field && !field.value);
      (firstMissing || $('#booking-step-one-title'))?.focus({ preventScroll: true });
    }, 0);
  }

  $$('[data-booking-open]').forEach((button) => {
    button.addEventListener('click', () => openBooking(button.dataset.branch || '', button.dataset.service || ''));
  });
  $$('[data-book-branch]').forEach((button) => {
    button.addEventListener('click', () => openBooking(button.dataset.bookBranch || ''));
  });
  $$('[data-dialog-close]').forEach((button) => button.addEventListener('click', () => bookingDialog?.close()));

  if (bookingDialog) {
    bookingDialog.addEventListener('click', (event) => {
      if (event.target === bookingDialog) bookingDialog.close();
    });
    bookingDialog.addEventListener('close', () => {
      resetBooking();
      if (returnFocusTo && typeof returnFocusTo.focus === 'function') returnFocusTo.focus({ preventScroll: true });
    });
  }

  $('#booking-next')?.addEventListener('click', () => {
    if (stepOneError) stepOneError.hidden = true;
    const firstInvalid = [bookingService, bookingBranch].find((field) => field && !field.checkValidity());
    if (firstInvalid) {
      if (stepOneError) stepOneError.hidden = false;
      firstInvalid.reportValidity();
      return;
    }
    if (stepContext) {
      stepContext.textContent = `${bookingService.value} · ${getBranchName(bookingBranch.value)}. Date and time are preferences only; the salon confirms availability.`;
    }
    bookingStepOne.hidden = true;
    bookingStepTwo.hidden = false;
    if (bookingProgress) {
      bookingProgress.innerHTML = '<span class="progress-current">02</span><span class="progress-line"></span><span>02</span><span class="progress-label">Visit preferences</span>';
    }
    $('#booking-step-two-title')?.focus({ preventScroll: true });
  });

  $('#booking-back')?.addEventListener('click', () => {
    bookingStepTwo.hidden = true;
    bookingStepOne.hidden = false;
    if (bookingProgress) {
      bookingProgress.innerHTML = '<span class="progress-current">01</span><span class="progress-line"></span><span>02</span><span class="progress-label">Service &amp; salon</span>';
    }
    $('#booking-step-one-title')?.focus({ preventScroll: true });
  });

  function isIndianMobile(value) {
    const digits = value.replace(/\D/g, '');
    const tenDigits = digits.length === 10 ? digits : (digits.length === 12 && digits.startsWith('91') ? digits.slice(2) : '');
    return /^[6-9]\d{9}$/.test(tenDigits);
  }

  function validateContactFields() {
    if (bookingName) {
      const trimmedName = bookingName.value.trim();
      bookingName.setCustomValidity(trimmedName.length > 0 && trimmedName.length < 2 ? 'Please enter at least two characters.' : '');
    }
    if (bookingPhone) {
      const raw = bookingPhone.value.trim();
      bookingPhone.setCustomValidity(raw && !isIndianMobile(raw) ? 'Enter a valid 10-digit Indian mobile number, with or without +91.' : '');
    }
  }
  bookingName?.addEventListener('input', validateContactFields);
  bookingPhone?.addEventListener('input', validateContactFields);

  bookingForm?.addEventListener('submit', (event) => {
    event.preventDefault();
    validateContactFields();
    const firstInvalid = $$('input, select', bookingStepTwo).find((field) => !field.checkValidity());
    if (firstInvalid) {
      firstInvalid.reportValidity();
      return;
    }

    const date = new Date(`${bookingDate.value}T12:00:00`);
    const dateText = new Intl.DateTimeFormat('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }).format(date);
    const summary = `${bookingName.value.trim()} · ${bookingService.value} · ${getBranchName(bookingBranch.value)} · ${dateText}, ${bookingTime.value}.`;
    requestSummary.textContent = summary;
    bookingForm.hidden = true;
    bookingProgress.hidden = true;
    bookingSuccess.hidden = false;
    $('#booking-success-title')?.focus({ preventScroll: true });
  });

  $('#booking-start-over')?.addEventListener('click', () => {
    resetBooking();
    $('#booking-step-one-title')?.focus({ preventScroll: true });
  });

  // Scroll reveals are progressive enhancement: without IntersectionObserver the content stays visible.
  const revealNodes = $$('.reveal');
  if ('IntersectionObserver' in window && !reduceMotion) {
    const observer = new IntersectionObserver((entries, revealObserver) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          revealObserver.unobserve(entry.target);
        }
      });
    }, { rootMargin: '0px 0px -7% 0px', threshold: 0.06 });
    revealNodes.forEach((node) => observer.observe(node));
  } else {
    revealNodes.forEach((node) => node.classList.add('is-visible'));
  }
  document.documentElement.classList.add('js-enabled');
})();
