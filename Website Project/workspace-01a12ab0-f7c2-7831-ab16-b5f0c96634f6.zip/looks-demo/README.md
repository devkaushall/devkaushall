# Looks Salon — interactive concept demo

A custom, responsive editorial website concept for Looks Salon. This is not the official site and is not connected to a live booking calendar.

## Run locally

From this directory:

```bash
python3 -m http.server 4173 --bind 0.0.0.0
```

Open `http://localhost:4173` in a browser. There are no build steps, package installs or external assets.

## What’s included

- Responsive landing page with original editorial direction and six locally generated image assets.
- Interactive service-category details, inspiration filters and image lightbox.
- Keyboard-operable styling-concept reveal slider (explicitly disclosed as generated concept art, not a real client result).
- Searchable area filter for four selected Delhi branches; branch cards include source-verified details, call links and map links.
- Two-step booking-request preview with required-field checks and Indian mobile-number validation. It stays in page memory, sends/stores nothing and never claims a booking was made. Users can continue to the official booking form or phone number.
- Native disclosure accordion, responsive mobile navigation, focus styles, skip link, reduced-motion support, SEO/social metadata and lazy-loaded supporting imagery.

## Research & accuracy

See [`RESEARCH.md`](RESEARCH.md) for official source links, verified service categories, selected branch details, uncertainty notes, design rationale and the research date. Prices, current offers and branch counts are intentionally not presented in the demo because the official material retrieved was incomplete or inconsistent for those claims.

## Smoke-test checklist

- Open page at desktop and mobile widths; inspect all six local images.
- Navigate by keyboard; check skip link, visible focus, mobile menu, service cards, filters, gallery dialog, range slider, location search, FAQ disclosures and booking dialog.
- Try an empty booking step, an invalid mobile number, a valid demo request, back / start-over / close / reopen and check the repeated disclaimer.
- Test location search with a matching and non-matching query, and both area filters.
- Run `node --check app.js`; request the page, CSS, JavaScript and image files over the local server.
